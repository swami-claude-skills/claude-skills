---
name: "youtube-comments"
description: "Get every comment and reply from a YouTube video with yt-dlp, then flatten the .info.json into threads for analysis or a vibe-dashboard. Use whenever Swami wants a video's comments."
---

# YouTube Comments: full extraction

Get the complete comment tree for a YouTube video, with all replies, and turn it into material for analysis or a vibe-dashboard.

Why this matters: YouTube lazy-loads comments and hides replies behind "show more replies". Manual copy-paste on the FORTH video captured 75 of 474 comments (about 16%), with whole reply chains missing and no way to tell. yt-dlp gets everything in one pass, with thread structure intact, no API key, and no video download.

## Where the extraction runs

Claude's cloud workspace usually cannot reach youtube.com, because its shell network is allowlisted. **Swami runs the yt-dlp command on his Mac and uploads the resulting `.info.json`.** Claude then does all the processing. Do not retry the download from the workspace with curl or another route.

- **A linked computer's shell is not his Mac.** When the chat is linked to his computer, `mcp__remote-devices__device_bash` runs in a sandboxed Linux workspace there that sees only connected folders. It has no ytx, and its network usually can't reach YouTube, so don't run the extraction there. Still ask Swami to run it.
- **Reading his files:** after he runs it, you may ask for access to his `~/yt` folder and read the `.info.json` there instead of having him upload it. If that access is declined or blocked, ask for the upload.
- **Check what's already there.** If `~/yt/<video-id>/` already exists from a transcript run without `-c`, its `.info.json` has no comments. Ask Swami to run `ytx -c "VIDEO_URL"`, which re-downloads it with comments.
- **Never switch to the browser on your own.** The browser fallback at the end of this skill is partial (75 of 474 comments on the FORTH video). Offer it only if Swami can't run yt-dlp or ytx, and only with his OK.

## Step 1: Install yt-dlp (one time, macOS)

Swami's Mac has no Homebrew and only Python 3.9. Use the **standalone `yt-dlp_macos` binary**, which bundles its own interpreter. Do not use the plain `yt-dlp` file, which needs Python 3.10+.

```bash
sudo mkdir -p /usr/local/bin
sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos -o /usr/local/bin/yt-dlp
sudo chmod a+rx /usr/local/bin/yt-dlp
yt-dlp --version
```

- Gatekeeper "unidentified developer" block: `sudo xattr -d com.apple.quarantine /usr/local/bin/yt-dlp`
- Needs macOS 10.15 or newer.
- If it's already installed, check first with `yt-dlp --version`. Update with `sudo yt-dlp -U` if extraction fails, since YouTube changes often break old versions.
- A warning about a missing JavaScript runtime is safe to ignore for a comments-only pull.

## Step 2: Extract

Work in a per-video folder so files don't land loose in the home folder:

```bash
mkdir -p ~/yt/SHORTNAME && cd ~/yt/SHORTNAME
yt-dlp --skip-download --write-comments --write-info-json \
  --extractor-args "youtube:comment_sort=top;max_comments=all,all,all,all,all" \
  "VIDEO_URL"
```

- `--skip-download`: metadata only, no media.
- `comment_sort=top` matches what the YouTube page shows by default. yt-dlp's own default is `new`.
- `max_comments` takes five values: total, parents, replies, replies-per-thread, and depth. **A depth of 1 silently discards every reply.** Always pass `all,all,all,all,all`.
- The run sits quiet for a minute or more while it pages through the thread. That's normal.
- Output is one `TITLE [VIDEOID].info.json` in the current folder, often over 1 MB because it also holds format lists, thumbnails, and similar metadata. Have Swami upload that file.

Give Swami the commands with the real URL and a short folder name already filled in, ready to paste.

**Shortcut with ytx.** Swami's `ytx` tool (from the youtube-transcript skill; it wraps this same yt-dlp) does the extraction in one step: `ytx -c "VIDEO_URL"` in Terminal, or copy the link, double-click **YouTube Transcript** on the Desktop, and answer y for comments. It writes `~/yt/<video-id>/` with the `.info.json` (comments inside) and a ready-made `comments-threaded.txt`; have Swami upload the `.info.json` (or read it from his `~/yt` folder when the chat is linked and he grants access). If ytx reports "yt-dlp failed", update yt-dlp with `sudo yt-dlp -U` and retry.

## On Windows

The steps above are for Swami's Mac. On a Windows 10 or 11 PC the same extraction works with the Windows build of yt-dlp, run in PowerShell. The Mac `ytx` is a Bash script, so Windows has its own PowerShell port, `ytx.ps1` (install and use it as described in the youtube-transcript skill). With it installed, `ytx -c "VIDEO_URL"`, or the Desktop **YouTube Transcript** icon with y for comments, does the extraction in one step into `%USERPROFILE%\yt\<video-id>\`. Without it, use the yt-dlp commands below. Give Windows users the commands in PowerShell form with the real URL and folder name filled in: one line each, no `sudo`, and no backslash line breaks.

1. **Install once:** `winget install yt-dlp.yt-dlp` (it also installs Deno and FFmpeg, which yt-dlp uses with YouTube), then close and reopen PowerShell and check `yt-dlp --version`. Without winget, download `yt-dlp.exe` from https://github.com/yt-dlp/yt-dlp/releases/latest into a folder on the PATH, and put `deno.exe` (version 2.3 or newer, from docs.deno.com) on the PATH or next to `yt-dlp.exe`. If SmartScreen says "Windows protected your PC", choose **More info › Run anyway**.
2. **Extract:**

```powershell
mkdir "$HOME\yt\SHORTNAME" -Force; cd "$HOME\yt\SHORTNAME"
yt-dlp --skip-download --write-comments --write-info-json --extractor-args "youtube:comment_sort=top;max_comments=all,all,all,all,all" "VIDEO_URL"
```

3. **Upload** the `TITLE [VIDEOID].info.json` from `C:\Users\<name>\yt\SHORTNAME`. Steps 3 and 4 below are the same on both systems.

- Update with `winget upgrade yt-dlp.yt-dlp` (winget install) or `yt-dlp -U` (downloaded .exe).
- The `max_comments` depth rule applies here too. yt-dlp uses a JavaScript runtime (Deno) to solve YouTube's challenges; for a comments-only pull a missing-runtime warning has been safe to ignore on the Mac, but if extraction fails, install Deno.

## Step 3: Process the uploaded JSON

The `comments` array is flat. Each entry has `id`, `parent` (`"root"` for top-level, otherwise the parent's `id`), `author`, `text`, `like_count`, `timestamp`, `author_is_uploader`, and `is_pinned`. Video fields live at the top level: `title`, `channel`, `view_count`, `like_count`, `upload_date`, `duration_string`, `comment_count`, and `webpage_url`.

Run this to get stats and a threaded text file:

```python
import json, glob, collections
path = glob.glob('/mnt/user-data/uploads/*info*.json')[0]
d = json.load(open(path, encoding='utf-8'))
c = d.get('comments') or []
ids = {x['id']: x for x in c}
def top_of(x):                      # walk a reply up to its top-level comment
    seen = set()
    while x['parent'] != 'root' and x['parent'] in ids and x['id'] not in seen:
        seen.add(x['id']); x = ids[x['parent']]
    return x
tops = [x for x in c if x['parent'] == 'root']
by = collections.defaultdict(list)  # top-level id -> every reply in its thread, nested ones too
for x in c:
    if x['parent'] != 'root': by[top_of(x)['id']].append(x)
print(d['title'], '|', d.get('channel'), '| views', d.get('view_count'), '| uploaded', d.get('upload_date'))
print('page count', d.get('comment_count'), '| extracted', len(c),
      '| top-level', len(tops), '| replies', len(c) - len(tops),
      '| authors', len({x['author'] for x in c}),
      '| uploader replies', sum(x.get('author_is_uploader', False) for x in c))
def thread_likes(t): return t.get('like_count', 0) + sum(r.get('like_count', 0) for r in by[t['id']])
tops.sort(key=thread_likes, reverse=True)
with open('comments-threaded.txt', 'w', encoding='utf-8') as f:
    for i, t in enumerate(tops, 1):
        f.write(f"\n### THREAD {i}  @{t['author']}  ({t.get('like_count',0)} likes)\n{t['text']}\n")
        for r in sorted(by[t['id']], key=lambda z: z.get('timestamp', 0)):
            up = ' [UPLOADER]' if r.get('author_is_uploader') else ''
            to = ids.get(r['parent'])
            to = f" (reply to @{to['author']})" if to and to['parent'] != 'root' else ''
            f.write(f"    -> @{r['author']}{up}{to}  ({r.get('like_count',0)} likes)\n    {r['text']}\n")
```

Notes:
- **Replies to replies:** a reply to a reply has the earlier reply's `id` as its `parent`, not the thread's. Grouping by `parent` alone drops it silently (ytx 1.2.0 did this; seen on Brad Tallis's surfacing video, Nov 2026). The code above walks every reply up to its top-level comment, so all replies land in their thread. Check that the replies printed equal the replies counted.
- The page's comment count rarely matches exactly, because YouTube's counter drifts as comments are held or removed. Report both numbers and don't chase the gap.
- Upload filenames may have had spaces and brackets replaced with underscores. The glob handles that.
- Comment permalink: `https://www.youtube.com/watch?v=VIDEOID&lc=COMMENTID`.
- Read `comments-threaded.txt` in chunks for long threads before deciding on sections.

## Step 4: Hand off

- **Dashboard (the usual goal):** load the `vibe-dashboard` skill and build from the threaded data. Attribute ideas to specific `@handles` throughout rather than paraphrasing anonymously; that is Swami's preference. Group sections by theme, not by comment order. Add a Method/data-provenance section that states the extraction command, counts, and date pulled. Follow the vibe-dashboard skill's own workflow in full (it adds the Search section, Mind Map, Glossary, and audio overview, and runs its privacy check before publishing) rather than rules remembered here, since that skill keeps changing.
- **Table or sentiment view:** one row per comment with number, @handle linked to the comment permalink, text, likes, and a sentiment tag (positive, humor, mixed, neutral, question, skeptical, negative).
- **Raw export:** send `comments-threaded.txt`, or build a CSV/XLSX with the xlsx skill if asked.

## Fallback when yt-dlp is not an option

Only with Swami's OK, and only when neither yt-dlp nor ytx can run on his computer. Open the video, scroll to comments, and paste this in the browser console (F12). Let it run a few minutes, then select all and copy. Reply nesting gets flattened, so treat the result as partial.

```js
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 400; i++) {
    window.scrollTo(0, document.documentElement.scrollHeight);
    document.querySelectorAll(
      'ytd-continuation-item-renderer #button, #more-replies button, ' +
      'ytd-comment-replies-renderer #more-replies, tp-yt-paper-button#more'
    ).forEach(b => b.click());
    await sleep(1200);
  }
  console.log(document.querySelectorAll('ytd-comment-thread-renderer').length + ' threads loaded');
})();
```