---
name: "youtube-transcript"
description: "Get a YouTube video's transcript, chapters (timestamp links) and optionally comments via Swami's ytx tool, then summarize or build a vibe-dashboard. Use whenever Swami shares a YouTube link and wants its transcript, chapters, summary or dashboard."
---

# YouTube Transcript → Chapters (→ Vibe Dashboard)

Turn a YouTube link into a timestamped transcript, a chapter list where every time is a clickable link, and optionally the full comment tree, then summarize it or build a vibe-dashboard.

## The tool: `ytx` (on Swami's Mac)

Swami has `ytx` installed at `/usr/local/bin/ytx`. It wraps yt-dlp and does all the cleanup. The current version is **1.2.0**, and both scripts ship inside this skill: `scripts/ytx` (Mac) and `scripts/ytx.ps1` (Windows). When ytx needs a fix, edit those files, raise `VERSION`, and rebuild the skill zip so the repo copy stays the source of truth.

ytx 1.2.0 first downloads only the video info, then asks YouTube for **one** caption track: the creator's English subtitles if there are any, otherwise the original auto track `en-orig`, otherwise `en`. If YouTube refuses one, ytx prints the error and tries the next. (Asking for every English track at once, as 1.1.0 did, triggered "HTTP Error 429" on the extra `en` track in Nov 2026.)

| Command | Result |
|---|---|
| `ytx URL` | `~/yt/<video-id>/` with `transcript.md`, `transcript.txt`, `chapters.txt`, `*.info.json`, `*.vtt` |
| `ytx -c URL` | the same, plus `comments-threaded.txt` and the comments inside the `.info.json` |
| `ytx -p` | uses the link on the clipboard |
| `ytx -n` | don't open the folder in Finder afterwards |
| `ytx --make-launcher` | (re)creates the Desktop double-click icon |

He also has a Desktop icon, **YouTube Transcript.command**. He copies a video link, double-clicks the icon, answers y/N for comments, and the folder opens.

- `transcript.md`: title, channel, date, length, chapter list, then ~20-second paragraphs grouped under chapter headings. Every `[m:ss]` is a link to `https://youtu.be/<id>?t=<seconds>`.
- `transcript.txt`: the same, plain, with `[m:ss]` stamps.
- `chapters.txt`: `m:ss  title  link` per chapter. It is absent when the video has no chapters.

## Where it runs: pick the first that works

1. **Always: Swami runs ytx.** Ask him to **copy the link and double-click "YouTube Transcript" on his Desktop** (answer y for comments), or run `ytx URL` in Terminal (`ytx -c URL` for comments). Give him the exact link to copy. Never send him a multi-line Terminal recipe for this; that is what ytx replaced.
2. **Getting the files:** he uploads `transcript.md` plus the `.info.json`, or zips the `~/yt/<id>` folder and uploads it. When the chat is linked to his computer, you may instead ask for access to his `~/yt` folder and read the files there; if that access is declined or blocked, ask for the upload.
   - **A linked computer's shell is not his Mac.** `mcp__remote-devices__device_bash` runs in a sandboxed Linux workspace on his computer that sees only connected folders. It has no ytx, and its network usually can't reach YouTube, so never try to run ytx or yt-dlp there.
   - **Files already in `~/yt/<id>/` may be incomplete.** An earlier run without `-c` has no comments. If what was asked for is missing, ask Swami to run ytx again with the right option rather than looking for another route.
3. **Don't** download from Claude's cloud workspace (its shell can't reach youtube.com), and **don't** use the Claude app's browser for the transcript. In Oct 2026, YouTube refused it there: the transcript panel stays empty, `get_transcript` returns 400, and the caption `baseUrl` fetch returns 0 bytes, even with a 1400px viewport. The browser is fine for chapters and title only (the `engagement-panel-macro-markers-description-chapters` panel), so use it just for that if ytx is unavailable. Never switch to the browser (for anything, comments included) without asking Swami first; the browser route for comments is partial (see the youtube-comments skill).

## First-time setup (only if `ytx` is missing or older than 1.2.0)

`ytx` needs the standalone yt-dlp at `/usr/local/bin/yt-dlp` (already installed; see the youtube-comments skill for that install) and `python3`. The script is in this skill's zip at `youtube-transcript/scripts/ytx`; download `youtube-transcript.zip` from the claude-skills repo (https://github.com/swami-claude-skills/claude-skills/raw/main/zips/youtube-transcript.zip) and unzip it in Downloads (Safari does this automatically). Then run:

```bash
sudo cp ~/Downloads/youtube-transcript/scripts/ytx /usr/local/bin/ytx && sudo chmod a+rx /usr/local/bin/ytx && sudo xattr -d com.apple.quarantine /usr/local/bin/ytx 2>/dev/null; ytx -v && ytx --make-launcher
```

It should print `ytx 1.2.0`. If Claude hands over a single new `ytx` file in chat instead, the same command works with `~/Downloads/ytx` as the source. To show Claude the installed copy, run `cp /usr/local/bin/ytx ~/Desktop/ytx.txt` and upload `ytx.txt`.

## On Windows: `ytx.ps1`

Windows users run `ytx.ps1` (in this skill at `scripts/ytx.ps1`), a PowerShell port of ytx 1.2.0 with the same commands, the same one-track caption download and the same output files, and no Python needed. It needs yt-dlp: `winget install yt-dlp.yt-dlp`, which also installs Deno and FFmpeg.

- **Install once:** unzip `youtube-transcript.zip` in Downloads and copy `youtube-transcript\scripts\ytx.ps1` to Downloads, then in PowerShell run `powershell -NoProfile -ExecutionPolicy Bypass -File "$HOME\Downloads\ytx.ps1" -Install`. It copies itself to `%LOCALAPPDATA%\ytx\`, adds a `ytx` command to the user PATH (no execution-policy change), and puts a **YouTube Transcript** icon on the Desktop. Close and reopen PowerShell, then run `ytx -v` (prints `ytx 1.2.0-win`) and `ytx -SelfTest` (every line PASS; it parses built-in sample caption files offline and compares the result with what the Mac ytx 1.2.0 produces, then checks that yt-dlp is installed).
- **Use:** the same as on the Mac. Copy a link and double-click **YouTube Transcript**, or run `ytx URL`, `ytx -c URL`, `ytx -p` (clipboard), or `ytx -n URL` (don't open the folder). Output goes to `%USERPROFILE%\yt\<video-id>\` and opens in File Explorer. `ytx -MakeLauncher` recreates the icon; `ytx -h` shows help.
- **Links containing `&`** (for example `watch?v=…&t=30s`): the `ytx` command runs through a small `.cmd` file, and Windows may cut the link at the `&`. The video ID comes before the `&`, so ytx still gets the right video, but a stray error line may follow. Use the Desktop icon, `ytx -p`, or the youtu.be share link to avoid it.
- **If the self-test shows FAIL,** have them upload the files from the folder it names.
- ytx.ps1 1.2.0 was rebuilt from the Mac script (the 1.1.0 Windows file was lost) and has never been run on a real Windows PC, or under PowerShell at all; treat the first run as a test and ask for a screenshot of `ytx -SelfTest`.

## Troubleshooting

- **"yt-dlp failed"**: have him run `sudo yt-dlp -U` (YouTube changes break old versions), then retry.
- **"HTTP Error 429: Too Many Requests"** on captions: check `ytx -v`. Below 1.2.0, install 1.2.0 (see First-time setup). On 1.2.0 it means YouTube refused every track; wait 15–30 minutes and run ytx again. If you're on 1.1.0 and can't update yet, this one-off command downloads just `en-orig`: `yt-dlp --skip-download --write-auto-subs --sub-langs en-orig --sub-format vtt --write-info-json -o "$HOME/yt/%(id)s/%(title)s [%(id)s].%(ext)s" URL`.
- **Typing in Terminal:** commands go in Terminal, not in the chat, and only the command itself (not words like "run"). ytx with the full link doesn't ask about comments; only the Desktop icon asks.
- **"No supported JavaScript runtime" warning**: harmless for captions, chapters and comments.
- **"no English captions found"**: the creator disabled captions, or the video has none yet (new uploads can take hours). Say so; don't guess at content.
- Never suggest `find ~` to locate files: it scans the whole home folder silently for minutes and can stall on macOS privacy prompts. Everything ytx makes is in `~/yt/<video-id>/`.
- Auto-captions have garbled spots and cut-off phrases. Flag any you quote from, and don't treat them as what the speaker actually said.

## Using the output

Read the `.info.json` first for `title`, `channel`, `uploader_id`, `upload_date`, `duration_string`, `description` and `chapters` (`start_time`, `title`). Then read `transcript.md`.

**Whose video it is decides how much text to reproduce.**
- **Swami's own videos** (his channel, or a recording of his Zoom sessions): a full verbatim transcript is fine, including a dashboard Source Document (Verbatim) section.
- **Anyone else's video**: deliver the chapter list with timestamp links plus section-by-section summaries **in your own words**. No full transcript, no verbatim section, and only short quotes where the exact wording matters. Swami keeps the full text in his local `transcript.md`, so say that rather than reproducing it.

### Chat answer (default when he just asks for transcript and chapters)
- Header line: title, channel, date, length.
- One paragraph per chapter: `**[m:ss](https://youtu.be/<id>?t=<s>) Chapter title.**` then a 1–3 sentence summary of what happens. Link times inside summaries the same way.
- If there are no chapters, make your own sections from topic shifts in the transcript and say that you did.
- End by offering the vibe-dashboard.

### Vibe dashboard (when asked)
Load the **vibe-dashboard** skill and follow its current version exactly: its design system, template, kicker, Dashboard Summary as section 01, Search section, Mind Map, Glossary, References, topic IDs, audio overview, privacy check, footer and delivery all apply. Where this section and vibe-dashboard seem to differ, vibe-dashboard wins. Build with a Python script, never hand-typed, so the page can be regenerated.

Work in vibe-dashboard's order: fill the template, apply its table-fit patch, run its `scripts/search_patch.py` (it inserts **Search** as section 02 and renumbers every section after it, so number the content sections from 02 as usual), run its Mind Map patch, write and record the audio overview with the noun/verb stress audit, run the privacy check, then publish the page from the working directory as a private artifact with no capabilities.

Video-specific mapping:
- Kicker `VIDEO BREAKDOWN`. Byline: channel/creator, then a linked "YouTube · length · date".
- Sections, with their final numbers after the patches: 01 Dashboard Summary → 02 Search (added by `search_patch.py`) → 03 Video Overview & Chapter Index (a `.resource` card for the video plus a table Topic / Time / Chapter / What happens, with the Time cell an external timestamp link) → topic sections grouping related chapters, each with its own category → a "Gotcha/Caveat" section if the video has one → an optional "Takeaways" section that says in its first sentence it is Claude's own analysis → Mind Map (added by the Mind Map patch) → Glossary → References → Source Document (Verbatim), only for Swami's own videos (see above).
- **Glossary (required):** 10–30 terms from the video: its tools, products, terms of art, and acronyms, in vibe-dashboard's Glossary format (Term / Topic / Definition / Appears in / Qty, color-coded Topic column). Every term's matcher must hit the page at least once.
- **References:** vibe-dashboard's References format; at least the video itself, plus any links from its description that the page cites.
- With comments (`-c`): add the youtube-comments skill's sections (threads attributed to `@handles`, comment permalinks `https://www.youtube.com/watch?v=<id>&lc=<commentid>`), placed before the Mind Map.
- Timestamp links are external `target="_blank"` links. That's allowed; only bare `#id` anchors are banned.
- Verify headlessly before publishing: no console errors other than the sandbox Google Fonts failure, no `{{…}}` left, the category colors applied, every row of the section 01 summary table linked (including Search and Mind Map), no Glossary term with a count of 0, the Mind Map opening fitted, the audio player under the byline, and a clean privacy check.