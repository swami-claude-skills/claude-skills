# ytx.ps1 - YouTube transcript + chapters (+ comments) in one command. Windows port of ytx.
# Vibe Coding: Swami · AI: Claude
#
#   ytx URL          transcript + chapters          -> %USERPROFILE%\yt\<video-id>\
#   ytx -c URL       same, plus every comment/reply -> comments-threaded.txt
#   ytx -p           use the YouTube link currently on the clipboard
#   ytx -n URL       don't open the folder afterwards
#   ytx -Install     install: copy to %LOCALAPPDATA%\ytx, add the ytx command, make the Desktop icon
#   ytx -MakeLauncher   (re)make the "YouTube Transcript" Desktop icon
#   ytx -SelfTest    check the caption parser offline (every line should say PASS)
#   ytx -v / -h      version / help
#
# Output folder: transcript.md, transcript.txt, chapters.txt (if the video has chapters),
# comments-threaded.txt (with -c), and the raw yt-dlp *.info.json and *.vtt files.
#
# Needs yt-dlp:  winget install yt-dlp.yt-dlp   (also installs Deno and FFmpeg)
#
# 1.2.0  asks YouTube for ONE caption track (creator English subs, else the original
#        auto track en-orig, else en), which avoids "HTTP Error 429"; correct paragraph
#        times (start at 0:00); keeps one-word caption lines.
#        UNTESTED on a real Windows PC - treat the first run as a test.

$VERSION = '1.2.0-win'
$ErrorActionPreference = 'Continue'
$UTF8 = New-Object System.Text.UTF8Encoding $false
$HOME_DIR = $env:USERPROFILE
$APP_DIR = Join-Path $env:LOCALAPPDATA 'ytx'

function Write-Utf8($path, $text) { [System.IO.File]::WriteAllText($path, $text, $UTF8) }

function MmSs([int]$s) {
    $h = [math]::Floor($s / 3600); $r = $s % 3600; $m = [math]::Floor($r / 60); $sec = $r % 60
    if ($h -gt 0) { return ('{0}:{1:00}:{2:00}' -f $h, $m, $sec) }
    return ('{0}:{1:00}' -f $m, $sec)
}

function Secs($h, $m, $s) {
    $hh = 0; if ($h) { $hh = [int]$h }
    return $hh * 3600 + [int]$m * 60 + [double]::Parse($s, [Globalization.CultureInfo]::InvariantCulture)
}

# ---- parse a .vtt into (start seconds, text) lines; handles YouTube's rolling auto captions
function Convert-Vtt([string]$path) {
    $out = New-Object System.Collections.ArrayList
    $raw = [System.IO.File]::ReadAllText($path, $UTF8).Replace("`r", '')
    $rolling = $raw.Contains('<c>')
    $last = ''
    foreach ($cue in [regex]::Split($raw, '\n[ \t]*\n(?=[^\n]*-->|\d+\n)')) {
        $rows = $cue -split "`n"
        $k = -1
        for ($n = 0; $n -lt $rows.Count; $n++) { if ($rows[$n].Contains('-->')) { $k = $n; break } }
        if ($k -lt 0) { continue }
        $m = [regex]::Match($rows[$k], '^\s*(?:(\d+):)?(\d+):([\d.]+)\s*-->\s*(?:(\d+):)?(\d+):([\d.]+)')
        if (-not $m.Success) { continue }
        $t0 = Secs $m.Groups[1].Value $m.Groups[2].Value $m.Groups[3].Value
        $t1 = Secs $m.Groups[4].Value $m.Groups[5].Value $m.Groups[6].Value
        $text = @($rows[($k + 1)..($rows.Count)] | Where-Object { $_ -and $_.Trim() })
        if ($k + 1 -ge $rows.Count) { $text = @() }
        if ($rolling) {
            # a real cue is [previous line, new line]; the 10 ms cues only repeat text
            if (($t1 - $t0) -lt 0.05 -or $text.Count -eq 0) { continue }
            if ($rows[-1].Trim()) { $text = @($rows[-1]) } else { $text = @($text[-1]) }
        }
        $s = [regex]::Replace(($text -join ' '), '<[^>]+>', '')
        $s = [System.Net.WebUtility]::HtmlDecode($s).Trim()
        $s = [regex]::Replace($s, '\s+', ' ')
        if (-not $s -or $s -eq $last) { continue }
        $last = $s
        [void]$out.Add(@([int][math]::Floor($t0), $s))
    }
    return , $out
}

# ---- group lines into ~20 s paragraphs, always breaking at a chapter start
function Group-Paras($lines, $starts) {
    $paras = New-Object System.Collections.ArrayList
    $buf = New-Object System.Collections.ArrayList; $st = $null
    foreach ($ln in $lines) {
        $t = $ln[0]
        if ($buf.Count -gt 0) {
            $cross = $false
            foreach ($c in $starts) { if ($st -lt $c -and $c -le $t) { $cross = $true } }
            if ($cross) { [void]$paras.Add(@($st, ($buf -join ' '))); $buf.Clear(); $st = $null }
        }
        if ($null -eq $st) { $st = $t }
        [void]$buf.Add($ln[1])
        if ($t - $st -ge 20) { [void]$paras.Add(@($st, ($buf -join ' '))); $buf.Clear(); $st = $null }
    }
    if ($buf.Count -gt 0) { [void]$paras.Add(@($st, ($buf -join ' '))) }
    return , $paras
}

function Show-Help { Get-Content -LiteralPath $PSCommandPath -TotalCount 22 | Select-Object -Skip 1 | ForEach-Object { $_ -replace '^# ?', '' } }

function Make-Launcher {
    $desk = [Environment]::GetFolderPath('Desktop')
    $l = Join-Path $desk 'YouTube Transcript.cmd'
    $body = @(
        '@echo off',
        'title YouTube Transcript (ytx)',
        'echo YouTube Transcript (ytx)',
        'set "A="',
        'set /p A=Also download all comments? (y/N) ',
        ('if /i "%A%"=="y" (call "' + (Join-Path $APP_DIR 'ytx.cmd') + '" -c -p) else (call "' + (Join-Path $APP_DIR 'ytx.cmd') + '" -p)'),
        'echo.',
        'pause'
    ) -join "`r`n"
    [System.IO.File]::WriteAllText($l, $body + "`r`n", (New-Object System.Text.ASCIIEncoding))
    Write-Host "Made: $l"
    Write-Host "Use it: copy a YouTube link, then double-click 'YouTube Transcript' on your Desktop."
}

function Install-Ytx {
    New-Item -ItemType Directory -Force -Path $APP_DIR | Out-Null
    Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $APP_DIR 'ytx.ps1') -Force
    $cmd = '@powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ytx.ps1" %*'
    [System.IO.File]::WriteAllText((Join-Path $APP_DIR 'ytx.cmd'), $cmd + "`r`n", (New-Object System.Text.ASCIIEncoding))
    $p = [Environment]::GetEnvironmentVariable('Path', 'User'); if (-not $p) { $p = '' }
    if (-not (($p -split ';') -contains $APP_DIR)) {
        [Environment]::SetEnvironmentVariable('Path', ($p.TrimEnd(';') + ';' + $APP_DIR).TrimStart(';'), 'User')
        Write-Host "Added $APP_DIR to your PATH."
    }
    Make-Launcher
    Write-Host "Installed ytx $VERSION. Close and reopen PowerShell, then run: ytx -v   and   ytx -SelfTest"
    if (-not (Get-Command yt-dlp -ErrorAction SilentlyContinue)) {
        Write-Host "yt-dlp is not installed yet. Run:  winget install yt-dlp.yt-dlp"
    }
}

# ---- offline check: expected results come from the Mac ytx 1.2.0 on the same samples
function Self-Test {
    $tmp = Join-Path ([IO.Path]::GetTempPath()) ('ytx-selftest-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tmp | Out-Null
    $auto = "WEBVTT`nKind: captions`nLanguage: en`n`n" +
        "00:00:00.800 --> 00:00:03.190 align:start position:0%`n `nWe<00:00:00.960><c> can</c><00:00:01.160><c> search</c><00:00:01.400><c> for</c>`n`n" +
        "00:00:03.190 --> 00:00:03.200 align:start position:0%`nWe can search for`n `n`n" +
        "00:00:03.200 --> 00:00:04.630 align:start position:0%`nWe can search for`nAutodesk`n`n" +
        "00:00:04.630 --> 00:00:04.640 align:start position:0%`nAutodesk`n `n`n" +
        "00:00:24.640 --> 00:00:26.510 align:start position:0%`nAutodesk`ntom<00:00:25.000><c> &amp;</c><00:00:25.500><c> jerry</c>`n`n" +
        "00:00:26.510 --> 00:00:26.520 align:start position:0%`ntom & jerry`n `n`n" +
        "00:00:26.520 --> 00:00:28.000 align:start position:0%`ntom & jerry`nPeace.`n"
    $manual = "WEBVTT`nKind: captions`nLanguage: en`n`n1`n00:00:00.000 --> 00:00:02.500`nHello &amp; welcome`nto the show.`n`n2`n00:00:02.500 --> 00:00:25.000`nToday: Fusion.`n`n3`n00:00:25.000 --> 00:00:27.000`nBye.`n"
    Write-Utf8 (Join-Path $tmp 'a.vtt') $auto
    Write-Utf8 (Join-Path $tmp 'm.vtt') ($manual.Replace("`n", "`r`n"))
    $ok = $true
    $checks = @(
        @('auto captions', (Join-Path $tmp 'a.vtt'), @('0|We can search for Autodesk tom & jerry', '26|Peace.')),
        @('creator subtitles', (Join-Path $tmp 'm.vtt'), @('0|Hello & welcome to the show. Today: Fusion. Bye.'))
    )
    foreach ($c in $checks) {
        $got = @((Group-Paras (Convert-Vtt $c[1]) @()) | ForEach-Object { '{0}|{1}' -f $_[0], $_[1] })
        $want = $c[2]
        if (($got -join "`n") -eq ($want -join "`n")) { Write-Host "PASS  $($c[0])" }
        else { $ok = $false; Write-Host "FAIL  $($c[0])"; Write-Host "   want: $($want -join ' / ')"; Write-Host "   got:  $($got -join ' / ')" }
    }
    $t = @((MmSs 0), (MmSs 65), (MmSs 3725)) -join ' '
    if ($t -eq '0:00 1:05 1:02:05') { Write-Host 'PASS  time format' } else { $ok = $false; Write-Host "FAIL  time format: $t" }
    if (Get-Command yt-dlp -ErrorAction SilentlyContinue) { Write-Host 'PASS  yt-dlp found' } else { $ok = $false; Write-Host 'FAIL  yt-dlp not found (winget install yt-dlp.yt-dlp)' }
    Remove-Item -LiteralPath $tmp -Recurse -Force
    if ($ok) { Write-Host 'All checks passed.'; exit 0 } else { Write-Host "Some checks failed. Send the lines above to Claude."; exit 1 }
}

# ---------------- arguments
$COMMENTS = $false; $OPEN = $true; $PASTE = $false; $URL = $null
foreach ($a in $args) {
    switch -Regex ($a) {
        '^(-c|--comments)$' { $COMMENTS = $true; continue }
        '^(-n|--no-open)$' { $OPEN = $false; continue }
        '^(-p|--paste)$' { $PASTE = $true; continue }
        '^(-v|--version)$' { Write-Host "ytx $VERSION"; exit 0 }
        '^(-h|--help|-\?)$' { Show-Help; exit 0 }
        '^-Install$' { Install-Ytx; exit 0 }
        '^(-MakeLauncher|--make-launcher)$' { Make-Launcher; exit 0 }
        '^-SelfTest$' { Self-Test }
        default { if (-not $URL) { $URL = $a } }
    }
}
if ($PASTE) { $URL = (Get-Clipboard -Raw); if ($URL) { $URL = $URL.Trim() } }
if (-not $URL) {
    if ($PASTE) { Write-Host 'ytx: the clipboard is empty. Copy a YouTube link first.'; exit 1 }
    Write-Host 'usage: ytx [-c] [-n] YOUTUBE_URL   or   ytx -p   (ytx -h for help)'; exit 1
}
if (-not (Get-Command yt-dlp -ErrorAction SilentlyContinue)) { Write-Host 'ytx: yt-dlp not found. Run:  winget install yt-dlp.yt-dlp'; exit 1 }

$m = [regex]::Match($URL, '(?:v=|youtu\.be/|shorts/|live/|embed/)([A-Za-z0-9_-]{11})')
if ($m.Success) { $ID = $m.Groups[1].Value }
elseif ($URL -match '^[A-Za-z0-9_-]{11}$') { $ID = $URL }
else {
    $short = $URL; if ($short.Length -gt 120) { $short = $short.Substring(0, 120) }
    Write-Host "ytx: that doesn't look like a YouTube link: $short"
    if ($PASTE) { Write-Host "     Copy the video's link (Share -> Copy, or the address bar) and try again." }
    exit 1
}

$DIR = Join-Path (Join-Path $HOME_DIR 'yt') $ID
New-Item -ItemType Directory -Force -Path $DIR | Out-Null
Set-Location -LiteralPath $DIR
Write-Host "ytx $VERSION -> $DIR"
Get-ChildItem -LiteralPath $DIR -File | Where-Object { $_.Name -like '*.vtt' -or $_.Name -like '*.info.json' } | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force }

$TEMPLATE = '%(title)s [%(id)s].%(ext)s'
$ytArgs = @('--skip-download', '--write-info-json', '--no-warnings', '-o', $TEMPLATE)
if ($COMMENTS) {
    $ytArgs += @('--write-comments', '--extractor-args', 'youtube:comment_sort=top;max_comments=all,all,all,all,all')
    Write-Host 'Downloading video info and comments (comments can take a minute or more)...'
} else { Write-Host 'Downloading video info and chapters...' }
& yt-dlp @ytArgs "https://www.youtube.com/watch?v=$ID"
if ($LASTEXITCODE -ne 0) { Write-Host "ytx: yt-dlp failed. Try 'yt-dlp -U' (or 'winget upgrade yt-dlp.yt-dlp'), then run ytx again."; exit 1 }

$infoFile = Get-ChildItem -LiteralPath $DIR -File | Where-Object { $_.Name -like '*.info.json' } | Select-Object -First 1
$info = $null
if ($infoFile) { $info = [System.IO.File]::ReadAllText($infoFile.FullName, $UTF8) | ConvertFrom-Json }

# ---- pick caption tracks to try, best first: creator English subs, then auto en-orig, then auto en
$cands = New-Object System.Collections.ArrayList
if ($info) {
    $subs = @()
    if ($info.subtitles) { $subs = @($info.subtitles.PSObject.Properties.Name | Where-Object { ($_ -split '-')[0] -eq 'en' }) }
    $subs = @($subs | Sort-Object @{ Expression = { $_ -ne 'en' } }, @{ Expression = { $_ } })
    foreach ($k in $subs) { [void]$cands.Add(@('subs', $k)) }
    if ($info.automatic_captions) {
        $autoNames = @($info.automatic_captions.PSObject.Properties.Name)
        foreach ($k in @('en-orig', 'en')) { if ($autoNames -contains $k) { [void]$cands.Add(@('auto', $k)) } }
    }
}
$LANG = ''
if ($cands.Count -gt 0) {
    Write-Host 'Downloading captions...'
    foreach ($c in $cands) {
        $flag = '--write-auto-subs'; if ($c[0] -eq 'subs') { $flag = '--write-subs' }
        $err = & yt-dlp --load-info-json $infoFile.FullName --skip-download $flag --sub-langs $c[1] --sub-format vtt --no-warnings -o $TEMPLATE 2>&1 | Out-String
        $got = Get-ChildItem -LiteralPath $DIR -File | Where-Object { $_.Name -like ('*.' + $c[1] + '.vtt') }
        if ($LASTEXITCODE -eq 0 -and $got) { $LANG = $c[1]; Write-Host "  captions: $($c[1]) ($($c[0]))"; break }
        $line = ($err -split "`n" | Where-Object { $_ -match 'ERROR' } | Select-Object -First 1)
        Write-Host "  $($c[1]) ($($c[0])) failed: $line"
    }
    if (-not $LANG) { Write-Host 'ytx: YouTube refused every caption track. If it says 429, wait 15-30 minutes and run ytx again.' }
}

# ---- build transcript.md / transcript.txt / chapters.txt
$vid = $ID; $url = "https://youtu.be/$vid"
$title = $vid; if ($info -and $info.title) { $title = $info.title }
function Lnk([int]$s) { return "[$(MmSs $s)]($url`?t=$s)" }

$chapters = New-Object System.Collections.ArrayList
if ($info -and $info.chapters) { foreach ($c in $info.chapters) { [void]$chapters.Add(@([int][math]::Floor([double]$c.start_time), ([string]$c.title).Trim())) } }

$vtts = @(Get-ChildItem -LiteralPath $DIR -File | Where-Object { $_.Name -like '*.vtt' } | Sort-Object Name)
$pick = $null
$pats = @(); if ($LANG) { $pats += ".$LANG.vtt" }; $pats += @('.en.vtt', '.en-orig.vtt', '.en-US.vtt', '.en-GB.vtt')
foreach ($p in $pats) { $pick = $vtts | Where-Object { $_.Name.EndsWith($p) } | Select-Object -First 1; if ($pick) { break } }
if (-not $pick -and $vtts.Count -gt 0) { $pick = $vtts[0] }

$lines = @(); if ($pick) { $lines = Convert-Vtt $pick.FullName }
$starts = @($chapters | ForEach-Object { $_[0] })
$paras = Group-Paras $lines $starts

$pub = '- Published: '
if ($info -and $info.upload_date) { $u = [string]$info.upload_date; $pub = "- Published: $($u.Substring(0,4))-$($u.Substring(4,2))-$($u.Substring(6,2))" }
$capName = 'none found'; if ($pick) { $capName = $pick.Name }
$chan = ''; $dur = ''; if ($info) { $chan = $info.channel; $dur = $info.duration_string }
$head = @("# $title", '', "- Channel: $chan", $pub, "- Length: $dur", "- Video: $url", "- Captions: $capName", '')
$md = New-Object System.Collections.ArrayList; $txt = New-Object System.Collections.ArrayList
foreach ($h in $head) { [void]$md.Add($h); if ($h.StartsWith('# ')) { [void]$txt.Add($h.Substring(2)) } else { [void]$txt.Add($h) } }
if ($chapters.Count -gt 0) {
    [void]$md.Add('## Chapters'); [void]$md.Add('')
    foreach ($c in $chapters) { [void]$md.Add("- $(Lnk $c[0]) $($c[1])") }
    [void]$md.Add(''); [void]$txt.Add('CHAPTERS')
    foreach ($c in $chapters) { [void]$txt.Add("[$(MmSs $c[0])] $($c[1])") }
    [void]$txt.Add('')
    $ch = @($chapters | ForEach-Object { "$(MmSs $_[0])  $($_[1])  $url`?t=$($_[0])" }) -join "`n"
    Write-Utf8 (Join-Path $DIR 'chapters.txt') "$title`n$url`n`n$ch`n"
}
[void]$md.Add('## Transcript'); [void]$md.Add(''); [void]$txt.Add('TRANSCRIPT'); [void]$txt.Add('')
$cur = $null
foreach ($p in $paras) {
    $t = $p[0]; $chap = $null
    foreach ($c in $chapters) { if ($c[0] -le $t) { $chap = $c } }
    if ($chapters.Count -gt 0 -and $chap -and -not ($cur -and $cur[0] -eq $chap[0])) {
        $cur = $chap
        [void]$md.Add("### $(Lnk $chap[0]) $($chap[1])"); [void]$md.Add('')
        [void]$txt.Add("--- $($chap[1]) ---"); [void]$txt.Add('')
    }
    [void]$md.Add("$(Lnk $t) $($p[1])"); [void]$md.Add('')
    [void]$txt.Add("[$(MmSs $t)] $($p[1])"); [void]$txt.Add('')
}
if ($paras.Count -eq 0) {
    [void]$md.Add('_No English captions were found for this video._'); [void]$md.Add('')
    [void]$txt.Add('No English captions were found for this video.'); [void]$txt.Add('')
}
Write-Utf8 (Join-Path $DIR 'transcript.md') ($md -join "`n")
Write-Utf8 (Join-Path $DIR 'transcript.txt') ($txt -join "`n")

# ---- comments (only present when run with -c)
$cm = @(); if ($info -and $info.comments) { $cm = @($info.comments) }
if ($cm.Count -gt 0) {
    $by = @{}
    foreach ($x in $cm) { $par = 'root'; if ($x.parent) { $par = [string]$x.parent }; if (-not $by.ContainsKey($par)) { $by[$par] = New-Object System.Collections.ArrayList }; [void]$by[$par].Add($x) }
    $tops = @(); if ($by.ContainsKey('root')) { $tops = @($by['root']) }
    function Kids($id) { if ($by.ContainsKey([string]$id)) { return @($by[[string]$id]) } return @() }
    $tops = @($tops | Sort-Object -Descending { [int]$_.like_count + ((Kids $_.id | Measure-Object -Property like_count -Sum).Sum) })
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append("$title`n$url`npage count $($info.comment_count) | extracted $($cm.Count) | top-level $($tops.Count) | replies $($cm.Count - $tops.Count)`n")
    $i = 0
    foreach ($t in $tops) {
        $i++
        [void]$sb.Append("`n### THREAD $i  @$(([string]$t.author).TrimStart('@'))  ($([int]$t.like_count) likes)`n$($t.text)`n")
        foreach ($r in @(Kids $t.id | Sort-Object { [long]$_.timestamp })) {
            $up = ''; if ($r.author_is_uploader) { $up = ' [UPLOADER]' }
            [void]$sb.Append("    -> @$(([string]$r.author).TrimStart('@'))$up  ($([int]$r.like_count) likes)`n    $($r.text)`n")
        }
    }
    Write-Utf8 (Join-Path $DIR 'comments-threaded.txt') $sb.ToString()
}

Write-Host ''
Write-Host "OK  $title"
$sum = "  $($chapters.Count) chapters · $($paras.Count) transcript paragraphs"; if ($cm.Count -gt 0) { $sum += " · $($cm.Count) comments" }
Write-Host $sum
$files = '  transcript.md · transcript.txt'; if ($chapters.Count -gt 0) { $files += ' · chapters.txt' }; if ($cm.Count -gt 0) { $files += ' · comments-threaded.txt' }
Write-Host $files
if (-not $pick) { Write-Host '  WARNING: no English captions found for this video' }
if ($OPEN) { Start-Process explorer.exe $DIR }
exit 0
