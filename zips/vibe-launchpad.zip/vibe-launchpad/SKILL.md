---
name: vibe-launchpad
description: 'Build a "Vibe Coding" launch pad — a single self-contained dark-theme .html page whose whole job is to be a set of big clickable tiles that link OUT to other pages (Claude artifacts, Gemini/NotebookLM shares, Facebook/community posts, Zoom recordings, docs, live sites). Same locked #0d0d0f/#00e5ff design system as vibe-dashboard, but stripped to header + launch tiles + footer — no collapsible sections, no TOC, no search. Use this WHENEVER Swami supplies one or more web links and wants a "launch page," "launch pad," "hub," "index page," "landing page," "link page," or "portal" — i.e. a page that is mostly links. The user supplies the URLs; Claude writes all the tile text (title, badge, one-line description) and decides grouping, accent color, and layout. If the request is to turn CONTENT into a browsable page (a post, session, files, a concept), use vibe-dashboard instead — this skill is for the case where the deliverable is chiefly a curated set of outbound links.'
---

# Vibe Launch Pad

A launch pad is the link-hub variant of Swami's vibe-dashboard: the exact same locked design
system, reduced to **header → launch tiles → footer**. No collapsible sections, no sticky TOC,
no live search. Each tile is a big clickable card that opens one URL in a new tab.

The division of labor is fixed: **Swami supplies the links; Claude writes everything else** —
the tile titles, the mono badge, the one-line description, the grouping, the accent colors, and
the layout. Ask for link text only when a URL is genuinely ambiguous and can't be resolved.

## Workflow

1. **Collect the links.** Swami will paste one or more URLs (often with a rough label or the
   page's top-of-page title). Fetch each one to confirm what it is when possible. Claude AI
   artifacts and other client-rendered pages usually can't be read by fetch (the title comes
   back blank or generic) — in that case, do NOT block: use whatever label Swami gave, infer
   from the URL/context, or ask a single compact question only if a tile would otherwise be
   mislabeled.
2. **Decide the text.** For every tile Claude writes:
   - **Title** (`<h2>`) — the artifact/page name, short.
   - **Badge** (`.tile-badge`) — a 1–4 word UPPERCASE mono tag naming the *kind* of thing:
     e.g. `CONCEPT REFERENCE · WIP`, `DESIGN CRITIQUE`, `CAM SESSION`, `FB POST`, `ZOOM RECORDING`,
     `NOTEBOOKLM`, `LIVE DEMO`. Never leave it as `HTML` — say what the page *is*, not its format.
   - **Description** (`<p>`) — one plain sentence on what's inside / why open it.
3. **Decide the layout & accents.**
   - If one link is clearly the primary/hero, give it its own full-width `.grid.hero` group
     (green accent by default) and group the rest below in a normal auto-fit `.grid`.
   - Otherwise use a single auto-fit grid. Assign each tile an accent by cycling the palette
     hues (green → cyan → amber → pink → violet) so adjacent tiles read as distinct. Set both
     `--accent` and `--accent-bg` inline on the `<a class="tile">` (see template for the exact
     rgba pairs).
   - Optional `.group-label` above a grid only if grouping genuinely helps; otherwise omit it.
     (Swami has previously asked to *remove* a "Related artifacts" label — don't add group
     labels reflexively.)
4. **Fill the template.** Copy `assets/template.html`, fill placeholders, duplicate/delete
   `<a class="tile">` blocks to match the link count, renumber the `.tile-num` (01, 02, 03…),
   and delete the hero group if there's no hero.
5. **Save & publish.** Write the file in the working directory (not `/mnt/user-data/outputs/`)
   with a descriptive kebab-case filename (e.g. `bumper-guard-launch.html`), then publish it with
   the Artifact tool. Files in the working directory publish without an approval prompt. Declare
   no runtime capabilities — this page needs none. Send the .html as a file too (SendUserFile or
   present_files) only when Swami asks for a standalone copy. One `.html` file; the two Google
   Fonts are the only external dependency.

## The locked design system — identical to vibe-dashboard, DO NOT deviate

**Palette** (`:root`): `--bg:#0d0d0f` · `--panel:#141418` · `--panel-2:#1a1a20` ·
`--cyan:#00e5ff` (default accent) · `--green:#00ff88` · `--amber:#ffb020` · `--pink:#ff5c7a` ·
`--violet:#7c5cff` · `--text:#e8e8ec` · `--text-dim:#9aa0aa` · `--text-mute:#6a6f78` ·
`--border:#26262e`.

**Fonts:** JetBrains Mono (`--mono`, labels/nums/links) + DM Sans (`--sans`, body), from Google Fonts.

**Non-negotiables** (pre-built in the template — keep intact):
- **Header kicker is REQUIRED** — the `.kicker` UPPERCASE mono eyebrow above the H1 (e.g.
  `LAUNCH PAD`, `PROJECT HUB`, `RESOURCE INDEX`). Never blank, never deleted.
- **Footer text is exactly** `Vibe Coding: Swami · AI: Claude`, Swami being the runtime-assembled
  mailto link (`'swami.human' + '@' + 'gmail.com'`) — never hard-code the address in an `href`.
- **Outbound links are plain `<a href="…" target="_blank" rel="noopener">` anchors ONLY.**
  Do NOT add any JS click handler (`window.open`, `preventDefault`, `window.top.location`) to a
  tile. A prior session proved JS interception triggers claude.ai's "content is blocked" screen
  and breaks the links; bare anchors are the working pattern. (Note: links open only when the
  file is opened directly in a browser, not inside the artifact preview sandbox — that's expected.)
- Tiles are centered (`.tile{text-align:center}`), each with a small external-link SVG next to
  the title that nudges on hover. Content is centered per Swami's standing preference for these
  cards.

## Placeholders in the template

`{{PAGE_TITLE}}` (browser tab) · `{{KICKER}}` (REQUIRED eyebrow) · `{{H1_TITLE}}` ·
`{{BYLINE_A/B/C}}` (byline chips, `·`-separated automatically; add/remove `<span>`s as needed) ·
`{{LEAD}}` (small mono line above the grid, e.g. "Choose an artifact to open") · per-tile
`{{URL_N}}` + `{{BADGE_N}}` + `{{TILE_N_TITLE}}` + `{{TILE_N_DESC}}` · `{{MAIL_SUBJECT}}`.

See `references/example.md` for a filled reference (the BumpGuard launch pad this skill is based on).
