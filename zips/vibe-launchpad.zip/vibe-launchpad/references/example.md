# Filled reference — the BumpGuard launch pad

This is the page this skill was distilled from, showing how link → text decisions were made.

## Input Swami gave

Three Claude artifact URLs plus rough labels:
- `.../68a9815c-…` → hero, WIP concept reference
- `.../675dcdf4-…` → design critique
- (companion artifacts under the "Next-Gen 360° Bumper Guard" project)

## Header

```
kicker:  LAUNCH PAD
h1:      'BumpGuard' / 'Next-Gen 360° Bumper Guard'
byline:  GNSS Protector · 'BG': product by Site Twin · 'NG360BG': concept by Jon Presti
lead:    Choose an artifact to open
```

## Tiles — how the text was chosen

| # | accent | badge | title | description |
|---|--------|-------|-------|-------------|
| 01 (hero) | green | `CONCEPT REFERENCE · WIP` | Next-Gen 360° Bumper Guard | One-piece printed shield for survey GNSS receivers — early work in progress |
| 02 | cyan | `WIP` | Next-Gen 360° Bumper Guard | Companion interactive artifact |
| 03 | amber | `DESIGN CRITIQUE` | BumpGuard | Next-Gen 360° Bumper Guard — analysis & critique |

Notes that became rules:
- Badges name **what the page is** (`CONCEPT REFERENCE`, `DESIGN CRITIQUE`), never the format
  (`HTML` was explicitly removed).
- The hero tile (01) sits alone in a full-width `.grid.hero` group; 02 and 03 share a normal grid
  below — **no** "Related artifacts" group label (Swami removed it).
- Card content is **centered**.
- Byline chips are separated by `·` via CSS `::after`, not typed inline.

## The tile markup pattern (one tile)

```html
<a class="tile" href="https://…" target="_blank" rel="noopener"
   style="--accent:var(--amber);--accent-bg:rgba(255,176,32,.12)">
  <div class="tile-top">
    <span class="tile-num">03</span>
    <span class="tile-badge">DESIGN CRITIQUE</span>
  </div>
  <h2>BumpGuard <svg class="ext" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg></h2>
  <p>Next-Gen 360° Bumper Guard — analysis &amp; critique.</p>
</a>
```

## Accent → rgba background pairs (for the inline `--accent-bg`)

```
green : --accent:var(--green);  --accent-bg:rgba(0,255,136,.12)
cyan  : --accent:var(--cyan);   --accent-bg:var(--cyan-dim)
amber : --accent:var(--amber);  --accent-bg:rgba(255,176,32,.12)
pink  : --accent:var(--pink);   --accent-bg:rgba(255,92,122,.12)
violet: --accent:var(--violet); --accent-bg:rgba(124,92,255,.12)
```
