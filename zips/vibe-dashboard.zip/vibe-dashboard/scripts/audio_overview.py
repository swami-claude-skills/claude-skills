#!/usr/bin/env python3
"""Audio overview for vibe dashboards.

  extract  PAGE.html                       Print the page's text outline (kicker, title, sections, rows)
                                           to write a narration from.
  build    PAGE.html NARRATION.txt OUT.html [--trigger trig_...] [--artifact https://claude.ai/artifact/...]
                                           Speak NARRATION.txt (single female voice, Kokoro "af_heart"),
                                           embed the MP3 and the player under the header byline.
                                           Re-running on a page that already has a player REPLACES it and
                                           keeps its existing --trigger/--artifact unless new ones are given.
  speak    NARRATION.txt OUT.mp3           Only make the MP3.

Narration: plain spoken English, one paragraph per thought (paragraph breaks become short pauses),
acronyms spelled for speech ("C A M", "A I"), numbers as words where it reads better.
"""
import argparse, base64, html, os, re, subprocess, sys, tempfile
from html.parser import HTMLParser

HERE = os.path.dirname(os.path.abspath(__file__))
SNIPPET = os.path.join(HERE, '..', 'assets', 'audio-player.html')
CACHE = os.path.expanduser('~/.cache/vibe-audio')
MODEL_URL = 'https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/'
VOICE = 'af_heart'          # single female voice
BEGIN, END = '<!-- AUDIO-OVERVIEW:BEGIN', '<!-- AUDIO-OVERVIEW:END -->'

# ---------------------------------------------------------------- speech
def _ensure_tts():
    try:
        import kokoro_onnx, soundfile  # noqa
    except ImportError:
        subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', '--break-system-packages',
                        'kokoro-onnx', 'soundfile'], check=True)
    os.makedirs(CACHE, exist_ok=True)
    for name, fn in (('kokoro-v1.0.onnx', 'kokoro.onnx'), ('voices-v1.0.bin', 'voices.bin')):
        dst = os.path.join(CACHE, fn)
        if not os.path.exists(dst) or os.path.getsize(dst) < 1_000_000:
            subprocess.run(['curl', '-sSLf', '-o', dst, MODEL_URL + name], check=True)

def speak(text, mp3_path):
    _ensure_tts()
    import numpy as np, soundfile as sf
    from kokoro_onnx import Kokoro
    k = Kokoro(os.path.join(CACHE, 'kokoro.onnx'), os.path.join(CACHE, 'voices.bin'))
    paras = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]
    if not paras:
        sys.exit('narration is empty')
    parts, sr = [], 24000
    for p in paras:
        s, sr = k.create(' '.join(p.split()), voice=VOICE, speed=1.0, lang='en-us')
        parts += [s, np.zeros(int(sr * 0.55), dtype=s.dtype)]
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, 'a.wav')
        sf.write(wav, np.concatenate(parts), sr)
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-ac', '1', '-b:a', '64k', mp3_path], check=True)
    dur = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', mp3_path],
                         capture_output=True, text=True).stdout.strip()
    return float(dur or 0)

# ---------------------------------------------------------------- page
def _existing(page):
    i = page.find(BEGIN)
    if i < 0:
        return None, None, None
    j = page.find(END, i)
    if j < 0:
        sys.exit('page has an AUDIO-OVERVIEW:BEGIN marker without END')
    block = page[i:j + len(END)]
    trig = re.search(r'data-trigger="([^"]*)"', block)
    art = re.search(r'data-artifact="([^"]*)"', block)
    return (i, j + len(END)), (trig.group(1) if trig else ''), (art.group(1) if art else '')

def build(page_path, narration_path, out_path, trigger=None, artifact=None):
    page = open(page_path, encoding='utf8').read()
    span, old_trig, old_art = _existing(page)
    trigger = trigger if trigger is not None else (old_trig or '')
    artifact = artifact if artifact is not None else (old_art or '')
    if trigger and not re.fullmatch(r'trig_[A-Za-z0-9]+', trigger):
        sys.exit('bad --trigger')
    if artifact and not re.fullmatch(r'https://claude\.ai/[A-Za-z0-9/_-]+', artifact):
        sys.exit('bad --artifact')
    with tempfile.TemporaryDirectory() as d:
        mp3 = os.path.join(d, 'overview.mp3')
        secs = speak(open(narration_path, encoding='utf8').read(), mp3)
        b64 = base64.b64encode(open(mp3, 'rb').read()).decode()
    block = (open(SNIPPET, encoding='utf8').read().strip()
             .replace('{{AO_MP3_B64}}', b64).replace('{{AO_TRIGGER}}', trigger).replace('{{AO_ARTIFACT}}', artifact))
    if span:
        page = page[:span[0]] + block + page[span[1]:]
    else:
        k = page.find('</header>')
        if k < 0:
            sys.exit('no </header> in page — is this a vibe dashboard?')
        page = page[:k] + block + '\n' + page[k:]
    open(out_path, 'w', encoding='utf8').write(page)
    m, s = divmod(round(secs), 60)
    print(f'audio {m}:{s:02d} · {len(b64)//1024} KB base64 · refresh button: {"on" if trigger and artifact else "off"} → {out_path}')

# ---------------------------------------------------------------- outline
class _Text(HTMLParser):
    SKIP = {'script', 'style', 'svg', 'audio', 'noscript'}
    BLOCK = {'p', 'li', 'tr', 'h1', 'h2', 'h3', 'div', 'br', 'pre'}
    def __init__(self):
        super().__init__(); self.out = []; self.skip = 0
    def handle_starttag(self, tag, a):
        if tag in self.SKIP: self.skip += 1
        a = dict(a)
        if tag == 'div' and 'section' in (a.get('class') or '').split():
            self.out.append('\n\n## SECTION: ' + (a.get('data-title') or '') + '\n')
        elif tag in self.BLOCK: self.out.append('\n')
        if tag == 'td': self.out.append(' | ')
    def handle_endtag(self, tag):
        if tag in self.SKIP: self.skip = max(0, self.skip - 1)
    def handle_data(self, d):
        if not self.skip: self.out.append(d)

def extract(page_path):
    page = open(page_path, encoding='utf8').read()
    span, *_ = _existing(page)
    if span: page = page[:span[0]] + page[span[1]:]
    page = re.sub(r'data:[^"\')\s]{200,}', '', page)
    p = _Text(); p.feed(page)
    txt = html.unescape(''.join(p.out))
    txt = re.sub(r'[ \t]+', ' ', txt)
    txt = re.sub(r'\n\s*\n\s*(\n\s*)+', '\n\n', txt)
    lines = [l.strip() for l in txt.splitlines()]
    print('\n'.join(l for l in lines if l and l not in ('▶', '|'))[:60000])

# ---------------------------------------------------------------- cli
if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    e = sub.add_parser('extract'); e.add_argument('page')
    b = sub.add_parser('build'); b.add_argument('page'); b.add_argument('narration'); b.add_argument('out')
    b.add_argument('--trigger'); b.add_argument('--artifact')
    s = sub.add_parser('speak'); s.add_argument('narration'); s.add_argument('mp3')
    a = ap.parse_args()
    if a.cmd == 'extract': extract(a.page)
    elif a.cmd == 'build': build(a.page, a.narration, a.out, a.trigger, a.artifact)
    else: print(round(speak(open(a.narration, encoding='utf8').read(), a.mp3), 1), 'seconds')
