# Search scroll logic (reference)

The template's search positioning, for reference if a dashboard's script is ever rebuilt or merged. It relies on the template's existing `stack`, `matches`, `current` and `updateCount`.

```js
/* Where to scroll for a hit. Up to three sticky layers pin over the content:
   TOC/toolbar → section header → item header (+ the floating column header
   for table rows). The target line must clear every layer that will be pinned
   above the hit. A hit INSIDE a sticky header is measured from its container
   (section / item / table), whose position doesn't change when the header pins. */
function hitTarget(m){
  const h = el => el ? el.getBoundingClientRect().height : 0;
  const sec = m.closest('.section'), secHead = sec && sec.querySelector('.sec-head');
  const item = m.closest('.citem'), itemHead = item && item.querySelector('.citem-head');
  const table = m.closest('.table-wrap table');
  let anchor = m, line = h(stack);
  if(secHead && secHead.contains(m)){ anchor = sec; }
  else {
    line += h(secHead);
    if(itemHead && itemHead.contains(m)){ anchor = item; }
    else {
      line += h(itemHead);
      if(table && table.tHead && table.tHead.contains(m)) anchor = table;
      else if(table && table.tHead) line += h(table.tHead);   // floating column header
    }
  }
  return {anchor, line: line + 12};
}
let focusFix = 0;
function focusMatch(){
  matches.forEach(m=>m.classList.remove('active'));
  const m=matches[current];
  if(!m) return;
  m.classList.add('active');
  const go = smooth => {
    const {anchor, line} = hitTarget(m);
    const y = Math.max(0, anchor.getBoundingClientRect().top + window.scrollY - line);
    if(Math.abs(y - window.scrollY) > 2) window.scrollTo({top:y, behavior: smooth ? 'smooth' : 'auto'});
  };
  go(true);
  // re-check once the smooth scroll settles (table fitting / font load can shift
  // layout mid-scroll) and snap the hit exactly into place.
  const token = ++focusFix;
  const settle = () => { if(token === focusFix) go(false); };
  if('onscrollend' in window){
    window.addEventListener('scrollend', settle, {once:true});
    setTimeout(settle, 1200);                  // in case no scroll was needed
  } else setTimeout(settle, 700);
  updateCount();
}
```