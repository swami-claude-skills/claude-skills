# Patterns & worked examples

Read this when filling `assets/template.html` and you want a concrete section to copy from, or help naming categories.

## Required first section: Dashboard Summary

Every dashboard opens with a "Dashboard Summary" section (01) — the template ships it pre-built. Fill its intro paragraph, an optional "Start Here" callout (delete the `.callout` if you don't want one), and the **"What each section covers"** table: one row per *other* section, columns **# / Section / Category / Focus / Use When**. The **Category** cell is an empty `<td class="sec-cat"></td>` placed right after the Section cell; at runtime `fillSummaryCategories` inserts a `.cat-pill` with the target section's badge label, colored and tinted exactly like that section's `.cat-badge` (row matched by its # number, falling back to the section name). Don't type category text or add per-category CSS for it — it follows whatever category each section uses. The "#" cell is a plain `<span class="secnum">NN</span>` — `NN` is the section's zero-padded number (02, 03, …). It is NOT a link; the section NAME in the Section column is the clickable jump (handled automatically by `linkSectionRefs`). The table title comes from `data-desc="What each section covers"` — keep that exact text. Number the real content sections from 02 onward. Don't remove the summary or its table. The table always ends with a **"Source Document (Verbatim)" row**; its number is resolved at runtime from `data-target-title="Source Document (Verbatim)"` (leave the number cell empty — JS fills it), and the row auto-removes if that section isn't present. Like all tables, it's click-sortable.

## Filled section example

```html
<div class="section cat-photo" data-title="Walkaround Photos" data-cat="photo">
  <div class="sec-head"><span class="sec-num">02</span><span class="sec-title">Walkaround Photos</span><span class="cat-badge">Photo Sources</span><span class="chevron">▶</span></div>
  <div class="sec-body">
    <p>Start with a plain search — <strong>"[subject] walkaround"</strong> — but one critical view is always missing. Build a composite from several sets.</p>
    <div class="resource"><span class="r-name">Wikimedia Commons</span><span class="r-note">Often a clean photo collection.</span><a href="https://commons.wikimedia.org/wiki/Main_Page" target="_blank" rel="noopener">commons.wikimedia.org</a></div>
    <div class="callout"><span class="lbl">Pro tip</span>Search in the subject's native language for fresh hits.</div>
  </div>
</div>
```

Key points the JS relies on:
- `class="section cat-NAME"` — the category NAME drives the left-edge stripe and badge color.
- `data-title` — verbatim text the TOC chip shows.
- `data-cat="NAME"` — the SAME name; drives the TOC chip's `tc-NAME` color class.
- `sec-num` — zero-padded running number. The TOC auto-pads its own numbers, so keep these consistent (01, 02, …).
- No `open` class → starts collapsed.
- Every NAME used must have its `--cat-NAME` var and CSS trio defined (see below).

## Category naming

Categories are visual accents grouping related sections. Invent them per dashboard, named for what they group — there is no fixed list and no cap. Use one, use ten; use as many as the content genuinely needs. Give each a lowercase machine name (used in the class/var: `cat-mechanical`, `cat-warning`) and a short UPPERCASE badge label (shown on the section: `MECHANICAL`, `WARNING`).

Do NOT ship generic placeholder names like `cat-a`, `cat-b`. Name them after the content.

Colors: assign in order from the verified 8-color palette (each ≥30° apart on the hue wheel, all readable on `#0d0d0f`), one hue per category, never repeated: cyan `#38dafa`, green `#38fa79`, yellow `#dafa38`, orange `#fa9938`, pink `#fa3899`, magenta `#ea38fa`, violet `#7938fa`, blue `#3879fa`. For a 9th+ category pick a hue ≥30° from every color already used. The template's `checkCategoryColours` logs a console warning if any two used category colors are too close (Δhue < 25° or Δrgb < 90) — a finished dashboard must show no warning. Reserve pink/magenta for warning/caveat/error categories by convention.

## Defining a category

Each category needs FIVE things kept in sync. For a category named `mechanical` using palette color cyan `#38dafa` (rgb 56,218,250):

1. Color var in `:root`:
   `--cat-mechanical:#38dafa;`
2–5. The CSS block (in the CATEGORY BLOCKS area):
```css
.cat-mechanical .cat-badge{color:var(--cat-mechanical);background:rgba(56,218,250,.10)}
.cat-mechanical{border-left:3px solid var(--cat-mechanical)}
.toc-chip.tc-mechanical{border-left-color:var(--cat-mechanical)}
.toc-chip.tc-mechanical:hover{color:var(--cat-mechanical)}
.toc-tip.tc-mechanical .tip-badge{color:var(--cat-mechanical);background:rgba(56,218,250,.10)}
```
Then each section using it: `class="section cat-mechanical"`, `data-cat="mechanical"`, and a `<span class="cat-badge">MECHANICAL</span>`. The `rgba()` is the same hue at 10% alpha — convert the hex to r,g,b. Use a different palette color for every category (see the palette list above).

## Tables (sticky header)

Always wrap a table in `.table-wrap` with a `data-desc` — the logical description shown in the table's collapsed item header and the TOC (e.g. "Cutting parameters"). No scroll box, no `max-height`. A JS engine (`buildFloatingHeaders`/`syncFloatingHeaders`) clones each header row into a `position:fixed` element on `document.body` and floats it just below the sticky TOC/toolbar whenever any part of the table is on screen. So the header pins on **page scroll** and stays put as long as one row is visible — and it works for short tables too.

```html
<div class="table-wrap" data-desc="Cutting parameters">
  <table>
    <thead><tr><th>Param</th><th>Value</th><th>Note</th></tr></thead>
    <tbody>
      <tr><td><strong>Feed rate</strong></td><td>1200 mm/min</td><td>roughing</td></tr>
      <tr><td><strong>Spindle</strong></td><td>18000 rpm</td><td>—</td></tr>
    </tbody>
  </table>
</div>
```

- **Why not plain CSS sticky?** The locked `.section{overflow:hidden}` (rounded-corner clipping) kills `position:sticky` on descendants trying to pin to the page — a hard constraint. A bounded-scroll wrapper works but only pins while you scroll *inside* the box, so short tables never pin. The floating clone lives outside the section's clip, on `document.body`, which is why it works everywhere.
- Header cells are auto-styled: cyan mono uppercase, cyan bottom border. The floating clone reuses the same styling and mirrors column widths + horizontal scroll from the live table.
- First cell of each row: wrap the label in `<strong>` for the brighter `--text` color.
- **Wide tables** — add `pin-first`: `<div class="table-wrap pin-first" data-desc="…">` also freezes the first column horizontally (both in the live table and the floating clone).
- Cells are `white-space:nowrap` by default (keeps columns aligned); if a column needs wrapping text, add inline `style="white-space:normal"` on those `td`s.
- The engine re-syncs on scroll, resize, font load, and section/item expand/collapse — no per-table setup needed beyond the wrapper.

## Collapsible body items

Every `.callout`, `.resource`, and `.table-wrap` in a section body is auto-wrapped by JS in a collapsible `.citem` shell — you never write `.citem` yourself, just author the plain building blocks. Each shell's header shows a uniform `[TAG]` (`[CALLOUT]`/`[RESOURCE]`/`[TABLE]`, one cyan color, left-justified into a shared-width column so the descriptions align) plus a description. **All items start collapsed** and toggle independently.

The tag + description come from `deriveSubs` (same source as the TOC tooltip, so they always match). Description per kind: callout → its `.lbl`; resource → its `.r-name`; table → its `data-desc` (fallback: first header cell). To surface a new element type, extend the selector + `TAG_CH` map in the wrapping pass and `deriveSubs`.

## TOC chips & hover tooltip

Chips are compact (number + title) and wrap inline — no per-chip setup. On hover, `buildTip` assembles a tooltip: the section's `.cat-badge` text, the `data-title`, then the list of **auto-derived sub-items** — the same ones wrapped as `.citem`s in the body. Tags are bracketed and uniform-colored, left-justified into a grid column so the text aligns. Each sub is a clickable link that opens the parent section, opens that item, and scrolls to it (`scrollToAnchor`). A section with three callouts shows three `[CALLOUT]` sub-links; a section with none shows "No sub-sections."

The tooltip is JS-positioned and viewport-clamped (`placeTip`), so it never clips at the edges; don't wrap it in an `overflow:hidden` ancestor or add a hardcoded `left`.

Per category, add one tooltip-badge tint line mirroring the section badge, e.g. `.toc-tip.tc-mechanical .tip-badge{color:var(--cat-mechanical);background:rgba(R,G,B,.10)}`.

## References section

When the dashboard cites external sources, keep the "References" section (ships in the template, sits just before the verbatim section). Its table has columns **Source / What it covers / Domain / Webpage**; the Webpage cell holds the real external link (`target="_blank" rel="noopener"`). One row per cited source. If the dashboard cites nothing, delete the section.

## Inline section links

`linkSectionRefs` links EVERY reference to a section — by exact title ("see Surface & Temperature") or by number ("section 3", "sec 3", "sec. 04", "§2") — into a `.secref` jump-link. It runs everywhere in section bodies, tables included, matching titles longest-first and linking every hit in a node (overlaps resolved so the longest wins). It skips only existing links and code (so nothing double-links), and a number that matches no section stays plain text. Numbers map by each section's displayed `sec-num` (and its bare integer), so "section 3" targets the section numbered 03. No markup needed — just write references naturally.

## Verbatim block

Use only when preserving an original post/document exactly. Put the raw text in the `VERBATIM` template literal in the script; the code injects it into `<pre id="verbatim">` and double-spaces paragraphs. If not preserving a source, delete both the `VERBATIM` const/injection and the verbatim `.section`.

## Byline

The header byline is a flex row of `<span>`s — author name, group (linked), post (linked), type. Add or drop spans freely. All external links: `target="_blank" rel="noopener"`. **Never use a copyright mark in the byline** — no `©`, no "Copyright", and specifically never `© Swami`. Attribution belongs in the footer (`Vibe Coding: Swami · AI: Claude`); the byline is plain author/context text.

## Filename

Save as descriptive kebab-case, e.g. `twincat-plc-breakdown.html`, `kicker-grille-reference.html`, `stair-stringer-dashboard.html`.

## Glossary (cross-linked terms)

The template ships an optional **Glossary** section just before References. Number it in sequence with the other sections (it ships as `97` — renumber like References). Write one row per term; `linkGlossary` does the rest at runtime: dotted-underline links on each term's first mention per section, a hover definition, the **Appears in** jump links (colored by section category, with a hover preview of the line) and the **Qty** count.

```html
<tr data-gterm="stepover" data-match="stepovers?|step-over" data-code="stepover">
  <td><strong>Stepover</strong></td>
  <td>Sideways distance between adjacent passes of the tool, usually a % of tool diameter.</td>
  <td class="gloss-uses"></td><td class="gloss-count"></td>
</tr>
<tr data-gterm="skill-md" data-match="" data-code="SKILL.md|skill.md">
  <td><strong>SKILL.md</strong></td>
  <td>The one required file in a skill: YAML frontmatter plus instructions.</td>
  <td class="gloss-uses"></td><td class="gloss-count"></td>
</tr>
```

Choosing terms and matchers:
- Pick terms a reader might not know: jargon, product/feature names, acronyms, file and field names. 10–40 is typical; definitions are one or two plain sentences.
- `data-match` is a case-insensitive regex for body text. Cover plurals and variants (`hooks?`, `MCP servers?|MCP`), and start/end with a word character. Overlapping terms are fine — the longest pattern wins at each spot, so a specific term ("Claude Marketplace") never gets swallowed by a general one ("marketplace").
- `data-code` catches terms written as `<code>` (file names, fields, variables): list the exact code texts, `|`-separated. Code that doesn't exactly match stays unlinked.
- After publishing-quality checks, scan the Qty column: a 0 means the matcher misses the body wording — fix the regex or drop the row.
- Don't hand-link terms in the body or type anything into the Appears in / Qty cells.
