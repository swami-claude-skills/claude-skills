# Audio refresh scheduled task

One run-on-demand scheduled task serves every dashboard's owner-only ↻ button.
Create it only if `list_triggers` shows no task with this name.

- **Name:** `Vibe dashboard — refresh audio overview`
- **Schedule:** none (omit `cron_expression` and `run_once_at`)
- **initiation:** `human_request` · **notifications:** `{push: true}`
- **Prompt:** (verbatim)

```
Refresh the audio overview on one of Swami's vibe dashboards.

The firing's extra message gives the dashboard's claude.ai artifact URL (a line "ARTIFACT_URL: https://claude.ai/artifact/..."). If there is no such URL, or it is not a claude.ai artifact link, stop and do nothing.

Steps:
1. Load the vibe-dashboard skill (Skill tool) and follow its "Audio overview" section, sub-section "Refreshing an existing dashboard". Its script is scripts/audio_overview.py.
2. Read the artifact with the Artifact tool (action "read" with the URL, then action "read" with path "index.html" to get the full page as a local file). Only proceed if the read says Swami can edit it ("writer").
3. Run `python3 <skill>/scripts/audio_overview.py extract <page.html>` to get the page's current text outline, and write a fresh narration (single speaker, ~2–3 minutes, plain spoken English, acronyms spelled for speech) describing the dashboard as it now stands.
4. Run `python3 <skill>/scripts/audio_overview.py build <page.html> <narration.txt> <out.html>` — it regenerates the MP3 with the female Kokoro voice and replaces the existing player audio, keeping the owner-only refresh button settings already embedded in the page.
5. Publish <out.html> back to the SAME artifact with the Artifact tool, passing `url` = the artifact URL and NO `capabilities` field (so the page keeps its declared capabilities). Label the publish "Audio overview refresh".
6. Finish with one line: the new audio length and the time of the refresh. Do not change anything else on the page.
```

The page fires it with `fire_trigger({trigger_id, text: "ARTIFACT_URL: <url>"})`, so the URL
always comes from the page's own `data-artifact` attribute.
