---
name: "vibe-dashboard"
description: "Build Swami's signature \"Vibe Coding\" dark-theme HTML dashboard — a single self-contained .html file with the locked #0d0d0f/#00e5ff design system (JetBrains Mono + DM Sans), collapsible numbered sections, sticky TOC chips with hover tooltips, live search, sortable and resizable tables, a required Dashboard Summary, and an optional cross-linked Glossary of terms. Use this WHENEVER Swami asks for a vibe dashboard, a dashboard, a reference page, a consultation or session write-up, a breakdown, comparison or explainer page in his style, or wants a post, video, document, files or notes turned into a browsable page — including when he asks to add or edit a glossary on a dashboard. It is also the delivery format other skills use when they build a dashboard. For pages that are mostly outbound links use vibe-launchpad; for input forms that output text or JSON use vibe-promptmaker or vibe-json."
---

# Vibe Dashboard

Swami's dashboards all share ONE locked design system. This skill reproduces it exactly so every page is on-brand and self-contained. Never invent new colors, fonts, or layout patterns — the system is fixed. Vary only the content, the section categories, and the card types.

## Workflow

1. **Get the content.** It comes from a pasted post, uploaded project/CAD/PLC files, a link, a client session, or Swami's own notes. If files are uploaded and not yet in context, read them first (view / the file-reading skill). If a Google Drive file is referenced, retrieve it. Read everything before structuring.
2. **Structure into sections.** Break the content into logical collapsible sections (typically 4–10). Give each a short title, a running zero-padded number, and a category.
3. **Assign categories.** Categories are named accents that group related sections. Invent them per dashboard from the actual content — there is no fixed list and no cap; use as many or as few as the material warrants. Each category is a `cat-<name>` class mapping to a color + a short UPPERCASE badge label. Reuse the same category across related sections. **Every category's color must be unique and clearly distinguishable** — assign in order from the 8-color palette in the template's CATEGORY ACCENTS comment (cyan, green, yellow, orange, pink, magenta, violet, blue), never repeating a hue; for a 9th+, pick a hue ≥30° from every color already used. A runtime check (`checkCategoryColours`) logs a console warning if any two used category colors are too close — a finished dashboard must produce no such warning. You must define each category's CSS blocks (badge color, section left-edge, TOC chip color, tooltip-badge tint) plus its `--cat-<name>` color var in `:root` — see `references/patterns.md` for the copy-paste block. Do NOT ship generic placeholder category names.
3a. **Pick the glossary terms.** If the dashboard uses jargon, product names, acronyms or field names a reader may not know (most technical dashboards do), include the Glossary section (see "Glossary" under building blocks): one row per term with a one- or two-sentence definition and its matchers. Typically 10–40 terms. Skip it — and delete the section — only when there is genuinely nothing to define.
4. **Copy the template** `assets/template.html` to the working directory, **then immediately run the template patch** (see "Template patch — REQUIRED" below) on the copy, then fill placeholders, add/duplicate sections, and delete anything unused (e.g. the verbatim block).
5. **Save & publish.** Write the file in the working directory (not `/mnt/user-data/outputs/`)
   with a descriptive kebab-case filename (e.g. `stair-stringer-dashboard.html`), then publish it with
   the Artifact tool. Files in the working directory publish without an approval prompt. Declare
   no runtime capabilities — a dashboard needs none — unless the page has a feature that strictly
   requires one (e.g. a download button needs `downloads`). Send the .html as a file too (SendUserFile
   or present_files) only when Swami asks for a standalone copy. One `.html` file; the two Google
   Fonts are the only external dependency.
   **This rule also governs dashboards built "per the vibe-dashboard skill" by other skills**
   (facebook-comments, makerworld-reviews, youtube-transcript, youtube-comments, …): it overrides any
   save location or `/mnt/user-data/outputs/` fallback those calling skills mention.

## The locked design system — DO NOT deviate

**Palette** (CSS vars in `:root`):
`--bg:#0d0d0f` · `--panel:#141418` · `--panel-2:#1a1a20` · `--cyan:#00e5ff` (accent) · `--green:#00ff88` (search-hit glow) · `--text:#e8e8ec` · `--text-dim:#9aa0aa` · `--text-mute:#6a6f78` · `--border:#26262e`. Category accents default to cyan `#00e5ff`, amber `#ffb020`, pink `#ff5c7a`, violet `#7c5cff`, green `#00ff88` — rename per dashboard but keep the hues.

**Fonts:** JetBrains Mono (`--mono`, for labels/nums/code/links) + DM Sans (`--sans`, body). Loaded from Google Fonts.

**Non-negotiable behaviors** (all pre-built in the template — keep them intact):
- **Full-width layout.** Every band spans the full width of the browser window — header, TOC bar, toolbar, all sections in `main`, and footer. `main`, `.toc-bar` and `.toolbar` have only side padding (22px), **no `max-width` and no `margin:0 auto` centering cap**. Never reintroduce a fixed content width (e.g. the old `max-width:900px`). Tables still fit their wrapper on open (`fitVisibleTables`), so they now use the full page width too.
- **Header kicker is REQUIRED.** Always include the `.kicker` element above the H1 with a short (1–4 word) UPPERCASE tag naming what kind of page this is (e.g. `CLIENT SESSION`, `TWINCAT PLC BREAKDOWN`, `CAM COMPARISON`, `REVERSE ENGINEERING REFERENCE`). Never leave it blank or delete it.
- **Dashboard Summary is REQUIRED as section 01.** Every dashboard opens with a "Dashboard Summary" section that includes a table titled (via `data-desc`) "What each section covers" — one row per section **including the Dashboard Summary itself (the first row, 01)**, columns **# / Section / Category / Focus / Use When**. The **Category** cell is always left as an empty `<td class="sec-cat"></td>` — `fillSummaryCategories` fills it at runtime with a pill showing the target section's category badge label in that category's own color (copied from the section's badge, so it always matches the dashboard's color coding); never type the category by hand. The "#" cell is a plain `.secnum` span showing the zero-padded section number (e.g. `01`, `02`) — it is NOT a link; navigation is via the clickable section NAME in the Section column (`linkSectionRefs` links it automatically). The table **always includes a "Source Document (Verbatim)" row** (last row) — its number resolves at runtime via `data-target-title`, and the row auto-drops if the verbatim section isn't present. The template ships this as the first section; fill it, don't remove it, and number the real content sections from 02 onward. An optional intro callout is fine; the intro paragraph and the table are not optional.
- **All sections start COLLAPSED.** Never add the `open` class in markup.
- **Sticky stack** (TOC bar + toolbar) sticks to `top:0`; its height is measured at runtime (`getBoundingClientRect().height`, published as the `--stack-h` CSS var) so scroll targets land correctly regardless of wrapping.
- **Three stacked sticky layers.** While scrolling a long table, three headers pin in order below the TOC/toolbar: (1) the main **section header** (`.sec-head`, `position:sticky` at `top:var(--stack-h)`), (2) the **table item header** (`.citem-head`, sticky at `top:calc(var(--stack-h) + var(--sechead-h))`), and (3) the **table column header** (the floating clone, parked below both). Neither `.section` nor `.citem` may use `overflow:hidden` (it would break their sticky headers) — corners are rounded on the header + body instead; keep that. `--stack-h` and `--sechead-h` are measured at runtime; the floating-clone sync (`syncFloatingHeaders`) adds the section- and item-header heights to its park line and only shows the clone once the item header is pinned. **Anything that scrolls to content (search hits especially) must clear ALL of these layers**, not just the TOC/toolbar.
- **Collapsible body items.** Every callout, resource card, and table in a section body is auto-wrapped by JS in a collapsible shell (`.citem`) with a header showing a uniform `[TAG]` (`[CALLOUT]`/`[RESOURCE]`/`[TABLE]`, all one cyan color, left-justified into a shared-width column so descriptions align) and a description. **All items start collapsed.** The tag + description come from the same `deriveSubs` used by the TOC tooltip, so the two always match. Tables take their description from a `data-desc` attribute on the `.table-wrap` (write a logical one per table); callouts use their `.lbl`, resources their `.r-name`. Author the plain `.callout`/`.resource`/`.table-wrap` markup as before — the wrapping is automatic; don't hand-write `.citem`. Keep the wrapping pass and `.citem` CSS intact.
- **Compact TOC with rich hover tooltip.** Chips are compact (number + short title) and wrap inline. Hovering a chip pops a tooltip showing the category badge, the section title, and the list of auto-derived sub-items — every one a clickable link (title scrolls to the section; each sub scrolls to that item and opens it). Tags are bracketed and uniform-colored, left-justified into a column so the text aligns, matching the body headers. The tooltip is positioned by JS (`placeTip`) and clamped to the viewport so it never clips at the left/right (or flips above when it would overflow the bottom). Keep the `deriveSubs`/`buildTip`/`placeTip`/`scrollToAnchor` script and the `.toc-tip` CSS intact.
- **Precise jumps.** Every jump (TOC chip, tooltip sub-item, section link, glossary link) goes through `preciseScroll`: it opens and fits whatever is revealed, lands the target just below EVERY pinned layer (TOC/toolbar, plus the section header for sub-items, plus item and column headers for glossary targets), grows an invisible end-of-page spacer (`#endSpacer`) when the target sits too close to the bottom to reach the top, and re-snaps once the smooth scroll settles. `scrollToSection`, `scrollToAnchor` and `jumpToEl` are built on it — never go back to a fixed `stack height + 12` scroll for anything but the section itself.
- **`data-target` navigation, never bare `href` anchors.** TOC chips carry `data-target="<index>"` and scroll via JS. Bare `href="#id"` anchors trigger the artifact sandbox's external-link dialog — do not use them anywhere.
- **Live search** with debounced input, `mark` highlights, prev/next stepping (Enter / Shift-Enter and buttons), `n/total` counter, active hit in green with glow, and a reset "×" that restores scroll position without jumping. The active hit must land just BELOW every pinned layer above it: TOC/toolbar, section header, item header, and (for table rows) the floating column header, never underneath them. A hit inside a sticky header is positioned from that header's container (section / item / table), and the position is re-checked and snapped after the smooth scroll settles. Implemented by `hitTarget` + `focusMatch`; keep them intact and never reintroduce a fixed offset (e.g. stack height + 20) for search hits.
- **Runtime-assembled mailto** on the "Swami" footer link — build the address from parts (`'swami.human' + '@' + 'gmail.com'`); never hard-code it in an `href`.
- **Footer text is exactly:** `Vibe Coding: Swami · AI: Claude` (Swami is the clickable mail link).
- **Pinned column header is aligned AND interactive.** The floating clone uses the live table's fixed layout, identical per-column widths, and the live table's true x offset, so it never shifts left of the columns below it. Clicking a clone header sorts the table (forwarded to the live header, arrows mirrored), and its resizer grips drag/double-click like the live ones. Supplied by the template patch.

## Section & card building blocks

Inside a `.sec-body` use these, all pre-styled:
- `<p>` with `<strong>` for emphasis (strong brightens to `--text`).
- `<ul>`/`<li>` — bullets are custom cyan `▸`.
- `.callout` — `.lbl` mono uppercase label + text; cyan left border. For key principles / pro tips / methods.
- `.resource` — a card with `.r-name` (mono), `.r-note`, and an optional link. Rename the class per use if it helps (spec / part / step / stat), but the visual pattern is this card.
- **Tables** — wrap every `<table>` in `<div class="table-wrap" data-desc="…">`. The `data-desc` is the logical description shown in the item's collapsed header and the TOC (e.g. "Cutting parameters", "Regression checklist"). A JS engine floats a clone of the header row just below the sticky TOC/toolbar whenever any part of the table is on screen, so the header stays pinned on **page scroll** — including for short tables that don't scroll internally. (Pure CSS `position:sticky` can't do this here: the locked `.section{overflow:hidden}` clips it, so short tables would never pin. The floating clone lives on `document.body`, outside that clip.) Keep the `buildFloatingHeaders`/`syncFloatingHeaders` script and the `.float-head` CSS intact. Add `class="table-wrap pin-first"` to also freeze the first column for wide tables. **All tables are sortable, resizable, and word-wrapped** — `initSortableTables` adds to every header: a click-to-sort affordance (asc → desc → original) with a clearly visible indicator, and a draggable column-resizer on the right edge (double-click it to fit the column to its widest cell). **On open, every table is sized to fit its wrapper width** (`fitVisibleTables`) — no horizontal scroll; the first column fits its widest entry on one line and the remaining columns share the rest by their natural proportions, word-wrapping as needed, so all columns are visible within the page width. **No column is ever squeezed below its header label:** each column's floor is its one-line header label plus an 8px gap (`HEAD_GAP`) before the sort arrows. If those floors can't all fit, header labels may wrap (`head-wrap` class, mirrored on the pinned clone) and the floor drops to the header's longest word. Only if even that can't fit (e.g. a 5-column table on a phone) does the table scroll sideways on open — labels never sit under the arrows. Dragging a divider resizes **only that column** — every column is pinned to an explicit px width (`table-layout:fixed` + a `<colgroup>`; `setColWidth` keeps the table element exactly as wide as the sum of its columns, so it fits on open yet grows and lets the wrapper scroll when a column is dragged wider). **Resizing a column never changes the table's current sort order or direction** — a drag only touches column widths, never rows. Body cells word-wrap; header labels stay one line; visible dividers separate columns. Keep the `initSortableTables`/`measureColWidth`/`fitVisibleTables` scripts, the `<colgroup>` they build, and the sort/resizer/divider CSS intact. Use tables for specs, comparisons, parameter lists, BOMs, etc. Do not put a bare `<table>` directly in a `.sec-body`. **Non-sortable opt-out:** `<div class="table-wrap no-sort" data-desc="…">` keeps the table resizable and pinned but removes sort indicators and click-sort (live and pinned header); use it when Swami asks for a table that must not be sortable (e.g. a list converted to a table whose order matters).
- **Inline section links.** `linkSectionRefs` turns EVERY reference to a section — by name ("Surface & Temperature") or by number ("section 3", "sec. 04", "§2") — into a clickable `.secref` jump-link, everywhere in body text including inside all tables. Automatic; just write references naturally. It only skips existing links and code so nothing is double-linked, and a number with no matching section is left as plain text. **Every** section link anywhere in the body also gets the target's section number appended in square brackets — "Facing **[03]**" — which is itself a clickable jump. Two exceptions: links inside **tables in section 01** (the Dashboard Summary index already shows the number in its # column), and links whose text is already followed by that exact `[NN]` (never double it). A source citation like `[17]` is not a section number and never blocks the suffix. Supplied by the template patch.
- **Glossary section** (built into the template; sits just before References). A table titled `data-desc="Glossary of terms"` with columns **Term / Definition / Appears in / Qty**, cross-linked to the body in both directions — all automatic from the rows you write:
  - **Row markup:** `<tr data-gterm="ID" data-match="REGEX" data-code="EXACT|EXACT"><td><strong>Term</strong></td><td>Definition</td><td class="gloss-uses"></td><td class="gloss-count"></td></tr>`. `data-gterm` is a short unique kebab-case id. `data-match` is a case-insensitive regex for the term in body **text** (use `|` for alternatives and `s?` for plurals, e.g. `plugins?|plugin bundle`); start and end it with a word character so word boundaries work. `data-code` lists exact `<code>` texts that are this term, `|`-separated (e.g. `SKILL.md|skill.md`). Either matcher may be empty. Leave the last two cells empty — JS fills them. Definitions: plain text, one or two sentences, accurate.
  - **Body → glossary:** `linkGlossary` wraps the **first** mention of each term **per content section** in a dotted-underline `.gterm` (only the first, so common words don't underline dozens of times). Hover shows the term, its definition, and "(click term to go to 'Glossary')"; click jumps to the term's row and flashes it green. It skips the summary, Glossary, References and verbatim sections, headings, column headers, section links, pills/badges and callout labels.
  - **Glossary → body:** the **Appears in** cell gets one numbered `.gloss-jump` per section where the term appears, colored by that section's category. Hover previews the section (number, title, category badge), the line with the term highlighted, and the mention count in that section; click opens the section/item, scrolls the term clear of every pinned header and flashes it green.
  - **Qty:** total mentions across the content sections, repeats included (linked or not); sorts numerically. A term with no mentions shows "—" and 0 — reword its matcher or drop the row.
  - **Longest pattern wins** when terms overlap (e.g. "Claude Marketplace" beats "marketplace"); a bad regex logs a console warning and disables text matching, so a finished dashboard must show no such warning.
  - The Dashboard Summary row for the Glossary is pre-wired (`data-target-title="Glossary"`, auto-numbered, auto-dropped if the section is deleted). Mention the Glossary in the summary intro ("terms with a dotted underline jump to the Glossary") when you include one.
- **References section.** When the dashboard cites external sources, include a "References" section immediately before the verbatim section (the template ships it) with a table — columns Source / What it covers / Domain / Webpage — the Webpage cell holding the real `target="_blank"` link. One row per cited source.
- Verbatim/raw-source block — a `.verbatim-body` section with `<pre id="verbatim">`; text is injected from the `VERBATIM` JS string (kept out of markup to avoid re-parsing). Include only when preserving an original post/source; otherwise delete the block and its section.

## Self-contained files

Dashboards must be single files. For images, embed as base64 data URIs. If images are large, compress first with Python/Pillow before embedding. No external CSS/JS beyond the Google Fonts link.

## Placeholders in the template

`{{PAGE_TITLE}}` (browser tab) · `{{KICKER}}` (small cyan mono eyebrow — REQUIRED, always fill it, never leave blank or delete the element) · `{{H1_TITLE}}` + `{{H1_SUBTITLE}}` · `{{BYLINE_A/B/…}}` (author, group, post link, type — never a copyright mark; no `©`, no `© Swami`) · the REQUIRED Dashboard Summary section: `{{SUMMARY_BADGE}}` (category badge), `{{SUMMARY_INTRO}}` (what the dashboard covers), `{{SUMMARY_CALLOUT_LABEL}}` + `{{SUMMARY_CALLOUT_TEXT}}` (optional intro callout — delete the `.callout` if unused), and the "What each section covers" table rows `{{SEC_x_TITLE/FOCUS/WHEN}}` (add one row per other section, each with an empty `<td class="sec-cat"></td>` Category cell right after the Section cell — JS fills it) · per-section `{{SECTION_N_TITLE}}` + `{{BADGE_N}}` (content sections, numbered from 02) · `{{VERBATIM_TEXT}}` · `{{MAIL_SUBJECT}}` (email subject line) · the Glossary rows `{{GLOSS_x_ID/MATCH/CODE/TERM/DEF}}` (one row per term; delete the section and leave the summary row — it auto-drops — if there is nothing to define) · the References section rows `{{REF_x_SOURCE/COVERS/DOMAIN/URL/LINKTEXT}}` (one per cited source; drop the section if the dashboard cites nothing). See `references/patterns.md` for a filled example section and category-naming guidance.

## Template patch — REQUIRED (run on every fresh copy of the template)

`assets/template.html` predates two fixes. After copying it to the working directory, save this script to the scratchpad and run it on the copy (`python3 -I patch_template.py <copy>.html`). It is idempotent and asserts if an anchor is missing — if it fails, apply the same changes by hand rather than shipping an unpatched page. It provides:
1. **Pinned table header fix** — clone aligned to the live columns (no left shift), sortable by click, resizable, plus the `no-sort` opt-out.
2. **Section-number brackets** — every section link gets `[NN]`, except in section 01 tables or where already present.

```python
import sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()
def rep(old, new, label):
    global s
    if new in s: return                      # already patched
    assert old in s, 'patch anchor not found: ' + label
    s = s.replace(old, new, 1)

# 1. floating header clone: interactive + matching dividers/resizer (CSS)
rep('''    pointer-events:none;
    border-bottom:1px solid var(--cyan-line);''',
'''    pointer-events:auto;          /* clicks forward to the live header (sort / resize) */
    border-bottom:1px solid var(--cyan-line);''', 'float-head pointer-events')
rep('''  .float-head th[data-dir="asc"] .sort-ind,
  .float-head th[data-dir="desc"] .sort-ind{color:var(--cyan);opacity:1}
''', '''  .float-head th[data-dir="asc"] .sort-ind,
  .float-head th[data-dir="desc"] .sort-ind{color:var(--cyan);opacity:1}
  .float-head th{border-right:1px solid var(--cyan-line);cursor:pointer;user-select:none;overflow:hidden}
  .float-head th:last-child{border-right:none}
  .float-head th:hover{color:var(--text)}
  .float-head th .col-resizer{position:absolute;top:0;right:0;width:9px;height:100%;cursor:col-resize;z-index:3;display:flex;align-items:center;justify-content:center}
  .float-head th .col-resizer::before{content:'';width:2px;height:60%;background:var(--cyan-line);border-radius:1px}
  .float-head th .col-resizer:hover::before{background:var(--cyan);height:100%}
  /* opt-out: <div class="table-wrap no-sort"> = resizable but not sortable */
  .table-wrap.no-sort thead th,.float-head.no-sort th{cursor:default}
''', 'float-head CSS')

# 2. clone build: tag no-sort, forward clicks / resizer drags to the live header
rep('''    fh.className = 'float-head' + (wrap.classList.contains('pin-first') ? ' pin-first' : '');''',
'''    fh.className = 'float-head' + (wrap.classList.contains('pin-first') ? ' pin-first' : '') + (wrap.classList.contains('no-sort') ? ' no-sort' : '');''', 'float-head className')
rep('''    document.body.appendChild(fh);
    floatHeads.push({wrap, table, thead, fh, cloneTable:t});''',
'''    document.body.appendChild(fh);
    floatHeads.push({wrap, table, thead, fh, cloneTable:t});
    // forward interaction to the live header so the pinned clone sorts/resizes too
    const liveCells = () => [...thead.rows[0].cells];
    t.tHead.querySelectorAll('th').forEach((cth, i) => {
      cth.addEventListener('click', e => {
        if(e.target.closest('.col-resizer')) return;
        const live = liveCells()[i]; if(live) live.click();
      });
      const g = cth.querySelector('.col-resizer');
      if(g){
        g.addEventListener('mousedown', e => {
          e.preventDefault(); e.stopPropagation();
          const lg = liveCells()[i]?.querySelector('.col-resizer');
          if(lg) lg.dispatchEvent(new MouseEvent('mousedown', {bubbles:true, cancelable:true, clientX:e.clientX, clientY:e.clientY}));
        });
        g.addEventListener('dblclick', e => {
          e.stopPropagation();
          const lg = liveCells()[i]?.querySelector('.col-resizer');
          if(lg) lg.dispatchEvent(new MouseEvent('dblclick', {bubbles:true, cancelable:true}));
        });
        g.addEventListener('click', e => e.stopPropagation());
      }
    });''', 'float-head forwarding')

# 3. clone sync: same fixed layout, per-column widths and true x offset as the live table
rep('''    fh.style.top = parkTop + 'px';
    fh.style.left = wr.left + 'px';
    fh.style.width = wr.width + 'px';
    cloneTable.style.width = table.getBoundingClientRect().width + 'px';
    cloneTable.style.transform = 'translateX(' + (-wrap.scrollLeft) + 'px)'; // mirror h-scroll
    const liveTh = thead.querySelectorAll('th');
    const cloneTh = cloneTable.querySelectorAll('th');
    liveTh.forEach((th,i)=>{ if(cloneTh[i]) cloneTh[i].style.width = th.getBoundingClientRect().width + 'px'; });''',
'''    const clipLeft = wr.left + wrap.clientLeft;       // wrapper's visible client box
    fh.style.top = parkTop + 'px';
    fh.style.left = clipLeft + 'px';
    fh.style.width = wrap.clientWidth + 'px';
    const tr = table.getBoundingClientRect();
    cloneTable.style.tableLayout = 'fixed';
    cloneTable.style.width = tr.width + 'px';
    cloneTable.style.transform = 'translateX(' + (tr.left - clipLeft) + 'px)'; // true offset (h-scroll + inset)
    const liveTh = [...thead.rows[0].cells];
    let cg = cloneTable.querySelector('colgroup');
    if(!cg){ cg = document.createElement('colgroup'); liveTh.forEach(()=>cg.appendChild(document.createElement('col'))); cloneTable.insertBefore(cg, cloneTable.tHead); }
    const cloneTh = [...cloneTable.tHead.rows[0].cells];
    liveTh.forEach((th,i)=>{
      const w = th.getBoundingClientRect().width + 'px';
      if(cg.children[i]) cg.children[i].style.width = w;
      if(cloneTh[i]){ cloneTh[i].style.width = w; cloneTh[i].style.boxSizing = 'border-box'; }
    });''', 'float-head sync geometry')

# 4. no-sort opt-out in initSortableTables
rep('''    const original = [...tbody.rows];''',
'''    const original = [...tbody.rows];
    const noSort = !!table.closest('.table-wrap.no-sort');   // opt-out: no indicator / click-sort''', 'noSort flag')
rep('''      th.appendChild(ind);
''', '''      if(!noSort) th.appendChild(ind);
''', 'noSort indicator')
rep('''      th.addEventListener('click', () => {
        const cur = th.dataset.dir;''', '''      if(!noSort) th.addEventListener('click', () => {
        const cur = th.dataset.dir;''', 'noSort click')

# 5. section links: EVERY link gets [NN] (except tables in section 01, or if already present)
rep('''      const inOpening = openingP ? openingP.contains(node) : false;''',
'''      const inSummaryTable = sec === sections[0] && !!node.parentElement.closest('table');''', 'bracket scope')
rep('''        // opening-paragraph NAME links get the section number appended: Name [03]
        if(inOpening && !h.isNum){''',
'''        // every section link gets its number appended: Name [03] — except links
        // inside tables in section 01, and where the text already carries [NN]
        const numTag = '[' + secDisplayNum(h.i) + ']';
        const already = val.slice(h.e).replace(/^\\s+/, '').startsWith(numTag);
        if(!inSummaryTable && !already){''', 'bracket rule')
rep('''          b.textContent = '[' + secDisplayNum(h.i) + ']';''', '''          b.textContent = numTag;''', 'bracket text')

open(p, 'w', encoding='utf-8').write(s)
print('template patched:', p)
```

## Search scroll logic (reference)

The template's search positioning, for reference if a dashboard's script is ever rebuilt or merged. It relies on the template's existing `stack`, `matches`, `current` and `updateCount`.

```js
/* Where to scroll for a hit. Up to three sticky layers pin over the content:
   TOC/toolbar → section header → item header (+ the floating column header
   for table rows). The target line must clear every layer that will be pinned
   above the hit. A hit INSIDE a sticky header is measured from its container
   (section / item / table), whose position doesn't change when the header pins. */
function hitTarget(m){
  const h = el => el ? el.getBoundingClientRect().height : 0;
  const sec = m.closest('.section'), secHead = sec && sec.querySelector('.sec-head');
  const item = m.closest('.citem'), itemHead = item && item.querySelector('.citem-head');
  const table = m.closest('.table-wrap table');
  let anchor = m, line = h(stack);
  if(secHead && secHead.contains(m)){ anchor = sec; }
  else {
    line += h(secHead);
    if(itemHead && itemHead.contains(m)){ anchor = item; }
    else {
      line += h(itemHead);
      if(table && table.tHead && table.tHead.contains(m)) anchor = table;
      else if(table && table.tHead) line += h(table.tHead);   // floating column header
    }
  }
  return {anchor, line: line + 12};
}
let focusFix = 0;
function focusMatch(){
  matches.forEach(m=>m.classList.remove('active'));
  const m=matches[current];
  if(!m) return;
  m.classList.add('active');
  const go = smooth => {
    const {anchor, line} = hitTarget(m);
    const y = Math.max(0, anchor.getBoundingClientRect().top + window.scrollY - line);
    if(Math.abs(y - window.scrollY) > 2) window.scrollTo({top:y, behavior: smooth ? 'smooth' : 'auto'});
  };
  go(true);
  // re-check once the smooth scroll settles (table fitting / font load can shift
  // layout mid-scroll) and snap the hit exactly into place.
  const token = ++focusFix;
  const settle = () => { if(token === focusFix) go(false); };
  if('onscrollend' in window){
    window.addEventListener('scrollend', settle, {once:true});
    setTimeout(settle, 1200);                  // in case no scroll was needed
  } else setTimeout(settle, 700);
  updateCount();
}
```