---
name: "youtube-video-launch-kit"
description: "Turn a YouTube link into three published vibe dashboards (transcript, comments, launch page) using Swami's yt skills, one thread each. Use when Swami shares a video and asks for the launch kit or these three threads."
---

# YouTube video launch kit

Input: one YouTube URL. Output: three **published** vibe dashboards (artifacts, not just files), with the launch page linking to the other two.

## 1. Gather data (once, on Swami's Mac)
- YouTube is not reachable from the cloud. Ask Swami to run in Terminal:
  `ytx -c "<VIDEO_URL>"`
  This one run fetches transcript, chapters and comments into `~/yt/<VIDEO_ID>/` (including `.info.json`).
- Threads read that output through folder access to `~/yt` (already approved on Swami's device). No upload needed; just wait for Swami to say the run finished.
- As soon as Swami says the run finished (a screenshot counts), start Threads A and B in `~/yt` (device mode files) right away. Don't ask for paths or uploads, and don't confirm the files first. If a folder-approval card appears, it's a one-time approval for the project, so tell him that in one line.
- Comments refresh (on demand): Swami reruns `ytx -c` and says "refresh comments". Then republish the Comments dashboard and the launch page's Comments section to the same artifacts, and flag threads that are new since the last update. Build the Comments dashboard with one JSON data block and a 'last updated' date so this is easy.

## 2. Thread A: Transcript dashboard
- Use the `youtube-transcript` skill, then `vibe-dashboard`.
- Include chapters with timestamp links, summary, key results (chart if numeric), glossary, search, mind map, audio overview.
- Publish as an artifact.

## 3. Thread B: Comments dashboard
- Use the `youtube-comments` skill (flatten `.info.json` into threads), then `vibe-dashboard`.
- All comments threaded, tagged, translated; theme analysis; charts of any figures viewers report.
- Treat viewer claims as claims: attribute them ("viewers say..."), never restate as fact without verification.
- Publish as an artifact.

## 4. Thread C: Launch page dashboard (after A and B are published)
- Build a new vibe dashboard from the transcript and comments dashboards.
- Separate, **brief** sections: "Transcript" and "Comments", each summarizing and linking to its full dashboard (links under the title and in a Companion pages box in the summary).
- Plus overall summary, results chart, combined takeaways, audio overview.
- Place the owner-only section directly after the "Comments" section. For the owner it takes the next number and later sections shift. For everyone else, numbering has no gap: renumber headers, TOC chips, summary table, cross-links, glossary "Appears in", mind map and search filters.
- Add an owner-only **"Update comments"** section, visible only to Swami and hidden from anyone else who opens the shared page (use the artifact runtime's viewer identity, not just CSS; you MUST declare the `user: {}` capability when publishing or the owner check comes back empty and the section stays hidden; test in the real viewer, not a faked runtime). It shows the last-updated date and comment and thread counts, the exact `ytx -c "<VIDEO_URL>"` command with a copy button, the phrase "refresh comments" to send, and a checklist of what a refresh updates.
- Publish as an artifact.

## 4b. Refresh comments (when Swami says "refresh comments")
- He has already rerun `ytx -c`, so read the new `.info.json` in `~/yt/<VIDEO_ID>/`.
- Update every related dashboard and republish each one to its same artifact: the Comments dashboard (NEW tags, counts, themes, charts) and the launch page (Comments section, combined takeaways, overall summary, Update comments section).
- Re-record the audio overview of any page whose comment content changed.
- Update the transcript dashboard only if comments correct or add to a fact there (verify first).

## 5. Hand back
- Post all three artifact cards together. Remind Swami they are private until he makes them public with each page's Share button (links between pages only work for viewers once all three are public).

## Rules learned
- Every deliverable is a published vibe dashboard, never only files.
- Do not state technical facts (e.g. a product's geometry kernel) from comments alone; verify or attribute. Example: SolidCraft's kernel was Truck, now SolidCore (based on NVIDIA SMLib), never OpenCascade.
- Audio narration: write "V-Twin" as "vee twin" (two separate words). "CAD" is one word rhyming with "fad", never spelled out, including inside names. "MiniCAD" is "MIN-ee-cad", stressed on MIN. Verify each by listening. Check project memory for other pronunciations before recording.
- If a correction comes in, fix every dashboard that carries the claim and republish to the same artifact.