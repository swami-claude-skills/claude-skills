---
name: "ai-rule-review"
description: "Review a batch of proposed Fusion AI rules (issues or a candidate file) against the existing rule set: map, find conflicts and gaps, recommend fixes, and get Swami's decision."
---

# AI Rule Review

Use this skill when someone proposes rules for the Fusion AI Rules set (`swami-claude-skills/fusion-ai-rules`). A proposal can arrive as a GitHub issue from the propose-rule form, as a file, as pasted text, or as a dashboard. The goal is a clear decision from Swami and a ready pull request.

## Steps

1. **Collect the batch.** Copy each proposal verbatim into `candidates/<YYYY-MM-author-topic>/C-YYYY-MM-NN-slug.yaml`. Number C- IDs per month, never reused. Keep the author's own label (such as `#29B`) in `source.author_label`. Give each a `proposed_id`: the next free R numbers, in order. Fill in title, category, priority, rule, why, good, avoid, works and scope, and never change the author's meaning at this stage.
2. **Map each candidate** against every active rule in `rules/`. For each candidate, mark it as one of:
   - New: it covers ground no rule covers.
   - Tightens: it makes an existing rule stricter or more specific.
   - Overlaps: it says the same thing as an existing rule.
   - Conflicts: it contradicts an existing rule.
   Record conflicts in `conflicts_with` and links in `related`. Check the fiddly areas closely: parameters and math (R08, R09), mirroring and timeline order, intersect or cut intent, naming, and anything a Must rule forbids.
3. **Write up each conflict** in the batch README with a title, the IDs on both sides, a one-paragraph description quoting both texts, and 2 or 3 fix options. Recommend the option that keeps existing Must rules intact and changes the least. Note when a candidate's own example already points to a fix.
4. **Check fit.**
   - Is the priority justified? A Must should be something the AI gets wrong and that is costly.
   - Is it clear on its own, with the jargon defined?
   - Does it name Fusion features as they appear in the UI?
   - Does `works` hold for each AI? Use 1 when the rule needs the live model.
   - How long is it? Long rules push the size-limited targets down to Must only or titles only, so suggest a shorter wording when a rule runs past about 600 characters.
5. **Run the build** (`python3 build/build.py check`). It must pass with the candidates in place: a `proposed_id` can't already be taken, and every referenced ID must exist.
6. **Ask Swami once** with a decision card. The recommended option should be "accept with the recommended fixes". Other options can be an alternative fix for the biggest conflict, a partial accept, or hold. Put the details in a short message (what each fix changes) and keep working on the recommended option while waiting.
7. **Build the result on a branch** using the ai-rules-manager steps: promote, fix conflicts, choose the version bump (deprecating or rewording an existing rule is a major bump), update the changelog, page text and audio, and open a PR. The PR stays unmerged until Swami decides and the author has agreed to CC BY 4.0.
8. **When the choice differs** from the recommendation, amend the branch and say what changed.

## Optional review page

For a large batch, or when Swami wants to share the review with the author, build a Rule Review page with the vibe-dashboard skill. Include the candidates verbatim, a mapping table, the conflict cards with options, the proposed IDs, and a sign-off checklist. Izzy's Symmetry & Mirror review page is the model. Never publish private links or NDA names in anything that goes into the public repo.

## Record

After the merge, the batch README in `sources/` keeps the decisions table, and `CHANGELOG.md` names the version that took the batch. Each accepted rule also gets a test question in `tests/prompts/` (see ai-rules-manager, Tests and results).

## On Windows

Nothing runs on Swami's computer: every step happens in Claude's workspace and on GitHub, so it works the same from Windows 10 or 11.