---
name: "fusion-doc-json"
description: "Build Swami's \"Fusion Doc to JSON\" vibe page: an in-browser tool that turns a zip of a saved Autodesk Fusion product-documentation page plus its URL into operation > tabs > sections > settings JSON for another dashboard."
---

# Fusion Doc → JSON

A modified **vibe-dashboard** page that converts a saved Autodesk **Fusion** product-documentation page into structured JSON, entirely in the viewer's browser. The JSON is meant to feed another dashboard (mainly fusion-cam-settings).

The page has these sections, in this order:

| # | Section | Contents |
|---|---------|----------|
| 01 | Dashboard Summary | Standard vibe-dashboard summary: intro, "Making the zip", "How the parser reads the page", "Limits" callouts, and the "What each section covers" table (# / Section / Category / Focus / Use When; Category is filled at runtime with the section's own colored pill) |
| 02 | Search | vibe-dashboard Search patch (added by the build script) |
| 03 | Input | Zip upload (drop zone) with a "how to make the zip" hint, **Product documentation URL** field, editable dialog-group-name list, "embed images as data URIs" checkbox, convert / reset / clear buttons, status line |
| 04 | Output | Counts line, copy JSON + download .json buttons, structure preview (tab → section → settings), the JSON |
| 05 | JSON Format | Table of every field in the JSON, level by level |
| 06 | Mind Map | vibe-dashboard Mind Map patch (added by the build script) |
| 07 | Glossary | 15 terms from the `GLOSSARY` list in the build script |

Plus the audio overview player under the header. No References and no Source Document section (the page has no source text).

Canonical published copy: https://claude.ai/artifact/YVMpvz8DWUciAw9HS3w5cu. Its byline shows the version (`Runs in your browser · v1.1.0`); `GEN_VERSION` in the JSON's `generator.version` matches it. If Swami just wants the tool again and that link shows the current version, point him to it instead of rebuilding. If it shows an older version, rebuild and republish to that same URL.

## Build workflow

1. **Locate the vibe-dashboard skill:** `VIBE=$(dirname $(dirname $(find / -path '*vibe-dashboard/assets/template.html' 2>/dev/null | head -1)))`. There is no separate template step: the build script reads `$VIBE/assets/template.html` directly.
2. **Save the build script below** as `build_page.py` (scratchpad) and run it, writing the page into the working directory (not `/mnt/user-data/outputs/`):
   `python3 -I build_page.py "$VIBE" fusion-doc-json.html <workdir>`
   It replaces the template's sections with Summary / Input / Output / JSON Format, fills the Glossary, removes References and the verbatim block, defines the categories (overview cyan, input green, output yellow, format orange, reference pink) and injects the converter JS. Then it applies vibe-dashboard's table-fit, Search and Mind Map patches (extracted from vibe-dashboard's SKILL.md, so they match its current version) and saves `stress_audio.py` in `<workdir>`. It asserts if any template anchor is missing; if so, fix the anchor by hand rather than shipping a broken page.
3. **Add the audio overview** per vibe-dashboard's "Audio overview" rules: get the outline with `python3 "$VIBE/scripts/audio_overview.py" extract fusion-doc-json.html`, write `narration.txt` (each section by number then header; say "data U R I" as the voice does; follow its Pronunciation table), run `python3 <workdir>/stress_audio.py "$VIBE" audit narration.txt` and mark any wrong stress (for example `[uploaded](/ʌplˈoʊdᵻd/)`, `[download](/daʊnlˈoʊd/)` as verbs), then `python3 <workdir>/stress_audio.py "$VIBE" build fusion-doc-json.html narration.txt fusion-doc-json.html`. If the recording can't be made, follow vibe-dashboard's browser-voice fallback.
4. **Test before publishing** (Playwright + Chromium are preinstalled): load the page at 1000 px and 1440 px, `setInputFiles('#zipFile', <zip>)`, wait for `#status` to contain "Converted", check `#jsonOut` parses and the `#tree` grouping looks right, and check that `#groupNames` is unchanged (glossary terms must never match text in that list). No page errors, no table wider than its section, every summary row linked, and no glossary term with a zero count. Run vibe-dashboard's privacy check.
5. **Publish** with the Artifact tool from the working directory, `capabilities: {downloads: true}`. The download button needs it (the page hides the button when the capability is absent, and copy still works). No other capabilities. Republish to the canonical URL above.

## Using it on a zip Swami sends in chat

The deliverable is still the tool page. If he also wants the JSON file right away, run the page headlessly on his zip (step 4), save `#jsonOut` to `<operation-slug>-settings.json`, and send it with SendUserFile. Fill the URL field (`#docUrl`) first if he gave one; otherwise the page takes it from the saved file's `saved from url` comment.

## Making the zip (any OS)

Any browser that can save a complete page works (Chrome, Edge, Firefox, or Comet, which Swami uses): **File › Save Page As… › Webpage, Complete** (Ctrl+S on Windows). That writes an `.html` file and a `_files` folder. Zip both: on macOS select them in Finder › right-click › Compress 2 Items; on Windows select them in File Explorer › right-click › Compress to ZIP file (Windows 11) or Send to › Compressed (zipped) folder (Windows 10). Safari can't do this (it saves a web archive), so don't suggest it.

## How the parser works (keep in sync with the JS)

- Unzips with a built-in central-directory reader + `DecompressionStream('deflate-raw')` — no libraries; ignores `__MACOSX/` and `._` files. Picks the `.html` that has a matching `_files/` folder.
- Content root: `.body_content` → `.caas_body` → `article` → `main` → `body`. Stops at "Pages in this section" / "Parent page".
- `h1` → operation name/title. Paragraphs before the first heading → summary, menu path (`A > B > C`), description, images.
- Heading ending in **"tab settings"** (or "tab") → new tab; the first image under it → `screenshot`, an icon inside the heading → `icon`.
- Heading in the **dialog group name list** → new section in that tab (a repeated name reuses the section).
- Generic headings ("Settings", "Parameters", "Options") → each following bullet becomes its own setting.
- Any other heading → setting (in a default section named after the tab if no group heading came first).
- Under a setting: first paragraph → `description`, others → `notes`; bullets `Name - description` → `options` (with image); a short text right after an image → that image's caption; a short label paragraph followed by a paragraph → `details[{label,text}]`; image tables → images captioned from the next row; `div.note` → notes.
- "The X drop-down…" paragraph at group level → a setting named X that owns the bullets after it.
- `controlGuess` is inferred from the description (dropdown / checkbox / selection / number / unknown).

## JSON shape

```
{ operation: {name, title, pageTitle, url, summary, menuPath, description[], images[], links[], relatedPages[], parentPage},
  schema, generator: {name, version, generatedAt, sourceZip, htmlFile, groupNames[]},
  counts: {tabs, sections, settings, images},
  tabs: [ {id, name, icon, screenshot, notes[],
     sections: [ {name, description, hasEnableCheckbox, notes[], images[],
        settings: [ {name, controlGuess, description, notes[], options[{name, description, image}], details[{label, text}], images[{file, caption, dataUri?}], links[{text, href}]} ] } ] } ] }
```
Empty arrays are omitted. `images[].file` is the original filename in the zip; `dataUri` only when embedding is on; `missingFromZip: true` flags an image the zip lacks.

## Known limits (state them if Swami asks why a grouping is off)

The help page doesn't record which dialog group a setting sits in, so sections come only from headings that match the group-name list (editable in Input; e.g. Parallel's "Leads & Transitions" has no heading, so its settings land in Linking). Dialog example values live only in screenshots and aren't extracted. Tested on the Parallel Finishing reference: 5 tabs · 14 sections · 74 settings · 67 images.

## Design rules

Everything from vibe-dashboard's locked design system applies (palette, fonts, sticky stack, Search section, Mind Map, Glossary, audio overview, footer `Vibe Coding: Swami · AI: Claude`, runtime mailto, collapsed sections, data-target navigation). Add no sections beyond those listed above. The Input/Output panels use `.io-panel` (not callout/resource/table) so they stay visible instead of being wrapped in collapsible items.

## build_page.py

```python
"""Build the "Fusion Doc → JSON" vibe page straight from the vibe-dashboard template.
usage: python3 -I build_page.py VIBE_DIR OUT.html [WORKDIR]
  VIBE_DIR  the vibe-dashboard skill folder (assets/template.html, scripts/search_patch.py, SKILL.md)
  WORKDIR   where vibe-dashboard's patch helpers and stress_audio.py are saved (default: OUT's folder)
Sections: Dashboard Summary · Search · Input · Output · JSON Format · Mind Map · Glossary.
Applies vibe-dashboard's table-fit, Search and Mind Map patches (extracted from its SKILL.md, so they
always match the current skill). The audio overview is added afterwards (see SKILL.md)."""
import sys, re, os, html, subprocess

VIBE, out = sys.argv[1], sys.argv[2]
WD = sys.argv[3] if len(sys.argv) > 3 else os.path.dirname(os.path.abspath(out))
s = open(os.path.join(VIBE, 'assets', 'template.html'), encoding='utf-8').read()

CATS = [('overview', '#38dafa', '56,218,250', 'OVERVIEW'),
        ('input', '#38fa79', '56,250,121', 'INPUT'),
        ('output', '#dafa38', '218,250,56', 'OUTPUT'),
        ('format', '#fa9938', '250,153,56', 'FORMAT'),
        ('reference', '#fa3899', '250,56,153', 'REFERENCE')]

DEFAULT_GROUPS = ("Tool, Feed & Speed, Shaft & Holder, Geometry, Slope, Rest Machining, Tool Orientation, Model, "
                  "Avoid/Touch Surfaces, Stock Contours, Clearance Height, Retract Height, Feed Height, Top Height, "
                  "Bottom Height, Passes, Stock to Leave, Fillets, Smoothing, Feed Optimization, Linking, "
                  "Leads & Transitions, Ramp, Positions, Lead-In, Lead-Out, Transitions, Roughing Passes, Finishing Passes")

SECTIONS = '''  <div class="section cat-overview" data-title="Dashboard Summary" data-cat="overview">
    <div class="sec-head"><span class="sec-num">01</span><span class="sec-title">Dashboard Summary</span><span class="cat-badge">OVERVIEW</span><span class="chevron">▶</span></div>
    <div class="sec-body">
      <p>Converts a saved page of Autodesk <strong>Fusion product documentation</strong> (a help-page zip) into structured JSON: <strong>operation → tabs → sections → settings</strong>. Upload the zip and confirm the page URL in Input; the JSON appears in Output, ready to copy or download and feed into another dashboard. Everything runs in your browser — nothing is uploaded anywhere.</p>
      <div class="callout"><span class="lbl">Making the zip</span>Open the Fusion help page in any browser that can save a complete page (Chrome, Edge, Firefox, Comet…) → <strong>File › Save Page As… › Webpage, Complete</strong>. Safari saves a web archive instead, which this page can’t read. That writes an <strong>.html</strong> file plus a <strong>_files</strong> folder of images. Zip both together and upload the zip in Input.</div>
      <div class="callout"><span class="lbl">How the parser reads the page</span>Headings ending in <strong>"tab settings"</strong> start a tab. Headings matching a <strong>dialog group name</strong> (editable list in Input) start a section inside that tab. Every other heading is a setting; the paragraphs, bullet options (<em>Name - description</em>), images and captions under it are attached to that setting. Settings before any group heading go into a section named after the tab. A generic heading such as "Settings" splits its bullets into separate settings.</div>
      <div class="callout"><span class="lbl">Limits</span>The help page doesn't say which dialog group each setting lives in, so sections come from the group-name list — check the structure preview in Output and edit the list if a group is missing or wrong. Control types are guesses (<strong>controlGuess</strong>). Dialog example values aren't in the page text, so they aren't extracted.</div>
      <div class="table-wrap" data-desc="What each section covers">
        <table>
          <thead><tr><th>#</th><th>Section</th><th>Category</th><th>Focus</th><th>Use When</th></tr></thead>
          <tbody>
            <tr><td><span class="secnum">01</span></td><td><strong>Dashboard Summary</strong></td><td class="sec-cat"></td><td>This overview, how to make the zip, how parsing works</td><td>Getting oriented</td></tr>
            <tr><td><span class="secnum">02</span></td><td><strong>Input</strong></td><td class="sec-cat"></td><td>Zip upload, documentation URL, dialog group names, image embedding</td><td>Converting a page</td></tr>
            <tr><td><span class="secnum">03</span></td><td><strong>Output</strong></td><td class="sec-cat"></td><td>Generated JSON, structure preview, copy and download</td><td>Taking the JSON to another dashboard</td></tr>
            <tr><td><span class="secnum">04</span></td><td><strong>JSON Format</strong></td><td class="sec-cat"></td><td>Every field the JSON holds, level by level</td><td>Reading the JSON or building on it</td></tr>
            <tr><td><span class="secnum" data-target-title="Glossary"></span></td><td><strong>Glossary</strong></td><td class="sec-cat"></td><td>Term definitions with jump links both ways</td><td>A term is unfamiliar, or you want every place it's used</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="section cat-input" data-title="Input" data-cat="input">
    <div class="sec-head"><span class="sec-num">02</span><span class="sec-title">Input</span><span class="cat-badge">INPUT</span><span class="chevron">▶</span></div>
    <div class="sec-body">
      <div class="io-panel">
        <label class="fld-lbl" for="zipFile">Documentation zip</label>
        <label class="drop" id="drop"><input type="file" id="zipFile" accept=".zip,application/zip"><span id="dropTxt">Drop a .zip here or click to choose</span></label>
        <div class="fld-hint">Save the help page as Webpage, Complete, then zip the .html file together with its <code>_files</code> folder of images.</div>
        <label class="fld-lbl" for="docUrl">Product documentation URL</label>
        <input class="fld" id="docUrl" type="url" placeholder="https://help.autodesk.com/view/fusion360/ENU/?guid=…" autocomplete="off">
        <div class="fld-hint">Filled automatically from the saved page's "saved from url" line when left blank. Edit to override.</div>
        <label class="fld-lbl" for="groupNames">Dialog group names <span class="fld-hint-inline">(comma separated — headings with these names start a new section)</span></label>
        <textarea class="fld" id="groupNames" rows="4">''' + DEFAULT_GROUPS + '''</textarea>
        <div class="row-btns">
          <label class="chk"><input type="checkbox" id="embedImgs"> Embed images as data URIs (larger JSON, fully self-contained)</label>
        </div>
        <div class="row-btns">
          <button class="tool-btn act" id="convertBtn" type="button" disabled>convert → JSON</button>
          <button class="tool-btn" id="resetGroups" type="button">reset group names</button>
          <button class="tool-btn" id="clearAll" type="button">clear</button>
        </div>
        <div class="status" id="status">No zip loaded.</div>
      </div>
    </div>
  </div>

  <div class="section cat-output" data-title="Output" data-cat="output">
    <div class="sec-head"><span class="sec-num">03</span><span class="sec-title">Output</span><span class="cat-badge">OUTPUT</span><span class="chevron">▶</span></div>
    <div class="sec-body">
      <div class="io-panel">
        <div class="stats" id="stats">Nothing converted yet — load a zip in Input.</div>
        <div class="row-btns">
          <button class="tool-btn" id="copyBtn" type="button" disabled>copy JSON</button>
          <button class="tool-btn" id="dlBtn" type="button" disabled hidden>download .json</button>
          <span class="copy-msg" id="outMsg"></span>
        </div>
        <div class="fld-lbl">Structure preview</div>
        <div class="tree" id="tree"><span class="muted">—</span></div>
        <div class="fld-lbl">JSON</div>
        <pre class="json-pre" id="jsonOut">{}</pre>
      </div>
    </div>
  </div>

  <div class="section cat-format" data-title="JSON Format" data-cat="format">
    <div class="sec-head"><span class="sec-num">04</span><span class="sec-title">JSON Format</span><span class="cat-badge">FORMAT</span><span class="chevron">▶</span></div>
    <div class="sec-body">
      <p>The JSON nests four levels: one <strong>operation</strong>, its <strong>tabs</strong>, each tab's dialog group <strong>sections</strong>, and each section's <strong>settings</strong>. Empty lists are left out, so a field missing from a setting simply means the help page had nothing for it.</p>
      <div class="table-wrap" data-desc="Fields in the JSON">
        <table>
          <thead><tr><th>Field</th><th>Level</th><th>What it holds</th></tr></thead>
          <tbody>
            <tr><td><code>operation</code></td><td>Top</td><td>The command or toolpath: name, title, page title, documentation URL, summary, menu path, description paragraphs, images, links, related pages and parent page.</td></tr>
            <tr><td><code>tabs[]</code></td><td>Top</td><td>One entry per dialog tab (a heading ending in "tab settings"), with its name, icon, screenshot and notes.</td></tr>
            <tr><td><code>sections[]</code></td><td>Tab</td><td>One entry per dialog group heading found in the group-name list, with a description, notes, images, and <code>hasEnableCheckbox</code> when the group is switched on by a checkbox.</td></tr>
            <tr><td><code>settings[]</code></td><td>Section</td><td>One entry per setting: its name, description, notes, options, details, images and links.</td></tr>
            <tr><td><code>controlGuess</code></td><td>Setting</td><td>The likely control type (dropdown, checkbox, selection, number or unknown), guessed from the description.</td></tr>
            <tr><td><code>options[]</code></td><td>Setting</td><td>Choices from "Name - description" bullets, each with an optional image.</td></tr>
            <tr><td><code>details[]</code></td><td>Setting</td><td>Short label and paragraph pairs found under a setting, often one per choice.</td></tr>
            <tr><td><code>images[]</code></td><td>Any</td><td>Each image's original file name in the zip and its caption, plus a data URI when embedding is on.</td></tr>
            <tr><td><code>missingFromZip</code></td><td>Image</td><td>Marks an image the help page used but the zip doesn't contain.</td></tr>
            <tr><td><code>counts</code></td><td>Top</td><td>How many tabs, sections, settings and images were found.</td></tr>
            <tr><td><code>generator</code></td><td>Top</td><td>Tool name and version, time of conversion, zip and .html file names, and the dialog group names used.</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

'''

GLOSSARY = [
  # (term, match regex, exact <code> texts, definition)
  ('Fusion help page', 'help pages?', '', "Autodesk's product-documentation web page for one Fusion command or toolpath."),
  ('Webpage, Complete', 'Webpage, Complete', '', "The browser's save option that writes the page's .html file plus a _files folder of its images."),
  ('_files folder', '', '_files', 'The folder of images the browser saves next to the .html file.'),
  ('Zip', 'zips?', '', 'One compressed file holding the saved .html file and its _files folder.'),
  ('Documentation URL', 'documentation URL', '', 'The web address of the help page, kept in the JSON so other dashboards can link to it.'),
  ('Dialog group names', 'dialog group names?', '', 'The editable list of group headings that start a new section in the JSON.'),
  ('JSON', 'JSON', '', 'A plain-text data format; this page writes the help page as nested JSON for other dashboards to read.'),
  ('Operation', 'operation', 'operation', 'The command or toolpath the help page documents; the top level of the JSON.'),
  ('Tab', 'tabs?', 'tabs[]', 'One page of the Fusion dialog; a heading ending in "tab settings" starts one.'),
  ('Setting', 'settings?', 'settings[]', 'One control in the dialog, with its description, options, notes and images.'),
  ('controlGuess', '', 'controlGuess', "The page's guess at a setting's control type: dropdown, checkbox, selection, number or unknown."),
  ('Option', 'options?', 'options[]', 'One choice of a setting, taken from a "Name - description" bullet.'),
  ('Data URI', 'data URIs?', '', 'An image written into the JSON as text, so the JSON works without the zip.'),
  ('missingFromZip', '', 'missingFromZip', 'A flag on an image the help page used but the zip lacks.'),
  ('Structure preview', 'structure preview', '', 'The tab, section and settings outline shown in Output for a quick check.'),
]

CSS = '''
  /* ---- Fusion Doc → JSON: input / output panels ---- */
  .io-panel{padding:14px 0 4px}
  .fld-lbl{display:block;font-family:var(--mono);font-size:10.5px;letter-spacing:2px;text-transform:uppercase;color:var(--cyan);margin:16px 0 7px}
  .fld-hint-inline{letter-spacing:0;text-transform:none;color:var(--text-mute)}
  .fld{width:100%;background:var(--panel-2);border:1px solid var(--border);color:var(--text);font-family:var(--mono);font-size:12.5px;padding:9px 12px;border-radius:6px;outline:none;resize:vertical}
  .fld:focus{border-color:var(--cyan);box-shadow:0 0 0 2px var(--cyan-dim)}
  .fld-hint{font-size:12px;color:var(--text-mute);margin-top:5px}
  .drop{display:flex;align-items:center;justify-content:center;min-height:86px;border:1.5px dashed var(--cyan-line);border-radius:8px;background:var(--panel-2);color:var(--text-dim);font-family:var(--mono);font-size:12.5px;cursor:pointer;text-align:center;padding:14px}
  .drop:hover,.drop.over{border-color:var(--cyan);color:var(--cyan);background:rgba(0,229,255,.05)}
  .drop input{display:none}
  .row-btns{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:14px}
  .tool-btn.act{border-color:var(--cyan-line);color:var(--cyan)}
  .tool-btn:disabled{opacity:.4;cursor:not-allowed}
  .chk{font-size:13px;color:var(--text-dim);display:flex;gap:8px;align-items:center;cursor:pointer}
  .chk input{accent-color:var(--cyan)}
  .status{margin-top:14px;font-family:var(--mono);font-size:12px;color:var(--text-dim);white-space:pre-wrap;background:var(--panel-2);border:1px solid var(--border);border-radius:6px;padding:10px 12px}
  .status.err{color:#fa3899;border-color:rgba(250,56,153,.4)}
  .status.ok{color:var(--green)}
  .stats{font-family:var(--mono);font-size:12.5px;color:var(--text)}
  .copy-msg{font-family:var(--mono);font-size:11px;color:var(--green)}
  .tree{font-size:13px;color:var(--text-dim);background:var(--panel-2);border:1px solid var(--border);border-radius:7px;padding:10px 14px;max-height:420px;overflow:auto}
  .tree .t-tab{font-family:var(--mono);color:var(--cyan);margin-top:8px}
  .tree .t-tab:first-child{margin-top:0}
  .tree .t-sec{padding-left:16px;color:var(--text)}
  .tree .t-set{padding-left:32px;font-size:12.5px;color:var(--text-dim)}
  .tree .muted{color:var(--text-mute)}
  .json-pre{font-family:var(--mono);font-size:11.5px;line-height:1.55;color:var(--text-dim);background:var(--bg);border:1px solid var(--border);border-radius:7px;padding:14px;max-height:620px;overflow:auto;white-space:pre}
</style>'''

JS = r'''
/* ================= Fusion Doc → JSON converter (runs entirely in the browser) ================= */
const GEN_VERSION = '1.1.0';
const DEFAULT_GROUPS = document.getElementById('groupNames').value;
const $ = id => document.getElementById(id);
let zipEntries = null, zipName = '', outJSON = '', outObj = null;

/* ---- minimal ZIP reader: central directory + DecompressionStream('deflate-raw') ---- */
async function readZip(file){
  const buf = await file.arrayBuffer(), dv = new DataView(buf), u8 = new Uint8Array(buf);
  let eocd = -1;
  for(let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 65557); i--){
    if(dv.getUint32(i, true) === 0x06054b50){ eocd = i; break; }
  }
  if(eocd < 0) throw new Error('Not a zip file (no end-of-central-directory record).');
  const count = dv.getUint16(eocd + 10, true);
  let p = dv.getUint32(eocd + 16, true);
  const dec = new TextDecoder('utf-8'), entries = [];
  for(let n = 0; n < count; n++){
    if(dv.getUint32(p, true) !== 0x02014b50) throw new Error('Corrupt zip central directory.');
    const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true);
    const nlen = dv.getUint16(p + 28, true), xlen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true);
    const loff = dv.getUint32(p + 42, true);
    const name = dec.decode(u8.subarray(p + 46, p + 46 + nlen));
    p += 46 + nlen + xlen + clen;
    if(name.endsWith('/') || name.startsWith('__MACOSX/') || /(^|\/)\._/.test(name)) continue;
    const dstart = loff + 30 + dv.getUint16(loff + 26, true) + dv.getUint16(loff + 28, true);
    const raw = u8.subarray(dstart, dstart + csize);
    entries.push({name, base: name.split('/').pop(), method, bytes: async () => {
      if(method === 0) return raw.slice();
      if(method !== 8) throw new Error('Unsupported zip compression in ' + name);
      if(typeof DecompressionStream === 'undefined') throw new Error('This browser cannot unzip (no DecompressionStream). Use a current Chrome, Edge, Safari or Firefox.');
      const st = new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
      return new Uint8Array(await new Response(st).arrayBuffer());
    }});
  }
  return entries;
}

/* ---- helpers ---- */
const clean = t => (t || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
const norm = t => clean(t).toLowerCase().replace(/&amp;/g, '&').replace(/\band\b/g, '&').replace(/\s*&\s*/g, '&').replace(/\s*\/\s*/g, '/');
const slug = t => clean(t).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'item';
const MIME = {png:'image/png', jpg:'image/jpeg', jpeg:'image/jpeg', gif:'image/gif', svg:'image/svg+xml', webp:'image/webp'};
function b64(u8){ let s = ''; for(let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
function imgFile(img){
  const src = img.getAttribute('src') || img.getAttribute('data-src') || '';
  let f = src.split(/[?#]/)[0].split('/').pop();
  try{ f = decodeURIComponent(f); }catch(_){}
  return f;
}
function guessControl(st){
  const d = (st.description || '').toLowerCase();
  if(st.options && st.options.length > 1) return 'dropdown';
  if(/^(enable|when enabled|select to|check to|turn on|controls whether)/.test(d) || /\benable (this|to)\b/.test(d)) return 'checkbox';
  if(/selection button|^select (a|the|one)|lets you (select|specify surfaces)/.test(d)) return 'selection';
  if(/(distance|radius|angle|feedrate|feed rate|stepover|stepdown|diameter|length|tolerance|amount|number of|speed|clearance|height|offset|depth)/.test(d)) return 'number';
  return 'unknown';
}
const GENERIC = new Set(['settings', 'parameters', 'options']);

/* ---- flatten the content root into an ordered block list ---- */
function flatten(root){
  const blocks = [];
  const SKIPCLS = /related-links|familylinks|feedback|breadcrumb|helpful/;
  (function walk(el){
    for(const c of el.children){
      const tag = c.tagName, cls = c.className && c.className.baseVal === undefined ? c.className : '';
      if(SKIPCLS.test(cls)) continue;
      if(/^H[1-6]$/.test(tag)) blocks.push({k:'h', lvl:+tag[1], el:c});
      else if(tag === 'P' || tag === 'FIGCAPTION' || tag === 'PRE') blocks.push({k:'p', el:c});
      else if(tag === 'UL' || tag === 'OL') { for(const li of c.children) if(li.tagName === 'LI') blocks.push({k:'li', el:li}); }
      else if(tag === 'DL') { for(const dt of c.querySelectorAll('dt')) blocks.push({k:'li', el:dt, dd:dt.nextElementSibling}); }
      else if(tag === 'TABLE') blocks.push({k:'table', el:c});
      else if(tag === 'IMG') blocks.push({k:'p', el:c});
      else if(tag === 'DIV' && /\bnote\b/.test(cls)) blocks.push({k:'note', el:c});
      else if(!/^(SCRIPT|STYLE|NOSCRIPT|BUTTON|FORM|NAV)$/.test(tag)) walk(c);
    }
  })(root);
  return blocks;
}

/* ---- main conversion ---- */
async function convert(){
  const status = $('status');
  try{
    if(!zipEntries) throw new Error('Load a zip first.');
    const htmls = zipEntries.filter(e => /\.html?$/i.test(e.name));
    if(!htmls.length) throw new Error('No .html file found in the zip. Save the page as "Webpage, Complete" and zip the .html with its _files folder.');
    // prefer the html sitting next to a matching _files folder, else the largest
    let htmlE = htmls.find(h => zipEntries.some(e => e.name.startsWith(h.name.replace(/\.html?$/i, '') + '_files/'))) || htmls[0];
    const raw = await htmlE.bytes();
    let text = new TextDecoder('utf-8').decode(raw);
    const cs = (text.slice(0, 2048).match(/charset=["']?([\w-]+)/i) || [])[1];
    if(cs && !/utf-?8/i.test(cs)){ try{ text = new TextDecoder(cs).decode(raw); }catch(_){} }
    const doc = new DOMParser().parseFromString(text, 'text/html');

    // URL: field → "saved from url" → canonical
    let url = clean($('docUrl').value);
    const saved = (text.match(/saved from url=\(\d+\)(\S+?)\s*-->/) || [])[1];
    const canon = doc.querySelector('link[rel="canonical"]')?.getAttribute('href');
    if(!url && (saved || canon)){ url = saved || canon; $('docUrl').value = url; }

    const groupSet = new Set($('groupNames').value.split(',').map(norm).filter(Boolean));
    const embed = $('embedImgs').checked;
    const byBase = new Map(zipEntries.map(e => [e.base, e]));
    const imgCache = new Map();
    async function imgObj(img, caption){
      const file = imgFile(img);
      const o = {file, caption: clean(caption || img.getAttribute('alt') || '')};
      if(!o.caption) delete o.caption;
      if(embed && byBase.has(file)){
        if(!imgCache.has(file)){
          const ext = file.split('.').pop().toLowerCase();
          imgCache.set(file, 'data:' + (MIME[ext] || 'application/octet-stream') + ';base64,' + b64(await byBase.get(file).bytes()));
        }
        o.dataUri = imgCache.get(file);
      }
      if(!byBase.has(file)) o.missingFromZip = true;
      return o;
    }
    const linksOf = el => [...el.querySelectorAll('a[href]')].map(a => ({text: clean(a.textContent), href: a.href.startsWith('http') ? a.href : (a.getAttribute('href') || '')}))
      .filter(l => l.text && /^https?:/.test(l.href));

    const root = doc.querySelector('.body_content') || doc.querySelector('.caas_body') || doc.querySelector('article') || doc.querySelector('main') || doc.body;
    const h1 = doc.querySelector('h1');
    const op = {
      name: clean(h1?.textContent).replace(/\s+reference$/i, ''),
      title: clean(h1?.textContent) || clean(doc.title),
      pageTitle: clean(doc.title),
      url,
      summary: '', menuPath: '', description: [], images: [], links: [],
      relatedPages: [...doc.querySelectorAll('.related-links li a, .relinfo a')].map(a => clean(a.textContent)).filter(Boolean),
      parentPage: clean(doc.querySelector('.parentLink a, .parentlink a')?.textContent) || ''
    };
    const tabs = [];
    let tab = null, sec = null, set = null, lastImg = null, lastImgOwner = null, pendingLabel = null;

    const newTab = (name, el) => { tab = {id: slug(name), name, icon: null, screenshot: null, notes: [], sections: []}; tabs.push(tab); sec = null; set = null;
      const ic = el.querySelector('img'); if(ic) tab._icon = ic; };
    const ensureTab = () => { if(!tab) newTab('General', document.createElement('div')); };
    const getSec = name => { ensureTab(); let s2 = tab.sections.find(x => norm(x.name) === norm(name));
      if(!s2){ s2 = {name, hasEnableCheckbox: null, description: '', notes: [], images: [], settings: []}; tab.sections.push(s2); } return s2; };
    const newSetting = name => { if(!sec) sec = getSec(tab.name);
      let st = sec.settings.find(x => norm(x.name) === norm(name));
      if(!st){ st = {name, controlGuess: 'unknown', description: '', notes: [], options: [], details: [], images: [], links: []}; sec.settings.push(st); }
      set = st; return st; };
    // where loose content goes right now
    const owner = () => set || sec || tab || null;

    function addText(t, el){
      const o = owner();
      if(!o){ // before first heading after h1 → operation
        if(!op.summary) op.summary = t;
        else if(/\s>\s/.test(t) && t.length < 140 && !op.menuPath) op.menuPath = t;
        else op.description.push(t);
        op.links.push(...linksOf(el)); return;
      }
      if(o.settings && !o.description && o === sec){ sec.description = t; return; }
      if('description' in o && !o.description && o !== tab) { o.description = t; }
      else (o.notes || (o.notes = [])).push(t);
      if(o.links) o.links.push(...linksOf(el));
    }

    for(const b of flatten(root)){
      const el = b.el;
      if(b.k === 'h'){
        const t = clean(el.textContent);
        if(!t || b.lvl === 1) continue;
        if(/^pages in this section|^parent page/i.test(t)) break;
        lastImg = null; pendingLabel = null;
        const tm = t.match(/^(.*?)\s+tab(\s+settings?)?$/i);
        if(tm){ newTab(tm[1], el); continue; }
        ensureTab();
        if(groupSet.has(norm(t))){ sec = getSec(t); set = null; continue; }
        if(GENERIC.has(norm(t))){ set = null; sec && (sec._generic = true); if(!sec) sec = getSec(tab.name), sec._generic = true; continue; }
        if(sec) sec._generic = false;
        newSetting(t); continue;
      }
      if(b.k === 'p'){
        const imgs = el.tagName === 'IMG' ? [el] : [...el.querySelectorAll('img')];
        const t = clean(el.textContent);
        if(imgs.length){
          const o = owner();
          for(const im of imgs){
            const io = await imgObj(im, t || '');
            if(!o){ op.images.push(io); if(!op.menuPath && /\S\s>\s\S/.test(t)) op.menuPath = t; continue; }
            if(o === tab && !tab.screenshot && !tab.sections.length){ tab.screenshot = io; continue; }
            if(o.images) o.images.push(io); else (o.images = [io]);
            lastImg = t ? null : io; lastImgOwner = o;
          }
          continue;
        }
        if(!t) continue;
        // short text right after an uncaptioned image = its caption
        if(lastImg && t.length <= 70 && !/[.:]$/.test(t)){ lastImg.caption = t; lastImg = null; pendingLabel = null; continue; }
        lastImg = null;
        if(set && t.length <= 40 && !/[.:,;]$/.test(t) && t.split(' ').length <= 5){ pendingLabel = t; continue; }
        if(set && pendingLabel){ set.details.push({label: pendingLabel, text: t}); pendingLabel = null; continue; }
        const o = owner();
        if(o && o.images && t.length <= 40 && !/[.:]$/.test(t) && o.images.some(i => i.caption === t)) continue; // duplicate caption
        // "The Orientation drop-down menu provides…" at group level → a setting owning the bullets that follow
        const dd = t.match(/\bthe\s+(.{2,40}?)\s+drop-?down\b/i);
        if(dd && tab && (!set || set._dd)){ const st = newSetting(dd[1].replace(/^\w/, ch => ch.toUpperCase())); st._dd = true;
          if(!st.description) st.description = t; else st.notes.push(t); continue; }
        addText(t, el); continue;
      }
      if(b.k === 'li'){
        lastImg = null;
        const liImgs = [...el.querySelectorAll('img')];
        const cl = el.cloneNode(true); let liCap = '';
        for(const im of [...cl.querySelectorAll('img')]){
          const box = im.closest('p,figure,div') && cl.contains(im.closest('p,figure,div')) && im.closest('p,figure,div') !== cl ? im.closest('p,figure,div') : im;
          liCap = liCap || clean(box.textContent); box.remove();
        }
        let t = clean(b.dd ? cl.textContent + ' - ' + b.dd.textContent : cl.textContent);
        // first-level text only for the option name split
        const m = t.match(/^(.{1,80}?)\s+[-–—:]\s+(.+)$/);
        const opt = m ? {name: m[1], description: m[2]} : {name: t};
        if(liImgs.length) opt.image = await imgObj(liImgs[0], liCap || opt.name);
        if(sec && sec._generic){ // generic heading: each bullet is its own setting
          const st = newSetting(opt.name); if(opt.description && !st.description) st.description = opt.description;
          if(opt.image) st.images.push(opt.image); set = null; continue;
        }
        const o = owner();
        if(!o){ op.description.push(t); continue; }
        if(o === tab || o === sec){ // bullets directly under a tab or group heading = one setting each
          if(o === tab) sec = getSec(tab.name);
          const st = newSetting(opt.name); if(opt.description && !st.description) st.description = opt.description;
          if(opt.image) st.images.push(opt.image); set = null; continue;
        }
        (o.options || (o.options = [])).push(opt);
        continue;
      }
      if(b.k === 'table'){
        lastImg = null;
        const rows = [...el.rows].map(r => [...r.cells]);
        const o = owner() || op;
        let handled = false;
        for(let r = 0; r < rows.length; r++){
          const imgsRow = rows[r].map(c => c.querySelector('img'));
          if(imgsRow.some(Boolean)){
            handled = true;
            for(let c = 0; c < imgsRow.length; c++){
              if(!imgsRow[c]) continue;
              const cap = clean(rows[r][c].textContent) || clean(rows[r + 1]?.[c]?.textContent);
              (o.images || (o.images = [])).push(await imgObj(imgsRow[c], cap));
            }
            r++; // caption row consumed
          }
        }
        if(!handled){
          const lines = rows.map(r => r.map(c => clean(c.textContent)).filter(Boolean).join(' | ')).filter(Boolean);
          if(lines.length) (o.notes || (o.notes = [])).push(...lines);
        }
        continue;
      }
      if(b.k === 'note'){
        const t = clean(el.textContent);
        if(t){ const o = owner() || op; (o.notes || (o.notes = [])).push(t); }
      }
    }

    // finalize
    let nSec = 0, nSet = 0, nImg = op.images.length;
    for(const t of tabs){
      if(t._icon){ t.icon = await imgObj(t._icon, t.name + ' tab icon'); delete t._icon; }
      for(const s2 of t.sections){
        delete s2._generic;
        s2.hasEnableCheckbox = /^(enable|when enabled)/i.test(s2.description) ? true : null;
        nImg += s2.images.length;
        for(const st of s2.settings){
          delete st._dd;
          st.controlGuess = guessControl(st);
          nImg += st.images.length + st.options.filter(o2 => o2.image).length;
          for(const k of ['notes', 'options', 'details', 'images', 'links']) if(!st[k].length) delete st[k];
        }
        for(const k of ['notes', 'images']) if(!s2[k].length) delete s2[k];
        if(!s2.description) delete s2.description;
        if(s2.hasEnableCheckbox === null) delete s2.hasEnableCheckbox;
        nSec++; nSet += s2.settings.length;
      }
      if(!t.notes.length) delete t.notes;
    }
    if(!op.links.length) delete op.links;
    if(!url) op.url = '';

    outObj = {
      operation: op,
      schema: 'operation > tabs[] > sections[] > settings[]. controlGuess is inferred from the description text. details[] = short label + paragraph pairs found under a setting (often per-option explanations). images[].file = original filename in the zip; dataUri present only when embedding was on.',
      generator: {name: 'Fusion Doc → JSON', version: GEN_VERSION, generatedAt: new Date().toISOString(), sourceZip: zipName, htmlFile: htmlE.name, groupNames: [...groupSet]},
      counts: {tabs: tabs.length, sections: nSec, settings: nSet, images: nImg},
      tabs
    };
    outJSON = JSON.stringify(outObj, null, 2);
    renderOutput();
    status.className = 'status ok';
    status.textContent = '✓ Converted ' + htmlE.name + '\n' + tabs.length + ' tabs · ' + nSec + ' sections · ' + nSet + ' settings · ' + nImg + ' images' + (url ? '' : '\n⚠ No documentation URL — add it above and convert again.');
    openSection('Output');
  }catch(err){
    status.className = 'status err';
    status.textContent = '✗ ' + (err && err.message || err);
  }
}

function renderOutput(){
  const c = outObj.counts, op = outObj.operation;
  $('stats').textContent = (op.title || 'Untitled') + ' — ' + c.tabs + ' tabs · ' + c.sections + ' sections · ' + c.settings + ' settings · ' + c.images + ' images · ' + (new Blob([outJSON]).size / 1024).toFixed(1) + ' KB';
  $('jsonOut').textContent = outJSON;
  const tree = $('tree'); tree.textContent = '';
  const line = (cls, txt) => { const d = document.createElement('div'); d.className = cls; d.textContent = txt; tree.appendChild(d); };
  if(!outObj.tabs.length) line('muted', 'No tabs or settings found.');
  for(const t of outObj.tabs){
    line('t-tab', '▸ ' + t.name + ' tab' + (t.screenshot ? '  [screenshot]' : ''));
    for(const s2 of t.sections){
      line('t-sec', s2.name + '  (' + s2.settings.length + ')');
      line('t-set', s2.settings.map(x => x.name).join(' · ') || '—');
    }
  }
  $('copyBtn').disabled = false;
  $('dlBtn').disabled = false;
}

function openSection(title){
  const s2 = [...document.querySelectorAll('.section')].find(x => x.dataset.title === title);
  if(s2 && !s2.classList.contains('open')) s2.querySelector('.sec-head').click();
}

/* ---- wiring ---- */
async function loadZip(file){
  const status = $('status');
  if(!file) return;
  try{
    status.className = 'status'; status.textContent = 'Reading ' + file.name + '…';
    zipEntries = await readZip(file); zipName = file.name;
    $('dropTxt').textContent = file.name + ' — ' + zipEntries.length + ' files';
    const nh = zipEntries.filter(e => /\.html?$/i.test(e.name)).length;
    status.textContent = 'Loaded ' + file.name + ': ' + zipEntries.length + ' files, ' + nh + ' html. Converting…';
    $('convertBtn').disabled = false;
    await convert();
  }catch(err){ zipEntries = null; $('convertBtn').disabled = true; status.className = 'status err'; status.textContent = '✗ ' + (err && err.message || err); }
}
$('zipFile').addEventListener('change', e => loadZip(e.target.files[0]));
const drop = $('drop');
['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', e => loadZip(e.dataTransfer.files[0]));
$('convertBtn').addEventListener('click', convert);
$('resetGroups').addEventListener('click', () => { $('groupNames').value = DEFAULT_GROUPS; });
$('clearAll').addEventListener('click', () => {
  zipEntries = null; outObj = null; outJSON = ''; $('zipFile').value = ''; $('docUrl').value = '';
  $('dropTxt').textContent = 'Drop a .zip here or click to choose'; $('convertBtn').disabled = true;
  $('status').className = 'status'; $('status').textContent = 'No zip loaded.';
  $('jsonOut').textContent = '{}'; $('tree').innerHTML = '<span class="muted">—</span>';
  $('stats').textContent = 'Nothing converted yet — load a zip in Input.'; $('copyBtn').disabled = true; $('dlBtn').disabled = true;
});
const flash = t => { $('outMsg').textContent = t; setTimeout(() => $('outMsg').textContent = '', 2600); };
$('copyBtn').addEventListener('click', () => {
  const fallback = () => { const ta = document.createElement('textarea'); ta.value = outJSON; ta.style.cssText = 'position:fixed;opacity:0';
    document.body.appendChild(ta); ta.select(); let ok = false; try{ ok = document.execCommand('copy'); }catch(_){} ta.remove(); flash(ok ? 'copied ✓' : 'copy failed — select the JSON below'); };
  if(navigator.clipboard?.writeText) navigator.clipboard.writeText(outJSON).then(() => flash('copied ✓'), fallback); else fallback();
});
// download via the artifact "downloads" capability; hidden when unavailable
(async () => {
  let dl = null;
  try{ dl = window.claude && window.claude.use ? await window.claude.use('downloads') : null; }catch(_){}
  if(!dl) return;
  const b = $('dlBtn'); b.hidden = false;
  b.addEventListener('click', async () => {
    const name = slug(outObj?.operation?.name || 'fusion-doc') + '-settings.json';
    try{ await dl.save({filename: name, data: outJSON}); flash('saved ✓'); }
    catch(e){ if(e && e.code === 'declined') flash('download cancelled');
      else if(e && e.code === 'rate_limited') flash('a save prompt is already open');
      else { b.hidden = true; flash('download unavailable here — use copy'); } }
  });
})();
'''

# ---- splice sections into <main>, keeping the template's Glossary section ----
a = s.index('  <!-- REQUIRED FIRST SECTION'); g = s.index('  <!-- OPTIONAL (include whenever the dashboard uses terms')
s = s[:a] + SECTIONS + s[g:]
a = s.index('  <!-- REQUIRED (when the dashboard cites external sources)'); z = s.index('</main>')
s = s[:a] + s[z:]
gr = ''.join('<tr data-gterm="%s" data-match="%s" data-code="%s"><td><strong>%s</strong></td><td>%s</td><td class="gloss-uses"></td><td class="gloss-count"></td></tr>\n            '
             % (re.sub(r'[^a-z0-9]+', '-', t.lower()).strip('-'), html.escape(m), html.escape(c), html.escape(t), html.escape(d)) for t, m, c, d in GLOSSARY)
a = s.index('            <tr data-gterm="{{GLOSS_A_ID}}"'); z = s.index('            <!-- one row per term -->')
s = s[:a] + '            ' + gr + s[z:]
s = s.replace('<div class="section cat-source" data-title="Glossary" data-cat="source">', '<div class="section cat-reference" data-title="Glossary" data-cat="reference">')
s = s.replace('<span class="sec-num">97</span><span class="sec-title">Glossary</span><span class="cat-badge">Source</span>',
              '<span class="sec-num">05</span><span class="sec-title">Glossary</span><span class="cat-badge">REFERENCE</span>')

# ---- placeholders ----
rep = {
  '{{PAGE_TITLE}}': 'Fusion Doc to JSON',
  '{{KICKER}}': 'FUSION DOC → JSON',
  '{{H1_TITLE}}': 'Fusion Documentation to JSON',
  '{{H1_SUBTITLE}}': 'Saved help page in, operation → tabs → sections → settings out',
  '<span>{{BYLINE_A}}</span>': '<span>Autodesk Fusion product documentation</span>',
  '<span>{{BYLINE_B}}</span>': '<span>Runs in your browser · v1.1.0</span>',
  '{{MAIL_SUBJECT}}': 'Fusion Doc to JSON',
}
for k, v in rep.items():
    assert k in s, k; s = s.replace(k, v)
s = re.sub(r"const VERBATIM = `\{\{VERBATIM_TEXT\}\}`;\nif\(document.getElementById\('verbatim'\)\)\{\n.*?\n\}\n", '', s, flags=re.S)

# ---- categories ----
s = re.sub(r'    --cat-overview:#38dafa;.*?\n    --cat-source:#38fa79;.*?\n', ''.join(f'    --cat-{n}:{h};\n' for n, h, _, _ in CATS), s, count=1)
s = re.sub(r"  \.toc-tip\.tc-overview \.tip-badge\{[^\n]*\n  \.toc-tip\.tc-source \.tip-badge\{[^\n]*\n",
           ''.join(f'  .toc-tip.tc-{n} .tip-badge{{color:var(--cat-{n});background:rgba({r},.10)}}\n' for n, _, r, _ in CATS), s, count=1)
blk0 = s.index('  /* live defs for the template'); blk1 = s.index('  .chevron{')
s = s[:blk0] + ''.join(f'''  .cat-{n} .cat-badge{{color:var(--cat-{n});background:rgba({r},.10)}}
  .cat-{n}{{border-left:3px solid var(--cat-{n})}}
  .toc-chip.tc-{n}{{border-left-color:var(--cat-{n})}}
  .toc-chip.tc-{n}:hover{{color:var(--cat-{n})}}
''' for n, _, r, _ in CATS) + s[blk1:]

s = s.replace('</style>', CSS, 1)
assert s.count('</script>') == 1
s = s.replace('</script>', JS + '</script>')
assert '{{' not in s, re.findall(r'\{\{\w+\}\}', s)
open(out, 'w', encoding='utf-8').write(s)

# ---- vibe-dashboard patches: table fit, Search, Mind Map (extracted so they always match the current skill) ----
sk = open(os.path.join(VIBE, 'SKILL.md'), encoding='utf-8').read()
blocks = re.findall(r'`{3}python\n(.*?)`{3}', sk, re.S)
pick = lambda test: next(b for b in blocks if test(b))
os.makedirs(WD, exist_ok=True)
open(os.path.join(WD, 'fit_patch.py'), 'w').write(pick(lambda b: 'function bodyWordMin(' in b and 'table-fit patch' in b))
open(os.path.join(WD, 'mindmap_patch.py'), 'w').write(pick(lambda b: '"""mindmap_patch.py' in b))
open(os.path.join(WD, 'stress_audio.py'), 'w').write(pick(lambda b: 'stress_audio.py — run' in b))
for cmd in (['python3', os.path.join(WD, 'fit_patch.py'), out], ['python3', os.path.join(VIBE, 'scripts/search_patch.py'), out],
            ['python3', os.path.join(WD, 'mindmap_patch.py'), out]):
    r = subprocess.run(cmd, capture_output=True, text=True); print(r.stdout.strip() or r.stderr.strip())
    if r.returncode: sys.exit('patch failed: ' + ' '.join(cmd))
print('built', out, os.path.getsize(out), 'bytes · stress_audio.py saved in', WD)
```

## Changes

- **v1.1.0, Nov 9, 2026:** Removed the old "Template patch" step; the build script reads the template directly. Added Search, Mind Map, a Glossary, a JSON Format section, table fitting and the audio overview, as vibe-dashboard now requires. Summary categories use the template's own pills. Added the "Making the zip" steps for macOS and Windows (any browser that saves a complete page; not Safari). The converter itself is unchanged, so its JSON matches v1.0.0 apart from `generator.version`.
