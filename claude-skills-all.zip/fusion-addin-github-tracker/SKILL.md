---
name: "fusion-addin-github-tracker"
description: "Build Swami's tracker dashboard for taking a Fusion add-in to GitHub from just its name, for moving an existing add-in or starting a new one in a repo."
---

# Fusion add-in GitHub tracker

Builds a fresh **tracker dashboard** (a vibe-dashboard page with its own owner-only database) for one Autodesk Fusion add-in on its way to a public GitHub repo. It follows the shape of the Selection Inspector move tracker (Nov 24, 2026) and has two paths:

| Path | When | Steps |
|---|---|---|
| `move` | An add-in already exists (Swami uploads its zip) | 1 Instructions, 2 Tracker, 3 Audit, 4 Create repo, 5 First release, 6 Future releases, 7 Field guide |
| `new` | A new add-in, built in its repo from day one | 1 Instructions, 2 Tracker, 3 Create repo (model layout, no release yet), 4 Build on branch `dev`, 5 First release (merge to main), 6 Future releases, 7 Field guide |

Every tracker has: a step table with a copyable prompt per step, a status and a done tick saved in the page's database (only Swami, or Claude writing as him, can change them); a diagram of the whole job with a colour key; Decisions; Links that turn live; the model repo layout and the planned layout as collapsible trees; a 15-check Test in Fusion list; Troubleshooting; plus everything vibe-dashboard requires (Summary, Search, Mind Map, Glossary, References, Source Document, audio overview).

## Lessons baked in (keep them)

- **The first public release always includes the update check.** An install without it can never be told about a fix and strands its users. For a move, the first release is a minor bump over the uploaded version (e.g. 2.36.6 → 2.37.0) with the audit fixes and the update check; there is no separate "as-is" release.
- **Update-banner tests only work from the second release.** Checks 13–15 in Test in Fusion are tagged with the next patch version, and step 6's prompt says so.
- **The Claude GitHub app may need the new repo added before the first push** (github.com/settings/installations → Claude → Repository access; GitHub confirms by email). The create-repo prompt checks this.
- **Path `new`:** main gets no `version.json` until the first release, so the release workflow has nothing to publish while the add-in is being built on `dev`.
- **Never write the privacy exclusion terms anywhere** (tracker, prompts, narration, memory, files). Read the current project's own exclusion list from its project instructions, scan with it, and refer to an exclusion only as "1 item excluded for privacy".

## Inputs

Ask only for what you can't work out:
- **path**: `move` or `new` (an uploaded zip means `move`).
- **name**: display name, e.g. "Selection Inspector". **internal**: PascalCase name for folder, .py, .manifest, IDs and zip (default: the name without spaces). Repo: `fusion-addin-<kebab of internal>` under `swami-claude-skills` unless the project says otherwise.
- **description**: one sentence on what it does. **location**: where the button goes (e.g. "INSPECT panel of each workspace tab").
- **move only:** the uploaded zip; read the version from its .py / manifest (`uploaded_version`).
- Optional: `first_version` (default: move → minor bump of uploaded, new → 1.0.0), `model_repo` (default `fusion-export-selected-to-dxf`), `request` (Swami's own words for the Source Document; default is a generated request).

Follow the project's instructions on top of this skill (plan first, ask before every Create/Save on github.com, privacy check before every push or publish).

## Build

`VD` = the vibe-dashboard skill folder (holding `assets/template.html` and `scripts/`). Load the vibe-dashboard skill first; its rules govern the page.

1. **Get the kit.** It lives in Swami's private repo `swami-claude-skills/vibe-dashboards`, folder `addin-tracker/`: `build_tracker.py`, `tracker.js`, `extra.css`, `post.py`, plus copies of vibe-dashboard's `toolbar_patch.py`, `source_colour_patch.py` and `tooltip_patch.py`, and two sample configs (`samples/move.json`, `samples/new.json`). Attach the repo with the Claude Code Remote `add_repo` tool (owner `swami-claude-skills`, repo `vibe-dashboards`, read access is enough), `git clone --depth 1`, and copy `addin-tracker/` into a working folder (e.g. `/mnt/project-files/<repo-name>-tracker/`, so later threads can rebuild). If the repo can't be reached, the Claude GitHub app lacks access: Swami adds it under github.com/settings/installations, Claude, Repository access. If the three patch files are missing, save them from vibe-dashboard's SKILL.md.
2. Write `cfg.json`, e.g.
   `{"path":"new","name":"Hole Counter","internal":"HoleCounter","description":"Counts and lists the holes in the selected bodies by size.","location":"INSPECT panel of the Design workspace","started":"Tue Nov 24, 2026"}`
   (a move adds `"uploaded_version":"2.36.6"`).
3. Build and patch, in this order, in the working folder:
   ```
   TRACKER_SVG=diagram.svg python3 build_tracker.py cfg.json $VD/assets/template.html index.html
   python3 $VD/scripts/fit_patch.py index.html
   python3 toolbar_patch.py index.html
   python3 $VD/scripts/search_patch.py index.html
   python3 post.py index.html
   python3 $VD/scripts/mindmap_patch.py index.html
   python3 source_colour_patch.py index.html
   python3 tooltip_patch.py index.html
   ```
   `build_tracker.py` also writes a `narration.txt` draft next to the page.
4. **Check by eye and in a browser** (Playwright): render `diagram.svg` to PNG and look for overlaps; open the page at 1440, 1000 and 390 px: no console errors or colour warnings, no sideways scroll at 390, `document.querySelectorAll('[title]').length === 0`, every glossary term has a count above 0 (fix its matcher or drop it), 13 sections in order (Summary, Search, Steps, Diagram, Decisions, Links, Repo Layout, Test in Fusion, Troubleshooting, Mind Map, Glossary, References, Source Document).
5. **Audio overview:** read `narration.txt`, fix anything the page no longer says, run `stress_audio.py $VD audit narration.txt`, then `stress_audio.py $VD build index.html narration.txt index.html`. If recording fails, follow vibe-dashboard's "When the recording can't be made".
6. **Privacy scan** the page, narration and cfg.json against the project's exclusion list (case-insensitive; check each hit for a false positive, such as an ordinary word that contains a listed term). Any real hit stops the publish.
7. **Publish** `index.html` as a new artifact, icon `checklist`, with an owner-only database. The artifact tools differ by session; use whichever is present:
   - **Artifact tool:** publish with `capabilities:` the set below.
   - **claude-artifacts server:** publish with `publish_files` (title and icon), then call `declare_capabilities` on the new slug with the same set (read `describe_capabilities` first if its shape is unclear).

   The set: `capabilities: {db: {rules: [{path: "steps", read: "view", write: "owner"}, {path: "tests", read: "view", write: "owner"}, {path: "links", read: "view", write: "owner"}]}, user: {}}`.
   Every later republish to the same file or URL leaves `capabilities` out (on claude-artifacts, republishing never touches the declaration), so the rules and saved ticks stay.
8. **Verify and seed:** one `list` of `steps`, `tests` and `links` with the artifact database tool (`ArtifactData`, or `db_list` on claude-artifacts; empty is fine). Then mark step 2 done (and step 1 if the project instructions are already set) with `set` on `steps/s2`: `{done: true, status: "done", updated: <ISO now>}`.
9. **Record it:** save a project-memory file (one per tracker) with the link, path, step list and the database layout below; tell Swami to add the tracker link to the project instructions ("Tracker: <link>. Tick each step there when it's done."). Commit the sources per vibe-dashboard's "Version history" when that repo is reachable.

## Ticking steps later (any thread)

Use the artifact database tool on the tracker URL: `ArtifactData` (`get`, `set`), or on the claude-artifacts server `db_get` and `db_write` (load them with ToolSearch). Either writes as Swami, the owner. Read a doc first; a set (a whole-doc write) replaces the whole doc, so include every field.
- `steps` / `s1`…`s7`: `{done: bool, status: "todo"|"doing"|"blocked"|"done", updated: ISO}`. A doc that doesn't exist yet is created by `set`.
- `tests` / `t01`…`t15`: `{done: bool, updated}` (t13–t15 need the second release).
- `links` / `repo`, `pages`, `release`, `zip`, `version`: `{live: bool, updated}`; `release` also has `tag` (e.g. `"v1.0.0"`).

To change the page's text, edit `cfg.json` (or `build_tracker.py`), rerun the whole Build list, and republish to the same URL without `capabilities`; saved ticks are kept because they live in the database.

## Changing the kit

`build_tracker.py` holds all the page text: step prompts (`S1`, `S2`, `MID` per path, `S6`, `S7`), `TESTS`, `LINKS`, `DECISIONS`, `TROUBLE`, `GLOSS`, `REFS`, the diagram (`diagram()`, `LEGEND`) and the narration draft. When a move or build teaches a new lesson, change it there, rebuild both samples (`samples/*.json`) and check them as in Build step 4, run the privacy scan, and commit to `vibe-dashboards` with a short message (no client names). Keep this skill's "Lessons" list in step.