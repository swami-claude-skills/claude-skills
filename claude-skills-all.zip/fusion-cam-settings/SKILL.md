---
name: "fusion-cam-settings"
description: "Build Swami's Fusion CAM settings vibe-dashboard from an operation's settings CSV (Tab,Group,Parameter,Value,Default) plus a Fusion Doc JSON of that operation's product documentation. Use whenever he uploads a Fusion toolpath settings CSV and wants a dashboard."
---

# Fusion CAM Settings Dashboard

Turns one Autodesk Fusion CAM operation (2D Offset Roughing, 2D Pocket, Adaptive, Contour, Drill, Parallel…) into a published **vibe-dashboard** page. It explains every setting the operation used: the raw value, what the value works out to for this tool, whether it was changed from default, and what Autodesk's docs say the setting does.

The reference build is the 2D Offset Roughing dashboard (https://claude.ai/artifact/F3ZWMaeUvopSmYNLBmKdfV). Every dashboard from this skill must match its pattern.

## Inputs

1. **Settings CSV**: exported from the Fusion operation, columns `Tab,Group,Parameter,Value,Default`. One row per dialog setting in dialog order. `Value` is the literal or Fusion expression (`250.in/min`, `tool_diameter*.5`, `'helix'`). `Default` is `Yes` (at default), `No` (user-set) or `N/A`.
2. **Doc JSON**: that operation's Autodesk product-documentation page in the **fusion-doc-json** shape (`operation > tabs[] > sections[] > settings[]`, each setting with `name`, `description`, optional `options[{name, description}]`; `operation.url`, `operation.summary`). Swami's "Fusion Doc to JSON" page makes it (fusion-doc-json skill).

If either input is missing, ask for it once. If Swami says to go ahead without the doc JSON, pass `-` as DOCJSON. The page then builds without doc lines, the docs-only table or References.

## Sections (always in this order)

| # | Section | Built from |
|---|---|---|
| 01 | Dashboard Summary | auto intro, "Start here" callout, "What the docs say" callout (doc summary), index table |
| 02 | Setup at a Glance | `notes.glance` table + "Math used" callout |
| 03… | One section per dialog **tab** in CSV order (`Tool Tab`, `Geometry Tab`, `Heights Tab`, `Passes Tab`, `Linking Tab`, …) | CSV rows. A tab gets one table per group when its groups average ≥3 rows; otherwise a single table with a Group column. Heights also gets an auto "Height stack" table (From / Offset per height) |
| next | Changed from Default | every `Default = No` row |
| next | Review Notes | `notes.review`, one table: Item · Where / What the export shows / What to check |
| next | Full Parameter List | all rows + "In the documentation but not in the export" table |
| next | References | doc URL + related pages + `notes.references` |
| last | Source Document (Verbatim) | the CSV, single-spaced |

Parameter tables have the columns **Parameter / Value (as exported) / Resolved / Status**. Under each parameter name there's a grey doc line: the first sentence of the matched doc description. When the value names one of the doc's options (e.g. `'helix'` → Helix), a "▸ Option: …" line is added. Status shows **CHANGED** (pink), `default` or `n/a`. Categories: overview cyan, then each tab in palette order (green, yellow, orange, violet, blue, then extra hues), with changes/review pink and reference magenta.

## Workflow

1. **Read both inputs fully.** Note the tool: name, type, diameter, corner radius, vendor, and flute count if present. Note spindle speed, cutting feed and plunge feed. Check whether the tool name contradicts the diameter.
2. **Write `notes.json`** in the scratchpad. See "Notes JSON" below. This is where the thinking goes: resolve every expression for this tool and write the review notes.
3. **Prepare the template.** Find vibe-dashboard with `find / -path '*vibe-dashboard/assets/template.html' 2>/dev/null | head -1` and copy `template.html` to the scratchpad. Extract the python block under "Template patch — REQUIRED" from vibe-dashboard's SKILL.md into `patch_template.py` and run `python3 -I patch_template.py tpl.html`.
4. **Save the builder below** as `build_cam_dashboard.py` in the scratchpad. Run it, writing the page into the working directory (not `/mnt/user-data/outputs/`) with a kebab-case name such as `adaptive-clearing-parameters-dashboard.html`:
   `python3 -I build_cam_dashboard.py tpl.html <csv> <doc.json|-> notes.json <out>.html`
   It prints section, match and docs-only counts, then any **UNRESOLVED** rows. Add each one to `notes.resolved` and rebuild until the list is empty.
5. **Check it renders.** Playwright + Chromium are preinstalled (`/opt/pw-browsers`). Load the page, open a tab section and its first table, and screenshot it. You must see no page errors and no console warning from `checkCategoryColours`. If the doc match count is low, look for naming differences between the CSV and the doc JSON and mention them.
6. **Publish** with the Artifact tool from the working directory. Declare no capabilities. To update a published dashboard, republish the same file path.
7. **Reply briefly:** what the page covers, the 1–3 most important review notes, and anything the export left out (flute count, library stepover, ramp angle…).

For follow-up edits (e.g. "make section 09 a table"), change `notes.json` or the builder, rebuild from a fresh patched template, and republish the same path. Don't hand-edit the HTML; it will drift from the builder.

## Notes JSON

Every key is optional except `glance`, `resolved` and `review`, which make the page worth having. HTML is allowed in `glanceIntro`, `glanceMath`, `tabIntros`, `tabCallouts`, `startHere`, `summaryIntro`, `reviewIntro` and the last two review columns. Everything else is plain text.

```json
{
  "title": "2D Offset Roughing",
  "subtitle": "“THE SLAYER” 0.375 in roughing upcut · 18,000 rpm · 250 in/min",
  "kicker": "FUSION CAM PARAMETERS",
  "startHere": "Open Setup at a Glance, then Review Notes — the tool is named 1/4 in but defined as 0.375 in.",
  "summaryIntro": "(optional override of the auto intro)",
  "glanceIntro": "The export’s expressions <strong>worked out for this tool</strong> (D = 0.375 in, flat end)…",
  "glance": [["Tool", "0.375 in flat end mill — IDC Woodcraft"], ["Spindle / surface speed", "18,000 rpm · ≈ 1,767 SFM"]],
  "glanceMath": "Surface speed = π × 0.375 × 18,000 ÷ 12 ≈ 1,767 SFM. Chip load = 250 ÷ (18,000 × flutes)…",
  "tabTitles": {"Tool": "Tool Tab · Feeds & Speeds"},
  "tabIntros": {"Passes": "The heart of the operation. Changed here: <strong>…</strong>"},
  "tabCallouts": {"Tool": [["Linked feeds", "Lead-in, lead-out and transition feeds follow <code>tool_feedCutting</code>…"]]},
  "sectionIndex": {"Tool Tab · Feeds & Speeds": ["Tool, coolant, every feed and speed", "Checking feeds, chip load or plunge"]},
  "resolved": {"Feed & Speed|Surface Speed": "≈ 1,767 SFM (21,206 in/min)", "Multiple Depths|Maximum Stepdown": "0.1875 in (½ × D)"},
  "review": [["Tool name vs. diameter", "Tool Tab · Feeds & Speeds", "Named “1/4 in” but defined as 0.375 in.", "Confirm the real cutter size…"]],
  "reviewIntro": "(optional)",
  "references": [["IDC Woodcraft — THE SLAYER", "Manufacturer page for the tool", "https://…"]]
}
```

**`resolved` keys** are `Group|Parameter`, matching the CSV exactly (use `Tab|Group|Parameter` if a group name repeats across tabs). The builder already turns plain literals into readable text: `true/false` → On/Off, `'helix'` → Helix, `250.in/min` → 250 in/min, `25deg` → 25°. Add a `resolved` entry only for expressions, or for literals worth explaining (`"Left (climb, on CW spindle)"`, `"Off — cuts to final size"`). How to resolve:
- Substitute the tool's numbers: `tool_diameter`, `tool_cornerRadius` (0 for a flat end mill), `tool_spindleSpeed`, `tool_feedCutting`, `tool_feedPlunge`, `tool_numberOfFlutes`. Show the result with units: `0.1875 in (½ × D)`.
- Fusion's export writes function arguments with `;` (`Math.min(a; b)`); read them as commas.
- If a value depends on a library field the CSV doesn't carry (flute count, `tool_stepover`, `tool_rampAngle`, `tool_fluteLength`, `tool_taperAngle` on a tapered tool), say so: `From tool library (value not in export)`. For chip load, give a value per likely flute count. Never invent the number.
- Mark settings that a disabled parent switches off as `(inactive)`, e.g. Lead-In radius when Lead-In is off, or Radial Stock to Leave when Stock to Leave is off.
- Heights: give each Offset its absolute result, e.g. `+0.4 in → 0.6 in above stock top`.

**`glance`** has 10–14 rows covering tool, speed/SFM, cutting feed, plunge/ramp feed, chip load, stepdown, stepover, entry/ramp, heights, stock to leave, finishing, direction and coolant. Leave out rows that don't apply (drilling has no stepover).

**`review`** has 4–8 rows, most important first. Each row is `[item, where, what the export shows, what to check]`, where `where` is an exact section title such as `Passes Tab`. It auto-links as `Passes Tab [06]`. Look for:
- tool name vs. diameter mismatches
- values the export doesn't carry
- no stock to leave on a roughing op
- feeds that look high or low for the chip load
- Both Ways / climb-vs-conventional choices
- leads off with Keep Tool Down
- ramp vs. plunge entry
- heights that collide (retract = feed)
- export artifacts (semicolons)

Use the doc text to back up a point where it helps. These are observations, not errors, so keep the tone advisory.

## How doc matching works

The builder matches each CSV row to a doc setting. First pass, exact matches in this order: same tab and same normalized name; same tab and the name without its "(…)" part; any tab and same name. Second pass, for rows still unmatched: the CSV name as a whole-word phrase inside an unused doc setting's name in the same tab. Doc tab names lose "tab settings". When the doc section matches the CSV group, that hit wins. Doc settings that nothing matched go in the "In the documentation but not in the export" table.

## Builder: build_cam_dashboard.py

```python
#!/usr/bin/env python3
"""Fusion CAM settings dashboard builder.

usage: python3 -I build_cam_dashboard.py TEMPLATE CSV DOCJSON NOTESJSON OUT
  TEMPLATE  copy of vibe-dashboard assets/template.html, ALREADY PATCHED
  CSV       Fusion operation export: Tab,Group,Parameter,Value,Default
  DOCJSON   Fusion Doc -> JSON output (operation > tabs > sections > settings), or - for none
  NOTESJSON Claude-written notes (resolved values, glance, review...) - see SKILL.md
  OUT       output .html (overwritten)
Prints any expression rows still unresolved so they can be added to the notes.
"""
import csv, json, html, re, sys, textwrap, colorsys, os

tpl_p, csv_p, doc_p, notes_p, out_p = sys.argv[1:6]
E = html.escape
rows = list(csv.DictReader(open(csv_p, encoding='utf-8-sig')))
need = {'Tab', 'Group', 'Parameter', 'Value', 'Default'}
assert rows and need <= set(rows[0].keys()), 'CSV must have columns ' + ','.join(sorted(need))
for r in rows:
    for k in need: r[k] = (r[k] or '').strip()
raw = open(csv_p, encoding='utf-8-sig').read()
doc = json.load(open(doc_p, encoding='utf-8')) if doc_p != '-' else {}
N = json.load(open(notes_p, encoding='utf-8'))
t = open(tpl_p, encoding='utf-8').read()
assert 'pointer-events:auto' in t, 'template is not patched - run the vibe-dashboard template patch first'
csv_name = os.path.basename(csv_p)

# ---------- helpers ----------
def W(x, n):
    """escape + hard-wrap long text with <br> so table columns stay balanced"""
    x = (x or '').strip()
    return '<br>'.join(E(l) for l in textwrap.wrap(x, n, break_long_words=False, break_on_hyphens=False)) or E(x)

def norm(s, parens=True):
    s = (s or '').lower()
    if not parens: s = re.sub(r'\(.*?\)', ' ', s)
    s = s.replace('&', ' and ')
    return re.sub(r'[^a-z0-9]+', ' ', s).strip()

def first_sentence(s, cap=170):
    s = re.sub(r'\s+', ' ', s or '').strip()
    m = re.match(r'(.+?[.!?])(\s|$)', s)
    s = m.group(1) if m else s
    return s if len(s) <= cap else s[:cap].rsplit(' ', 1)[0] + '…'

def auto_resolve(v):
    """plain literals -> readable text; expressions -> None"""
    v = v.strip()
    if v in ('', 'N/A'): return '—'
    if v.lower() == 'true': return 'On'
    if v.lower() == 'false': return 'Off'
    m = re.fullmatch(r"'([^']*)'", v)
    if m: s = m.group(1); return s[:1].upper() + s[1:]
    m = re.fullmatch(r'(-?\d+(?:\.\d*)?)\s*(in/min|inpm|ipm|mm/min|in|mm|deg|rpm|%)?', v)
    if m:
        num = m.group(1).rstrip('.')
        if '.' in num: num = num.rstrip('0').rstrip('.') or '0'
        u = m.group(2) or ''
        if u == 'deg': return num + '°'
        if u in ('inpm', 'ipm'): u = 'in/min'
        return (num + ' ' + u).strip()
    return None

def resolved(r):
    R = N.get('resolved', {})
    return R.get(r['Group'] + '|' + r['Parameter']) or R.get(r['Tab'] + '|' + r['Group'] + '|' + r['Parameter']) \
        or R.get(r['Parameter']) or auto_resolve(r['Value'])

def status(v):
    if v == 'No':  return '<span style="color:var(--cat-review);font-family:var(--mono);white-space:nowrap">CHANGED</span>'
    if v == 'Yes': return '<span style="color:var(--text-mute);font-family:var(--mono);white-space:nowrap">default</span>'
    return '<span style="color:var(--text-mute);font-family:var(--mono);white-space:nowrap">n/a</span>'

# ---------- documentation index ----------
op = doc.get('operation', {}) if doc else {}
def tab_key(name): return norm(re.sub(r'\b(tab settings|tab|settings)\b', '', name or '', flags=re.I))
doc_settings = []          # (tabkey, tabname, sectionname, setting)
for tb in (doc.get('tabs') or []):
    for sec in tb.get('sections') or []:
        for st in sec.get('settings') or []:
            doc_settings.append((tab_key(tb.get('name')), tb.get('name', ''), sec.get('name', ''), st))
used = set()
def find_doc(r, loose):
    tk, p, p0 = tab_key(r['Tab']), norm(r['Parameter']), norm(r['Parameter'], False)
    if not loose:
        tests = [lambda d: d[0] == tk and norm(d[3].get('name')) == p,
                 lambda d: d[0] == tk and norm(d[3].get('name'), False) == p0,
                 lambda d: norm(d[3].get('name')) == p]
    else:   # only against settings nobody matched exactly; CSV name must sit inside the doc name
        tests = [lambda d: d[0] == tk and len(p0) >= 5 and re.search(r'\b' + re.escape(p0) + r'\b', norm(d[3].get('name'), False))]
    for test in tests:
        hits = [i for i, d in enumerate(doc_settings) if test(d) and not (loose and i in used)]
        if hits:
            # prefer a hit whose doc section matches the CSV group
            hits.sort(key=lambda i: norm(doc_settings[i][2]) != norm(r['Group']))
            used.add(hits[0]); return doc_settings[hits[0]][3]
    return None
for r in rows: r['_doc'] = find_doc(r, False)
for r in rows:
    if not r['_doc']: r['_doc'] = find_doc(r, True)

def option_note(r):
    st = r['_doc']
    if not st: return ''
    v = norm(r['Value'].strip("'\""))
    for o in st.get('options') or []:
        if v and norm(o.get('name')) == v and o.get('description'):
            return o['name'] + ': ' + first_sentence(o['description'], 120)
    return ''

def pcell(r, wrap=44):
    """parameter cell: name + dim doc line (+ matched option line)"""
    s = '<strong>%s</strong>' % E(r['Parameter'])
    d = first_sentence((r['_doc'] or {}).get('description', ''))
    if d: s += '<br><span class="docline">%s</span>' % W(d, wrap)
    o = option_note(r)
    if o: s += '<br><span class="docline docopt">%s</span>' % W('▸ ' + o, wrap)
    return s

def ptable(desc, sel, show_group):
    hdr = '<th>Parameter</th>' + ('<th>Group</th>' if show_group else '') + \
          '<th>Value (as exported)</th><th>Resolved</th><th>Status</th>'
    body = ''.join('<tr><td>%s</td>%s<td><code>%s</code></td><td>%s</td><td>%s</td></tr>' % (
        pcell(r), ('<td>%s</td>' % E(r['Group'])) if show_group else '', W(r['Value'], 28),
        W(resolved(r) or '⚠ unresolved', 24), status(r['Default'])) for r in sel)
    return '<div class="table-wrap" data-desc="%s"><table><thead><tr>%s</tr></thead><tbody>%s</tbody></table></div>' % (E(desc), hdr, body)

def section(num, cat, badge, title, inner):
    return ('<div class="section cat-%s" data-title="%s" data-cat="%s"><div class="sec-head"><span class="sec-num">%s</span>'
            '<span class="sec-title">%s</span><span class="cat-badge">%s</span><span class="chevron">▶</span></div>'
            '<div class="sec-body">%s</div></div>\n') % (cat, E(title), cat, num, E(title), E(badge), inner)

def callout(lbl, txt): return '<div class="callout"><span class="lbl">%s</span>%s</div>' % (E(lbl), txt)

# ---------- structure ----------
tabs = []
for r in rows:
    if r['Tab'] not in tabs: tabs.append(r['Tab'])
def groups_of(tab):
    g = []
    for r in rows:
        if r['Tab'] == tab and r['Group'] not in g: g.append(r['Group'])
    return g
changed = [r for r in rows if r['Default'] == 'No']
tab_title = {tb: N.get('tabTitles', {}).get(tb, tb + ' Tab') for tb in tabs}

FIXED = {'overview', 'review', 'reference'}
def slug(s):
    s = re.sub(r'[^a-z0-9]+', '-', s.lower()).strip('-') or 'tab'
    return 'tab-' + s if s in FIXED else s
tab_cat = {tb: slug(tb) for tb in tabs}

S, index = [], []
num = 1
def nxt():
    global num
    num += 1
    return '%02d' % num

# 02 Setup at a Glance
glance = N.get('glance', [])
gt = '<div class="table-wrap" data-desc="Key settings, resolved to numbers"><table><thead><tr><th>Item</th><th>Effective setting</th></tr></thead><tbody>' + \
     ''.join('<tr><td><strong>%s</strong></td><td>%s</td></tr>' % (E(a), E(b)) for a, b in glance) + '</tbody></table></div>'
inner = '<p>%s</p>' % N.get('glanceIntro', 'The key settings of this operation, with each expression worked out for this tool.') + gt
if N.get('glanceMath'): inner += callout('Math used', N['glanceMath'])
S.append(section(nxt(), 'overview', 'OVERVIEW', 'Setup at a Glance', inner))
index.append(('Setup at a Glance', 'Key settings resolved to real numbers', 'You want the whole op in one table'))

# one section per dialog tab
for tb in tabs:
    sel = [r for r in rows if r['Tab'] == tb]
    gs = groups_of(tb)
    ch = [r['Parameter'] for r in sel if r['Default'] == 'No']
    intro = N.get('tabIntros', {}).get(tb) or (
        '%d parameters in %d group%s. %s' % (len(sel), len(gs), '' if len(gs) == 1 else 's',
        ('Changed from default here: <strong>' + E(', '.join(ch)) + '</strong>.') if ch else 'Every value is at its Fusion default.'))
    inner = '<p>%s</p>' % intro
    if norm(tb) == 'heights':
        stack = []
        for g in gs:
            fr = next((r for r in sel if r['Group'] == g and r['Parameter'] == 'From'), None)
            of = next((r for r in sel if r['Group'] == g and r['Parameter'] == 'Offset'), None)
            if fr or of:
                stack.append('<tr><td><strong>%s</strong></td><td>%s</td><td>%s</td></tr>' % (
                    E(g), E(resolved(fr) if fr else '—'), E(resolved(of) if of else '—')))
        if stack:
            inner += '<div class="table-wrap no-sort" data-desc="Height stack, top to bottom"><table><thead><tr><th>Height</th><th>From</th><th>Offset / result</th></tr></thead><tbody>' + ''.join(stack) + '</tbody></table></div>'
    if len(sel) / max(1, len(gs)) < 3 or len(gs) == 1:
        inner += ptable(tb + ' parameters', sel, len(gs) > 1)
    else:
        for g in gs: inner += ptable(g + ' parameters', [r for r in sel if r['Group'] == g], False)
    for lbl, txt in N.get('tabCallouts', {}).get(tb, []): inner += callout(lbl, txt)
    S.append(section(nxt(), tab_cat[tb], tb.upper(), tab_title[tb], inner))
    focus, when = N.get('sectionIndex', {}).get(tab_title[tb], [', '.join(gs[:5]), 'Checking the %s tab settings' % tb])
    index.append((tab_title[tb], focus, when))

# Changed from Default
ct = '<div class="table-wrap" data-desc="User-set parameters"><table><thead><tr><th>Parameter</th><th>Tab › Group</th><th>Value</th><th>Resolved</th></tr></thead><tbody>' + \
     ''.join('<tr><td>%s</td><td>%s</td><td><code>%s</code></td><td>%s</td></tr>' % (
         pcell(r), E(r['Tab'] + ' › ' + r['Group']), W(r['Value'], 28), W(resolved(r) or '⚠ unresolved', 24)) for r in changed) + '</tbody></table></div>'
S.append(section(nxt(), 'review', 'CHANGES', 'Changed from Default',
    '<p>Of the %d parameters, <strong>%d</strong> are not at their Fusion default — these are the choices that make this operation yours.</p>' % (len(rows), len(changed)) + ct))
index.append(('Changed from Default', 'The %d user-set parameters' % len(changed), 'Seeing what was customized'))

# Review Notes
rv = N.get('review', [])
rt = '<div class="table-wrap" data-desc="Items to check before running"><table><thead><tr><th>Item · Where</th><th>What the export shows</th><th>What to check</th></tr></thead><tbody>' + \
     ''.join('<tr><td><strong>%s</strong><br><span style="font-size:12px">%s</span></td><td>%s</td><td>%s</td></tr>' % (E(a), E(b), c, d) for a, b, c, d in rv) + '</tbody></table></div>'
S.append(section(nxt(), 'review', 'REVIEW', 'Review Notes',
    '<p>%s</p>' % N.get('reviewIntro', 'Things worth a second look before running the job. These are observations from the export, not errors in Fusion.') + rt))
index.append(('Review Notes', 'Items worth a second look', 'Before posting and running the job'))

# Full Parameter List (+ docs-only settings)
full = '<div class="table-wrap" data-desc="All %d parameters"><table><thead><tr><th>Parameter</th><th>Tab › Group</th><th>Value (as exported)</th><th>Resolved</th><th>Status</th></tr></thead><tbody>' % len(rows) + \
       ''.join('<tr><td>%s</td><td>%s</td><td><code>%s</code></td><td>%s</td><td>%s</td></tr>' % (
           pcell(r), E(r['Tab'] + ' › ' + r['Group']), W(r['Value'], 28), W(resolved(r) or '⚠ unresolved', 24), status(r['Default'])) for r in rows) + '</tbody></table></div>'
docs_only = [d for i, d in enumerate(doc_settings) if i not in used]
if docs_only:
    full += '<div class="table-wrap" data-desc="In the documentation but not in the export"><table><thead><tr><th>Setting</th><th>Tab › Section</th><th>What it does (docs)</th></tr></thead><tbody>' + \
            ''.join('<tr><td><strong>%s</strong></td><td>%s</td><td>%s</td></tr>' % (
                E(d[3].get('name', '')), E(d[1] + ' › ' + d[2]), W(first_sentence(d[3].get('description', ''), 260), 60)) for d in docs_only) + '</tbody></table></div>'
matched = sum(1 for r in rows if r['_doc'])
docnote = (' %d of them matched to the product documentation (shown as the grey line under each name).' % matched) if doc_settings else ''
S.append(section(nxt(), 'reference', 'REFERENCE', 'Full Parameter List',
    '<p>All %d rows from the CSV in their original order, with resolved values added.%s Sort any column — click <strong>Status</strong> to group the changed values together.</p>' % (len(rows), docnote) + full))
index.append(('Full Parameter List', 'All %d rows, sortable' % len(rows), 'Looking up any single parameter'))

# References
refs = []
if op.get('url'):
    refs.append((op.get('title') or op.get('name') or 'Product documentation', 'Official Autodesk explanation of every setting in this operation', op['url']))
for p in (op.get('relatedPages') or []):
    if isinstance(p, dict):
        u = p.get('href') or p.get('url'); tx = p.get('text') or p.get('title') or u
        if u: refs.append((tx, 'Related documentation page', u))
for a, b, u in N.get('references', []): refs.append((a, b, u))
if refs:
    def dom(u): return re.sub(r'^https?://([^/]+).*$', r'\1', u)
    rtab = '<div class="table-wrap" data-desc="Cited reference links"><table><thead><tr><th>Source</th><th>What it covers</th><th>Domain</th><th>Webpage</th></tr></thead><tbody>' + \
           ''.join('<tr><td><strong>%s</strong></td><td>%s</td><td>%s</td><td><a href="%s" target="_blank" rel="noopener">%s</a></td></tr>' % (
               E(a), E(b), E(dom(u)), E(u), E(dom(u))) for a, b, u in refs) + '</tbody></table></div>'
    S.append(section(nxt(), 'reference', 'SOURCE', 'References', '<p>Documentation cited throughout this dashboard.</p>' + rtab))
    index.append(('References', 'Autodesk product documentation', 'Reading the official explanation'))

verb_num = nxt()

# ---------- splice into template ----------
a = t.index('  <!-- SECTION PATTERN'); b = t.index('  <!-- OPTIONAL verbatim')
t = t[:a] + ''.join(S) + '\n' + t[b:]
sum_rows = ''.join('<tr><td><span class="secnum">%02d</span></td><td><strong>%s</strong></td><td>%s</td><td>%s</td></tr>' % (
    i + 2, E(a), E(f), E(w)) for i, (a, f, w) in enumerate(index))
a = t.index('            <tr><td><span class="secnum">02</span>'); b = t.index('            <!-- REQUIRED: always include the Source')
t = t[:a] + sum_rows + '\n' + t[b:]
t = t.replace('<span class="sec-num">99</span>', '<span class="sec-num">%s</span>' % verb_num)
t = t.replace('cat-source', 'cat-reference').replace('data-cat="source"', 'data-cat="reference"')
t = t.replace('<span class="cat-badge">Source</span>', '<span class="cat-badge">SOURCE</span>')
t = t.replace('Original reproduced exactly as supplied.', 'The uploaded CSV, reproduced exactly as supplied.')

# summary callouts: docs description after the Start-here callout
docs_sum = op.get('summary') or ' '.join((op.get('description') or [])[:1])
if docs_sum:
    t = t.replace('{{SUMMARY_CALLOUT_TEXT}}</div>', '{{SUMMARY_CALLOUT_TEXT}}</div>' + callout('What the docs say', E(first_sentence(docs_sum, 400))), 1)

# ---------- categories ----------
cats = [('overview', '#38dafa')]
tab_colours = ['#38fa79', '#dafa38', '#fa9938', '#7938fa', '#3879fa']
extra_hues = [0, 105]
for i, tb in enumerate(tabs):
    if i < len(tab_colours): c = tab_colours[i]
    else:
        h = extra_hues[(i - len(tab_colours)) % len(extra_hues)]
        rr, gg, bb = colorsys.hls_to_rgb(h / 360, 0.6, 0.95); c = '#%02x%02x%02x' % (int(rr * 255), int(gg * 255), int(bb * 255))
    cats.append((tab_cat[tb], c))
cats += [('review', '#fa3899'), ('reference', '#ea38fa')]
def rgb(h): return ','.join(str(int(h[i:i + 2], 16)) for i in (1, 3, 5))
vars_ = ''.join('    --cat-%s:%s;\n' % c for c in cats)
a = t.index('    /* the two vars below'); b = t.index('  }', a)
t = t[:a] + vars_ + t[b:]
blocks = ''
for n, h in cats:
    blocks += ('  .cat-{n} .cat-badge{{color:var(--cat-{n});background:rgba({r},.10)}}\n  .cat-{n}{{border-left:3px solid var(--cat-{n})}}\n'
               '  .toc-chip.tc-{n}{{border-left-color:var(--cat-{n})}}\n  .toc-chip.tc-{n}:hover{{color:var(--cat-{n})}}\n'
               '  .toc-tip.tc-{n} .tip-badge{{color:var(--cat-{n});background:rgba({r},.10)}}\n').format(n=n, r=rgb(h))
blocks += '  .docline{font-size:12px;font-weight:400;color:var(--text-mute);line-height:1.45}\n  .docline.docopt{color:var(--text-dim)}\n'
a = t.index('  /* live defs for the template'); b = t.index('  .chevron{')
t = t[:a] + blocks + t[b:]
a = t.index('  .toc-tip.tc-overview .tip-badge'); b = t.index('\n', t.index('  .toc-tip.tc-source .tip-badge')) + 1
t = t[:a] + t[b:]

# ---------- placeholders ----------
title = N.get('title') or op.get('title') or op.get('name') or re.sub(r'[_-]+', ' ', os.path.splitext(csv_name)[0])
doc_span = ('<a href="%s" target="_blank" rel="noopener">Autodesk product documentation</a>' % E(op['url'])) if op.get('url') else 'No documentation JSON supplied'
rep = {
    '{{PAGE_TITLE}}': E(N.get('pageTitle', title + ' Parameters')),
    '{{KICKER}}': E(N.get('kicker', 'FUSION CAM PARAMETERS')),
    '{{H1_TITLE}}': E(title),
    '{{H1_SUBTITLE}}': E(N.get('subtitle', '')),
    '{{BYLINE_A}}': E(N.get('author', 'Swami')),
    '{{BYLINE_B}}': 'Source: %s · %d parameters</span>\n    <span>%s' % (E(csv_name), len(rows), doc_span),
    '{{SUMMARY_BADGE}}': 'OVERVIEW',
    '{{SUMMARY_INTRO}}': N.get('summaryIntro') or (
        'A browsable breakdown of the Fusion <strong>%s</strong> operation, exported as %d parameters across the %s tabs. Each value is shown as exported, resolved to a real number for this tool, and marked as default or changed%s.'
        % (E(title), len(rows), E(', '.join(tabs)), ', with the official description of each setting from the Autodesk documentation' if doc_settings else '')),
    '{{SUMMARY_CALLOUT_LABEL}}': 'Start here',
    '{{SUMMARY_CALLOUT_TEXT}}': N.get('startHere', 'Open Setup at a Glance for the whole operation in one table, then Review Notes before running the job.'),
    '{{MAIL_SUBJECT}}': (title + ' parameters dashboard').replace("'", ''),
}
for k, v in rep.items(): t = t.replace(k, v)
v = raw.replace('\\', '\\\\').replace('`', '\\`').replace('${', '\\${').rstrip('\n')
t = t.replace('{{VERBATIM_TEXT}}', v)
t = t.replace("VERBATIM.replace(/\\n/g, '\\n\\n')", 'VERBATIM')   # CSV lines stay single-spaced
open(out_p, 'w', encoding='utf-8').write(t)

left = re.findall(r'\{\{[A-Z_0-9]+\}\}', t)
unres = [r['Group'] + '|' + r['Parameter'] for r in rows if not resolved(r)]
print('built %s: %d sections, %d parameters, %d changed, %d/%d matched to docs, %d docs-only'
      % (out_p, len(S) + 2, len(rows), len(changed), matched, len(rows), len(docs_only)))
if left: print('LEFTOVER PLACEHOLDERS:', left)
if unres: print('UNRESOLVED (add to notes.resolved):\n  ' + '\n  '.join(unres))
```