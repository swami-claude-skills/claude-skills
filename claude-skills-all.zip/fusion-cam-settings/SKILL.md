---
name: "fusion-cam-settings"
description: "Build Swami's Fusion CAM settings vibe-dashboard from an operation's settings export (CSV or JSON: Tab,Group,Parameter,Value,Default) plus a Fusion Doc JSON of that operation's product documentation. Use whenever he uploads a Fusion toolpath settings CSV or JSON and wants a dashboard."
---

# Fusion CAM Settings Dashboard

Turns one Autodesk Fusion CAM operation (2D Offset Roughing, 2D Pocket, Adaptive, Contour, Drill, Parallel…) into a published **vibe-dashboard** page. It explains every setting the operation used: the raw value, what the value works out to for this tool, whether it was changed from default, and what Autodesk's docs say the setting does. Like every vibe-dashboard it carries a Search section, a Mind Map, a Glossary, fitted tables and an audio overview.

The reference build is the 2D Offset Roughing dashboard (https://claude.ai/artifact/F3ZWMaeUvopSmYNLBmKdfV). Every dashboard from this skill must match its pattern.

## Inputs

1. **Settings export**, either format:
   - **CSV** with columns `Tab,Group,Parameter,Value,Default`.
   - **JSON**: a list of objects with those same keys (key case doesn't matter), or an object holding that list under `rows`, `settings` or `parameters`.

   One row per dialog setting in dialog order. `Value` is the literal or Fusion expression (`250.in/min`, `tool_diameter*.5`, `'helix'`). `Default` is `Yes` (at default), `No` (user-set) or `N/A`. The file name ends in `.csv` or `.json`; the builder picks the reader from it.
2. **Doc JSON**: that operation's Autodesk product-documentation page in the **fusion-doc-json** shape (`operation > tabs[] > sections[] > settings[]`, each setting with `name`, `description`, optional `options[{name, description}]`; `operation.url`, `operation.summary`). Swami's "Fusion Doc to JSON" page makes it (fusion-doc-json skill).

If either input is missing, ask for it once. If Swami says to go ahead without the doc JSON, pass `-` as DOCJSON. The page then builds without doc lines, the docs-only table or References.

## Sections (always in this order)

| # | Section | Built from |
|---|---|---|
| 01 | Dashboard Summary | auto intro, "Start here" callout, "What the docs say" callout (doc summary), index table |
| 02 | Search | vibe-dashboard Search patch (applied by the builder) |
| 03 | Setup at a Glance | `notes.glance` table + "Math used" callout |
| 04… | One section per dialog **tab** in export order (`Tool Tab`, `Geometry Tab`, `Heights Tab`, `Passes Tab`, `Linking Tab`, …) | export rows. A tab gets one table per group when its groups average ≥3 rows; otherwise a single table with a Group column. Heights also gets an auto "Height stack" table (From / Offset per height) |
| next | Changed from Default | every `Default = No` row |
| next | Review Notes | `notes.review`, one table: Item · Where / What the export shows / What to check |
| next | Full Parameter List | all rows + "In the documentation but not in the export" table |
| next | Mind Map | vibe-dashboard Mind Map patch (applied by the builder) |
| next | Glossary | `notes.glossary` |
| next | References | doc URL + related pages + `notes.references` |
| last | Source Document (Verbatim) | the export file, single-spaced |

Parameter tables have the columns **Parameter / Value (as exported) / Resolved / Status**. Under each parameter name there's a grey doc line: the first sentence of the matched doc description. When the value names one of the doc's options (e.g. `'helix'` → Helix), a "▸ Option: …" line is added. Status shows **CHANGED** (pink), `default` or `n/a`. Categories: overview cyan, then each tab in palette order (green, yellow, orange, violet, blue, then extra hues), with changes/review pink and reference magenta.

## Workflow

1. **Read both inputs fully.** Note the tool: name, type, diameter, corner radius, vendor, and flute count if present. Note spindle speed, cutting feed and plunge feed. Check whether the tool name contradicts the diameter.
2. **Write `notes.json`** in the scratchpad. See "Notes JSON" below. This is where the thinking goes: resolve every expression for this tool, write the review notes and the glossary.
3. **Find vibe-dashboard.** `VIBE=$(dirname $(dirname $(find / -path '*vibe-dashboard/assets/template.html' 2>/dev/null | head -1)))`. There is no separate template patch step: the builder reads `$VIBE/assets/template.html` directly and applies vibe-dashboard's own patches (table-fit, Search, Mind Map) itself, so the page always follows the current vibe-dashboard.
4. **Save the builder below** as `build_cam_dashboard.py` in the scratchpad. Run it, writing the page into the working directory (not `/mnt/user-data/outputs/`) with a kebab-case name such as `adaptive-clearing-parameters-dashboard.html`:
   `python3 -I build_cam_dashboard.py "$VIBE" <settings.csv|settings.json> <doc.json|-> notes.json <out>.html <workdir>`
   It prints section, match and docs-only counts, then any **UNRESOLVED** rows, **NO GLOSSARY** or **GLOSSARY TERMS NOT FOUND**. Add each unresolved row to `notes.resolved`, fix any glossary term that never appears in the page (reword its `match`, or set `code`), and rebuild until none are left. It also saves vibe-dashboard's `stress_audio.py` into `<workdir>`.
5. **Add the audio overview** per vibe-dashboard's "Audio overview" rules. Get the outline with `python3 "$VIBE/scripts/audio_overview.py" extract <out>.html`, write `narration.txt` (each section by number then header, including Search, Mind Map, Glossary, References and Source Document; follow its Pronunciation table), run `python3 <workdir>/stress_audio.py "$VIBE" audit narration.txt` and mark any wrong stress, then `python3 <workdir>/stress_audio.py "$VIBE" build <out>.html narration.txt <out>.html`. If the recording can't be made, follow vibe-dashboard's browser-voice fallback; never ship without a player.
6. **Check it renders.** Playwright + Chromium are preinstalled (`/opt/pw-browsers`). Load the page at 1000 px and 1440 px wide, open a tab section and its first table, and screenshot it. You must see no page errors, no console warning from `checkCategoryColours`, no table wider than its section, every Dashboard Summary row linked to a section, and no glossary term with a zero count. If the doc match count is low, look for naming differences between the export and the doc JSON and mention them.
7. **Privacy check** per vibe-dashboard (people under NDA) on the page and narration.
8. **Publish** with the Artifact tool from the working directory. Declare no capabilities. To update a published dashboard, republish the same file path.
9. **Reply briefly:** what the page covers, the 1–3 most important review notes, and anything the export left out (flute count, library stepover, ramp angle…).

For follow-up edits (e.g. "make section 09 a table"), change `notes.json` or the builder, rebuild, re-record the audio if the sections changed (otherwise carry the `AUDIO-OVERVIEW` block over), and republish the same path. Don't hand-edit the HTML; it will drift from the builder.

## Notes JSON

Every key is optional except `glance`, `resolved` and `review`, which make the page worth having. HTML is allowed in `glanceIntro`, `glanceMath`, `tabIntros`, `tabCallouts`, `startHere`, `summaryIntro`, `reviewIntro` and the last two review columns. Everything else is plain text.

```json
{
  "title": "2D Offset Roughing",
  "subtitle": "“THE SLAYER” 0.375 in roughing upcut · 18,000 rpm · 250 in/min",
  "kicker": "FUSION CAM PARAMETERS",
  "startHere": "Open Setup at a Glance, then Review Notes — the tool is named 1/4 in but defined as 0.375 in.",
  "summaryIntro": "(optional override of the auto intro)",
  "glanceIntro": "The export’s expressions <strong>worked out for this tool</strong> (D = 0.375 in, flat end)…",
  "glance": [["Tool", "0.375 in flat end mill — IDC Woodcraft"], ["Spindle / surface speed", "18,000 rpm · ≈ 1,767 SFM"]],
  "glanceMath": "Surface speed = π × 0.375 × 18,000 ÷ 12 ≈ 1,767 SFM. Chip load = 250 ÷ (18,000 × flutes)…",
  "tabTitles": {"Tool": "Tool Tab · Feeds & Speeds"},
  "tabIntros": {"Passes": "The heart of the operation. Changed here: <strong>…</strong>"},
  "tabCallouts": {"Tool": [["Linked feeds", "Lead-in, lead-out and transition feeds follow <code>tool_feedCutting</code>…"]]},
  "sectionIndex": {"Tool Tab · Feeds & Speeds": ["Tool, coolant, every feed and speed", "Checking feeds, chip load or plunge"]},
  "resolved": {"Feed & Speed|Surface Speed": "≈ 1,767 SFM (21,206 in/min)", "Multiple Depths|Maximum Stepdown": "0.1875 in (½ × D)"},
  "review": [["Tool name vs. diameter", "Tool Tab · Feeds & Speeds", "Named “1/4 in” but defined as 0.375 in.", "Confirm the real cutter size…"]],
  "reviewIntro": "(optional)",
  "glossary": [{"term": "Stepover", "match": "stepover", "code": "", "def": "How far the tool moves sideways between passes."}],
  "glossary": [{"term": "Stepover", "match": "stepover", "code": "", "def": "How far the tool moves sideways between passes."}],
  "references": [["IDC Woodcraft — THE SLAYER", "Manufacturer page for the tool", "https://…"]]
}
```

**`resolved` keys** are `Group|Parameter`, matching the export exactly (use `Tab|Group|Parameter` if a group name repeats across tabs). The builder already turns plain literals into readable text: `true/false` → On/Off, `'helix'` → Helix, `250.in/min` → 250 in/min, `25deg` → 25°. Add a `resolved` entry only for expressions, or for literals worth explaining (`"Left (climb, on CW spindle)"`, `"Off — cuts to final size"`). How to resolve:
- Substitute the tool's numbers: `tool_diameter`, `tool_cornerRadius` (0 for a flat end mill), `tool_spindleSpeed`, `tool_feedCutting`, `tool_feedPlunge`, `tool_numberOfFlutes`. Show the result with units: `0.1875 in (½ × D)`.
- Fusion's export writes function arguments with `;` (`Math.min(a; b)`); read them as commas.
- If a value depends on a library field the export doesn't carry (flute count, `tool_stepover`, `tool_rampAngle`, `tool_fluteLength`, `tool_taperAngle` on a tapered tool), say so: `From tool library (value not in export)`. For chip load, give a value per likely flute count. Never invent the number.
- Mark settings that a disabled parent switches off as `(inactive)`, e.g. Lead-In radius when Lead-In is off, or Radial Stock to Leave when Stock to Leave is off.
- Heights: give each Offset its absolute result, e.g. `+0.4 in → 0.6 in above stock top`.

**`glance`** has 10–14 rows covering tool, speed/SFM, cutting feed, plunge/ramp feed, chip load, stepdown, stepover, entry/ramp, heights, stock to leave, finishing, direction and coolant. Leave out rows that don't apply (drilling has no stepover).

**`review`** has 4–8 rows, most important first. Each row is `[item, where, what the export shows, what to check]`, where `where` is an exact section title such as `Passes Tab`. It auto-links as `Passes Tab [06]`. Look for:
- tool name vs. diameter mismatches
- values the export doesn't carry
- no stock to leave on a roughing op
- feeds that look high or low for the chip load
- Both Ways / climb-vs-conventional choices
- leads off with Keep Tool Down
- ramp vs. plunge entry
- heights that collide (retract = feed)
- export artifacts (semicolons)

Use the doc text to back up a point where it helps. These are observations, not errors, so keep the tone advisory.

**`glossary`** has 10–20 entries for the CAM terms a reader meets on this page (stepover, stepdown, chip load, SFM, climb milling, ramp, lead-in, stock to leave, retract height…). Each is `{term, match, code, def}`: `match` is the lowercase word or phrase the page uses (it must start and end with a letter or digit), `code` is the code-styled form if the term only appears inside `<code>` (otherwise `""`), and `def` is one plain sentence. Every term must appear somewhere in the page body; the builder warns about any that don't.

**`glossary`** has 10–20 entries for the CAM terms a reader meets on this page (stepover, stepdown, chip load, SFM, climb milling, ramp, lead-in, stock to leave, retract height…). Each is `{term, match, code, def}`: `match` is the lowercase word or phrase the page uses (it must start and end with a letter or digit), `code` is the code-styled form if the term only appears inside `<code>` (otherwise `""`), and `def` is one plain sentence. Every term must appear somewhere in the page body; the builder warns about any that don't.

## How doc matching works

The builder matches each export row to a doc setting. First pass, exact matches in this order: same tab and same normalized name; same tab and the name without its "(…)" part; any tab and same name. Second pass, for rows still unmatched: the export name as a whole-word phrase inside an unused doc setting's name in the same tab. Doc tab names lose "tab settings". When the doc section matches the export group, that hit wins. Doc settings that nothing matched go in the "In the documentation but not in the export" table.


## Builder: build_cam_dashboard.py

Save verbatim. It needs no changes per operation; put operation-specific text in `notes.json`.

```python
#!/usr/bin/env python3
"""Fusion CAM settings dashboard builder.

usage: python3 -I build_cam_dashboard.py VIBE_DIR SETTINGS DOCJSON NOTESJSON OUT [WORKDIR]
  VIBE_DIR  the vibe-dashboard skill folder (assets/template.html, scripts/search_patch.py, SKILL.md)
  SETTINGS  Fusion operation settings: a .csv with columns Tab,Group,Parameter,Value,Default,
            or a .json list of objects with those keys (or {"rows": [...]})
  DOCJSON   Fusion Doc -> JSON output (operation > tabs > sections > settings), or - for none
  NOTESJSON Claude-written notes (resolved values, glance, review, glossary...) - see SKILL.md
  OUT       output .html (overwritten)
  WORKDIR   where vibe-dashboard's patch helpers and stress_audio.py are saved (default: OUT's folder)
Applies vibe-dashboard's table-fit, Search and Mind Map patches. Prints any expression rows still
unresolved so they can be added to the notes, and any glossary term that never appears in the page.
"""
import csv, json, html, re, sys, textwrap, colorsys, os, subprocess

VIBE, set_p, doc_p, notes_p, out_p = sys.argv[1:6]
WD = sys.argv[6] if len(sys.argv) > 6 else os.path.dirname(os.path.abspath(out_p))
E = html.escape
need = {'Tab', 'Group', 'Parameter', 'Value', 'Default'}
raw = open(set_p, encoding='utf-8-sig').read()
if set_p.lower().endswith('.json'):
    data = json.loads(raw)
    if isinstance(data, dict): data = data.get('rows') or data.get('settings') or data.get('parameters') or []
    canon = {k.lower(): k for k in need}
    rows = [{canon.get(str(k).strip().lower(), k): ('' if v is None else str(v)) for k, v in d.items()} for d in data]
    kind = 'JSON'
else:
    rows = list(csv.DictReader(raw.splitlines()))
    kind = 'CSV'
assert rows and need <= set(rows[0].keys()), 'settings must have fields ' + ','.join(sorted(need))
for r in rows:
    for k in need: r[k] = (r[k] or '').strip()
doc = json.load(open(doc_p, encoding='utf-8')) if doc_p != '-' else {}
N = json.load(open(notes_p, encoding='utf-8'))
t = open(os.path.join(VIBE, 'assets/template.html'), encoding='utf-8').read()
csv_name = os.path.basename(set_p)

# ---------- helpers ----------
def W(x, n):
    """escape + hard-wrap long text with <br> so table columns stay balanced"""
    x = (x or '').strip()
    return '<br>'.join(E(l) for l in textwrap.wrap(x, n, break_long_words=False, break_on_hyphens=False)) or E(x)

def norm(s, parens=True):
    s = (s or '').lower()
    if not parens: s = re.sub(r'\(.*?\)', ' ', s)
    s = s.replace('&', ' and ')
    return re.sub(r'[^a-z0-9]+', ' ', s).strip()

def first_sentence(s, cap=170):
    s = re.sub(r'\s+', ' ', s or '').strip()
    m = re.match(r'(.+?[.!?])(\s|$)', s)
    s = m.group(1) if m else s
    return s if len(s) <= cap else s[:cap].rsplit(' ', 1)[0] + '…'

def auto_resolve(v):
    """plain literals -> readable text; expressions -> None"""
    v = v.strip()
    if v in ('', 'N/A'): return '—'
    if v.lower() == 'true': return 'On'
    if v.lower() == 'false': return 'Off'
    m = re.fullmatch(r"'([^']*)'", v)
    if m: s = m.group(1); return s[:1].upper() + s[1:]
    m = re.fullmatch(r'(-?\d+(?:\.\d*)?)\s*(in/min|inpm|ipm|mm/min|in|mm|deg|rpm|%)?', v)
    if m:
        num = m.group(1).rstrip('.')
        if '.' in num: num = num.rstrip('0').rstrip('.') or '0'
        u = m.group(2) or ''
        if u == 'deg': return num + '°'
        if u in ('inpm', 'ipm'): u = 'in/min'
        return (num + ' ' + u).strip()
    return None

def resolved(r):
    R = N.get('resolved', {})
    return R.get(r['Group'] + '|' + r['Parameter']) or R.get(r['Tab'] + '|' + r['Group'] + '|' + r['Parameter']) \
        or R.get(r['Parameter']) or auto_resolve(r['Value'])

def status(v):
    if v == 'No':  return '<span style="color:var(--cat-review);font-family:var(--mono);white-space:nowrap">CHANGED</span>'
    if v == 'Yes': return '<span style="color:var(--text-mute);font-family:var(--mono);white-space:nowrap">default</span>'
    return '<span style="color:var(--text-mute);font-family:var(--mono);white-space:nowrap">n/a</span>'

# ---------- documentation index ----------
op = doc.get('operation', {}) if doc else {}
def tab_key(name): return norm(re.sub(r'\b(tab settings|tab|settings)\b', '', name or '', flags=re.I))
doc_settings = []          # (tabkey, tabname, sectionname, setting)
for tb in (doc.get('tabs') or []):
    for sec in tb.get('sections') or []:
        for st in sec.get('settings') or []:
            doc_settings.append((tab_key(tb.get('name')), tb.get('name', ''), sec.get('name', ''), st))
used = set()
def find_doc(r, loose):
    tk, p, p0 = tab_key(r['Tab']), norm(r['Parameter']), norm(r['Parameter'], False)
    if not loose:
        tests = [lambda d: d[0] == tk and norm(d[3].get('name')) == p,
                 lambda d: d[0] == tk and norm(d[3].get('name'), False) == p0,
                 lambda d: norm(d[3].get('name')) == p]
    else:   # only against settings nobody matched exactly; CSV name must sit inside the doc name
        tests = [lambda d: d[0] == tk and len(p0) >= 5 and re.search(r'\b' + re.escape(p0) + r'\b', norm(d[3].get('name'), False))]
    for test in tests:
        hits = [i for i, d in enumerate(doc_settings) if test(d) and not (loose and i in used)]
        if hits:
            # prefer a hit whose doc section matches the CSV group
            hits.sort(key=lambda i: norm(doc_settings[i][2]) != norm(r['Group']))
            used.add(hits[0]); return doc_settings[hits[0]][3]
    return None
for r in rows: r['_doc'] = find_doc(r, False)
for r in rows:
    if not r['_doc']: r['_doc'] = find_doc(r, True)

def option_note(r):
    st = r['_doc']
    if not st: return ''
    v = norm(r['Value'].strip("'\""))
    for o in st.get('options') or []:
        if v and norm(o.get('name')) == v and o.get('description'):
            return o['name'] + ': ' + first_sentence(o['description'], 120)
    return ''

def pcell(r, wrap=44):
    """parameter cell: name + dim doc line (+ matched option line)"""
    s = '<strong>%s</strong>' % E(r['Parameter'])
    d = first_sentence((r['_doc'] or {}).get('description', ''))
    if d: s += '<br><span class="docline">%s</span>' % W(d, wrap)
    o = option_note(r)
    if o: s += '<br><span class="docline docopt">%s</span>' % W('▸ ' + o, wrap)
    return s

def ptable(desc, sel, show_group):
    hdr = '<th>Parameter</th>' + ('<th>Group</th>' if show_group else '') + \
          '<th>Value (as exported)</th><th>Resolved</th><th>Status</th>'
    body = ''.join('<tr><td>%s</td>%s<td><code>%s</code></td><td>%s</td><td>%s</td></tr>' % (
        pcell(r), ('<td>%s</td>' % E(r['Group'])) if show_group else '', W(r['Value'], 28),
        W(resolved(r) or '⚠ unresolved', 24), status(r['Default'])) for r in sel)
    return '<div class="table-wrap" data-desc="%s"><table><thead><tr>%s</tr></thead><tbody>%s</tbody></table></div>' % (E(desc), hdr, body)

def section(num, cat, badge, title, inner):
    return ('<div class="section cat-%s" data-title="%s" data-cat="%s"><div class="sec-head"><span class="sec-num">%s</span>'
            '<span class="sec-title">%s</span><span class="cat-badge">%s</span><span class="chevron">▶</span></div>'
            '<div class="sec-body">%s</div></div>\n') % (cat, E(title), cat, num, E(title), E(badge), inner)

def callout(lbl, txt): return '<div class="callout"><span class="lbl">%s</span>%s</div>' % (E(lbl), txt)

# ---------- structure ----------
tabs = []
for r in rows:
    if r['Tab'] not in tabs: tabs.append(r['Tab'])
def groups_of(tab):
    g = []
    for r in rows:
        if r['Tab'] == tab and r['Group'] not in g: g.append(r['Group'])
    return g
changed = [r for r in rows if r['Default'] == 'No']
tab_title = {tb: N.get('tabTitles', {}).get(tb, tb + ' Tab') for tb in tabs}

FIXED = {'overview', 'review', 'reference'}
def slug(s):
    s = re.sub(r'[^a-z0-9]+', '-', s.lower()).strip('-') or 'tab'
    return 'tab-' + s if s in FIXED else s
tab_cat = {tb: slug(tb) for tb in tabs}

S, index = [], []
num = 1
def nxt():
    global num
    num += 1
    return '%02d' % num

# 02 Setup at a Glance
glance = N.get('glance', [])
gt = '<div class="table-wrap" data-desc="Key settings, resolved to numbers"><table><thead><tr><th>Item</th><th>Effective setting</th></tr></thead><tbody>' + \
     ''.join('<tr><td><strong>%s</strong></td><td>%s</td></tr>' % (E(a), E(b)) for a, b in glance) + '</tbody></table></div>'
inner = '<p>%s</p>' % N.get('glanceIntro', 'The key settings of this operation, with each expression worked out for this tool.') + gt
if N.get('glanceMath'): inner += callout('Math used', N['glanceMath'])
S.append(section(nxt(), 'overview', 'OVERVIEW', 'Setup at a Glance', inner))
index.append(('Setup at a Glance', 'Key settings resolved to real numbers', 'You want the whole op in one table'))

# one section per dialog tab
for tb in tabs:
    sel = [r for r in rows if r['Tab'] == tb]
    gs = groups_of(tb)
    ch = [r['Parameter'] for r in sel if r['Default'] == 'No']
    intro = N.get('tabIntros', {}).get(tb) or (
        '%d parameters in %d group%s. %s' % (len(sel), len(gs), '' if len(gs) == 1 else 's',
        ('Changed from default here: <strong>' + E(', '.join(ch)) + '</strong>.') if ch else 'Every value is at its Fusion default.'))
    inner = '<p>%s</p>' % intro
    if norm(tb) == 'heights':
        stack = []
        for g in gs:
            fr = next((r for r in sel if r['Group'] == g and r['Parameter'] == 'From'), None)
            of = next((r for r in sel if r['Group'] == g and r['Parameter'] == 'Offset'), None)
            if fr or of:
                stack.append('<tr><td><strong>%s</strong></td><td>%s</td><td>%s</td></tr>' % (
                    E(g), E(resolved(fr) if fr else '—'), E(resolved(of) if of else '—')))
        if stack:
            inner += '<div class="table-wrap no-sort" data-desc="Height stack, top to bottom"><table><thead><tr><th>Height</th><th>From</th><th>Offset / result</th></tr></thead><tbody>' + ''.join(stack) + '</tbody></table></div>'
    if len(sel) / max(1, len(gs)) < 3 or len(gs) == 1:
        inner += ptable(tb + ' parameters', sel, len(gs) > 1)
    else:
        for g in gs: inner += ptable(g + ' parameters', [r for r in sel if r['Group'] == g], False)
    for lbl, txt in N.get('tabCallouts', {}).get(tb, []): inner += callout(lbl, txt)
    S.append(section(nxt(), tab_cat[tb], tb.upper(), tab_title[tb], inner))
    focus, when = N.get('sectionIndex', {}).get(tab_title[tb], [', '.join(gs[:5]), 'Checking the %s tab settings' % tb])
    index.append((tab_title[tb], focus, when))

# Changed from Default
ct = '<div class="table-wrap" data-desc="User-set parameters"><table><thead><tr><th>Parameter</th><th>Tab › Group</th><th>Value</th><th>Resolved</th></tr></thead><tbody>' + \
     ''.join('<tr><td>%s</td><td>%s</td><td><code>%s</code></td><td>%s</td></tr>' % (
         pcell(r), E(r['Tab'] + ' › ' + r['Group']), W(r['Value'], 28), W(resolved(r) or '⚠ unresolved', 24)) for r in changed) + '</tbody></table></div>'
S.append(section(nxt(), 'review', 'CHANGES', 'Changed from Default',
    '<p>Of the %d parameters, <strong>%d</strong> are not at their Fusion default — these are the choices that make this operation yours.</p>' % (len(rows), len(changed)) + ct))
index.append(('Changed from Default', 'The %d user-set parameters' % len(changed), 'Seeing what was customized'))

# Review Notes
rv = N.get('review', [])
rt = '<div class="table-wrap" data-desc="Items to check before running"><table><thead><tr><th>Item · Where</th><th>What the export shows</th><th>What to check</th></tr></thead><tbody>' + \
     ''.join('<tr><td><strong>%s</strong><br><span style="font-size:12px">%s</span></td><td>%s</td><td>%s</td></tr>' % (E(a), E(b), c, d) for a, b, c, d in rv) + '</tbody></table></div>'
S.append(section(nxt(), 'review', 'REVIEW', 'Review Notes',
    '<p>%s</p>' % N.get('reviewIntro', 'Things worth a second look before running the job. These are observations from the export, not errors in Fusion.') + rt))
index.append(('Review Notes', 'Items worth a second look', 'Before posting and running the job'))

# Full Parameter List (+ docs-only settings)
full = '<div class="table-wrap" data-desc="All %d parameters"><table><thead><tr><th>Parameter</th><th>Tab › Group</th><th>Value (as exported)</th><th>Resolved</th><th>Status</th></tr></thead><tbody>' % len(rows) + \
       ''.join('<tr><td>%s</td><td>%s</td><td><code>%s</code></td><td>%s</td><td>%s</td></tr>' % (
           pcell(r), E(r['Tab'] + ' › ' + r['Group']), W(r['Value'], 28), W(resolved(r) or '⚠ unresolved', 24), status(r['Default'])) for r in rows) + '</tbody></table></div>'
docs_only = [d for i, d in enumerate(doc_settings) if i not in used]
if docs_only:
    full += '<div class="table-wrap" data-desc="In the documentation but not in the export"><table><thead><tr><th>Setting</th><th>Tab › Section</th><th>What it does (docs)</th></tr></thead><tbody>' + \
            ''.join('<tr><td><strong>%s</strong></td><td>%s</td><td>%s</td></tr>' % (
                E(d[3].get('name', '')), E(d[1] + ' › ' + d[2]), W(first_sentence(d[3].get('description', ''), 260), 60)) for d in docs_only) + '</tbody></table></div>'
matched = sum(1 for r in rows if r['_doc'])
docnote = (' %d of them matched to the product documentation (shown as the grey line under each name).' % matched) if doc_settings else ''
S.append(section(nxt(), 'reference', 'REFERENCE', 'Full Parameter List',
    '<p>All %d rows from the export in their original order, with resolved values added.%s Sort any column — click <strong>Status</strong> to group the changed values together.</p>' % (len(rows), docnote) + full))
index.append(('Full Parameter List', 'All %d rows, sortable' % len(rows), 'Looking up any single parameter'))

# References
refs = []
if op.get('url'):
    refs.append((op.get('title') or op.get('name') or 'Product documentation', 'Official Autodesk explanation of every setting in this operation', op['url']))
for p in (op.get('relatedPages') or []):
    if isinstance(p, dict):
        u = p.get('href') or p.get('url'); tx = p.get('text') or p.get('title') or u
        if u: refs.append((tx, 'Related documentation page', u))
for a, b, u in N.get('references', []): refs.append((a, b, u))
REFS = refs

GLOSS = N.get('glossary', [])

# ---------- splice into template ----------
# content sections go before the template's Glossary; its Glossary, References and verbatim blocks are kept
a = t.index('  <!-- SECTION PATTERN'); b = t.index('  <!-- OPTIONAL (include whenever the dashboard uses terms')
t = t[:a] + ''.join(S) + '\n' + t[b:]
sum_rows = ''.join('<tr><td><span class="secnum">%02d</span></td><td><strong>%s</strong></td><td class="sec-cat"></td><td>%s</td><td>%s</td></tr>\n' % (
    i + 2, E(a), E(f), E(w)) for i, (a, f, w) in enumerate(index))
a = t.index('            <tr><td><span class="secnum">02</span>'); b = t.index('            <!-- one row per remaining section -->')
t = t[:a] + sum_rows + t[b:]

# Glossary (notes.glossary: [{term, match, code, def}]) - required by vibe-dashboard
if GLOSS:
    grows = ''.join('<tr data-gterm="%s" data-match="%s" data-code="%s"><td><strong>%s</strong></td><td>%s</td><td class="gloss-uses"></td><td class="gloss-count"></td></tr>\n            ' % (
        E(re.sub(r'[^a-z0-9]+', '-', g['term'].lower()).strip('-')), E(g.get('match', '')), E(g.get('code', '')), E(g['term']), E(g['def'])) for g in GLOSS)
    a = t.index('            <tr data-gterm="{{GLOSS_A_ID}}"'); b = t.index('            <!-- one row per term -->')
    t = t[:a] + '            ' + grows + t[b:]
else:
    a = t.index('  <!-- OPTIONAL (include whenever the dashboard uses terms'); b = t.index('  <!-- REQUIRED (when the dashboard cites')
    t = t[:a] + t[b:]

# References in the template's format: Source / Topic / What it covers / Cited in / Domain / Webpage
if REFS:
    PAL = ['#38dafa', '#38fa79', '#dafa38', '#fa9938', '#fa3899', '#ea38fa', '#7938fa', '#3879fa']
    def dom(u): return re.sub(r'^https?://([^/]+).*$', r'\1', u)
    def rtopic(i, b): return 'Autodesk docs' if i == 0 and op.get('url') else ('Related docs' if b == 'Related documentation page' else 'Tool / other')
    tcol = {}
    for i, (a_, b_, u_) in enumerate(REFS): tcol.setdefault(rtopic(i, b_), PAL[len(tcol) % 8])
    rrows = ''.join('<tr data-ref="%d"><td><strong>[%d] %s</strong></td><td><span class="tid" style="--tc:%s">%s</span></td><td>%s</td><td>—</td><td>%s</td><td><a href="%s" target="_blank" rel="noopener">open ↗</a></td></tr>\n            ' % (
        i + 1, i + 1, E(a_), tcol[rtopic(i, b_)], E(rtopic(i, b_)), E(b_), E(dom(u_)), E(u_)) for i, (a_, b_, u_) in enumerate(REFS))
    a = t.index('            <tr data-ref="{{REF_A_NUM}}"'); b = t.index('            <!-- one row per cited source -->')
    t = t[:a] + '            ' + rrows + t[b:]
    t = t.replace('Sources cited throughout this dashboard. The bracketed numbers in the text are citations; click one to land on its row here.', 'The Autodesk documentation behind the doc lines on this page, plus related pages.')
else:
    a = t.index('  <!-- REQUIRED (when the dashboard cites'); b = t.index('  <!-- OPTIONAL verbatim')
    t = t[:a] + t[b:]
    t = re.sub(r'\s*<tr><td><span class="secnum" data-target-title="References"></span>.*?</tr>', '', t, count=1)
for old in ('97', '98', '99'):
    if '<span class="sec-num">%s</span>' % old in t: t = t.replace('<span class="sec-num">%s</span>' % old, '<span class="sec-num">%s</span>' % nxt())
t = t.replace('cat-source', 'cat-reference').replace('data-cat="source"', 'data-cat="reference"')
t = t.replace('<span class="cat-badge">Source</span>', '<span class="cat-badge">SOURCE</span>')
t = t.replace('Original reproduced exactly as supplied.', 'The uploaded %s settings file, reproduced exactly as supplied.' % kind)
t = t.replace('<td>Original source, reproduced verbatim</td>', '<td>The uploaded settings file, verbatim</td>')

# summary callouts: docs description after the Start-here callout
docs_sum = op.get('summary') or ' '.join((op.get('description') or [])[:1])
if docs_sum:
    t = t.replace('{{SUMMARY_CALLOUT_TEXT}}</div>', '{{SUMMARY_CALLOUT_TEXT}}</div>' + callout('What the docs say', E(first_sentence(docs_sum, 400))), 1)

# ---------- categories ----------
cats = [('overview', '#38dafa')]
tab_colours = ['#38fa79', '#dafa38', '#fa9938', '#7938fa', '#3879fa']
extra_hues = [0, 105]
for i, tb in enumerate(tabs):
    if i < len(tab_colours): c = tab_colours[i]
    else:
        h = extra_hues[(i - len(tab_colours)) % len(extra_hues)]
        rr, gg, bb = colorsys.hls_to_rgb(h / 360, 0.6, 0.95); c = '#%02x%02x%02x' % (int(rr * 255), int(gg * 255), int(bb * 255))
    cats.append((tab_cat[tb], c))
cats += [('review', '#fa3899'), ('reference', '#ea38fa')]
def rgb(h): return ','.join(str(int(h[i:i + 2], 16)) for i in (1, 3, 5))
vars_ = ''.join('    --cat-%s:%s;\n' % c for c in cats)
a = t.index('    /* the two vars below'); b = t.index('  }', a)
t = t[:a] + vars_ + t[b:]
blocks = ''
for n, h in cats:
    blocks += ('  .cat-{n} .cat-badge{{color:var(--cat-{n});background:rgba({r},.10)}}\n  .cat-{n}{{border-left:3px solid var(--cat-{n})}}\n'
               '  .toc-chip.tc-{n}{{border-left-color:var(--cat-{n})}}\n  .toc-chip.tc-{n}:hover{{color:var(--cat-{n})}}\n'
               '  .toc-tip.tc-{n} .tip-badge{{color:var(--cat-{n});background:rgba({r},.10)}}\n').format(n=n, r=rgb(h))
blocks += '  .docline{font-size:12px;font-weight:400;color:var(--text-mute);line-height:1.45}\n  .docline.docopt{color:var(--text-dim)}\n'
a = t.index('  /* live defs for the template'); b = t.index('  .chevron{')
t = t[:a] + blocks + t[b:]
a = t.index('  .toc-tip.tc-overview .tip-badge'); b = t.index('\n', t.index('  .toc-tip.tc-source .tip-badge')) + 1
t = t[:a] + t[b:]

# ---------- placeholders ----------
title = N.get('title') or op.get('title') or op.get('name') or re.sub(r'[_-]+', ' ', os.path.splitext(csv_name)[0])
doc_span = ('<a href="%s" target="_blank" rel="noopener">Autodesk product documentation</a>' % E(op['url'])) if op.get('url') else 'No documentation JSON supplied'
rep = {
    '{{PAGE_TITLE}}': E(N.get('pageTitle', title + ' Parameters')),
    '{{KICKER}}': E(N.get('kicker', 'FUSION CAM PARAMETERS')),
    '{{H1_TITLE}}': E(title),
    '{{H1_SUBTITLE}}': E(N.get('subtitle', '')),
    '{{BYLINE_A}}': E(N.get('author', 'Swami')),
    '{{BYLINE_B}}': 'Source: %s · %d parameters</span>\n    <span>%s' % (E(csv_name), len(rows), doc_span),
    '{{SUMMARY_BADGE}}': 'OVERVIEW',
    '{{SUMMARY_INTRO}}': N.get('summaryIntro') or (
        'A browsable breakdown of the Fusion <strong>%s</strong> operation, exported as %d parameters across the %s tabs. Each value is shown as exported, resolved to a real number for this tool, and marked as default or changed%s.'
        % (E(title), len(rows), E(', '.join(tabs)), ', with the official description of each setting from the Autodesk documentation' if doc_settings else '')),
    '{{SUMMARY_CALLOUT_LABEL}}': 'Start here',
    '{{SUMMARY_CALLOUT_TEXT}}': N.get('startHere', 'Open Setup at a Glance for the whole operation in one table, then Review Notes before running the job.'),
    '{{MAIL_SUBJECT}}': (title + ' parameters dashboard').replace("'", ''),
}
for k, v in rep.items(): t = t.replace(k, v)
t = t.replace('{{VERBATIM_TEXT}}', '__VERBATIM_SLOT__')
t = t.replace("VERBATIM.replace(/\\n/g, '\\n\\n')", 'VERBATIM')   # settings lines stay single-spaced
left = re.findall(r'\{\{[A-Z_0-9]+\}\}', t)
open(out_p, 'w', encoding='utf-8').write(t)

# ---------- vibe-dashboard patches (taken from its current SKILL.md, so they stay in step) ----------
sk = open(os.path.join(VIBE, 'SKILL.md'), encoding='utf-8').read()
blocks_ = re.findall(r'`{3}python\n(.*?)`{3}', sk, re.S)
pick = lambda test: next(b for b in blocks_ if test(b))
os.makedirs(WD, exist_ok=True)
open(os.path.join(WD, 'fit_patch.py'), 'w').write(pick(lambda b: 'function bodyWordMin(' in b and 'table-fit patch' in b))
open(os.path.join(WD, 'mindmap_patch.py'), 'w').write(pick(lambda b: '"""mindmap_patch.py' in b))
open(os.path.join(WD, 'stress_audio.py'), 'w').write(pick(lambda b: 'stress_audio.py — run' in b))
for cmd in (['python3', os.path.join(WD, 'fit_patch.py'), out_p], ['python3', os.path.join(VIBE, 'scripts/search_patch.py'), out_p],
            ['python3', os.path.join(WD, 'mindmap_patch.py'), out_p]):
    pr = subprocess.run(cmd, capture_output=True, text=True); print(pr.stdout.strip() or pr.stderr.strip())
    if pr.returncode: sys.exit('patch failed: ' + ' '.join(cmd))
# verbatim goes in last, escaped for a JS template string, so no patch ever sees it
v = raw.replace('\\', '\\\\').replace('`', '\\`').replace('${', '\\${').replace('</', '<\\/').replace('<!--', '<\\!--').rstrip('\n')
t = open(out_p, encoding='utf-8').read()
assert t.count('__VERBATIM_SLOT__') == 1
open(out_p, 'w', encoding='utf-8').write(t.replace('__VERBATIM_SLOT__', v))

body = re.sub(r'<[^>]+>', ' ', ''.join(S))
zero = [g['term'] for g in GLOSS if g.get('match') and not re.search(g['match'], body, re.I)]
unres = [r['Group'] + '|' + r['Parameter'] for r in rows if not resolved(r)]
print('built %s: %d sections, %d parameters, %d changed, %d/%d matched to docs, %d docs-only'
      % (out_p, len(S) + 2, len(rows), len(changed), matched, len(rows), len(docs_only)))
if left: print('LEFTOVER PLACEHOLDERS:', left)
if not GLOSS: print('NO GLOSSARY: add notes.glossary (10-20 terms) - vibe-dashboard requires one')
if zero: print('GLOSSARY TERMS NOT FOUND IN THE PAGE (fix their match):', ', '.join(zero))
if unres: print('UNRESOLVED (add to notes.resolved):\n  ' + '\n  '.join(unres))
```

## Changes

- **Nov 9, 2026:** Settings accepted as CSV or JSON. The builder now reads vibe-dashboard's template directly (the old "Template patch" step is gone) and applies its table-fit, Search and Mind Map patches, keeps the Glossary from `notes.glossary`, uses the 5-column summary rows and 6-column References, and saves `stress_audio.py` for the audio overview. Workflow adds the audio overview, render checks at 1000/1440 px, and the privacy check.
