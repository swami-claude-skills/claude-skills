#!/usr/bin/env python3
"""Check that a built Graphic Finder page still matches the locked template pattern.

Usage:
    python3 check_pattern.py BUILT.html [TEMPLATE.html]

Reports:
  - whether the <style> block is byte-identical to the template (expected unless
    the user asked for a style change)
  - any required element IDs, classes or JS functions that went missing
  - section count / numbering and data-target range sanity
Exit code 0 = pattern intact, 1 = something to fix.
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_TEMPLATE = HERE.parent / "assets" / "template.html"

REQUIRED_IDS = [
    "stickyStack", "tocBar", "expandAll", "collapseAll", "search", "resetBtn",
    "prevBtn", "nextBtn", "searchCount", "content", "mailLink",
    "typeFilters", "styleFilters", "descInput", "urlInput", "dropZone", "fileInput",
    "imgPreview", "previewImg", "previewName", "runBtn", "clearToolBtn",
    "googleBtn", "bingBtn", "braveBtn", "ddgBtn", "svgrepoBtn", "freesvgBtn", "freepikBtn",
    "toolStatus", "derivedDesc", "searchFallback", "fbGoogle", "fbBing",
    "rawToggle", "rawLink", "rawBox", "resultsMeta", "resultsWrap", "resultsTable", "resultsBody",
]
REQUIRED_JS = [
    "function deriveSubs", "function buildTip", "function placeTip",
    "function buildFloatingHeaders", "function syncFloatingHeaders",
    "function initSortableTables", "function mirrorSortToClone",
    "function scrollToSection", "function scrollToAnchor", "function doSearch",
    "function handleFile", "function downscale", "function statusDone",
    "function scrollToResults", "function buildFilterBrief", "function buildEnhancedString",
    "function buildEngineQuery", "function openEngine", "async function callClaude",
    'claude.use("sample")', "function getSample", "function b64ToBlob", "function parseResults", "function renderResults",
    "function makeSortable", "async function onRun", "async function describeImage",
    "unhandledrejection",
]
REQUIRED_CLASSES = ["tool-sub", "tool-sub-head", "mode-btn", "mode-pane", "filter-chip",
                    "type-row-lbl", "handoff-lbl", "repo-btn", "engine-btn", "secnum-link", "seclink"]


def style_block(html):
    m = re.search(r"<style>(.*?)</style>", html, re.S)
    return m.group(1) if m else ""


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    built = Path(sys.argv[1]).read_text(encoding="utf-8")
    tpl = Path(sys.argv[2] if len(sys.argv) > 2 else DEFAULT_TEMPLATE).read_text(encoding="utf-8")
    problems = []

    if style_block(built) == style_block(tpl):
        print("CSS: identical to template")
    else:
        print("CSS: DIFFERS from template (fine only if the user asked for a style change)")

    for i in REQUIRED_IDS:
        if f'id="{i}"' not in built:
            problems.append(f"missing id: {i}")
    for j in REQUIRED_JS:
        if j not in built:
            problems.append(f"missing JS: {j}")
    if "api.anthropic.com/v1/messages" in built:
        problems.append("direct fetch to api.anthropic.com is back -- published artifacts block it; use claude.use(\"sample\")")
    for c in REQUIRED_CLASSES:
        if c not in built:
            problems.append(f"missing class: {c}")

    nums = re.findall(r'<span class="sec-num">(\d+)</span>', built)
    n = len(nums)
    expected = [f"{k:02d}" for k in range(1, n + 1)]
    if nums != expected:
        problems.append(f"section numbers not sequential 01..: {nums}")
    targets = [int(t) for t in re.findall(r'class="(?:secnum-link|seclink)"[^>]*data-target="(\d+)"', built)]
    bad = [t for t in targets if t < 0 or t >= n]
    if bad:
        problems.append(f"data-target out of range (0..{n-1}): {sorted(set(bad))}")
    print(f"Sections: {n}  ·  jump links: {len(targets)}")

    if problems:
        print("\nFIX:")
        for p in problems:
            print("  -", p)
        sys.exit(1)
    print("Pattern intact.")


if __name__ == "__main__":
    main()
