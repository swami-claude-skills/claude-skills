---
name: "vector-bitmap-graphic-finder"
description: Reproduce Swami's Vector & Bitmap Graphic Finder page exactly — the locked Vibe Coding dark-theme single .html (sticky TOC chips with hover tooltips, collapsible numbered sections, live AI search with describe/URL/upload input, file-type and style filter chips, Google/Bing/Brave/DuckDuckGo and SVGrepo/FreeSVG/Freepik hand-off buttons, sortable results, search-operator, file-type and vectorize reference tables). Use whenever Swami wants this graphic finder (or an image/SVG/DXF search tool for CAD, laser, CNC) rebuilt, copied, re-published, edited, or used as the base for a similar finder tool — the output must match the saved page pattern rather than be redesigned.
---

# Vector & Bitmap Graphic Finder (exact pattern)

`assets/template.html` is the finished, approved page. The job is **copy, then edit in place** — never rewrite it from memory or "clean it up". Every byte of CSS and JS in the template is deliberate (most of it fixed a real failure), so the safest build is the template itself with only the requested content changed.

## Build

1. `cp assets/template.html <name>.html` into the working directory. Default name: `vector-bitmap-graphic-finder.html`. Run scripts from this skill's folder (paths below are relative to it).
2. If the request is just "make the graphic finder" / "reproduce it" — stop here; the copy *is* the deliverable.
3. Otherwise make only the requested edits with targeted Edit calls (see "What may change"). Don't reflow, reindent, rename classes, reorder sections or "modernize" anything you weren't asked to touch.
4. Run `python3 scripts/check_pattern.py <name>.html` and fix anything under **FIX**. "CSS: DIFFERS" is acceptable only when a style change was asked for.
5. Deliver per the host's rules. On claude.ai, publish as an Artifact **with `capabilities: {sample: {images: true}}`** — the live AI search needs it (see "Live search host"). On a redeploy to the same artifact, omit `capabilities` to keep the stored declaration. Reply with one or two lines on what changed.

## Locked pattern (keep exactly)

- **Theme tokens** on `:root`: `--bg #0d0d0f`, `--panel #141418`, `--panel-2 #1a1a20`, `--cyan #00e5ff`, `--green #00ff88`, `--text #e8e8ec`, borders `#26262e`; fonts JetBrains Mono + DM Sans (Google Fonts).
- **Categories** (one `--cat-*` var + its CSS blocks each): `overview` cyan, `search` green, `guide` amber `#ffb020`, `vectorize` violet `#7c5cff`, `caveat` pink `#ff5c7a`.
- **Header**: kicker `CAD / CNC ASSET FINDER`, H1 with grey `.sub` line, mono byline row.
- **Sticky stack**: TOC chip bar (built by JS from `.section`s, rich hover tooltip listing sub-items) + toolbar (expand all / collapse all / in-page search with × reset, prev/next, count).
- **Sections**, all start collapsed, numbered 01–08:
  01 Dashboard Summary (overview) · 02 Find Graphics (Live Tool) (search) · 03 Search Operators (guide) · 04 What Makes a Good Vector (guide) · 05 What Makes a Good Bitmap (guide) · 06 File Type Reference (guide) · 07 Vectorize: Bitmap → Vector (vectorize) · 08 Limits & Caveats (caveat).
- Section 03 = intro paragraph, three tip bullets, an **Operator · What it does · Example** table (quotes, -word, OR, ( ), site:, -site:, filetype:, intitle:, inurl:, *, AROUND(n), contains:, imagesize:; engine-specific rows name their engines), and a "Where Operators Work" callout: operators typed in Describe pass through to the four engine buttons; leave them out for the repository buttons and live Search.
- Section 01 always opens with the **"What each section covers"** table whose `#` cells are `.secnum-link`s.
- Callouts, resource cards and `.table-wrap` tables in a section body are auto-wrapped by JS into collapsible `[TAG]` rows; tables get click-to-sort headers (asc → desc → original) and a floating sticky header clone.
- **Section 02** = three `.tool-sub` cards in this order: **Filters** (closed) → **Input / Search** (open) → **Results** (closed, auto-opens on results).
  - Filters: type chips in two labelled rows — Vector: SVG · DXF; Bitmap: PNG · JPG · GIF · WEBP — then style chips Free only · Silhouette · Black & white · Color · Clipart. All on by default; Reset turns them all back on.
  - Input: mode pills Describe It / Image URL / Upload Image; × clear inside inputs; Search + Reset; "Search elsewhere" row Google · Bing · Brave · DuckDuckGo; "Vector repositories" row SVGrepo · FreeSVG · Freepik; then status banner, Enhanced-search box, fallback note, "show raw response".
  - Results: sortable table Source / Title · Type · Cost · CAD Suitability Notes · Link, default-sorted by Type.
- **Footer**: `Vibe Coding: Swami · AI: Claude`, where "Swami" is a mailto assembled at runtime (`'swami.human' + '@' + 'gmail.com'`) — never write the address into the markup.

## What may change (only when asked)

- Text inside sections 01 and 03–08: paragraphs, bullets, callouts, table rows. Adding a row to the vectorize tools table keeps the table's existing column order and "Kind" grouping.
- Adding/removing a section: copy an existing `.section` block, give it a `cat-*` class + `data-title` + `data-cat`, renumber every `.sec-num` sequentially, **add a matching row to the Section 01 table**, and re-point every `data-target` (0-based index = section number − 1). A new category needs its `--cat-NAME` var plus the five CSS lines shown in the "CATEGORY BLOCKS" comment.
- Filter chips, engine/repo buttons: add the chip/button markup *and* its entry in `ENGINES` and its click listener; keep the two-row hand-off layout.
- Wording of the AI prompts in `runSearch` / `describeImage`.
- Model choice in `callClaude`: the template passes no model, so the viewer's default tier answers. Add `model` / `modelTier` to the `sample` options only if Swami asks for a specific model.

## Live search host

Published artifacts block `fetch()` to `https://api.anthropic.com` (it fails with "TypeError: Failed to fetch"), so `callClaude` goes through the artifact **`sample` capability**: `claude.use("sample")`, then `sample(text, {images})`. It converts the page's messages (text plus base64 image blocks) into one prompt and Blob images, and returns the same `{content:[{type:"text",text}], stop_reason}` shape the rest of the page reads. Never put a direct API fetch or an API key back in the page; `check_pattern.py` flags it.

What follows from that:
- The first Search in a view asks the viewer to allow Claude (and images). A decline or other failure shows a plain message from `SAMPLE_MSG` and the Google/Bing fallback.
- `sample` cannot browse. `runSearch` asks Claude for well-known graphics sites with each site's own **search-results URL** for the query, never invented deep links to individual files.
- The page cannot fetch remote images, so Image URL mode falls back to inferring a phrase from the link text; Upload Image is the reliable image path.
- Hand-off buttons open via a real `<a target="_blank">` click, because `window.open` is unreliable inside the artifact viewer.
- Opened from disk or another host, `claude.use` is absent: Search shows its error banner and the fallback links; every hand-off button, filter, TOC and reference table still works. If Swami wants it for another host, say once that live search won't run there and leave the rest unchanged.

These pieces exist because of past failures — never remove them: the `sample` shim in `callClaude` (with `getSample`, `b64ToBlob`, `SAMPLE_MSG`), the anchor-click `openEngine`, the salvage JSON parser, client-side downscaling to stay under the image size limit, the URL-is-a-page fallback, the global error/rejection handler, and the "show raw response" panel (it shows the `sample` error code on failure).

## Iterating

Swami sends short edits ("add Vector Magic to the tools table", "make the filters open by default"). Make exactly that change in the copy, re-run the check, and report in one line.
