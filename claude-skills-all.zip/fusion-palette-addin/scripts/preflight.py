#!/usr/bin/env python3
"""
Pre-delivery sanity check for a built add-in folder (Step 8 of SKILL.md).

Checks:
  1. py_compile the add-in .py
  2. bash -n the macOS .command installer
  3. .py / .manifest basenames match the folder name
  4. no {{PLACEHOLDER}} survives in any shipped file
  5. version agrees between the .py VERSION constant and the .manifest "version"

Usage:  python3 scripts/preflight.py <path/to/BuiltToolFolder>
Exit code 0 = all pass, 1 = something failed.
"""
import sys, os, re, json, subprocess, py_compile, glob

def fail(msg): print('  FAIL:', msg); return False
def ok(msg):   print('  ok  :', msg); return True

def main(folder):
    folder = os.path.abspath(folder)
    name = os.path.basename(folder.rstrip('/'))
    passed = True

    py = os.path.join(folder, f'{name}.py')
    man = os.path.join(folder, f'{name}.manifest')

    # 3. names match
    passed &= ok(f'folder name: {name}')
    passed &= (os.path.isfile(py) or fail(f'missing {name}.py (basename must equal folder)'))
    passed &= (os.path.isfile(man) or fail(f'missing {name}.manifest'))

    # 1. py_compile
    if os.path.isfile(py):
        try:
            py_compile.compile(py, doraise=True); passed &= ok('py_compile')
        except py_compile.PyCompileError as e:
            passed &= fail(f'py_compile: {e}')

    # 2. bash -n installer
    cmd = os.path.join(folder, 'install-macos.command')
    if os.path.isfile(cmd):
        r = subprocess.run(['bash', '-n', cmd], capture_output=True, text=True)
        passed &= ok('bash -n install-macos.command') if r.returncode == 0 else fail(r.stderr.strip())
    else:
        passed &= fail('missing install-macos.command')

    # 4. no surviving placeholders
    stray = []
    for f in glob.glob(os.path.join(folder, '**', '*'), recursive=True):
        if os.path.isfile(f) and not f.lower().endswith('.png'):
            try:
                if re.search(r'\{\{[^}]+\}\}', open(f, encoding='utf-8', errors='ignore').read()):
                    stray.append(os.path.relpath(f, folder))
            except Exception:
                pass
    passed &= ok('no {{PLACEHOLDER}} left') if not stray else fail('placeholders in: ' + ', '.join(stray))

    # 5. version agreement
    pv = mv = None
    if os.path.isfile(py):
        m = re.search(r"^VERSION\s*=\s*['\"]([^'\"]+)['\"]", open(py, encoding='utf-8').read(), re.M)
        pv = m.group(1) if m else None
    if os.path.isfile(man):
        try: mv = json.load(open(man, encoding='utf-8')).get('version')
        except Exception: mv = None
    if pv and mv and pv == mv:
        passed &= ok(f'version agrees: {pv}')
    else:
        passed &= fail(f'version mismatch: .py={pv} manifest={mv}')

    print('\nPREFLIGHT', 'PASS' if passed else 'FAIL')
    return 0 if passed else 1


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('Usage: python3 scripts/preflight.py <path/to/BuiltToolFolder>'); sys.exit(2)
    sys.exit(main(sys.argv[1]))
