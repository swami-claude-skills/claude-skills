#!/usr/bin/env python3
"""
Emit the three command-icon PNGs (16/32/64) into resources/command/.

Edit draw_glyph() per tool: ONE flat shape, high contrast, no thin strokes, no text.
Design for 16 px — render it, look at it, and check it against Swami's other add-in
icons so it isn't a repeat glyph (invisible in review, obvious in the toolbar).

Usage:  python3 scripts/make_icons.py
"""
from PIL import Image, ImageDraw
import os

# House accent so the glyph reads on Fusion's toolbar.
CYAN = (0, 229, 255, 255)
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))),
                   'resources', 'command')


def draw_glyph(d, s):
    """Draw the icon on a canvas of size s x s. REPLACE THIS per tool.

    Placeholder: a bold rounded square with a cut corner — distinct at 16 px.
    """
    m = s * 0.16                      # margin
    d.rounded_rectangle([m, m, s - m, s - m], radius=s * 0.16,
                        outline=CYAN, width=max(2, int(s * 0.11)))
    # a filled notch so it's not just an empty box
    d.rectangle([s * 0.5, s * 0.5, s - m, s - m], fill=CYAN)


def main():
    os.makedirs(OUT, exist_ok=True)
    for s in (16, 32, 64):
        img = Image.new('RGBA', (s, s), (0, 0, 0, 0))
        draw_glyph(ImageDraw.Draw(img), s)
        img.save(os.path.join(OUT, f'{s}x{s}.png'))
        print('wrote', os.path.join(OUT, f'{s}x{s}.png'))


if __name__ == '__main__':
    main()
