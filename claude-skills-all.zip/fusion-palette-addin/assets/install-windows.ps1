param([string]$Name = "{{TOOL_NAME}}")

$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:APPDATA "Autodesk\Autodesk Fusion 360\API\AddIns\$Name"

Write-Host "Installing $Name -> $dest"
New-Item -ItemType Directory -Force -Path $dest | Out-Null

$exclude = @('install-macos.command','install-windows.cmd','install-windows.ps1')
Get-ChildItem -Path $src -Recurse | Where-Object {
    $exclude -notcontains $_.Name
} | ForEach-Object {
    $rel = $_.FullName.Substring($src.Length).TrimStart('\')
    $target = Join-Path $dest $rel
    if ($_.PSIsContainer) {
        New-Item -ItemType Directory -Force -Path $target | Out-Null
    } else {
        New-Item -ItemType Directory -Force -Path (Split-Path $target) | Out-Null
        Copy-Item $_.FullName -Destination $target -Force
    }
}

Write-Host ""
Write-Host "Done. In Fusion: Utilities > Add-Ins > Scripts and Add-Ins (Shift+S),"
Write-Host "select `"$Name`" under Add-Ins, and click Run."
