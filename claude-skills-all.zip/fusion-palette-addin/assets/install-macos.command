#!/bin/bash
# Double-click installer (macOS). Set NAME to the add-in folder/.py/.manifest basename.
NAME="{{TOOL_NAME}}"

SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Library/Application Support/Autodesk/Autodesk Fusion 360/API/AddIns/$NAME"

echo "Installing $NAME -> $DEST"
mkdir -p "$DEST"
# copy everything except the installers themselves
rsync -a --delete \
  --exclude 'install-macos.command' \
  --exclude 'install-windows.cmd' \
  --exclude 'install-windows.ps1' \
  "$SRC"/ "$DEST"/

echo ""
echo "Done. In Fusion: Utilities > Add-Ins > Scripts and Add-Ins (Shift+S),"
echo "select \"$NAME\" under Add-Ins, and click Run."
echo ""
read -n 1 -s -r -p "Press any key to close."
