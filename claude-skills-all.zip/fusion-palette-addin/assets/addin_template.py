# {{TOOL_NAME}} — Fusion add-in (Swami house spec)
# Non-modal HTML palette · versioned title · settings + reset · full teardown.
# Replace every {{PLACEHOLDER}}. The .py and .manifest basenames MUST equal the folder name.

import adsk.core, adsk.fusion, traceback
import os, json, copy

# ---- single source of truth for the version (must match the .manifest) ----
VERSION   = '1.0.0'
TOOL_NAME = '{{TOOL_NAME}}'                       # e.g. VisibilityTools
CMD_ID    = '{{TOOL_NAME}}_cmd'
PALETTE_ID= '{{TOOL_NAME}}_palette'
# Where the toolbar button(s) land. One or more (workspace_id, panel_id).
PLACEMENTS = [
    ('FusionSolidEnvironment', 'SolidScriptsAddinsPanel'),   # DESIGN → Utilities → Add-Ins (default)
]

_HERE = os.path.dirname(os.path.realpath(__file__))
PALETTE_URL = os.path.join(_HERE, 'palette.html')

app = adsk.core.Application.get()
ui  = app.userInterface

# ---- persistent handler refs (Fusion garbage-collects otherwise) ----
_handlers = []

# ---- factory defaults = schema. Add every persisted value here. ----
DEFAULTS = {
    'options': { '{{OPTION_KEY}}': '{{OPTION_DEFAULT}}' },
    'ui': { 'collapsed': { 'general': True }, 'sort': 'name', 'filter': '' },
}

def _settings_path():
    base = os.environ.get('APPDATA', os.path.expanduser('~')) if os.name == 'nt' \
           else os.path.expanduser('~/Library/Application Support')
    d = os.path.join(base, 'SwamiFusionAddins', TOOL_NAME)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, 'settings.json')

def _deep_merge(b, o):
    out = copy.deepcopy(b)
    for k, v in (o or {}).items():
        out[k] = _deep_merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out

def load_settings():
    try:
        with open(_settings_path(), 'r', encoding='utf-8') as f:
            saved = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        saved = {}
    return _deep_merge(DEFAULTS, saved)

def save_settings(state):
    with open(_settings_path(), 'w', encoding='utf-8') as f:
        json.dump(state, f, indent=2)

STATE = load_settings()


class CmdCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        try:
            palette = ui.palettes.itemById(PALETTE_ID)
            if palette is None:
                palette = ui.palettes.add(
                    PALETTE_ID, f'{TOOL_NAME} (v{VERSION})', PALETTE_URL,
                    True, True, True, 380, 600)
                palette.dockingState = adsk.core.PaletteDockingStates.PaletteDockStateRight
                h = HtmlHandler();   palette.incomingFromHTML.add(h); _handlers.append(h)
                c = ClosedHandler();  palette.closed.add(c);          _handlers.append(c)
            else:
                palette.isVisible = not palette.isVisible
        except:
            ui.messageBox(f'{TOOL_NAME}: {traceback.format_exc()}')


class HtmlHandler(adsk.core.HTMLEventHandler):
    def notify(self, args):
        global STATE
        try:
            action = args.action
            data = json.loads(args.data) if args.data else {}
            palette = ui.palettes.itemById(PALETTE_ID)
            if action == 'ready' or action == 'getState':
                args.returnData = json.dumps({'version': VERSION, 'name': TOOL_NAME, 'state': STATE})
            elif action == 'setState':
                STATE = _deep_merge(STATE, data)
                save_settings(STATE)
                args.returnData = 'OK'
            elif action == 'reset':
                res = ui.messageBox('Reset all settings to defaults? This cannot be undone.',
                                    TOOL_NAME, adsk.core.MessageBoxButtonTypes.YesNoButtonType)
                if res == adsk.core.DialogResults.DialogYes:
                    STATE = copy.deepcopy(DEFAULTS)
                    save_settings(STATE)
                    if palette:
                        palette.sendInfoToHTML('stateChanged', json.dumps(STATE))
                args.returnData = 'OK'
            # {{ADD YOUR ACTIONS HERE — the actual tool behaviour}}
        except:
            p = ui.palettes.itemById(PALETTE_ID)
            if p: p.sendInfoToHTML('error', json.dumps({'msg': traceback.format_exc()}))


class ClosedHandler(adsk.core.UserInterfaceGeneralEventHandler):
    def notify(self, args):
        try:
            save_settings(STATE)
        except:
            pass


def run(context):
    try:
        cmd_def = ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def is None:
            cmd_def = ui.commandDefinitions.addButtonDefinition(
                CMD_ID, TOOL_NAME, '{{TOOLTIP}}', './resources/command')
        h = CmdCreatedHandler(); cmd_def.commandCreated.add(h); _handlers.append(h)
        for ws_id, panel_id in PLACEMENTS:
            ws = ui.workspaces.itemById(ws_id)
            panel = ws.toolbarPanels.itemById(panel_id) if ws else None
            if panel and panel.controls.itemById(CMD_ID) is None:
                panel.controls.addCommand(cmd_def)
    except:
        ui.messageBox(f'{TOOL_NAME} run: {traceback.format_exc()}')


def stop(context):
    try:
        for ws_id, panel_id in PLACEMENTS:
            ws = ui.workspaces.itemById(ws_id)
            panel = ws.toolbarPanels.itemById(panel_id) if ws else None
            ctrl = panel.controls.itemById(CMD_ID) if panel else None
            if ctrl: ctrl.deleteMe()
        cmd_def = ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def: cmd_def.deleteMe()
        palette = ui.palettes.itemById(PALETTE_ID)
        if palette: palette.deleteMe()
    except:
        if ui: ui.messageBox(f'{TOOL_NAME} stop: {traceback.format_exc()}')
