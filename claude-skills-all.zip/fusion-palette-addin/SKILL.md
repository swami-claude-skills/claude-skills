---
name: "fusion-palette-addin"
description: "Build an Autodesk Fusion (360) add-in to Swami's house spec — a non-modal dockable HTML palette with a dark-mode UI, collapsible sections, a versioned title like \"ToolName (v1.0.0)\", a toolbar icon, keyboard-shortcut eligibility, error handling, a reset-to-original-defaults control, and double-click macOS + Windows installers. Use this WHENEVER Swami asks for a Fusion add-in, tool, panel, or utility with an HTML or dark-mode UI, a non-modal or dockable window, collapsible sections, persistent settings, or a reset option — and ALWAYS when he pastes his add-in request template containing [INSERT ADD-IN NAME HERE] / [INSERT LOCATION/S HERE] / [INSERT DESCRIPTION HERE] placeholders. Also reach for it when he just says \"make me a Fusion tool that ...\" and it needs to stay open while he works, show a list, or remember preferences. Do NOT use for one-shot scripts, plain native command-dialog add-ins, or Fusion API debugging with no HTML UI (use fusion-addin-scaffold); or for documentation pages (use vibe-dashboard)."
---

# Fusion Palette Add-in (Swami house spec)

*Skill version 1.2.0 (Nov 9, 2026). What changed is listed under Changelog at the end.*

Every Fusion tool Swami commissions follows the same shape: a **non-modal HTML palette**, dark theme, collapsible sections, versioned title, icon, shortcut-eligible, hardened against errors, resettable to factory defaults, and installable by double-click on both platforms. This skill produces that whole package so nothing gets forgotten between builds.

This skill covers the **palette + packaging** layer. The Python API rules underneath it live in `fusion-addin-scaffold` — read that skill's SKILL.md and `references/ui-navigation.md` / `references/error-handling.md` for the actual Fusion API work the palette drives. This skill assumes those four non-negotiables (persistent handler refs, full teardown in `stop()`, document-type awareness, top-level try/except) and adds the house layer on top.

## Step 1 — Fill the intake spec before writing code

Swami's request template has blanks. Do not guess the three that matter:

| Field | If missing |
| --- | --- |
| **Add-in name** | Ask. It drives the folder, `.py`, `.manifest`, palette ID, command ID, and installers — renaming later touches ten files. |
| **Location(s)** | Ask which workspace/panel(s) the button belongs in, or offer the default (DESIGN → Utilities → Add-Ins). Plural is supported — a tool can appear in several places. |
| **Description / basic idea** | Ask. Everything else is boilerplate; this is the tool. |

Everything else has a house default — apply it silently, don't ask:
- Version starts at **`1.0.0`**, shown as `Name (v1.0.0)`.
- Non-modal palette docked right, ~380 px wide.
- All sections **collapsed on first open**.
- Icon generated, keyboard shortcut enabled (via eligibility — see Step 5).
- Settings persisted per-user with a **Reset to defaults** control.
- Both installers included.

If a placeholder-filled template arrives with all three blanks completed, go straight to building. Ask for the missing ones with the session's multiple-choice question tool (AskUserQuestion in the Claude app, `ask_user_input_v0` in a chat) rather than a wall of prose questions.

## Step 2 — Deliverable layout

```
ToolName/
├── ToolName.py                  # entry point: run() / stop(), palette, bridge, settings
├── ToolName.manifest            # version here MUST match VERSION in the .py
├── palette.html                 # the dark-mode UI (self-contained, no CDN)
├── resources/
│   └── command/                 # 16x16.png · 32x32.png · 64x64.png
├── install-macos.command
├── install-windows.cmd
├── install-windows.ps1
└── README.txt                   # install steps for whoever gets the zip (fusion-addin-installer)
```

The `.py` and `.manifest` basenames must equal the folder name or Fusion won't list the add-in. Copy the starting points from `assets/`:
- `assets/addin_template.py` — the full add-in: versioned title, multi-placement buttons, palette lifecycle, JS↔Python bridge, settings load/save, reset, teardown.
- `assets/palette_template.html` — the dark UI: collapsible sections, error strip, footer with version + Reset.
- `assets/manifest.json` — rename to `ToolName.manifest`. It already has `"autodeskProduct": "Fusion360"`: Autodesk's API docs say the field always has that value, even though the product is now called Fusion; leave it. Replace `{{GUID}}` in `"id"` with a freshly generated GUID (`python3 -c "import uuid; print(uuid.uuid4())"`), never the tool name and never one copied from another add-in, because Autodesk says every add-in needs its own unique GUID. Keep `"runOnStartup": true`, since house-spec tools should be on the toolbar as soon as Fusion starts.
- **Installers: build them with the `fusion-addin-installer` skill**. Read that skill's SKILL.md and set its `ADDIN_NAME` to the tool name. Its installers wipe the old install, skip their own files plus `__pycache__` and `.DS_Store` (stale copies can stop an add-in from loading), need no `rsync`, and pause so the user sees the result. This skill no longer bundles installers of its own.
- `scripts/make_icons.py` — edit `draw_glyph()` per tool, run it to emit the three PNGs.

Replace every `{{PLACEHOLDER}}`. Nothing named "MyAddin" or "ToolName" should survive into the delivered files.

## Step 3 — Version discipline

The version appears in four places and they must agree: the `VERSION` constant in the `.py` (the single source of truth), the `version` field in the manifest, the palette title, and the HTML footer. The `.py` pushes the title and footer at runtime, so in practice you edit **two** spots — the constant and the manifest.

Format is strict: `Name (v1.0.0)` — parentheses, lowercase `v`, no space between `v` and the digits. Semantic-ish: patch for fixes, minor for new capability, major for a rework or a settings-schema break.

**Bump the version on every change you ship back to Swami**, and say what changed. He tests live in Fusion; an unchanged title after a rebuild means he can't tell whether the reinstall took. This is the single most common source of "did that actually update?" confusion.

## Step 4 — Palette rules that bite

Read `references/palette-bridge.md` before writing the Python. The essentials:

1. **Build the palette URL as an absolute path** off `os.path.dirname(os.path.realpath(__file__))`. A bare relative `'palette.html'` resolves inconsistently.
2. **Create the palette lazily** — build the command definition and buttons in `run()`, create the palette on first button click. The button then toggles visibility, so clicking it again hides the panel.
3. **Reuse an existing palette by ID** before adding one. A reload that skipped teardown leaves the old palette alive and `palettes.add()` throws on a duplicate ID.
4. **The bridge is asynchronous both ways.** JS calls `adsk.fusionSendData(action, jsonString)` (returns a promise); Python replies through `args.returnData` and can push unsolicited updates with `palette.sendInfoToHTML(action, jsonString)`, which JS receives in `window.fusionJavaScriptHandler.handle`. Every payload is a JSON **string** in both directions — serialize and parse explicitly.
5. **Handle `palette.closed`** to save settings and section state, so closing the panel doesn't lose the user's arrangement.
6. **Delete the palette and every control in `stop()`** — one `deleteMe()` per placement, plus the command definition, plus the palette.
7. **If a document-modifying action misbehaves when run inline in the HTML handler** (UI freeze, half-applied edit), route it through a command definition executed from the handler instead of doing the work directly in `notify`. Doing heavy document surgery straight from an incoming HTML event is the pattern most likely to need this escape hatch.

Panel and workspace IDs are not fully documented and shift between releases. `references/palette-bridge.md` has a short snippet that enumerates the live IDs from inside Fusion — when Swami names a location you're not certain of, ship that snippet rather than inventing an ID.

## Step 5 — Icon and keyboard shortcut

Fusion only offers "Change Keyboard Shortcut" on a command that has an **icon resource** and a **reachable button**, so the icon isn't decoration — it's the precondition for the shortcut. Point `addButtonDefinition` at `'./resources/command'` and ship all three PNG sizes.

Design the glyph for 16 px: one flat shape, high contrast, no thin strokes, no text. Render it at 16 px and look at it before shipping. When Swami has several add-ins installed side by side, check the new icon against the existing ones — a repeat glyph is invisible in review and obvious in the toolbar.

The add-in cannot bind the hotkey itself. Tell Swami the steps in the handoff: right-click the toolbar button → **Change Keyboard Shortcut** → press the combination. Mention that the binding is per-user and survives reinstalls.

## Step 6 — Settings and reset to defaults

Read `references/settings-reset.md`. The shape:
- A `DEFAULTS` dict in the `.py` is the factory state and the schema.
- Settings live in a per-user JSON file **outside** the add-in folder, so reinstalling (which wipes and recopies the folder) doesn't erase preferences.
- Loading merges the saved file over `DEFAULTS`, so a new setting added in a later version appears with its default instead of crashing on a missing key.
- **Reset** restores `DEFAULTS` wholesale — options *and* UI state (section collapse, filters, sort) — then re-pushes state to the palette so the UI visibly snaps back. Confirm first; it's destructive and unrecoverable.

Reset that only resets half the state is worse than no reset, because it looks like it worked. When adding any new persisted value, add it to `DEFAULTS` in the same edit.

## Step 7 — The HTML UI

Read `references/palette-ui.md`. It carries the dark palette (`#0d0d0f` / `#00e5ff`) from Swami's dashboard system, adapted for a ~380 px dockable panel. The differences from a vibe-dashboard page matter:
- **No Google Fonts, no CDN** — the palette webview may have no network. Use a local stack with monospace fallbacks.
- **Set `color-scheme: dark`** or scrollbars and form controls render light on Windows and undo the theme.
- **Single column, no horizontal scroll** — 380 px is the design width, and it can be dragged narrower.
- **Collapsible sections group related controls**, all closed on first open, state persisted through the bridge.
- **A visible error strip** at the top. Errors from the Python side surface there instead of only in a message box, because a docked panel that silently does nothing is the hardest failure to diagnose.

## Step 8 — Deliver

1. Build the folder in the working directory, `chmod +x` the `.command`, and zip it with the `zip` command (Python's `zipfile` drops the executable bit; see fusion-addin-installer). In the Claude app, send the zip with SendUserFile. In a chat that only has `present_files`, copy the zip to `/mnt/user-data/outputs/` first and present it from there.
2. Sanity-check before presenting: `python3 -m py_compile` the add-in, `bash -n` the macOS installer, confirm the `.py`/`.manifest`/folder names match, confirm no `{{PLACEHOLDER}}` survives, and confirm the version agrees between the constant and the manifest. It also checks the two manifest fields: `autodeskProduct` is `Fusion360` and `id` is a GUID. `scripts/preflight.py` does all of these — run it.
3. In the handoff message, state: the version, where the button lands, the install steps (double-click installer → Fusion → **Utilities ▸ Add-Ins ▸ Scripts and Add-Ins**, Shift+S → select → Run), and the keyboard-shortcut steps. Note for macOS that Gatekeeper may require right-click → Open on first run of an unsigned `.command`. Note for Windows: right-click the zip → **Extract All…** first and run `install-windows.cmd` from the extracted folder (not from inside the zip); if SmartScreen shows "Windows protected your PC", click **More info → Run anyway**, once.

If Swami asks for install documentation or a write-up of the tool, that's a separate deliverable — switch to the `vibe-dashboard` skill for it. Keep Vibe Coding branding out of the `.py`; the palette HTML footer is where it belongs.

## Changelog

- **1.2.0 (Nov 9, 2026):** `scripts/preflight.py` now really checks the manifest's `autodeskProduct` (`Fusion360`) and that `id` is a GUID (1.1.0 said so but didn't). `assets/manifest.json` now ships `Fusion360` and a `{{GUID}}` placeholder. Removed the old rsync-based `assets/install-*` files. The handoff now tells Windows users to Extract All first and how to get past SmartScreen. The deliverable now includes the `README.txt` that fusion-addin-installer writes.

- **1.1.0 (Nov 7, 2026):** Manifest now follows Autodesk's documented spec (`autodeskProduct` set to `Fusion360`, `id` set to a fresh GUID). Installers are now built with the fusion-addin-installer skill instead of the bundled rsync-based files. Questions and delivery now name the tools for both the Claude app and chat. Preflight now also checks the two manifest fields.
- **1.0.0:** First version.