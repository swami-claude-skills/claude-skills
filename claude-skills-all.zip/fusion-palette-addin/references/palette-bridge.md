# Palette + JS↔Python bridge

Read this before writing the Python in `assets/addin_template.py`. It expands Step 4 of SKILL.md.

## 1. Absolute palette URL

The palette's HTML file must be addressed by an absolute path, never a bare relative name.

```python
import os
_HERE = os.path.dirname(os.path.realpath(__file__))
PALETTE_URL = 'file://' + os.path.join(_HERE, 'palette.html')  # Fusion also accepts a plain path
```

A bare `'palette.html'` resolves against Fusion's working directory, not the add-in folder, and loads inconsistently between platforms and launch methods.

## 2. Lazy palette creation, button toggles visibility

Build the command definition and toolbar button(s) in `run()`. Create the palette itself on the **first** button click, then have the button toggle `palette.isVisible` on subsequent clicks.

```python
def _on_command_created_handler(args):
    palette = ui.palettes.itemById(PALETTE_ID)
    if palette is None:
        palette = ui.palettes.add(
            PALETTE_ID, f'{TOOL_NAME} (v{VERSION})', PALETTE_URL,
            True,   # isVisible
            True,   # showCloseButton
            True,   # isResizable
            380, 600  # width, height
        )
        palette.dockingState = adsk.core.PaletteDockingStates.PaletteDockStateRight
        palette.incomingFromHTML.add(_html_handler)   # keep a persistent ref!
        palette.closed.add(_closed_handler)            # keep a persistent ref!
    else:
        palette.isVisible = not palette.isVisible
```

## 3. Reuse an existing palette by ID before adding

`ui.palettes.itemById(PALETTE_ID)` first. A reload that skipped `stop()` leaves the old palette alive; calling `palettes.add()` with a duplicate ID throws. The `if palette is None` guard above handles this.

## 4. The bridge is asynchronous both directions

Every payload is a JSON **string** in both directions. Serialize and parse explicitly.

**JS → Python** — JS calls, Python answers via `args.returnData`:

```javascript
// in palette.html
const resp = await adsk.fusionSendData('getState', JSON.stringify({ foo: 1 }));
const state = JSON.parse(resp);
```

```python
# in the incomingFromHTML handler
def notify(self, args):
    action = args.action
    data = json.loads(args.data) if args.data else {}
    if action == 'getState':
        args.returnData = json.dumps(current_state())
```

**Python → JS** — unsolicited push:

```python
palette.sendInfoToHTML('stateChanged', json.dumps(new_state))
```

```javascript
// in palette.html
window.fusionJavaScriptHandler = {
  handle(action, dataStr) {
    const data = JSON.parse(dataStr || '{}');
    if (action === 'stateChanged') applyState(data);
    return 'OK';
  }
};
```

## 5. Save on close

Add a `palette.closed` handler that persists settings and section-collapse state, so closing the panel doesn't discard the user's arrangement. (See `settings-reset.md`.)

## 6. Full teardown in stop()

```python
def stop(context):
    try:
        for pid in PLACEMENTS:            # one deleteMe() per placement
            panel = ui.allToolbarPanels.itemById(pid)
            ctrl = panel.controls.itemById(CMD_ID) if panel else None
            if ctrl: ctrl.deleteMe()
        cmd_def = ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def: cmd_def.deleteMe()
        palette = ui.palettes.itemById(PALETTE_ID)
        if palette: palette.deleteMe()
    except:
        pass
```

## 7. Escape hatch for document surgery

If a document-modifying action stutters when run inline in the HTML handler (UI freeze, half-applied edit), don't do the work in `notify`. Instead fire a command definition from the handler and do the document work in that command's `execute`, so it runs in Fusion's proper command context.

## Enumerating live workspace/panel IDs

Panel and workspace IDs are undocumented in places and shift between releases. When Swami names a location you're not certain of, ship this snippet for him to run (Utilities ▸ Add-Ins ▸ Scripts, paste as a script) rather than guessing an ID:

```python
import adsk.core, traceback
def run(context):
    ui = adsk.core.Application.get().userInterface
    try:
        lines = []
        for ws in ui.workspaces:
            lines.append(f'WORKSPACE  {ws.id}  ({ws.name})')
            try:
                for panel in ws.toolbarPanels:
                    lines.append(f'   PANEL   {panel.id}  ({panel.name})')
            except:
                pass
        ui.messageBox('\n'.join(lines[:120]))
    except:
        ui.messageBox(traceback.format_exc())
```
