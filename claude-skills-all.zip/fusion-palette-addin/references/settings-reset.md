# Settings + reset to defaults

Expands Step 6 of SKILL.md. The goal: preferences survive reinstalls, new settings don't crash old files, and Reset restores *everything* — options and UI state alike.

## DEFAULTS is the schema

A single `DEFAULTS` dict in the `.py` is both the factory state and the schema. Every persisted value lives here.

```python
DEFAULTS = {
    'options': {
        'unit': 'mm',
        'autoApply': False,
    },
    'ui': {                 # UI state is persisted too, and reset too
        'collapsed': {'general': True, 'advanced': True},
        'sort': 'name',
        'filter': '',
    },
}
```

## Store outside the add-in folder

Reinstalling wipes and recopies the add-in folder, so settings must live elsewhere — a per-user JSON file in the OS's app-data location.

```python
import os, json, copy

def _settings_path():
    if os.name == 'nt':
        base = os.environ.get('APPDATA', os.path.expanduser('~'))
    else:
        base = os.path.expanduser('~/Library/Application Support')
    d = os.path.join(base, 'SwamiFusionAddins', TOOL_NAME)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, 'settings.json')
```

## Load = merge saved over DEFAULTS

Deep-merge so a setting added in a later version appears with its default instead of raising `KeyError` on an old file.

```python
def _deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out

def load_settings():
    try:
        with open(_settings_path(), 'r', encoding='utf-8') as f:
            saved = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        saved = {}
    return _deep_merge(DEFAULTS, saved)

def save_settings(state):
    with open(_settings_path(), 'w', encoding='utf-8') as f:
        json.dump(state, f, indent=2)
```

## Reset restores DEFAULTS wholesale — then re-pushes

Reset is destructive and unrecoverable, so confirm first. It must restore both options AND UI state, then push the fresh state back to the palette so the panel visibly snaps back.

```python
def reset_to_defaults(palette):
    # confirm in the HTML side, or:
    res = ui.messageBox('Reset all settings to defaults? This cannot be undone.',
                        TOOL_NAME, adsk.core.MessageBoxButtonTypes.YesNoButtonType)
    if res != adsk.core.DialogResults.DialogYes:
        return
    state = copy.deepcopy(DEFAULTS)
    save_settings(state)
    palette.sendInfoToHTML('stateChanged', json.dumps(state))  # UI snaps back
```

A reset that only clears half the state is worse than none — it looks like it worked. **When you add any new persisted value, add it to `DEFAULTS` in the same edit.**
