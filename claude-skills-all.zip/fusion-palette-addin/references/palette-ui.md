# The palette HTML UI

Expands Step 7 of SKILL.md. This is the dark palette from Swami's dashboard system (`#0d0d0f` bg / `#00e5ff` accent) re-fit for a ~380 px dockable webview. `assets/palette_template.html` already implements all of this — this file explains the constraints so you don't undo them.

## The five differences from a vibe-dashboard page

1. **No Google Fonts, no CDN.** The palette webview may have no network. Use a local font stack:
   ```css
   --mono: ui-monospace, 'SF Mono', 'Cascadia Mono', Menlo, Consolas, monospace;
   --sans: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
   ```
2. **`color-scheme: dark`** on `:root`/`html`. Without it, scrollbars and native form controls render light on Windows and break the theme.
   ```css
   :root { color-scheme: dark; }
   ```
3. **Single column, no horizontal scroll.** 380 px is the design width and the user can drag it narrower. Everything is fluid width; no fixed pixel columns, no wide tables.
4. **Collapsible sections group related controls**, all closed on first open. Persist each section's collapsed state through the bridge (see `settings-reset.md` — it lives under `ui.collapsed`).
5. **A visible error strip at the top.** A docked panel that silently does nothing is the hardest failure to diagnose, so surface Python-side errors in the strip, not only in a message box.

## Error strip contract

Python pushes errors to the strip:

```python
palette.sendInfoToHTML('error', json.dumps({'msg': str(e)}))
```

```javascript
function showError(msg) {
  const strip = document.getElementById('errStrip');
  strip.textContent = msg;
  strip.style.display = msg ? 'block' : 'none';
}
// in window.fusionJavaScriptHandler.handle:
if (action === 'error') { showError(data.msg); return 'OK'; }
```

## Palette color tokens (match the house system)

```css
:root{
  color-scheme: dark;
  --bg:#0d0d0f; --panel:#141418; --panel-2:#1a1a20;
  --cyan:#00e5ff; --green:#00ff88;
  --text:#e8e8ec; --text-dim:#9aa0aa; --text-mute:#6a6f78;
  --border:#26262e; --red:#ff5c7a;
}
```

## Footer

The palette footer is the ONE place Vibe Coding branding belongs (never in the `.py`). Show the version there and keep it in sync with the title:

```
ToolName (v1.0.0) · Vibe Coding: Swami · AI: Claude
```

Include the **Reset to defaults** control in or beside the footer; wire its click to a `reset` action over the bridge, and confirm before applying.
