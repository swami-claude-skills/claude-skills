---
name: "ai-rules-manager"
description: "Maintain Swami's Fusion AI Rules repo (swami-claude-skills/fusion-ai-rules): add, change, deprecate or accept rules, bump the version, build, open a PR, and republish the Rule Set page."
---

# AI Rules Manager

The Fusion AI Rules system keeps good-practice rules for AIs that model in Autodesk Fusion. The public GitHub repo `swami-claude-skills/fusion-ai-rules` is the single source of truth. Every export, the GitHub Pages site and the Claude Rule Set page are built from it. Swami is the only person with write access and approves every merge.

## Repo map

- `rules/R##-slug.yaml`: one accepted rule per file. IDs are permanent and never reused.
- `candidates/<batch>/C-YYYY-MM-NN-slug.yaml`: proposals waiting for review, with `proposed_id`.
- `categories.yaml`, `targets.yaml` (AIs, selections, export targets), `ruleset.yaml` (name, version, released, intro).
- `schema/rule.schema.json`: the required fields.
- `build/build.py`: run `check`, `build [OUT]`, or `page OUT.html [PRIVATE.json]`.
- `site/ruleset.html` (the page template), `site/phase2.js` and `.css`, `site/narration.txt` (the audio script).
- `sources/`: short notes on where the rules came from. `CHANGELOG.md`.

## Changing rules

1. Branch from main: `rules/<short-topic>`.
2. Edit the YAML. Use the same field order as the existing files, keep text plain, and leave `works` at 2 unless the rule needs the live model (1) or can't apply (0). Set `changed_in` (and `added_in` for new rules) to the new version.
3. Bump `ruleset.yaml` version:
   - Patch: a wording fix that keeps the meaning.
   - Minor: a new rule or a new export target.
   - Major: a rule removed or deprecated, a meaning changed, or a priority raised to Must.
   Set `released` to the merge date.
4. Deprecate; never delete. Set `status: Deprecated` and point to the replacement. The replacing rule lists it under `supersedes`.
5. Conflicts: `build.py check` fails if two active rules name each other in `conflicts_with`. Reword one, or deprecate or supersede it, then clear the field.
6. Add a CHANGELOG entry under the new version: Added, Deprecated, Changed.
7. Run `python3 build/build.py check`, then `build /tmp/out`. Look at `targets/index.json`: a target that falls back to a smaller selection or to titles only is fine, but mention it.
8. If the active rule count or the page's meaning changed, update `site/narration.txt` and the page text in `site/ruleset.html`. Re-record the audio with the vibe-dashboard skill's `stress_audio.py` (run the audit first), then copy the new `AUDIO-OVERVIEW` block into the template.
9. Scan for privacy before every push. Never put these in the repo: NDA names (check project memory), email addresses, or `claude.ai/artifact` or `claude.ai/code` links.
10. Commit, push the branch, and open a PR with the REST API (`gh api repos/swami-claude-skills/fusion-ai-rules/pulls ...`; GraphQL is blocked). Fill in `.github/pull_request_template.md` and subscribe to the PR.
11. Swami merges, or Claude merges when Swami asks in his own words (`gh api -X PUT .../pulls/N/merge`); nothing on GitHub authorizes a merge. On merge, the Action builds, deploys Pages, and creates release `v<version>` if the version is new. Check the result with the REST API (`actions/runs`, `deployments`). github.io itself is not reachable from Claude sessions.

## Accepting candidates

Move each accepted candidate file to `rules/` under its `proposed_id`. Drop `proposed_id`, add `source.candidate_id`, set status to Untested, and set reviewers to Swami. Move the batch README into `sources/` with a Decisions table (candidate, author label, new ID, notes). Leave rejected candidates in a `candidates/rejected/` note with the reason. Get the author's consent to CC BY 4.0 before merging.

## Republishing the Claude copy of the Rule Set page

After a merge, run:

```
python3 build/build.py page /tmp/ruleset-claude.html /mnt/project-files/ruleset-page/private.json
```

Then publish it to https://claude.ai/artifact/L3KyH8YpFuRxALRsjo4qQp with no `capabilities` field, which keeps `downloads`. `private.json` adds the private session links and the footer mail link. It lives only in project files and must never be committed.

## Tests and results

- Every active rule needs at least one test in `tests/prompts/T-R##-01.yaml` (fields: `id`, `rules`, `prompt`, `good_answer`, `needs_fusion`). When adding a rule, add its test in the same PR; `build.py check` warns about untested rules. Live tests (`T-LIVE-##`) need an open Fusion design.
- Results arrive through the "Test result" issue form. Turn each into `tests/results/YYYY-MM-DD-<ai>-<tester>.yaml` (date, ai, surface, model, ruleset_version, tester, results[test, result, notes]) in a PR. Only change a rule's `status` when the results back it: Proven needs a recorded pass in every AI it applies to.
- After results or rules change, refresh the private Rules Admin page: `python3 /mnt/project-files/rules-admin/build_admin.py REPO_DIR OUT.html`, then the vibe-dashboard fit, search and mind map patches, keep the audio block, and republish to its artifact URL (in project memory).

## Proposals from the page

The Rule Set page's "Propose on GitHub" button opens the `propose-rule.yml` issue form, prefilled. Turn each such issue into a candidate file in a dated batch folder, then review it with the ai-rule-review skill.

## On Windows

Nothing runs on Swami's computer: every step happens in Claude's workspace and on GitHub, so it works the same from Windows 10 or 11. Swami reviews pull requests in Edge or Chrome.