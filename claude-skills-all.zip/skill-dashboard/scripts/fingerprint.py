#!/usr/bin/env python3
"""fingerprint.py — content fingerprint of a skill folder, and freshness checks for skill cards.

  python3 fingerprint.py SKILL_FOLDER                  -> prints {"fingerprint": "sha256:…", "files": [...]}
  python3 fingerprint.py check CARDS_DIR SKILLS_ROOT    -> one line per card: fresh | OUT OF DATE | skill missing
                                                           plus skills that have no card yet

The fingerprint is a SHA-256 over every file's relative path and bytes (sorted), so it changes when any
file in the skill is added, removed or edited, and never changes otherwise (timestamps are ignored).
CARDS_DIR holds <skill>.json cards (or <skill>/card.json). SKILLS_ROOT holds one folder per skill and,
when present, Claude's manifest.json (only source "plugin" skills — Swami's own — are reported as missing a card).
"""
import hashlib, json, os, sys

def fingerprint(folder):
    h, files = hashlib.sha256(), []
    for dp, dn, fn in os.walk(folder):
        dn[:] = sorted(d for d in dn if not d.startswith('.'))
        for f in sorted(fn):
            if f.startswith('.'): continue
            p = os.path.join(dp, f); rel = os.path.relpath(p, folder).replace(os.sep, '/')
            files.append(rel); h.update(rel.encode() + b'\0'); h.update(open(p, 'rb').read()); h.update(b'\0')
    return 'sha256:' + h.hexdigest()[:16], files

def load_cards(d):
    out = {}
    for e in sorted(os.listdir(d)):
        p = os.path.join(d, e)
        if e.endswith('.json') and os.path.isfile(p): c = json.load(open(p, encoding='utf-8'))
        elif os.path.isfile(os.path.join(p, 'card.json')): c = json.load(open(os.path.join(p, 'card.json'), encoding='utf-8'))
        else: continue
        if isinstance(c, dict) and c.get('skill'): out[c['skill']] = c
    return out

if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == 'check':
        cards, root = load_cards(a[1]), a[2]
        res = []
        for name, c in cards.items():
            folder = os.path.join(root, name)
            if not os.path.isfile(os.path.join(folder, 'SKILL.md')): res.append({'skill': name, 'state': 'skill missing'}); continue
            fp, _ = fingerprint(folder); old = c.get('meta', {}).get('fingerprint')
            res.append({'skill': name, 'state': 'fresh' if fp == old else 'OUT OF DATE', 'card': old, 'now': fp,
                        'status': c.get('meta', {}).get('status', '?')})
        mf = os.path.join(root, 'manifest.json')
        if os.path.exists(mf):
            for s in json.load(open(mf, encoding='utf-8'))['skills']:
                if s.get('source') == 'plugin' and s['name'] not in cards: res.append({'skill': s['name'], 'state': 'no dashboard yet'})
        for r in res: print(json.dumps(r))
    elif a:
        fp, files = fingerprint(a[0]); print(json.dumps({'fingerprint': fp, 'files': files}))
    else: sys.exit(__doc__)
