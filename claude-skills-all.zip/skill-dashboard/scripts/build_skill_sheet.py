#!/usr/bin/env python3
"""build_skill_sheet.py — render a skill card (skill-card.json) as a vibe-dashboard "skill sheet" (format F2).

usage: python3 -B build_skill_sheet.py CARD.json VIBE_DIR SKILL_FOLDER OUT.html [WORKDIR]

VIBE_DIR      the vibe-dashboard skill folder (assets/template.html, scripts/search_patch.py, SKILL.md)
SKILL_FOLDER  the skill being documented (its SKILL.md becomes the verbatim Source Document section)
WORKDIR       where helper scripts are saved (default: OUT's folder)

It fills the vibe-dashboard template with the fixed skill-sheet sections, then applies the vibe-dashboard
table-fit, Search and Mind Map patches (the first and last are extracted from vibe-dashboard's SKILL.md, so
they always match the current skill), saves stress_audio.py next to them, and writes narration-draft.txt
(section-by-section, from the card) for Claude to polish, audit and record. The page is NOT published here.
"""
import html, json, os, re, subprocess, sys

card_p, VIBE, SKF, OUT = sys.argv[1:5]
WD = sys.argv[5] if len(sys.argv) > 5 else os.path.dirname(os.path.abspath(OUT))
C = json.load(open(card_p, encoding='utf-8'))
M = C.get('meta', {})
e = html.escape

def md(t):
    """plain text with `code` and **bold** -> safe HTML"""
    t = e(str(t))
    t = re.sub(r'`([^`]+)`', r'<code>\1</code>', t)
    return re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', t)
def li(topic, text): return f'<li><span class="tid">{e(topic)}</span>{md(text)}</li>'
def ul(items, label=None):
    if not items: return ''
    a = f' data-mm-label="{e(label)}"' if label else ''
    return f'<ul{a}>' + ''.join(li(i['topic'], i['text']) for i in items) + '</ul>'
def table(desc, heads, rows, cls=''):
    if not rows: return ''
    th = ''.join(f'<th>{h}</th>' for h in heads)
    body = ''.join('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>' for r in rows)
    return f'<div class="table-wrap{(" " + cls) if cls else ""}" data-desc="{e(desc)}"><table><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table></div>'
def callout(lbl, text_html): return f'<div class="callout"><span class="lbl">{e(lbl)}</span>{text_html}</div>'
def P(t): return f'<p>{md(t)}</p>'
def B(t): return f'<strong>{md(t)}</strong>'
TAGC = {'Yes': '#38fa79', 'Required': '#fa9938', 'Optional': '#38dafa', 'Partial': '#dafa38', 'Untested': '#fa9938',
        'No': '#fa3899', 'Not needed': '#7938fa', 'Related': '#7938fa', 'Mac only': '#dafa38', 'Windows only': '#dafa38',
        'Required (Mac)': '#fa9938', 'Required (Windows)': '#fa9938'}
def tag(v): return f'<span class="tid" style="--tc:{TAGC.get(v, "#38dafa")}">{e(v)}</span>'
def tid(v): return f'<span class="tid">{e(v)}</span>'
def dt(v): return f'<strong class="dt">{e(v)}</strong>'

# ---------------- sections (fixed skill-sheet order) ----------------
CATS = [('overview', '#38dafa', 'OVERVIEW'), ('usage', '#38fa79', 'USAGE'), ('deps', '#dafa38', 'DEPENDENCIES'),
        ('scope', '#fa9938', 'SCOPE'), ('caveat', '#fa3899', 'GOTCHAS'), ('runtime', '#ea38fa', 'RUNTIME'),
        ('reference', '#7938fa', 'REFERENCE')]
name = C['skill']
S = []   # (cat, title, focus, when, body_html)
S.append(('overview', 'What It Is', 'The skill in plain words and why it exists', 'First look at the skill',
          ''.join(P(p) for p in C.get('what_it_is', [])) + (callout('Why it matters', md(C['why'])) if C.get('why') else '')))
S.append(('overview', 'What It Does', 'Everything the skill produces or handles', 'Checking whether it fits a job',
          ul(C.get('what_it_does', []))))
howto = ''
if C.get('triggers'):
    howto += callout('Ask for it', '<br>'.join(md(t) for t in C['triggers']))
WIN = bool(C.get('how_to_use_windows'))
howto += table('On macOS, step by step' if WIN else 'How to use it, step by step', ['#', 'Topic', 'Step', 'Who'],
               [[str(i), tid(s['topic']), md(s['step']), md(s.get('who', ''))] for i, s in enumerate(C.get('how_to_use', []), 1)], 'no-sort')
howto += table('On Windows, step by step', ['#', 'Topic', 'Step', 'Who'],
               [[str(i), tid(s['topic']), md(s['step']), md(s.get('who', ''))] for i, s in enumerate(C.get('how_to_use_windows', []), 1)], 'no-sort')
S.append(('usage', 'How to Use It', 'What to ask, then each step in order, on macOS and Windows' if WIN else 'What to ask, then each step in order', 'Running the skill', howto))
S.append(('deps', 'Skills It Depends On', 'Other skills it calls or hands off to', 'Installing or sharing the skill',
          table('Skill dependencies', ['Skill', 'Need', 'Why'], [[B(d['name']), tag(d['need']), md(d['why'])] for d in C.get('skills', [])])
          or P('None. This skill works on its own.')))
PWIN = any('install_windows' in d for d in C.get('programs', []))
S.append(('deps', 'Programs It Depends On', 'Software outside Claude and where it runs', 'Setting up a computer for it',
          table('Program dependencies', ['Program', 'Need', 'Where it runs', 'Why'] + (['macOS install / notes', 'Windows install / notes'] if PWIN else ['Install / notes']),
                [[B(d['name']), tag(d['need']), md(d.get('where', '')), md(d.get('why', '')), md(d.get('install', ''))]
                 + ([md(d.get('install_windows', '—'))] if PWIN else []) for d in C.get('programs', [])])
          or P('None outside Claude.')))
S.append(('scope', 'Capabilities and Limitations', 'What it can and cannot do', 'Setting expectations',
          ul(C.get('capabilities', []), 'Capabilities') + ul(C.get('limitations', []), 'Limitations')))
st = C.get('scheduled_tasks', {})
S.append(('runtime', 'Scheduled Tasks', 'Whether it needs or sets up scheduled tasks', 'Planning automation',
          P(st.get('summary', 'None.')) + table('Scheduled tasks', ['Task', 'Schedule', 'What it does'],
          [[B(t['name']), md(t.get('schedule', '')), md(t.get('what', ''))] for t in st.get('tasks', [])])))
S.append(('runtime', 'Where It Runs', 'Which Claude it runs in, plus notes for other AIs', 'Choosing where to run it',
          table('Claude surfaces', ['Where', 'Works', 'Notes'], [[B(r['where']), tag(r['status']), md(r['notes'])] for r in C.get('runs_in', [])])
          + table('Other AIs', ['AI', 'Works', 'Notes'], [[B(r['ai']), tag(r['status']), md(r['notes'])] for r in C.get('other_ais', [])])))
S.append(('caveat', 'Gotchas', 'Traps that cost time, and how to avoid them', 'Something went wrong', ul(C.get('gotchas', []))))
S.append(('reference', 'Other Requirements', 'Accounts, settings, hardware and access it needs', 'Before first use', ul(C.get('requirements', []))))
fresh = [[B('Skill'), f'<code>{e(name)}</code>'],
         [B('Skill last updated'), dt(M.get('skill_updated', '—'))],
         [B('Fingerprint'), f'<code>{e(M.get("fingerprint", "—"))}</code>'],
         [B('Files covered'), md(', '.join(f'`{f}`' for f in M.get('files', [])) or '—')],
         [B('Card written'), dt(M.get('carded', '—'))],
         [B('Status'), f'<span class="tid" style="--tc:{"#38fa79" if M.get("status") == "published" else "#fa9938"}">{"Published" if M.get("status") == "published" else "Draft"}</span>']]
if M.get('zip'): fresh.append([B('Download'), f'<a href="{e(M["zip"])}" target="_blank" rel="noopener">{e(name)}.zip ↗</a>'])
cardsec = (P('This page is built from a skill card. The fingerprint changes whenever any file in the skill changes, so a nightly check can flag this page as out of date.')
           + table('Card and freshness', ['Item', 'Value'], fresh, 'no-sort'))
if C.get('confirm'):
    cardsec += callout('To confirm before publishing', '<br>'.join('● ' + md(x) for x in C['confirm']))
S.append(('reference', 'Card and Freshness', 'Which version of the skill this page describes', 'Checking the page is current', cardsec))

# ---------------- render into the vibe-dashboard template ----------------
s = open(os.path.join(VIBE, 'assets/template.html'), encoding='utf-8').read()
rgb = lambda h: ','.join(str(int(h[i:i+2], 16)) for i in (1, 3, 5))
s = re.sub(r'    --cat-overview:#38dafa;.*?\n    --cat-source:#38fa79;.*?\n', ''.join(f'    --cat-{n}:{c};\n' for n, c, _ in CATS), s, count=1)
blocks = ''.join(f'  .cat-{n} .cat-badge{{color:var(--cat-{n});background:rgba({rgb(c)},.10)}}\n  .cat-{n}{{border-left:3px solid var(--cat-{n})}}\n'
                 f'  .toc-chip.tc-{n}{{border-left-color:var(--cat-{n})}}\n  .toc-chip.tc-{n}:hover{{color:var(--cat-{n})}}\n'
                 f'  .toc-tip.tc-{n} .tip-badge{{color:var(--cat-{n});background:rgba({rgb(c)},.10)}}\n' for n, c, _ in CATS)
a, b = s.index('  /* live defs for the template'), s.index('  .chevron{'); s = s[:a] + blocks + s[b:]
s = re.sub(r"  \.toc-tip\.tc-overview \.tip-badge\{[^\n]*\n  \.toc-tip\.tc-source \.tip-badge\{[^\n]*\n", '', s, count=1)
s = s.replace('</style>', '  .dt{color:var(--text);font-weight:700}\n</style>', 1)
title = C.get('title') or name
s = s.replace('{{PAGE_TITLE}}', e(title) + ' skill').replace('{{KICKER}}', 'SKILL SHEET').replace('{{H1_TITLE}}', e(title))
s = s.replace('{{H1_SUBTITLE}}', md(C.get('summary', '')))
s = s.replace('<span>{{BYLINE_A}}</span>', f'<span>Claude skill · <code>{e(name)}</code></span>')
s = s.replace('<span>{{BYLINE_B}}</span>', f'<span>Skill updated {dt(M.get("skill_updated", "—"))}</span><span>Card {dt(M.get("carded", "—"))}</span>')
s = s.replace('{{MAIL_SUBJECT}}', e(name) + ' skill sheet')
CAT = {n: badge for n, _, badge in CATS}
s = s.replace('{{SUMMARY_BADGE}}', 'OVERVIEW')
s = s.replace('{{SUMMARY_INTRO}}', md(C.get('summary', '')) + ' This page explains what the skill is, how to use it, what it depends on, where it runs, and its gotchas. Terms with a dotted underline jump to the Glossary.')
if C.get('confirm'):
    s = s.replace('{{SUMMARY_CALLOUT_LABEL}}', 'Draft').replace('{{SUMMARY_CALLOUT_TEXT}}', 'This page is a draft awaiting review; see "Card and Freshness" for the open questions.')
else:
    s = re.sub(r'\s*<div class="callout"><span class="lbl">\{\{SUMMARY_CALLOUT_LABEL\}\}</span>\{\{SUMMARY_CALLOUT_TEXT\}\}</div>', '', s)
rows = ''.join(f'<tr><td><span class="secnum">{i+2:02d}</span></td><td><strong>{t}</strong></td><td class="sec-cat"></td><td>{f}</td><td>{w}</td></tr>\n            '
               for i, (_, t, f, w, _) in enumerate(S))
a = s.index('            <tr><td><span class="secnum">02</span></td><td><strong>{{SEC_A_TITLE}}'); b = s.index('            <!-- one row per remaining section -->')
s = s[:a] + '            ' + rows + s[b:]
s = re.sub(r'            <tr><td><span class="secnum" data-target-title="References">.*?</tr>\n', '', s, count=1)
s = s.replace('<div class="section cat-overview" data-title="Dashboard Summary"', '<div class="section cat-overview" data-title="Dashboard Summary"')
content = ''.join(f'  <div class="section cat-{c}" data-title="{t}" data-cat="{c}">\n    <div class="sec-head"><span class="sec-num">{i+2:02d}</span>'
                  f'<span class="sec-title">{t}</span><span class="cat-badge">{CAT[c]}</span><span class="chevron">▶</span></div>\n'
                  f'    <div class="sec-body">\n      {body}\n    </div>\n  </div>\n\n' for i, (c, t, _, _, body) in enumerate(S))
a, b = s.index('  <!-- SECTION PATTERN'), s.index('  <!-- OPTIONAL (include whenever the dashboard uses terms'); s = s[:a] + content + s[b:]
# glossary (Topic column second, coloured per topic in order of first appearance)
PAL = ['#38dafa', '#38fa79', '#dafa38', '#fa9938', '#fa3899', '#ea38fa', '#7938fa', '#3879fa']
tc = {}
for g in C.get('glossary', []): tc.setdefault(g['topic'], PAL[len(tc) % 8])
bad = [g['term'] for g in C.get('glossary', []) if re.search(r'(?<!\\)\((?!\?)', g.get('match', ''))]
if bad: sys.exit('glossary match uses a capturing group (write (?:...) instead): ' + ', '.join(bad))
grows = ''.join(f'<tr data-gterm="{e(re.sub(r"[^a-z0-9]+", "-", g["term"].lower()).strip("-"))}" data-match="{e(g.get("match", ""))}" data-code="{e(g.get("code", ""))}">'
                f'<td><strong>{e(g["term"])}</strong></td><td><span class="tid" style="--tc:{tc[g["topic"]]}">{e(g["topic"])}</span></td>'
                f'<td>{e(g["def"])}</td><td class="gloss-uses"></td><td class="gloss-count"></td></tr>\n            ' for g in C.get('glossary', []))
s = s.replace('<thead><tr><th>Term</th><th>Definition</th><th>Appears in</th><th>Qty</th></tr></thead>',
              '<thead><tr><th>Term</th><th>Topic</th><th>Definition</th><th>Appears in</th><th>Qty</th></tr></thead>')
a, b = s.index('            <tr data-gterm="{{GLOSS_A_ID}}"'), s.index('            <!-- one row per term -->'); s = s[:a] + '            ' + grows + s[b:]
s = s.replace('click it to land on its row.', 'click it to land on its row. Each term\'s <strong>Topic</strong> tag names what it is about, one color per topic.', 1)
s = s.replace("def = row.cells[1].textContent.trim();",
              "def = ([...row.cells].slice(1).find(c => !c.querySelector('.tid') && !c.matches('.gloss-uses,.gloss-count')) || {textContent:''}).textContent.trim();")
GS = """
/* ---- glossary: start sorted by Topic column (asc) ---- */
(function(){
  const gsec = document.querySelector('.section[data-title="Glossary"]'); if(!gsec) return;
  const table = gsec.querySelector('.table-wrap table'); if(!table || !table.tHead) return;
  const ths = [...table.tHead.rows[0].cells];
  const ti = ths.findIndex(th => { const t = th.childNodes[0]; return t && t.nodeType === 3 && t.nodeValue.trim().toUpperCase() === 'TOPIC'; });
  if(ti >= 0) ths[ti].click();
})();
"""
DS = """/* DEFAULT-SORTS:BEGIN */
/* ---- open these tables sorted (asc) by one column, like the Glossary's Topic sort ---- */
[['Program dependencies','NEED'],['Claude surfaces','WORKS'],['Other AIs','WORKS']].forEach(([desc, col]) => {
  const w = [...document.querySelectorAll('.table-wrap')].find(x => x.dataset.desc === desc); if(!w) return;
  const t = w.querySelector('table'); if(!t || !t.tHead) return;
  const th = [...t.tHead.rows[0].cells].find(h => { const n = h.childNodes[0]; return n && n.nodeType === 3 && n.nodeValue.trim().toUpperCase() === col; });
  if(th) th.click();
});
/* DEFAULT-SORTS:END */
"""
k = s.index('buildFloatingHeaders();', s.index('initSortableTables();')) + len('buildFloatingHeaders();'); s = s[:k] + GS + DS + s[k:]
# drop References; Glossary + Source Document in the "reference" category; verbatim = the skill's SKILL.md
a, b = s.index('  <!-- REQUIRED (when the dashboard cites external sources)'), s.index('  <!-- OPTIONAL verbatim source section'); s = s[:a] + s[b:]
s = s.replace('<div class="section cat-source"', '<div class="section cat-reference"').replace('data-cat="source"', 'data-cat="reference"')
s = s.replace('<span class="cat-badge">Source</span>', '<span class="cat-badge">REFERENCE</span>')
n = len(S) + 1
s = s.replace('<span class="sec-num">97</span>', f'<span class="sec-num">{n+1:02d}</span>').replace('<span class="sec-num">99</span>', f'<span class="sec-num">{n+2:02d}</span>')
s = s.replace('Original reproduced exactly as supplied.', f'The skill\'s own instructions (SKILL.md), reproduced verbatim from the version this page describes.')
s = s.replace('<td>Original source, reproduced verbatim</td><td>Checking the raw source</td>', '<td>The skill\'s SKILL.md, verbatim</td><td>Reading the exact instructions Claude follows</td>')
v = open(os.path.join(SKF, 'SKILL.md'), encoding='utf-8').read().rstrip('\n')
VERB = v.replace('\\', '\\\\').replace('`', '\\`').replace('${', '\\${').replace('{{', '{\\{').replace('</', '<\\/').replace('<!--', '<\\!--')
s = s.replace('{{VERBATIM_TEXT}}', '__VERBATIM_SLOT__')
s = s.replace("VERBATIM.replace(/\\n/g, '\\n\\n')", 'VERBATIM')
left = sorted(set(re.findall(r'\{\{[A-Z0-9_]+\}\}', s)))
if left: sys.exit('placeholders left: ' + ', '.join(left))
open(OUT, 'w', encoding='utf-8').write(s)

# ---------------- vibe-dashboard patches (extracted from its SKILL.md so they stay current) ----------------
sk = open(os.path.join(VIBE, 'SKILL.md'), encoding='utf-8').read()
blocks = re.findall(r'```python\n(.*?)```', sk, re.S)
pick = lambda test: next(b for b in blocks if test(b))
os.makedirs(WD, exist_ok=True)
open(os.path.join(WD, 'fit_patch.py'), 'w').write(pick(lambda b: 'function bodyWordMin(' in b and 'table-fit patch' in b))
open(os.path.join(WD, 'mindmap_patch.py'), 'w').write(pick(lambda b: '"""mindmap_patch.py' in b))
open(os.path.join(WD, 'stress_audio.py'), 'w').write(pick(lambda b: 'stress_audio.py — run' in b))
for cmd in (['python3', os.path.join(WD, 'fit_patch.py'), OUT], ['python3', os.path.join(VIBE, 'scripts/search_patch.py'), OUT],
            ['python3', os.path.join(WD, 'mindmap_patch.py'), OUT]):
    r = subprocess.run(cmd, capture_output=True, text=True); print(r.stdout.strip() or r.stderr.strip())
    if r.returncode: sys.exit('patch failed: ' + ' '.join(cmd))
_t = open(OUT, encoding='utf-8').read(); assert _t.count('__VERBATIM_SLOT__') == 1
open(OUT, 'w', encoding='utf-8').write(_t.replace('__VERBATIM_SLOT__', VERB))

# ---------------- narration draft (Claude polishes, audits stress, then records) ----------------
NUM = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen',
       'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty']
nums = {m.group(2): int(m.group(1)) for m in re.finditer(r'<span class="sec-num">(\d+)</span><span class="sec-title">([^<]+)</span>', open(OUT, encoding='utf-8').read())}
say = C.get('spoken', {})
paras = [say.get('_intro', f'This page is the skill sheet for the {name} skill. ' + re.sub(r'[`*]', '', C.get('summary', '')))]
for t, i in sorted(nums.items(), key=lambda x: x[1]):
    default = {'Dashboard Summary': 'A short intro and a table of every section.',
               'Search': 'Type a few words to find anything on this page, in any order and with small typos forgiven. Narrow the results with filters, and click a result to jump to it.',
               'Mind Map': 'The whole page as bubbles you can open, hover for a summary, and click to jump to that spot.',
               'Glossary': 'The terms used on this page, each linked to where it appears.',
               'Source Document (Verbatim)': "The skill's own instructions, word for word."}.get(t, next((f for _, tt, f, _, _ in S if tt == t), ''))
    paras.append(f'Section {NUM[i] if i < len(NUM) else i}, {t.replace("&", "and").replace(" (Verbatim)", ", Verbatim")}. {say.get(t, default).rstrip(".")}.')
open(os.path.join(WD, 'narration-draft.txt'), 'w', encoding='utf-8').write('\n\n'.join(paras) + '\n')
print('built', OUT, '· sections', len(nums), '· narration-draft.txt written')
