---
name: "skill-dashboard"
description: "Create, update, check and publish a vibe-dashboard skill sheet for one of Swami's own Claude skills from a skill card. Use when Swami wants a skill's dashboard made, updated, checked or published."
---

# Skill Dashboard

Every one of Swami's own skills (Customize › Skills › Yours) gets a **skill sheet**: a vibe-dashboard page, in a fixed shape, explaining that skill. Each page is rendered from a **skill card**, a JSON file holding the facts about the skill plus a **fingerprint** of its files, so a later check can tell when the skill has changed and its page is out of date.

**Swami vets every page before it goes public.** This skill only ever publishes a *private draft* artifact. Nothing goes to GitHub or the Skill Library until Swami says to publish that skill.

Four modes. Pick from the request:

| Mode | Swami says | Result |
|---|---|---|
| **create** | "make a dashboard for youtube-transcript" | card + private draft artifact |
| **update** | "update the facebook-comments dashboard", or check found it out of date | card refreshed, draft republished to the same URL |
| **check** | "which skill dashboards are out of date?" | table in chat: fresh / out of date / no dashboard yet |
| **publish** | "publish the youtube-comments dashboard" (after vetting) | page + card on GitHub Pages, linked from the Skill Library |

Load the **vibe-dashboard** skill first (Skill tool). This skill depends on it for the template, the patches, the audio, the pronunciation rules and the privacy rules, and it always follows that skill's current version. Where the two differ, this file wins only on the points it states (fixed sections, drafts, no audio refresh button).

## Where things are

- **Skill folders:** `/mnt/skills/plugins/<skill>/` (with `manifest.json` one level up; Swami's own skills have `"source": "plugin"`). In some sessions the synced copy is under `/root/.claude/skills/synced/*/`; use whichever exists. Treat them as read-only.
- **vibe-dashboard folder (VIBE):** the same root, `…/vibe-dashboard/`.
- **Draft:** a private artifact per skill, titled "<Title> skill". It carries `card.txt` (the card) and `narration.txt` as published files, so a later session can rebuild it.
- **Published:** public repo `swami-claude-skills/claude-skills`, folder `dashboards/<skill>/` holding `index.html`, `card.json` and `narration.txt`, plus the registry `dashboards/index.json`. GitHub Pages serves them at `https://swami-claude-skills.github.io/claude-skills/dashboards/<skill>/`. The nightly sync (`gh_sync.py`) only touches `zips/`, the all-skills zip and `README.md`, so `dashboards/` is safe.
- **Skill Library:** the artifact https://claude.ai/artifact/Mg8X9h2EDFMLnsPcG9d2SE, rebuilt nightly by the scheduled task "Skills dashboard nightly refresh" from its published `build.txt` and `template.txt`.

## The skill sheet (format F2)

Fixed sections, always in this order, built by `build_skill_sheet.py` from the card:

01 Dashboard Summary · 02 Search · 03 What It Is · 04 What It Does · 05 How to Use It (macOS, then Windows) · 06 Skills It Depends On · 07 Programs It Depends On · 08 Capabilities and Limitations · 09 Scheduled Tasks · 10 Where It Runs (Claude surfaces, then other AIs) · 11 Gotchas · 12 Other Requirements · 13 Card and Freshness · 14 Mind Map · 15 Glossary · 16 Source Document (Verbatim) = the skill's SKILL.md.

Search, Mind Map, Glossary and the audio overview stay (all from vibe-dashboard). The audio is kept short (about 2½–3 minutes). Skill sheets do **not** get the owner-only audio refresh button: the published copy lives on GitHub Pages, where it can't work, and update mode re-records the audio anyway. So declare no capabilities.

## The skill card

`<skill>.json`. Text fields are plain text; `` `code` `` and `**bold**` are rendered. Lists of `{topic, text}` become list items with topic IDs (1–3 word Title Case topics).

```jsonc
{
  "skill": "youtube-comments",                 // folder name
  "title": "YouTube Comments",                 // page heading
  "summary": "One sentence: what it does.",
  "what_it_is": ["paragraph", "paragraph"],
  "why": "Optional: why the skill exists (a callout).",
  "what_it_does": [{"topic": "", "text": ""}],
  "triggers": ["\"What Swami types to start it\""],
  "how_to_use": [{"topic": "", "step": "", "who": "Swami | Claude | …"}],          // macOS steps
  "how_to_use_windows": [{"topic": "", "step": "", "who": ""}],                 // Windows steps (PowerShell)
  "skills":   [{"name": "", "need": "Required|Optional|Related", "why": ""}],
  "programs": [{"name": "", "need": "Required|Required (Mac)|Required (Windows)|Optional|Mac only|Windows only|Not needed",
                "where": "", "why": "", "install": "macOS notes", "install_windows": "Windows notes"}],
  "capabilities": [{"topic": "", "text": ""}],
  "limitations":  [{"topic": "", "text": ""}],
  "scheduled_tasks": {"summary": "None. …", "tasks": [{"name": "", "schedule": "", "what": ""}]},
  "runs_in":   [{"where": "Claude app, cloud session (web, desktop, mobile)", "status": "Yes|Partial|No|Untested", "notes": ""}],
  "other_ais": [{"ai": "ChatGPT|Gemini|Grok|…", "status": "Yes|Partial|No|Untested", "notes": ""}],
  "gotchas":      [{"topic": "", "text": ""}],
  "requirements": [{"topic": "", "text": ""}],
  "glossary": [{"term": "", "topic": "", "match": "regex", "code": "exact|code", "def": ""}],
  "confirm": ["Open question for Swami (shown only while non-empty)"],
  "spoken": {"_intro": "", "<Section title>": "one or two spoken sentences, no trailing period"},
  "meta": {"card_version": 1, "fingerprint": "sha256:…", "files": ["SKILL.md"],
           "skill_updated": "Sat Oct 3, 2026", "carded": "Sat Nov 7, 2026", "status": "draft|published",
           "zip": "https://github.com/swami-claude-skills/claude-skills/raw/main/zips/<skill>.zip",
           "draft_url": "", "public_url": ""}
}
```

What goes where:
- **Runs in.** Always rate these five rows: Claude app cloud session (web, desktop, mobile); Claude desktop app linked to the Mac; Claude desktop app linked to a Windows PC; Claude mobile app; Claude Code on the Mac. Base each rating on what the skill needs: browser tools (the built-in browser exists only in the desktop app), a linked Mac shell, code execution, uploads, connectors. Use **Untested** when not confirmed.
- **Other AIs.** ChatGPT, Gemini and Grok at least. Use what the Skill Library's install steps say: Claude takes the .zip; Gemini takes the unzipped folder; Grok imports the .zip, or the SKILL.md if refused, and installing by chat drifts; ChatGPT skills need Business, Enterprise, Edu or Healthcare. Then add what the skill needs (code execution, browser, dashboard hand-off needs vibe-dashboard installed there). Default **Untested**.
- **Programs.** Anything outside Claude: CLI tools (yt-dlp, ytx, ffmpeg), apps (Fusion, Terminal, a browser), plus Python in Claude's workspace when the skill runs code. Say where each runs (Swami's Mac or Claude's workspace) and how to install it. If a program people might expect is *not* used, list it as **Not needed**.
- **Windows.** Every card covers macOS and Windows, because the skills are shared with Windows users.
  - Give each program an `install_windows` note: winget or the .exe download, PowerShell instead of Terminal, no `sudo`, SmartScreen instead of Gatekeeper, and `C:\Users\<name>\…` paths.
  - Fill `how_to_use_windows`, and add Windows gotchas (for example one-line PowerShell commands, reopening PowerShell after winget) and requirements (Windows 10 or 11).
  - Tag Mac-only tools **Required (Mac)** or **Mac only**, and give the Windows alternative.
  - If the skill itself has no Windows steps, propose an improvement to that skill (propose_skills) adding an "On Windows" section, so the card still describes the skill as it is. Windows behavior nobody has tried is **Untested**.
- **Scheduled tasks.** Whether the skill needs one, creates one, or is run by one (look through `list_triggers` for task prompts that name the skill).
- **Glossary.** 10–25 terms. Each `match` must hit the page's body text at least once (the build check reports zero-count terms). Start and end each regex with a word character.
- **Spoken.** Follow vibe-dashboard's Pronunciation table. Spell tool names the voice gets wrong: yt-dlp → `why-tee-dee-ell-pee`. Check with the Kokoro tokenizer, and put verb-stress markup (for example `[upload](/ʌplˈoʊd/)`) right in the card, so rebuilds keep it. Sections without an entry fall back to their Focus line.
- **Confirm.** Anything you could not verify from the files, any mismatch with what Swami said, and any staleness you notice in the skill itself (for example a hand-off that predates vibe-dashboard's current rules). Ask Swami about these, and leave them on the draft until he answers.

## create

1. Find the skill folder and read **every** file in it (SKILL.md, scripts, references, assets). Read its manifest entry for `updatedAt` (show it in ET as `Sat Oct 3, 2026`).
2. Save `fingerprint.py` and `build_skill_sheet.py` (below) to `/home/claude/skill-dashboard/scripts/`. Run `python3 fingerprint.py SKILL_FOLDER` and put its fingerprint and file list in `meta`.
3. Write the card to `/home/claude/skill-dashboard/cards/<skill>.json` from what the files actually say. Check: other skills it loads or hands off to; programs it calls; scheduled tasks; where it can run. Fill `confirm`.
4. Build: `python3 scripts/build_skill_sheet.py cards/<skill>.json VIBE SKILL_FOLDER /home/claude/<skill>-skill.html work`. It renders the page, applies vibe-dashboard's table-fit, Search and Mind Map patches, and writes `work/narration-draft.txt` and `work/stress_audio.py`.
5. Audio: copy the draft to `work/narration.txt`, run `python3 work/stress_audio.py VIBE audit work/narration.txt`, and fix any wrong stress *in the card's `spoken` block*. Rebuild (step 4), re-audit until clean, then `python3 work/stress_audio.py VIBE build PAGE work/narration.txt PAGE`. If recording fails, follow vibe-dashboard's "When the recording can't be made".
6. Check in a browser (Playwright):
   - No console warnings other than font loading.
   - Every summary row is linked.
   - No glossary term has a count of 0.
   - Tables fit at 1000 px and 1440 px.
   - Run vibe-dashboard's privacy scan (its "Privacy: people under NDA" list). An excluded person must never appear.
7. Publish the page as a **new private artifact** (icon from the skill's subject; no capabilities). Set `meta.draft_url`, then republish with `files: {"card.txt": {from: card, contentType: "text/plain"}, "narration.txt": {from: work/narration.txt, contentType: "text/plain"}}`.
8. Tell Swami in a few lines: the draft is ready; list the `confirm` questions; ask him to vet it and then say "publish".

## update

1. Find the draft or published page: use `meta.draft_url`, or the registry `dashboards/index.json` in the repo, or list artifacts titled "<Title> skill". Read its `card.txt` (draft) or `dashboards/<skill>/card.json` (published).
2. Re-read the skill's files and re-run the fingerprint. Compare the files with the card and change only what the skill change affects. Keep Swami's edits and answers. Update `meta` (fingerprint, files, skill_updated, carded) and set `status` to `draft`.
3. Rebuild, re-record and check as in create steps 4–6. Republish the draft to the **same** URL (`url` = `meta.draft_url`). Changes to a published page always go through a draft first, then "publish".

## check

Collect the cards: the repo's `dashboards/*/card.json` (clone `swami-claude-skills/claude-skills` read-only), plus any draft `card.txt` files. Then run `python3 fingerprint.py check CARDS_DIR SKILLS_ROOT`. Reply in chat with a table: skill, state (fresh / OUT OF DATE / no dashboard yet / skill missing), status (draft or published), and its link. Offer to update the out-of-date ones.

## publish (only after Swami approves that skill's draft)

1. `confirm` must be empty (fold Swami's answers into the card, rebuild, and re-record if the text changed). Set `meta.status` to `published` and `meta.public_url` to `https://swami-claude-skills.github.io/claude-skills/dashboards/<skill>/`. Rebuild so the page shows "Published".
2. Attach the repo with `add_repo` (owner `swami-claude-skills`, repo `claude-skills`, access `push`). Clone it as that tool says and set the git user to Claude / noreply@anthropic.com.
3. Write `dashboards/<skill>/index.html` (the page), `card.json` and `narration.txt`. Update `dashboards/index.json`: `{"<skill>": {"title", "page": "dashboards/<skill>/", "fingerprint", "skill_updated", "published": "YYYY-MM-DD", "draft_url"}}`, sorted by skill. Make sure `dashboards/.nojekyll` exists (an empty file).
4. Run the privacy scan on every changed file. A hit stops everything.
5. Commit `Skill sheet: <skill>` (end with the session's Co-Authored-By line), push to `main`, and verify `git ls-remote origin main` = `git rev-parse HEAD`.
6. **First publish only: GitHub Pages.** Ask Swami to turn it on once: github.com/swami-claude-skills/claude-skills › Settings › Pages › Source "Deploy from a branch" › `main` / `(root)` › Save. Within a few minutes the page appears at the public URL.
7. **First publish only: wire the Skill Library**, so it shows the link and the out-of-date flag nightly with no change to the scheduled task. Read the Library artifact's `build.txt` and `template.txt`, then edit `build.py`:
   - Load `/home/claude/claude-skills/dashboards/index.json` if present; the nightly task already clones the repo there.
   - Add a **Dashboard** cell to each row:
     - a skill with no entry gets `—`;
     - a skill with an entry gets an `open ↗` link to `https://swami-claude-skills.github.io/claude-skills/<page>`, target blank;
     - when the fingerprint of `/mnt/skills/plugins/<skill>` (same algorithm as `fingerprint.py`) differs from the registry, add an orange "out of date" tag (`#fa9938`).
   - Add the matching `<th>Dashboard</th>` to `template.txt`.
   - Rebuild locally to test. Publish the Library to its URL with the same `files` map its nightly task uses, and no capabilities or icon field.
   - Its next nightly run keeps it current.
8. On later publishes, steps 6–7 are already done: the Library shows the link after its next nightly run, or republish it now if Swami wants it sooner.
9. Tell Swami the public URL and what was committed.

## Rules

- Never publish to GitHub or change the Skill Library without Swami's "publish" for that skill.
- Cards describe the skill as it is. Never invent behavior, results or test outcomes; anything unverified is **Untested** or goes in `confirm`.
- One skill per run unless Swami asks for more.
- An excluded (NDA) person must never appear on a skill sheet, its card, its narration or a commit message. Use vibe-dashboard's privacy rules and scan.
- Days, dates and times are bold and bright on the page (`.dt`), bullets are cyan ●, and lists use the Oxford comma, as in vibe-dashboard.

## fingerprint.py

```python
#!/usr/bin/env python3
"""fingerprint.py — content fingerprint of a skill folder, and freshness checks for skill cards.

  python3 fingerprint.py SKILL_FOLDER                  -> prints {"fingerprint": "sha256:…", "files": [...]}
  python3 fingerprint.py check CARDS_DIR SKILLS_ROOT    -> one line per card: fresh | OUT OF DATE | skill missing
                                                           plus skills that have no card yet

The fingerprint is a SHA-256 over every file's relative path and bytes (sorted), so it changes when any
file in the skill is added, removed or edited, and never changes otherwise (timestamps are ignored).
CARDS_DIR holds <skill>.json cards (or <skill>/card.json). SKILLS_ROOT holds one folder per skill and,
when present, Claude's manifest.json (only source "plugin" skills — Swami's own — are reported as missing a card).
"""
import hashlib, json, os, sys

def fingerprint(folder):
    h, files = hashlib.sha256(), []
    for dp, dn, fn in os.walk(folder):
        dn[:] = sorted(d for d in dn if not d.startswith('.'))
        for f in sorted(fn):
            if f.startswith('.'): continue
            p = os.path.join(dp, f); rel = os.path.relpath(p, folder).replace(os.sep, '/')
            files.append(rel); h.update(rel.encode() + b'\0'); h.update(open(p, 'rb').read()); h.update(b'\0')
    return 'sha256:' + h.hexdigest()[:16], files

def load_cards(d):
    out = {}
    for e in sorted(os.listdir(d)):
        p = os.path.join(d, e)
        if e.endswith('.json') and os.path.isfile(p): c = json.load(open(p, encoding='utf-8'))
        elif os.path.isfile(os.path.join(p, 'card.json')): c = json.load(open(os.path.join(p, 'card.json'), encoding='utf-8'))
        else: continue
        if isinstance(c, dict) and c.get('skill'): out[c['skill']] = c
    return out

if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == 'check':
        cards, root = load_cards(a[1]), a[2]
        res = []
        for name, c in cards.items():
            folder = os.path.join(root, name)
            if not os.path.isfile(os.path.join(folder, 'SKILL.md')): res.append({'skill': name, 'state': 'skill missing'}); continue
            fp, _ = fingerprint(folder); old = c.get('meta', {}).get('fingerprint')
            res.append({'skill': name, 'state': 'fresh' if fp == old else 'OUT OF DATE', 'card': old, 'now': fp,
                        'status': c.get('meta', {}).get('status', '?')})
        mf = os.path.join(root, 'manifest.json')
        if os.path.exists(mf):
            for s in json.load(open(mf, encoding='utf-8'))['skills']:
                if s.get('source') == 'plugin' and s['name'] not in cards: res.append({'skill': s['name'], 'state': 'no dashboard yet'})
        for r in res: print(json.dumps(r))
    elif a:
        fp, files = fingerprint(a[0]); print(json.dumps({'fingerprint': fp, 'files': files}))
    else: sys.exit(__doc__)
```

## build_skill_sheet.py

This block uses a four-backtick fence because the script itself contains triple backticks. Save everything between the fences verbatim.

````python
#!/usr/bin/env python3
"""build_skill_sheet.py — render a skill card (skill-card.json) as a vibe-dashboard "skill sheet" (format F2).

usage: python3 build_skill_sheet.py CARD.json VIBE_DIR SKILL_FOLDER OUT.html [WORKDIR]

VIBE_DIR      the vibe-dashboard skill folder (assets/template.html, scripts/search_patch.py, SKILL.md)
SKILL_FOLDER  the skill being documented (its SKILL.md becomes the verbatim Source Document section)
WORKDIR       where helper scripts are saved (default: OUT's folder)

It fills the vibe-dashboard template with the fixed skill-sheet sections, then applies the vibe-dashboard
table-fit, Search and Mind Map patches (the first and last are extracted from vibe-dashboard's SKILL.md, so
they always match the current skill), saves stress_audio.py next to them, and writes narration-draft.txt
(section-by-section, from the card) for Claude to polish, audit and record. The page is NOT published here.
"""
import html, json, os, re, subprocess, sys

card_p, VIBE, SKF, OUT = sys.argv[1:5]
WD = sys.argv[5] if len(sys.argv) > 5 else os.path.dirname(os.path.abspath(OUT))
C = json.load(open(card_p, encoding='utf-8'))
M = C.get('meta', {})
e = html.escape

def md(t):
    """plain text with `code` and **bold** -> safe HTML"""
    t = e(str(t))
    t = re.sub(r'`([^`]+)`', r'<code>\1</code>', t)
    return re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', t)
def li(topic, text): return f'<li><span class="tid">{e(topic)}</span>{md(text)}</li>'
def ul(items, label=None):
    if not items: return ''
    a = f' data-mm-label="{e(label)}"' if label else ''
    return f'<ul{a}>' + ''.join(li(i['topic'], i['text']) for i in items) + '</ul>'
def table(desc, heads, rows, cls=''):
    if not rows: return ''
    th = ''.join(f'<th>{h}</th>' for h in heads)
    body = ''.join('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>' for r in rows)
    return f'<div class="table-wrap{(" " + cls) if cls else ""}" data-desc="{e(desc)}"><table><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table></div>'
def callout(lbl, text_html): return f'<div class="callout"><span class="lbl">{e(lbl)}</span>{text_html}</div>'
def P(t): return f'<p>{md(t)}</p>'
def B(t): return f'<strong>{md(t)}</strong>'
TAGC = {'Yes': '#38fa79', 'Required': '#fa9938', 'Optional': '#38dafa', 'Partial': '#dafa38', 'Untested': '#fa9938',
        'No': '#fa3899', 'Not needed': '#7938fa', 'Related': '#7938fa', 'Mac only': '#dafa38', 'Windows only': '#dafa38',
        'Required (Mac)': '#fa9938', 'Required (Windows)': '#fa9938'}
def tag(v): return f'<span class="tid" style="--tc:{TAGC.get(v, "#38dafa")}">{e(v)}</span>'
def tid(v): return f'<span class="tid">{e(v)}</span>'
def dt(v): return f'<strong class="dt">{e(v)}</strong>'

# ---------------- sections (fixed skill-sheet order) ----------------
CATS = [('overview', '#38dafa', 'OVERVIEW'), ('usage', '#38fa79', 'USAGE'), ('deps', '#dafa38', 'DEPENDENCIES'),
        ('scope', '#fa9938', 'SCOPE'), ('caveat', '#fa3899', 'GOTCHAS'), ('runtime', '#ea38fa', 'RUNTIME'),
        ('reference', '#7938fa', 'REFERENCE')]
name = C['skill']
S = []   # (cat, title, focus, when, body_html)
S.append(('overview', 'What It Is', 'The skill in plain words and why it exists', 'First look at the skill',
          ''.join(P(p) for p in C.get('what_it_is', [])) + (callout('Why it matters', md(C['why'])) if C.get('why') else '')))
S.append(('overview', 'What It Does', 'Everything the skill produces or handles', 'Checking whether it fits a job',
          ul(C.get('what_it_does', []))))
howto = ''
if C.get('triggers'):
    howto += callout('Ask for it', '<br>'.join(md(t) for t in C['triggers']))
WIN = bool(C.get('how_to_use_windows'))
howto += table('On macOS, step by step' if WIN else 'How to use it, step by step', ['#', 'Topic', 'Step', 'Who'],
               [[str(i), tid(s['topic']), md(s['step']), md(s.get('who', ''))] for i, s in enumerate(C.get('how_to_use', []), 1)], 'no-sort')
howto += table('On Windows, step by step', ['#', 'Topic', 'Step', 'Who'],
               [[str(i), tid(s['topic']), md(s['step']), md(s.get('who', ''))] for i, s in enumerate(C.get('how_to_use_windows', []), 1)], 'no-sort')
S.append(('usage', 'How to Use It', 'What to ask, then each step in order, on macOS and Windows' if WIN else 'What to ask, then each step in order', 'Running the skill', howto))
S.append(('deps', 'Skills It Depends On', 'Other skills it calls or hands off to', 'Installing or sharing the skill',
          table('Skill dependencies', ['Skill', 'Need', 'Why'], [[B(d['name']), tag(d['need']), md(d['why'])] for d in C.get('skills', [])])
          or P('None. This skill works on its own.')))
PWIN = any('install_windows' in d for d in C.get('programs', []))
S.append(('deps', 'Programs It Depends On', 'Software outside Claude and where it runs', 'Setting up a computer for it',
          table('Program dependencies', ['Program', 'Need', 'Where it runs', 'Why'] + (['macOS install / notes', 'Windows install / notes'] if PWIN else ['Install / notes']),
                [[B(d['name']), tag(d['need']), md(d.get('where', '')), md(d.get('why', '')), md(d.get('install', ''))]
                 + ([md(d.get('install_windows', '—'))] if PWIN else []) for d in C.get('programs', [])])
          or P('None outside Claude.')))
S.append(('scope', 'Capabilities and Limitations', 'What it can and cannot do', 'Setting expectations',
          ul(C.get('capabilities', []), 'Capabilities') + ul(C.get('limitations', []), 'Limitations')))
st = C.get('scheduled_tasks', {})
S.append(('runtime', 'Scheduled Tasks', 'Whether it needs or sets up scheduled tasks', 'Planning automation',
          P(st.get('summary', 'None.')) + table('Scheduled tasks', ['Task', 'Schedule', 'What it does'],
          [[B(t['name']), md(t.get('schedule', '')), md(t.get('what', ''))] for t in st.get('tasks', [])])))
S.append(('runtime', 'Where It Runs', 'Which Claude it runs in, plus notes for other AIs', 'Choosing where to run it',
          table('Claude surfaces', ['Where', 'Works', 'Notes'], [[B(r['where']), tag(r['status']), md(r['notes'])] for r in C.get('runs_in', [])])
          + table('Other AIs', ['AI', 'Works', 'Notes'], [[B(r['ai']), tag(r['status']), md(r['notes'])] for r in C.get('other_ais', [])])))
S.append(('caveat', 'Gotchas', 'Traps that cost time, and how to avoid them', 'Something went wrong', ul(C.get('gotchas', []))))
S.append(('reference', 'Other Requirements', 'Accounts, settings, hardware and access it needs', 'Before first use', ul(C.get('requirements', []))))
fresh = [[B('Skill'), f'<code>{e(name)}</code>'],
         [B('Skill last updated'), dt(M.get('skill_updated', '—'))],
         [B('Fingerprint'), f'<code>{e(M.get("fingerprint", "—"))}</code>'],
         [B('Files covered'), md(', '.join(f'`{f}`' for f in M.get('files', [])) or '—')],
         [B('Card written'), dt(M.get('carded', '—'))],
         [B('Status'), f'<span class="tid" style="--tc:{"#38fa79" if M.get("status") == "published" else "#fa9938"}">{"Published" if M.get("status") == "published" else "Draft"}</span>']]
if M.get('zip'): fresh.append([B('Download'), f'<a href="{e(M["zip"])}" target="_blank" rel="noopener">{e(name)}.zip ↗</a>'])
cardsec = (P('This page is built from a skill card. The fingerprint changes whenever any file in the skill changes, so a nightly check can flag this page as out of date.')
           + table('Card and freshness', ['Item', 'Value'], fresh, 'no-sort'))
if C.get('confirm'):
    cardsec += callout('To confirm before publishing', '<br>'.join('● ' + md(x) for x in C['confirm']))
S.append(('reference', 'Card and Freshness', 'Which version of the skill this page describes', 'Checking the page is current', cardsec))

# ---------------- render into the vibe-dashboard template ----------------
s = open(os.path.join(VIBE, 'assets/template.html'), encoding='utf-8').read()
rgb = lambda h: ','.join(str(int(h[i:i+2], 16)) for i in (1, 3, 5))
s = re.sub(r'    --cat-overview:#38dafa;.*?\n    --cat-source:#38fa79;.*?\n', ''.join(f'    --cat-{n}:{c};\n' for n, c, _ in CATS), s, count=1)
blocks = ''.join(f'  .cat-{n} .cat-badge{{color:var(--cat-{n});background:rgba({rgb(c)},.10)}}\n  .cat-{n}{{border-left:3px solid var(--cat-{n})}}\n'
                 f'  .toc-chip.tc-{n}{{border-left-color:var(--cat-{n})}}\n  .toc-chip.tc-{n}:hover{{color:var(--cat-{n})}}\n'
                 f'  .toc-tip.tc-{n} .tip-badge{{color:var(--cat-{n});background:rgba({rgb(c)},.10)}}\n' for n, c, _ in CATS)
a, b = s.index('  /* live defs for the template'), s.index('  .chevron{'); s = s[:a] + blocks + s[b:]
s = re.sub(r"  \.toc-tip\.tc-overview \.tip-badge\{[^\n]*\n  \.toc-tip\.tc-source \.tip-badge\{[^\n]*\n", '', s, count=1)
s = s.replace('</style>', '  .dt{color:var(--text);font-weight:700}\n</style>', 1)
title = C.get('title') or name
s = s.replace('{{PAGE_TITLE}}', e(title) + ' skill').replace('{{KICKER}}', 'SKILL SHEET').replace('{{H1_TITLE}}', e(title))
s = s.replace('{{H1_SUBTITLE}}', md(C.get('summary', '')))
s = s.replace('<span>{{BYLINE_A}}</span>', f'<span>Claude skill · <code>{e(name)}</code></span>')
s = s.replace('<span>{{BYLINE_B}}</span>', f'<span>Skill updated {dt(M.get("skill_updated", "—"))}</span><span>Card {dt(M.get("carded", "—"))}</span>')
s = s.replace('{{MAIL_SUBJECT}}', e(name) + ' skill sheet')
CAT = {n: badge for n, _, badge in CATS}
s = s.replace('{{SUMMARY_BADGE}}', 'OVERVIEW')
s = s.replace('{{SUMMARY_INTRO}}', md(C.get('summary', '')) + ' This page explains what the skill is, how to use it, what it depends on, where it runs, and its gotchas. Terms with a dotted underline jump to the Glossary.')
if C.get('confirm'):
    s = s.replace('{{SUMMARY_CALLOUT_LABEL}}', 'Draft').replace('{{SUMMARY_CALLOUT_TEXT}}', 'This page is a draft awaiting review; see "Card and Freshness" for the open questions.')
else:
    s = re.sub(r'\s*<div class="callout"><span class="lbl">\{\{SUMMARY_CALLOUT_LABEL\}\}</span>\{\{SUMMARY_CALLOUT_TEXT\}\}</div>', '', s)
rows = ''.join(f'<tr><td><span class="secnum">{i+2:02d}</span></td><td><strong>{t}</strong></td><td class="sec-cat"></td><td>{f}</td><td>{w}</td></tr>\n            '
               for i, (_, t, f, w, _) in enumerate(S))
a = s.index('            <tr><td><span class="secnum">02</span></td><td><strong>{{SEC_A_TITLE}}'); b = s.index('            <!-- one row per remaining section -->')
s = s[:a] + '            ' + rows + s[b:]
s = re.sub(r'            <tr><td><span class="secnum" data-target-title="References">.*?</tr>\n', '', s, count=1)
s = s.replace('<div class="section cat-overview" data-title="Dashboard Summary"', '<div class="section cat-overview" data-title="Dashboard Summary"')
content = ''.join(f'  <div class="section cat-{c}" data-title="{t}" data-cat="{c}">\n    <div class="sec-head"><span class="sec-num">{i+2:02d}</span>'
                  f'<span class="sec-title">{t}</span><span class="cat-badge">{CAT[c]}</span><span class="chevron">▶</span></div>\n'
                  f'    <div class="sec-body">\n      {body}\n    </div>\n  </div>\n\n' for i, (c, t, _, _, body) in enumerate(S))
a, b = s.index('  <!-- SECTION PATTERN'), s.index('  <!-- OPTIONAL (include whenever the dashboard uses terms'); s = s[:a] + content + s[b:]
# glossary (Topic column second, coloured per topic in order of first appearance)
PAL = ['#38dafa', '#38fa79', '#dafa38', '#fa9938', '#fa3899', '#ea38fa', '#7938fa', '#3879fa']
tc = {}
for g in C.get('glossary', []): tc.setdefault(g['topic'], PAL[len(tc) % 8])
grows = ''.join(f'<tr data-gterm="{e(re.sub(r"[^a-z0-9]+", "-", g["term"].lower()).strip("-"))}" data-match="{e(g.get("match", ""))}" data-code="{e(g.get("code", ""))}">'
                f'<td><strong>{e(g["term"])}</strong></td><td><span class="tid" style="--tc:{tc[g["topic"]]}">{e(g["topic"])}</span></td>'
                f'<td>{e(g["def"])}</td><td class="gloss-uses"></td><td class="gloss-count"></td></tr>\n            ' for g in C.get('glossary', []))
s = s.replace('<thead><tr><th>Term</th><th>Definition</th><th>Appears in</th><th>Qty</th></tr></thead>',
              '<thead><tr><th>Term</th><th>Topic</th><th>Definition</th><th>Appears in</th><th>Qty</th></tr></thead>')
a, b = s.index('            <tr data-gterm="{{GLOSS_A_ID}}"'), s.index('            <!-- one row per term -->'); s = s[:a] + '            ' + grows + s[b:]
s = s.replace('click it to land on its row.', 'click it to land on its row. Each term\'s <strong>Topic</strong> tag names what it is about, one color per topic.', 1)
s = s.replace("def = row.cells[1].textContent.trim();",
              "def = ([...row.cells].slice(1).find(c => !c.querySelector('.tid') && !c.matches('.gloss-uses,.gloss-count')) || {textContent:''}).textContent.trim();")
GS = """
/* ---- glossary: start sorted by Topic column (asc) ---- */
(function(){
  const gsec = document.querySelector('.section[data-title="Glossary"]'); if(!gsec) return;
  const table = gsec.querySelector('.table-wrap table'); if(!table || !table.tHead) return;
  const ths = [...table.tHead.rows[0].cells];
  const ti = ths.findIndex(th => { const t = th.childNodes[0]; return t && t.nodeType === 3 && t.nodeValue.trim().toUpperCase() === 'TOPIC'; });
  if(ti >= 0) ths[ti].click();
})();
"""
k = s.index('buildFloatingHeaders();', s.index('initSortableTables();')) + len('buildFloatingHeaders();'); s = s[:k] + GS + s[k:]
# drop References; Glossary + Source Document in the "reference" category; verbatim = the skill's SKILL.md
a, b = s.index('  <!-- REQUIRED (when the dashboard cites external sources)'), s.index('  <!-- OPTIONAL verbatim source section'); s = s[:a] + s[b:]
s = s.replace('<div class="section cat-source"', '<div class="section cat-reference"').replace('data-cat="source"', 'data-cat="reference"')
s = s.replace('<span class="cat-badge">Source</span>', '<span class="cat-badge">REFERENCE</span>')
n = len(S) + 1
s = s.replace('<span class="sec-num">97</span>', f'<span class="sec-num">{n+1:02d}</span>').replace('<span class="sec-num">99</span>', f'<span class="sec-num">{n+2:02d}</span>')
s = s.replace('Original reproduced exactly as supplied.', f'The skill\'s own instructions (SKILL.md), reproduced verbatim from the version this page describes.')
s = s.replace('<td>Original source, reproduced verbatim</td><td>Checking the raw source</td>', '<td>The skill\'s SKILL.md, verbatim</td><td>Reading the exact instructions Claude follows</td>')
v = open(os.path.join(SKF, 'SKILL.md'), encoding='utf-8').read().rstrip('\n')
s = s.replace('{{VERBATIM_TEXT}}', v.replace('\\', '\\\\').replace('`', '\\`').replace('${', '\\${'))
s = s.replace("VERBATIM.replace(/\\n/g, '\\n\\n')", 'VERBATIM')
left = sorted(set(re.findall(r'\{\{[A-Z0-9_]+\}\}', s)))
if left: sys.exit('placeholders left: ' + ', '.join(left))
open(OUT, 'w', encoding='utf-8').write(s)

# ---------------- vibe-dashboard patches (extracted from its SKILL.md so they stay current) ----------------
sk = open(os.path.join(VIBE, 'SKILL.md'), encoding='utf-8').read()
blocks = re.findall(r'```python\n(.*?)```', sk, re.S)
pick = lambda test: next(b for b in blocks if test(b))
os.makedirs(WD, exist_ok=True)
open(os.path.join(WD, 'fit_patch.py'), 'w').write(pick(lambda b: 'function bodyWordMin(' in b and 'table-fit patch' in b))
open(os.path.join(WD, 'mindmap_patch.py'), 'w').write(pick(lambda b: '"""mindmap_patch.py' in b))
open(os.path.join(WD, 'stress_audio.py'), 'w').write(pick(lambda b: 'stress_audio.py — run' in b))
for cmd in (['python3', os.path.join(WD, 'fit_patch.py'), OUT], ['python3', os.path.join(VIBE, 'scripts/search_patch.py'), OUT],
            ['python3', os.path.join(WD, 'mindmap_patch.py'), OUT]):
    r = subprocess.run(cmd, capture_output=True, text=True); print(r.stdout.strip() or r.stderr.strip())
    if r.returncode: sys.exit('patch failed: ' + ' '.join(cmd))

# ---------------- narration draft (Claude polishes, audits stress, then records) ----------------
NUM = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen',
       'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty']
nums = {m.group(2): int(m.group(1)) for m in re.finditer(r'<span class="sec-num">(\d+)</span><span class="sec-title">([^<]+)</span>', open(OUT, encoding='utf-8').read())}
say = C.get('spoken', {})
paras = [say.get('_intro', f'This page is the skill sheet for the {name} skill. ' + re.sub(r'[`*]', '', C.get('summary', '')))]
for t, i in sorted(nums.items(), key=lambda x: x[1]):
    default = {'Dashboard Summary': 'A short intro and a table of every section.',
               'Search': 'Type a few words to find anything on this page, in any order and with small typos forgiven. Narrow the results with filters, and click a result to jump to it.',
               'Mind Map': 'The whole page as bubbles you can open, hover for a summary, and click to jump to that spot.',
               'Glossary': 'The terms used on this page, each linked to where it appears.',
               'Source Document (Verbatim)': "The skill's own instructions, word for word."}.get(t, next((f for _, tt, f, _, _ in S if tt == t), ''))
    paras.append(f'Section {NUM[i] if i < len(NUM) else i}, {t.replace("&", "and").replace(" (Verbatim)", ", Verbatim")}. {say.get(t, default).rstrip(".")}.')
open(os.path.join(WD, 'narration-draft.txt'), 'w', encoding='utf-8').write('\n\n'.join(paras) + '\n')
print('built', OUT, '· sections', len(nums), '· narration-draft.txt written')
````