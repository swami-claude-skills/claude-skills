---
name: "skill-dashboard"
description: "Create, update, check and publish a vibe-dashboard skill sheet for one of Swami's own Claude skills from a skill card. Use when Swami wants a skill's dashboard made, updated, checked or published."
---

# Skill Dashboard

Version: 1.0.1

Every one of Swami's own skills (Customize › Skills › Yours) gets a **skill sheet**: a vibe-dashboard page, in a fixed shape, explaining that skill. Each page is rendered from a **skill card**, a JSON file holding the facts about the skill plus a **fingerprint** of its files, so a later check can tell when the skill has changed and its page is out of date.

**Swami vets every page before it goes public.** This skill only ever publishes a *private draft* artifact. Nothing goes to GitHub or the Skill Library until Swami says to publish that skill.

Four modes. Pick from the request:

| Mode | Swami says | Result |
|---|---|---|
| **create** | "make a dashboard for youtube-transcript" | card + private draft artifact |
| **update** | "update the facebook-comments dashboard", or check found it out of date | card refreshed, draft republished to the same URL |
| **check** | "which skill dashboards are out of date?" | table in chat: fresh / out of date / no dashboard yet |
| **publish** | "publish the youtube-comments dashboard" (after vetting) | page + card on GitHub Pages, linked from the Skill Library |

Load the **vibe-dashboard** skill first (Skill tool). This skill depends on it for the template, the patches, the audio, the pronunciation rules and the privacy rules, and it always follows that skill's current version. Where the two differ, this file wins only on the points it states (fixed sections, drafts, no audio refresh button).

## Where things are

- **Skill folders:** `/mnt/skills/plugins/<skill>/` (with `manifest.json` one level up; Swami's own skills have `"source": "plugin"`). In some sessions the synced copy is under `/root/.claude/skills/synced/*/`; use whichever exists. Treat them as read-only.
- **vibe-dashboard folder (VIBE):** the same root, `…/vibe-dashboard/`.
- **Draft:** a private artifact per skill, titled "<Title> skill". It carries `card.txt` (the card) and `narration.txt` as published files, so a later session can rebuild it.
- **Published:** public repo `swami-claude-skills/claude-skills`, folder `dashboards/<skill>/` holding `index.html`, `card.json` and `narration.txt`, plus the registry `dashboards/index.json`. GitHub Pages serves them at `https://swami-claude-skills.github.io/claude-skills/dashboards/<skill>/`. The nightly sync (`gh_sync.py`) only touches `zips/`, the all-skills zip and `README.md`, so `dashboards/` is safe.
- **Skill Library:** the artifact https://claude.ai/artifact/Mg8X9h2EDFMLnsPcG9d2SE, rebuilt nightly by the scheduled task "Skills dashboard nightly refresh" from its published `build.txt` and `template.txt`.

## The skill sheet (format F2)

Fixed sections, always in this order, built by `build_skill_sheet.py` from the card:

01 Dashboard Summary · 02 Search · 03 What It Is · 04 What It Does · 05 How to Use It (macOS, then Windows) · 06 Skills It Depends On · 07 Programs It Depends On · 08 Capabilities and Limitations · 09 Scheduled Tasks · 10 Where It Runs (Claude surfaces, then other AIs) · 11 Gotchas · 12 Other Requirements · 13 Card and Freshness · 14 Mind Map · 15 Glossary · 16 Source Document (Verbatim) = the skill's SKILL.md.

Search, Mind Map, Glossary and the audio overview stay (all from vibe-dashboard). The audio is kept short (about 2½–3 minutes). Skill sheets do **not** get the owner-only audio refresh button: the published copy lives on GitHub Pages, where it can't work, and update mode re-records the audio anyway. So declare no capabilities.

## The skill card

`<skill>.json`. Text fields are plain text; `` `code` `` and `**bold**` are rendered. Lists of `{topic, text}` become list items with topic IDs (1–3 word Title Case topics).

```jsonc
{
  "skill": "youtube-comments",                 // folder name
  "title": "YouTube Comments",                 // page heading
  "summary": "One sentence: what it does.",
  "what_it_is": ["paragraph", "paragraph"],
  "why": "Optional: why the skill exists (a callout).",
  "what_it_does": [{"topic": "", "text": ""}],
  "triggers": ["\"What Swami types to start it\""],
  "how_to_use": [{"topic": "", "step": "", "who": "Swami | Claude | …"}],          // macOS steps
  "how_to_use_windows": [{"topic": "", "step": "", "who": ""}],                 // Windows steps (PowerShell)
  "skills":   [{"name": "", "need": "Required|Optional|Related", "why": ""}],
  "programs": [{"name": "", "need": "Required|Required (Mac)|Required (Windows)|Optional|Mac only|Windows only|Not needed",
                "where": "", "why": "", "install": "macOS notes", "install_windows": "Windows notes"}],
  "capabilities": [{"topic": "", "text": ""}],
  "limitations":  [{"topic": "", "text": ""}],
  "scheduled_tasks": {"summary": "None. …", "tasks": [{"name": "", "schedule": "", "what": ""}]},
  "runs_in":   [{"where": "Claude app, cloud session (web, desktop, mobile)", "status": "Yes|Partial|No|Untested", "notes": ""}],
  "other_ais": [{"ai": "ChatGPT|Gemini|Grok|…", "status": "Yes|Partial|No|Untested", "notes": ""}],
  "gotchas":      [{"topic": "", "text": ""}],
  "requirements": [{"topic": "", "text": ""}],
  "glossary": [{"term": "", "topic": "", "match": "regex", "code": "exact|code", "def": ""}],
  "confirm": ["Open question for Swami (shown only while non-empty)"],
  "spoken": {"_intro": "", "<Section title>": "one or two spoken sentences, no trailing period"},
  "meta": {"card_version": 1, "fingerprint": "sha256:…", "files": ["SKILL.md"],
           "skill_updated": "Sat Oct 3, 2026", "carded": "Sat Nov 7, 2026", "status": "draft|published",
           "zip": "https://github.com/swami-claude-skills/claude-skills/raw/main/zips/<skill>.zip",
           "draft_url": "", "public_url": ""}
}
```

What goes where:
- **Runs in.** Always rate these five rows: Claude app cloud session (web, desktop, mobile); Claude desktop app linked to the Mac; Claude desktop app linked to a Windows PC; Claude mobile app; Claude Code on the Mac. Base each rating on what the skill needs: browser tools (the built-in browser exists only in the desktop app), a linked Mac shell, code execution, uploads, connectors. Use **Untested** when not confirmed.
- **Other AIs.** ChatGPT, Gemini and Grok at least. Use what the Skill Library's install steps say: Claude takes the .zip; Gemini takes the unzipped folder; Grok imports the .zip, or the SKILL.md if refused, and installing by chat drifts; ChatGPT skills need Business, Enterprise, Edu or Healthcare. Then add what the skill needs (code execution, browser, dashboard hand-off needs vibe-dashboard installed there). Default **Untested**.
- **Programs.** Anything outside Claude: CLI tools (yt-dlp, ytx, ffmpeg), apps (Fusion, Terminal, a browser), plus Python in Claude's workspace when the skill runs code. Say where each runs (Swami's Mac or Claude's workspace) and how to install it. If a program people might expect is *not* used, list it as **Not needed**.
- **Windows.** Every card covers macOS and Windows, because the skills are shared with Windows users.
  - Give each program an `install_windows` note: winget or the .exe download, PowerShell instead of Terminal, no `sudo`, SmartScreen instead of Gatekeeper, and `C:\Users\<name>\…` paths.
  - Fill `how_to_use_windows`, and add Windows gotchas (for example one-line PowerShell commands, reopening PowerShell after winget) and requirements (Windows 10 or 11).
  - Tag Mac-only tools **Required (Mac)** or **Mac only**, and give the Windows alternative.
  - If the skill itself has no Windows steps, propose an improvement to that skill (propose_skills) adding an "On Windows" section, so the card still describes the skill as it is. Windows behavior nobody has tried is **Untested**.
- **Scheduled tasks.** Whether the skill needs one, creates one, or is run by one (look through `list_triggers` for task prompts that name the skill).
- **Glossary.** 10–25 terms. Each `match` must hit the page's body text at least once (the build check reports zero-count terms). Start and end each regex with a word character.
- **Spoken.** Follow vibe-dashboard's Pronunciation table. Spell tool names the voice gets wrong: yt-dlp → `why-tee-dee-ell-pee`. Check with the Kokoro tokenizer, and put verb-stress markup (for example `[upload](/ʌplˈoʊd/)`) right in the card, so rebuilds keep it. Sections without an entry fall back to their Focus line.
- **Confirm.** Anything you could not verify from the files, any mismatch with what Swami said, and any staleness you notice in the skill itself (for example a hand-off that predates vibe-dashboard's current rules). Ask Swami about these, and leave them on the draft until he answers.

## create

1. Find the skill folder and read **every** file in it (SKILL.md, scripts, references, assets). Read its manifest entry for `updatedAt` (show it in ET as `Sat Oct 3, 2026`).
2. Copy this skill's `scripts/fingerprint.py` and `scripts/build_skill_sheet.py` to `/home/claude/skill-dashboard/scripts/` (run them with `python3 -B`, so no `__pycache__` lands in a skill folder). Before writing a new card, check the registry `dashboards/index.json` and the artifact list for an existing draft of this skill; update it instead of making a second one. Run `python3 -B scripts/fingerprint.py SKILL_FOLDER` and put its fingerprint and file list in `meta`.
3. Write the card to `/home/claude/skill-dashboard/cards/<skill>.json` from what the files actually say. Check: other skills it loads or hands off to; programs it calls; scheduled tasks; where it can run. Fill `confirm`. Card text must not contain double curly braces (the build stops on them as unfilled placeholders).
4. Build: `python3 scripts/build_skill_sheet.py cards/<skill>.json VIBE SKILL_FOLDER /home/claude/<skill>-skill.html work`. It renders the page, applies vibe-dashboard's table-fit, Search and Mind Map patches, and writes `work/narration-draft.txt` and `work/stress_audio.py`.
5. Audio: copy the draft to `work/narration.txt`, run `python3 work/stress_audio.py VIBE audit work/narration.txt`, and fix any wrong stress *in the card's `spoken` block*. Rebuild (step 4), re-audit until clean, then `python3 work/stress_audio.py VIBE build PAGE work/narration.txt PAGE`. If recording fails, follow vibe-dashboard's "When the recording can't be made".
6. Check in a browser (Playwright):
   - No console warnings other than font loading.
   - Every summary row is linked.
   - No glossary term has a count of 0.
   - Tables fit at 1000 px and 1440 px.
   - Run vibe-dashboard's privacy scan (its "Privacy: people under NDA" list). An excluded person must never appear.
7. Copy the page, card and narration into the scratchpad (or working) directory first: the Artifact tool only publishes files from there. Publish the page as a **new private artifact** (icon from the skill's subject; no capabilities). The publish warns that the page uses `mcp` without declaring it: that is the audio player's unused refresh code, so ignore it. Set `meta.draft_url`, then republish with `files: {"card.txt": {from: card, contentType: "text/plain"}, "narration.txt": {from: work/narration.txt, contentType: "text/plain"}}`.
8. **Skill fixes.** If the `confirm` list proposes changes to the skill itself (staleness, a missing "On Windows" section, a broken step), make the fixed skill folder in a work copy, check it, and zip it as `/mnt/project-files/skill-sheets/<skill>/skill-fixes/<skill>.zip` (or another folder Swami can download from) for him to upload. Note the fixed folder's fingerprint. Once he uploads it and the synced copy matches, rebuild the draft from it.
9. Tell Swami in a few lines: the draft is ready; list the `confirm` questions and any skill-fix zip; ask him to vet it and then say "publish".

## update

1. Find the draft or published page: use `meta.draft_url`, or the registry `dashboards/index.json` in the repo, or list artifacts titled "<Title> skill". Read its `card.txt` (draft) or `dashboards/<skill>/card.json` (published).
2. Re-read the skill's files and re-run the fingerprint. Compare the files with the card and change only what the skill change affects. Keep Swami's edits and answers. Update `meta` (fingerprint, files, skill_updated, carded) and set `status` to `draft`.
3. Rebuild, re-record and check as in create steps 4–6. Republish the draft to the **same** URL (`url` = `meta.draft_url`). Changes to a published page always go through a draft first, then "publish".

## check

Collect the cards: the repo's `dashboards/*/card.json` (clone `swami-claude-skills/claude-skills` read-only), plus any draft `card.txt` files. Then run `python3 -B scripts/fingerprint.py check CARDS_DIR SKILLS_ROOT`. Reply in chat with a table: skill, state (fresh / OUT OF DATE / no dashboard yet / skill missing), status (draft or published), and its link. Offer to update the out-of-date ones.

## publish (only after Swami approves that skill's draft)

1. `confirm` must be empty (fold Swami's answers into the card, rebuild, and re-record if the text changed). Set `meta.status` to `published` and `meta.public_url` to `https://swami-claude-skills.github.io/claude-skills/dashboards/<skill>/`. Rebuild so the page shows "Published".
2. Attach the repo with `add_repo` (owner `swami-claude-skills`, repo `claude-skills`, access `push`). Clone it as that tool says and set the git user to Claude / noreply@anthropic.com.
3. Write `dashboards/<skill>/index.html` (the page), `card.json` and `narration.txt`. Update `dashboards/index.json`: `{"<skill>": {"title", "page": "dashboards/<skill>/", "fingerprint", "skill_updated", "published": "YYYY-MM-DD", "draft_url"}}`, sorted by skill. Make sure `dashboards/.nojekyll` exists (an empty file).
4. Run the privacy scan on every changed file. A hit stops everything.
5. Commit `Skill sheet: <skill>` (end with the session's Co-Authored-By line), push to `main`, and verify `git ls-remote origin main` = `git rev-parse HEAD`. To check the live files, use `https://raw.githubusercontent.com/swami-claude-skills/claude-skills/main/dashboards/<skill>/card.json`: github.io can be blocked from Claude's workspace.
6. **First publish only: GitHub Pages.** Ask Swami to turn it on once: github.com/swami-claude-skills/claude-skills › Settings › Pages › Source "Deploy from a branch" › `main` / `(root)` › Save. Within a few minutes the page appears at the public URL.
7. **First publish only: wire the Skill Library**, so it shows the link and the out-of-date flag nightly with no change to the scheduled task. Read the Library artifact's `build.txt` and `template.txt`, then edit `build.py`:
   - Load `/home/claude/claude-skills/dashboards/index.json` if present; the nightly task already clones the repo there.
   - Add a **Dashboard** cell to each row:
     - a skill with no entry gets `—`;
     - a skill with an entry gets an `open ↗` link to `https://swami-claude-skills.github.io/claude-skills/<page>`, target blank;
     - when the fingerprint of `/mnt/skills/plugins/<skill>` (same algorithm as `fingerprint.py`) differs from the registry, add an orange "out of date" tag (`#fa9938`).
   - Add the matching `<th>Dashboard</th>` to `template.txt`.
   - Rebuild locally to test. Publish the Library to its URL with the same `files` map its nightly task uses, and no capabilities or icon field.
   - Its next nightly run keeps it current.
8. On later publishes, steps 6–7 are already done: the Library shows the link after its next nightly run, or republish it now if Swami wants it sooner.
9. Republish the private draft with the published page and card, so the two match.
10. Tell Swami the public URL and what was committed.

## Rules

- Never publish to GitHub or change the Skill Library without Swami's "publish" for that skill.
- Cards describe the skill as it is. Never invent behavior, results or test outcomes; anything unverified is **Untested** or goes in `confirm`.
- One skill per run unless Swami asks for more.
- An excluded (NDA) person must never appear on a skill sheet, its card, its narration or a commit message. Use vibe-dashboard's privacy rules and scan.
- Glossary `match` regexes use non-capturing groups (`(?:es)?`, never `(es)?`): a capturing group breaks the page's term matcher, and the build stops on one.
- Days, dates and times are bold and bright on the page (`.dt`), bullets are cyan ●, and lists use the Oxford comma, as in vibe-dashboard.

## On Windows

Nothing runs on Swami's computer: every step happens in Claude's workspace, on claude.ai and on GitHub, so the steps are the same on Windows 10 or 11. Swami vets drafts in Edge or Chrome instead of Safari.

## Scripts

- `scripts/fingerprint.py`: content fingerprint of a skill folder (`python3 -B fingerprint.py SKILL_FOLDER`), and freshness checks for skill cards (`python3 -B fingerprint.py check CARDS_DIR SKILLS_ROOT`). The SHA-256 covers every file's relative path and bytes, so it changes when any file in the skill is added, removed or edited, and never otherwise. The Skill Library's `build.py` and artifact-sharing-audit's `scan.py` use the same algorithm; keep them in step if it ever changes.
- `scripts/build_skill_sheet.py`: renders a card as a skill sheet (`python3 -B build_skill_sheet.py CARD.json VIBE_DIR SKILL_FOLDER OUT.html [WORKDIR]`). It fills the vibe-dashboard template with the fixed sections, opens the Program dependencies, Claude surfaces and Other AIs tables sorted by Need and Works, applies vibe-dashboard's table-fit, Search and Mind Map patches (taken from vibe-dashboard's current SKILL.md), inserts the skill's SKILL.md verbatim after the patches (escaped, so a SKILL.md holding HTML or patch markers is safe), saves `stress_audio.py`, and writes `narration-draft.txt`. It does not publish.
