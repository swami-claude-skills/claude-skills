---
name: "youtube-transcript"
description: "Get a YouTube video's transcript, chapters (timestamp links) and optionally comments via Swami's ytx tool, then summarize or build a vibe-dashboard. Use whenever Swami shares a YouTube link and wants its transcript, chapters, summary or dashboard."
---

# YouTube Transcript → Chapters (→ Vibe Dashboard)

Turn a YouTube link into a timestamped transcript, a chapter list where every time is a clickable link, and optionally the full comment tree, then summarize it or build a vibe-dashboard.

## The tool: `ytx` (on Swami's Mac)

Swami has `ytx` installed at `/usr/local/bin/ytx`. It wraps yt-dlp and does all the cleanup.

| Command | Result |
|---|---|
| `ytx URL` | `~/yt/<video-id>/` with `transcript.md`, `transcript.txt`, `chapters.txt`, `*.info.json`, `*.vtt` |
| `ytx -c URL` | the same, plus `comments-threaded.txt` and the comments inside the `.info.json` |
| `ytx -p` | uses the link on the clipboard |
| `ytx -n` | don't open the folder in Finder afterwards |
| `ytx --make-launcher` | (re)creates the Desktop double-click icon |

He also has a Desktop icon, **YouTube Transcript.command**. He copies a video link, double-clicks the icon, answers y/N for comments, and the folder opens.

- `transcript.md`: title, channel, date, length, chapter list, then ~20-second paragraphs grouped under chapter headings. Every `[m:ss]` is a link to `https://youtu.be/<id>?t=<seconds>`.
- `transcript.txt`: the same, plain, with `[m:ss]` stamps.
- `chapters.txt`: `m:ss  title  link` per chapter. It is absent when the video has no chapters.

## Where it runs: pick the first that works

1. **Linked device shell present** (`mcp__remote-devices__device_bash`): run `ytx -n "URL"` (add `-c` if comments were asked for) yourself, then read `~/yt/<id>/transcript.md` and the `.info.json` from there. Swami does nothing.
2. **Otherwise (usual case)**: ask Swami to **copy the link and double-click "YouTube Transcript" on his Desktop** (or run `ytx URL` in Terminal). Then he uploads `transcript.md` plus the `.info.json`, or zips the `~/yt/<id>` folder and uploads it. Give him the exact link to copy. Never send him a multi-line Terminal recipe for this; that is what ytx replaced.
3. **Don't** download from Claude's cloud workspace (its shell can't reach youtube.com), and **don't** use the Claude app's browser for the transcript. In Oct 2026, YouTube refused it there: the transcript panel stays empty, `get_transcript` returns 400, and the caption `baseUrl` fetch returns 0 bytes, even with a 1400px viewport. The browser is fine for chapters and title only (the `engagement-panel-macro-markers-description-chapters` panel), so use it just for that if ytx is unavailable.

## First-time setup (only if `ytx` is missing)

`ytx` needs the standalone yt-dlp at `/usr/local/bin/yt-dlp` (already installed; see the youtube-comments skill for that install). To install ytx, Swami downloads the `ytx` file to Downloads and runs:

```bash
sudo cp ~/Downloads/ytx /usr/local/bin/ytx && sudo chmod a+rx /usr/local/bin/ytx && sudo xattr -d com.apple.quarantine /usr/local/bin/ytx 2>/dev/null; ytx -v && ytx --make-launcher
```

## On Windows: `ytx.ps1`

Windows users run `ytx.ps1`, a PowerShell port of ytx 1.1.0 with the same commands and the same output files, and no Python needed. It needs yt-dlp: `winget install yt-dlp.yt-dlp`, which also installs Deno and FFmpeg.

- **Install once:** save `ytx.ps1` to Downloads, then in PowerShell run `powershell -NoProfile -ExecutionPolicy Bypass -File "$HOME\Downloads\ytx.ps1" -Install`. It copies itself to `%LOCALAPPDATA%\ytx\`, adds a `ytx` command to the user PATH (no execution-policy change), and puts a **YouTube Transcript** icon on the Desktop. Close and reopen PowerShell, then run `ytx -v` (prints `ytx 1.1.0-win`) and `ytx -SelfTest` (every line PASS; it compares its output with the Mac ytx on built-in sample files, offline).
- **Use:** the same as on the Mac. Copy a link and double-click **YouTube Transcript**, or run `ytx URL`, `ytx -c URL`, `ytx -p` (clipboard), or `ytx -n URL` (don't open the folder). Output goes to `%USERPROFILE%\yt\<video-id>\` and opens in File Explorer. `ytx -MakeLauncher` recreates the icon; `ytx -h` shows help.
- **Links containing `&`** (for example `watch?v=…&t=30s`): the `ytx` command runs through a small `.cmd` file, and Windows may cut the link at the `&`. The video ID comes before the `&`, so ytx still gets the right video, but a stray error line may follow. Use the Desktop icon, `ytx -p`, or the youtu.be share link to avoid it.
- **If the self-test shows FAIL,** have them upload the files from the folder it names.
- ytx.ps1 has not been run on a real Windows PC yet; treat the first run as a test.

## Troubleshooting

- **"yt-dlp failed"**: have him run `sudo yt-dlp -U` (YouTube changes break old versions), then retry.
- **"No supported JavaScript runtime" warning**: harmless for captions, chapters and comments.
- **"no English captions found"**: the creator disabled captions, or the video has none yet (new uploads can take hours). Say so; don't guess at content.
- Never suggest `find ~` to locate files: it scans the whole home folder silently for minutes and can stall on macOS privacy prompts. Everything ytx makes is in `~/yt/<video-id>/`.
- Auto-captions have garbled spots and cut-off phrases. Flag any you quote from, and don't treat them as what the speaker actually said.

## Using the output

Read the `.info.json` first for `title`, `channel`, `uploader_id`, `upload_date`, `duration_string`, `description` and `chapters` (`start_time`, `title`). Then read `transcript.md`.

**Whose video it is decides how much text to reproduce.**
- **Swami's own videos** (his channel, or a recording of his Zoom sessions): a full verbatim transcript is fine, including a dashboard Source Document (Verbatim) section.
- **Anyone else's video**: deliver the chapter list with timestamp links plus section-by-section summaries **in your own words**. No full transcript, no verbatim section, and only short quotes where the exact wording matters. Swami keeps the full text in his local `transcript.md`, so say that rather than reproducing it.

### Chat answer (default when he just asks for transcript and chapters)
- Header line: title, channel, date, length.
- One paragraph per chapter: `**[m:ss](https://youtu.be/<id>?t=<s>) Chapter title.**` then a 1–3 sentence summary of what happens. Link times inside summaries the same way.
- If there are no chapters, make your own sections from topic shifts in the transcript and say that you did.
- End by offering the vibe-dashboard.

### Vibe dashboard (when asked)
Load the **vibe-dashboard** skill and follow it exactly. Build with a Python script, never hand-typed. Video-specific mapping:
- Kicker `VIDEO BREAKDOWN`. Byline: channel/creator, then a linked "YouTube · length · date".
- Sections: 01 Dashboard Summary → 02 Video Overview & Chapter Index (a `.resource` card for the video plus a table Time / Chapter / What happens, with the Time cell an external timestamp link) → topic sections grouping related chapters, each with its own category → a "Gotcha/Caveat" section if the video has one → an optional "Takeaways" section that says in its first sentence it is Claude's own analysis → References.
- With comments (`-c`): add the youtube-comments skill's sections (threads attributed to `@handles`, comment permalinks `https://www.youtube.com/watch?v=<id>&lc=<commentid>`).
- Timestamp links are external `target="_blank"` links. That's allowed; only bare `#id` anchors are banned.
- **Section-number brackets:** every in-text link to a section gets ` [NN]` appended, everywhere except the section 01 "What each section covers" table. If the template's `linkSectionRefs` only brackets the opening paragraph, change its `inOpening` test to `!node.parentElement?.closest('.table-wrap[data-desc="What each section covers"]')` and skip the bracket when `[NN]` already follows the text.
- **Category CSS goes after the template's `CATEGORY BLOCKS` comment closes (`*/`).** Inserting your blocks in place of the commented example and dropping the `*/` silently disables every category color (this happened in Oct 2026). Check after building: each `.cat-badge` must compute to its category color, not white.
- Verify headlessly before sending: no console errors other than the sandbox Google Fonts failure, no `{{…}}` left, and the category colors applied.