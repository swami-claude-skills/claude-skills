---
name: "fusion-addin-installer"
description: "Generate double-click installers for an Autodesk Fusion (Fusion 360) Python add-in — install-macos.command, install-windows.cmd and install-windows.ps1 — that copy the add-in folder into Fusion's AddIns directory on macOS or Windows. Use whenever the user asks for an installer, an install script, \"make it installable\", \"how do I install this add-in\", a distributable or shippable Fusion add-in, or a zip someone else can double-click to install; also use when packaging an existing Fusion add-in for another machine or another person. Do NOT use for building the add-in's own code or UI (use fusion-addin-scaffold or fusion-palette-addin), for non-Fusion software installers, or for MSI/PKG/notarized installers."
---

# Fusion add-in installers (macOS + Windows)

Produce three installer files plus a `README.txt` that sit **inside** the add-in folder; the installers install it by double-click.
No admin rights, no system changes, no dependencies.

## What gets produced

```
MyAddIn/
├── MyAddIn.py
├── MyAddIn.manifest
├── install-macos.command     <- macOS: double-click
├── install-windows.cmd       <- Windows: double-click
├── install-windows.ps1       <- does the Windows work; .cmd just launches it
└── README.txt                <- install steps for whoever receives the zip
```

Ship the whole folder zipped. The installers copy everything **except themselves and the README** into
Fusion's AddIns directory, then tell the user how to run it.

## Rules that are not optional

1. **The folder name, the `.py` name and the `.manifest` name must all match exactly.**
   Fusion will not list an add-in whose folder is `MyAddIn` but whose script is `main.py`.
   Set `ADDIN_NAME` in both installers to that shared name.

2. **Destination paths** — these are per-user, so no elevation is needed:
   - macOS: `$HOME/Library/Application Support/Autodesk/Autodesk Fusion 360/API/AddIns`
   - Windows: `%APPDATA%\Autodesk\Autodesk Fusion 360\API\AddIns`

   The folder is still called "Fusion 360" even though the product is now just "Fusion".

3. **The installers must exclude themselves (and `README.txt`) from the copy.** Otherwise each reinstall
   nests another copy, and Fusion tries to parse them.

4. **Also exclude `__pycache__` and `.DS_Store`.** Stale `.pyc` files from a different
   Python version make an add-in fail to load with no useful error.

5. **Wipe the destination before copying** (`rm -rf` / `Remove-Item -Recurse`). Copying
   over the top leaves orphaned files from the previous version — a renamed module keeps
   working from its old copy, and the bug only appears on a clean machine.

6. **Pause before exiting** (`read -r -p` / `Read-Host`). A double-clicked script closes
   its window instantly; without the pause the user never sees success or failure.

## The executable bit — the one that bites

A `.command` file that is not executable does nothing when double-clicked. This survives
`chmod +x` locally and then dies in the zip:

- `zip` (CLI) and macOS Finder's "Compress" preserve the bit.
- **Python's `zipfile` does not.** `z.write(path)` records mode 0o600 and the extracted
  file is not executable.

If packaging with Python, set it explicitly:

```python
import os, stat, zipfile

def add(z, src, arcname):
    zi = zipfile.ZipInfo.from_file(src, arcname)
    mode = os.stat(src).st_mode
    if arcname.endswith('.command') or arcname.endswith('.sh'):
        mode |= stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
    zi.external_attr = (mode & 0xFFFF) << 16
    zi.compress_type = zipfile.ZIP_DEFLATED
    with open(src, 'rb') as f:
        z.writestr(zi, f.read())
```

Then verify, rather than assuming:

```bash
unzip -Z MyAddIn.zip | grep '\.command'      # wants -rwxr-xr-x, not -rw-------
```

Tell the user the recovery if it still arrives non-executable: `chmod +x install-macos.command`.

## Gatekeeper

A `.command` downloaded from the internet is quarantined, and double-clicking shows
"cannot be opened because it is from an unidentified developer". The fix is
**right-click → Open → Open**, once. Put that line in `README.txt` (see below); do not try to work
around it, and do not tell the user to disable Gatekeeper.

## Windows execution policy

`.ps1` files usually will not run on a double-click. The `.cmd` launcher exists solely to
call PowerShell with `-ExecutionPolicy Bypass`, which applies **to that one process only**
and changes nothing on the machine. Never instruct the user to run `Set-ExecutionPolicy`.

## On Windows: extract first, and SmartScreen

Tell the user to right-click the zip › **Extract All…** and run `install-windows.cmd` from the
extracted folder. Double-clicking it inside the zip runs it from a temporary folder, so it
copies the wrong files. If Windows shows "Windows protected your PC" (SmartScreen, for files
downloaded from the internet), the fix is **More info › Run anyway**, once. Put both lines in
the handoff next to the Gatekeeper line; never tell the user to turn SmartScreen off.

---

## install-macos.command

```bash
#!/bin/bash
# Double-click installer for macOS. Copies this add-in into Fusion's AddIns folder.
set -euo pipefail

ADDIN_NAME="MyAddIn"

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST_ROOT="$HOME/Library/Application Support/Autodesk/Autodesk Fusion 360/API/AddIns"
DEST_DIR="$DEST_ROOT/$ADDIN_NAME"

echo "Installing $ADDIN_NAME ..."
echo "  from: $SRC_DIR"
echo "  to:   $DEST_DIR"

if [ ! -d "$DEST_ROOT" ]; then
    echo ""
    echo "AddIns folder not found. Is Fusion installed for this user?"
    echo "Expected: $DEST_ROOT"
    read -r -p "Press Return to close."
    exit 1
fi

rm -rf "$DEST_DIR"
mkdir -p "$DEST_DIR"
cp -R "$SRC_DIR"/. "$DEST_DIR"/
rm -f  "$DEST_DIR"/*.command "$DEST_DIR"/*.ps1 "$DEST_DIR"/*.cmd "$DEST_DIR"/README.txt "$DEST_DIR"/.DS_Store
find "$DEST_DIR" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true

echo ""
echo "Done. In Fusion: Utilities > Add-Ins > Scripts and Add-Ins (Shift+S),"
echo "select \"$ADDIN_NAME\" under Add-Ins, and click Run."
echo ""
echo "Your keyboard shortcut is preserved across reinstalls."
read -r -p "Press Return to close."
```

Mark it executable before packaging: `chmod +x install-macos.command`.

## install-windows.cmd

```bat
@echo off
REM Double-click launcher. Runs the PowerShell installer next to it, bypassing
REM execution policy for this one process only (no system change).
setlocal
set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%install-windows.ps1"
endlocal
```

## install-windows.ps1

```powershell
# PowerShell installer for Windows. Copies this add-in into Fusion's AddIns folder.
$AddinName = "MyAddIn"

$ErrorActionPreference = "Stop"

$SrcDir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$DestRoot = Join-Path $env:APPDATA "Autodesk\Autodesk Fusion 360\API\AddIns"
$DestDir  = Join-Path $DestRoot $AddinName

Write-Host "Installing $AddinName ..."
Write-Host "  from: $SrcDir"
Write-Host "  to:   $DestDir"

if (-not (Test-Path $DestRoot)) {
    Write-Host "AddIns folder not found. Is Fusion installed for this user?" -ForegroundColor Yellow
    Write-Host "Expected: $DestRoot"
    Read-Host "Press Enter to close"
    exit 1
}

if (Test-Path $DestDir) { Remove-Item $DestDir -Recurse -Force }
New-Item -ItemType Directory -Path $DestDir | Out-Null

$exclude = @("install-windows.ps1", "install-windows.cmd", "install-macos.command", "README.txt", "__pycache__", ".DS_Store")
Get-ChildItem -Path $SrcDir -Force | Where-Object { $exclude -notcontains $_.Name } | ForEach-Object {
    Copy-Item $_.FullName -Destination $DestDir -Recurse -Force
}
# The filter above only sees the top level; remove caches from subfolders too (as the macOS installer does).
Get-ChildItem -Path $DestDir -Recurse -Force -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force
Get-ChildItem -Path $DestDir -Recurse -Force -File -Filter ".DS_Store" | Remove-Item -Force

Write-Host ""
Write-Host "Done. In Fusion: Utilities > Add-Ins > Scripts and Add-Ins (Shift+S)," -ForegroundColor Green
Write-Host "select `"$AddinName`" under Add-Ins, and click Run."
Write-Host ""
Write-Host "Your keyboard shortcut is preserved across reinstalls."
Read-Host "Press Enter to close"
```

---

## README.txt

The installers can't explain how to get past Gatekeeper or SmartScreen, because those block
the installer before it runs. So the zip carries a plain-text `README.txt` that travels with it
to whoever receives it. Fill in the name, version and where the button lands; keep it short
and plain (no Markdown), and keep its steps in line with the installers' closing message.

```text
MyAddIn (v1.0.0) - Autodesk Fusion add-in

INSTALL ON macOS
1. Double-click the zip to unzip it.
2. Double-click install-macos.command.
   If macOS says it is from an unidentified developer: right-click it > Open > Open (once).
3. Wait for "Done", then press Return to close the window.

INSTALL ON WINDOWS
1. Right-click the zip > Extract All... (do not run anything from inside the zip).
2. Double-click install-windows.cmd.
   If Windows says "Windows protected your PC": click More info > Run anyway (once).
3. Wait for "Done", then press Enter to close the window.

THEN, IN FUSION
- Utilities > Add-Ins > Scripts and Add-Ins (Shift+S), select MyAddIn under Add-Ins, click Run.
- The button appears in: DESIGN > Utilities > Add-Ins.
- Optional keyboard shortcut: right-click the button > Change Keyboard Shortcut.

UPDATING: unzip the new version and run the installer again; your shortcut and settings stay.
REMOVING: stop the add-in in Scripts and Add-Ins, then delete its folder from
  macOS:   ~/Library/Application Support/Autodesk/Autodesk Fusion 360/API/AddIns/MyAddIn
  Windows: %APPDATA%\Autodesk\Autodesk Fusion 360\API\AddIns\MyAddIn
```

## Customising the closing message

The lines after "Done." are where the add-in explains itself. Add whatever is true of
this particular add-in, for example:

- where its button lands (`"The button lands in the INSPECT panel of every context tab."`)
- that the **Version shown in Scripts and Add-Ins is read at Fusion startup**, so it only
  catches up after a restart — worth saying whenever the add-in shows its own version
  somewhere more current, or the user will report a version mismatch that isn't one
- anything preserved across reinstalls (keyboard shortcuts, saved preferences)

Keep both platforms' messages identical in content. They are read by the same person on
different machines, and a difference reads as a difference in behaviour.

## Packaging checklist

Before handing over the zip:

- [ ] `ADDIN_NAME` in both installers matches the folder, the `.py` and the `.manifest`
- [ ] `install-macos.command` is executable inside the zip (`unzip -Z` to confirm)
- [ ] no `__pycache__`, no `.DS_Store`, no `.pyc` in the archive
- [ ] no zero-byte files (a truncated write is silent and `py_compile` passes on an
      empty file — assert `os.path.getsize(p) > 0` for every entry while zipping)
- [ ] the manifest's `version` matches whatever the add-in reports at runtime
- [ ] `README.txt` is in the zip, names the add-in and version, and states the Gatekeeper
      right-click → Open step for macOS
- [ ] `README.txt` and the handoff say, for Windows, Extract All first and SmartScreen ›
      More info › Run anyway

