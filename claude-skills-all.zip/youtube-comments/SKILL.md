---
name: "youtube-comments"
description: "Get every comment and reply from a YouTube video with yt-dlp, then flatten the .info.json into threads for analysis or a vibe-dashboard. Use whenever Swami wants a video's comments."
---

# YouTube Comments: full extraction

Get the complete comment tree for a YouTube video, with all replies, and turn it into material for analysis or a vibe-dashboard.

Why this matters: YouTube lazy-loads comments and hides replies behind "show more replies". Manual copy-paste on the FORTH video captured 75 of 474 comments (about 16%), with whole reply chains missing and no way to tell. yt-dlp gets everything in one pass, with thread structure intact, no API key, and no video download.

## Where the extraction runs

Claude's cloud workspace usually cannot reach youtube.com, because its shell network is allowlisted. **Swami runs the yt-dlp command on his Mac and uploads the resulting `.info.json`.** Claude then does all the processing. Do not retry the download from the workspace with curl or another route. If a linked device shell (`mcp__remote-devices__device_bash`) is available, run the command there instead, in a per-video folder.

## Step 1: Install yt-dlp (one time, macOS)

Swami's Mac has no Homebrew and only Python 3.9. Use the **standalone `yt-dlp_macos` binary**, which bundles its own interpreter. Do not use the plain `yt-dlp` file, which needs Python 3.10+.

```bash
sudo mkdir -p /usr/local/bin
sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos -o /usr/local/bin/yt-dlp
sudo chmod a+rx /usr/local/bin/yt-dlp
yt-dlp --version
```

- Gatekeeper "unidentified developer" block: `sudo xattr -d com.apple.quarantine /usr/local/bin/yt-dlp`
- Needs macOS 10.15 or newer.
- If it's already installed, check first with `yt-dlp --version`. Update with `sudo yt-dlp -U` if extraction fails, since YouTube changes often break old versions.
- A warning about a missing JavaScript runtime is safe to ignore for a comments-only pull.

## Step 2: Extract

Work in a per-video folder so files don't land loose in the home folder:

```bash
mkdir -p ~/yt/SHORTNAME && cd ~/yt/SHORTNAME
yt-dlp --skip-download --write-comments --write-info-json \
  --extractor-args "youtube:comment_sort=top;max_comments=all,all,all,all,all" \
  "VIDEO_URL"
```

- `--skip-download`: metadata only, no media.
- `comment_sort=top` matches what the YouTube page shows by default. yt-dlp's own default is `new`.
- `max_comments` takes five values: total, parents, replies, replies-per-thread, and depth. **A depth of 1 silently discards every reply.** Always pass `all,all,all,all,all`.
- The run sits quiet for a minute or more while it pages through the thread. That's normal.
- Output is one `TITLE [VIDEOID].info.json` in the current folder, often over 1 MB because it also holds format lists, thumbnails, and similar metadata. Have Swami upload that file.

Give Swami the commands with the real URL and a short folder name already filled in, ready to paste.

## Step 3: Process the uploaded JSON

The `comments` array is flat. Each entry has `id`, `parent` (`"root"` for top-level, otherwise the parent's `id`), `author`, `text`, `like_count`, `timestamp`, `author_is_uploader`, and `is_pinned`. Video fields live at the top level: `title`, `channel`, `view_count`, `like_count`, `upload_date`, `duration_string`, `comment_count`, and `webpage_url`.

Run this to get stats and a threaded text file:

```python
import json, glob, collections
path = glob.glob('/mnt/user-data/uploads/*info*.json')[0]
d = json.load(open(path, encoding='utf-8'))
c = d.get('comments') or []
by = collections.defaultdict(list)
for x in c: by[x['parent']].append(x)
tops = by['root']
print(d['title'], '|', d.get('channel'), '| views', d.get('view_count'), '| uploaded', d.get('upload_date'))
print('page count', d.get('comment_count'), '| extracted', len(c),
      '| top-level', len(tops), '| replies', len(c) - len(tops),
      '| authors', len({x['author'] for x in c}),
      '| uploader replies', sum(x.get('author_is_uploader', False) for x in c))
def thread_likes(t): return t.get('like_count', 0) + sum(r.get('like_count', 0) for r in by[t['id']])
tops.sort(key=thread_likes, reverse=True)
with open('comments-threaded.txt', 'w', encoding='utf-8') as f:
    for i, t in enumerate(tops, 1):
        f.write(f"\n### THREAD {i}  @{t['author']}  ({t.get('like_count',0)} likes)\n{t['text']}\n")
        for r in sorted(by[t['id']], key=lambda z: z.get('timestamp', 0)):
            up = ' [UPLOADER]' if r.get('author_is_uploader') else ''
            f.write(f"    -> @{r['author']}{up}  ({r.get('like_count',0)} likes)\n    {r['text']}\n")
```

Notes:
- The page's comment count rarely matches exactly, because YouTube's counter drifts as comments are held or removed. Report both numbers and don't chase the gap.
- Upload filenames may have had spaces and brackets replaced with underscores. The glob handles that.
- Comment permalink: `https://www.youtube.com/watch?v=VIDEOID&lc=COMMENTID`.
- Read `comments-threaded.txt` in chunks for long threads before deciding on sections.

## Step 4: Hand off

- **Dashboard (the usual goal):** load the `vibe-dashboard` skill and build from the threaded data. Attribute ideas to specific `@handles` throughout rather than paraphrasing anonymously; that is Swami's preference. Group sections by theme, not by comment order. Add a Method/data-provenance section that states the extraction command, counts, and date pulled. Remember vibe-dashboard's rules: replace each category name in all four CSS places, and strip the VERBATIM block and its CSS if unused.
- **Table or sentiment view:** one row per comment with number, @handle linked to the comment permalink, text, likes, and a sentiment tag (positive, humor, mixed, neutral, question, skeptical, negative).
- **Raw export:** send `comments-threaded.txt`, or build a CSV/XLSX with the xlsx skill if asked.

## Fallback when yt-dlp is not an option

Open the video, scroll to comments, and paste this in the browser console (F12). Let it run a few minutes, then select all and copy. Reply nesting gets flattened, so treat the result as partial.

```js
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 400; i++) {
    window.scrollTo(0, document.documentElement.scrollHeight);
    document.querySelectorAll(
      'ytd-continuation-item-renderer #button, #more-replies button, ' +
      'ytd-comment-replies-renderer #more-replies, tp-yt-paper-button#more'
    ).forEach(b => b.click());
    await sleep(1200);
  }
  console.log(document.querySelectorAll('ytd-comment-thread-renderer').length + ' threads loaded');
})();
```