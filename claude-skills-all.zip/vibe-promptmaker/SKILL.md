---
name: "vibe-promptmaker"
description: 'Build a "Vibe Coding" AI Prompt Maker — a single self-contained dark-theme .html tool where Swami fills in fields (basic data, description, web links, etc.) and gets clean plain ASCII text out, ready to paste into an AI prompt. Same locked #0d0d0f/#00e5ff design system as vibe-dashboard: editable Input form, live Output panel, copy-to-clipboard and download (.txt). Fields can be renamed, deleted, drag-reordered, switched between single value and multi-value list, and added. Use this WHENEVER Swami wants a "prompt maker," "promptmaker," "AI prompt maker," a prompt builder or input sheet, a form that outputs text for an AI prompt, or a reusable sheet defining a situation / case / record (a student, client, or someone he''s helping) that will feed an AI prompt. Swami supplies the field names and defaults; Claude fills the field set and header text. To turn CONTENT into a browsable page use vibe-dashboard.'
---

# Vibe Prompt Maker

The prompt maker is the data-entry variant of Swami's vibe world: the exact same locked design
system, reduced to **header → editable Input form → live plain-text Output**. Swami types into the
fields, the text updates live, and he copies it or downloads it as a `.txt` file to paste into an
AI prompt (or anywhere else).

The whole tool is one prebuilt HTML file, `assets/template.html`. Building an instance is almost
entirely **filling the field set and the header text** — do not rewrite the interaction logic,
the CSS, or the design system.

## Division of labor

**Swami supplies:** the field names, which fields should exist by default, any default values,
and which fields are multi-value or long-text. **Claude fills:** the `DEFAULTS` array, the header
kicker/title/subtitle, and the output filename. If Swami hasn't specified defaults, seed sensible
ones from context (e.g. `date` defaulting to today, `teacher/consultant/helper` defaulting to
`Swami`) and tell him they're editable in-app.

## Workflow

1. **Copy the template.** Start from `assets/template.html`. Never build the form from scratch —
   the field editor, drag-reorder, single/multi toggle, autosizing key boxes, live preview, copy,
   download, and single-click reset-with-undo are already built and tested. Keep all of it intact.
2. **Set the field set.** Edit the `DEFAULTS` array (marked `=== FIELD SET ===` in the script).
   One object per field:
   - `key` — the field name (a string; may contain slashes/spaces, e.g. `student/client/other`).
   - `value` — the default value. `''` for empty, a literal string for a preset, or `today()`
     for the current date (recomputed on every load/reset so it's always current).
   - `multi:true` — renders as a multi-value list and outputs as an indented `- ` list (use for
     things like `websites` that may have several entries).
   - `big:true` — renders as a large multi-line textarea (use for the long source
     `content/text` block).
   Fields with an empty value are omitted from the output automatically.
3. **Set the header text.** Replace the three comment-marked placeholders in the header:
   `<!--KICKER-->` (UPPERCASE mono eyebrow, e.g. `AI PROMPT`), `<!--TITLE-->` (default
   `AI Prompt Maker`), and `<!--SUBTITLE-->` (default `enter basic data, description, web links,
   etc. for an AI prompt`). Also set the `<title>` tag.
4. **Save & publish.** Write the file in the working directory (not `/mnt/user-data/outputs/`)
   with a descriptive kebab-case filename (e.g. `ai-prompt-maker.html`), then publish it with the
   Artifact tool. The **Download** button needs the artifact `downloads` capability, because a
   published page can't start a download by itself (blob/data links are blocked). Load the
   artifact-capabilities skill and publish with `capabilities: {downloads: true}`. The template's
   `saveFile()` already uses that capability when published and falls back to a plain browser
   download when the .html is opened locally — keep it intact. Expect one approval prompt for that
   publish — it's legitimate. If Swami only wants the file, skip publishing and send the .html with
   SendUserFile; opened locally, the plain download works. One `.html` file; Google Fonts are the
   only external dependency.

## What the finished tool does (already built — don't reimplement)

Two sections: **01 Input** and **02 Output**. There is no import section and no format switch.

- **Edit field name** — the mono cyan box, auto-sized to its text in `ch` units (never by
  measuring a hidden element, which collapses the labels when the page loads hidden); the value box butts against
  it (colon-joined) and fills the rest of the row. Long-text and multi-value fields put their
  value below the name row.
- **Edit value** — inline for plain fields; a growable list for `multi`; a big textarea for `big`.
- **Reorder** — drag the `⠿` handle.
- **Single ⇄ multi** — the `[ ]` / `[≣]` toggle converts a field between a single string and a
  multi-value list (comma-splits / comma-joins existing content on switch).
- **Delete** — the `✕` on the field row; **+ Add field** appends a new blank field and focuses it.
- **Output** — live plain ASCII text, field names highlighted in the preview only. Format:
  `key: value` per line; multi-value fields as `key:` followed by `  - item` lines; long text as
  `key:` followed by the text block. Empty-valued keys omitted. Non-ASCII characters are converted
  (smart quotes → straight quotes, dashes → `-`, `…` → `...`, accents stripped; anything else → `?`).
- **Copy** and **Download .txt** (filename derives from the `subject` field, falling back to
  `prompt`) in both the sticky toolbar and the output panel.
- **Reset to defaults** — single click restores the `DEFAULTS` (with a 4-second **Undo**). Note:
  `confirm()`/`alert()` are blocked in the artifact sandbox — never reintroduce them; use the
  in-button arm/undo pattern that's already there.
- **Both sections start collapsed**; clicking a section header toggles it.

## The locked design system — identical to vibe-dashboard, DO NOT deviate

**Palette** (`:root`): `--bg:#0d0d0f` · `--panel:#141418` · `--panel-2:#1a1a20` ·
`--cyan:#00e5ff` (accent, INPUT section) · `--green:#00ff88` (OUTPUT / confirm) ·
`--amber:#ffb020` · `--pink:#ff5c7a` (delete) · `--text:#e8e8ec` · `--text-dim:#9aa0aa` ·
`--text-mute:#6a6f78` · `--border:#26262e`.

**Fonts:** JetBrains Mono (`--mono`, labels/nums/keys/output) + DM Sans (`--sans`, body), from
Google Fonts.

**Non-negotiables** (prebuilt in the template — keep intact):
- **Header kicker is REQUIRED** — the `.kicker` UPPERCASE mono eyebrow above the H1. Never blank.
- **Footer text is exactly** `Vibe Coding: Swami · AI: Claude`, with Swami as the runtime-assembled
  mailto link (`'swami.human' + '@' + 'gmail.com'`) — never hard-code the address in an `href`. The
  email subject follows the page's `<title>` (the part before " — ").
- **No browser storage** (`localStorage`/`sessionStorage`) — state lives in the in-memory
  `fields` array only. Do not add storage.

## On Windows

Nothing changes for building: Claude fills the template in its own workspace, and the page runs in any
current browser (Edge, Chrome or Firefox on Windows 10 or 11). For people using it on Windows:
- **Copy** pastes with Ctrl+V.
- **Download .txt** on the published page asks where to save. Opened from disk as a .html file, it
  saves to the Downloads folder (`C:\Users\<name>\Downloads`).
- The .txt uses plain line endings; Notepad on Windows 10 (version 1809 or later) and Windows 11
  shows them correctly.
- Untested on Windows: drag-reorder and the downloads prompt in the Claude desktop app.

## Default field set

The template ships with Swami's field set already in place: `subject`, `topic`, `issue`, `date`
(defaults to today), `student/client/other`, `teacher/consultant/helper` (defaults to `Swami`),
`ai used`, `websites` (multi-value), `content/text` (big). Reuse it as-is when the request
matches; otherwise swap in the fields Swami asks for.
