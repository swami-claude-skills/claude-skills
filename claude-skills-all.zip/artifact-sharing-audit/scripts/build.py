#!/usr/bin/env python3
"""build.py — render Swami's private "Skill Maintenance" vibe dashboard.

usage: python3 build.py VIBE_DIR SHARING.json ISSUES.json KNOWN.json REGISTRY.json OUT.html [WORKDIR]

SHARING   pages tied to the skills, how each is shared now and should be, plus a history (written by artifact-sharing-audit)
ISSUES    output of scan.py (mechanical checks over the skills)
KNOWN     hand-kept items the scan cannot find
REGISTRY  claude-skills repo dashboards/index.json (the public skill sheets on GitHub Pages)

Fills the vibe-dashboard template, then applies its table-fit, Search and Mind Map patches (extracted from
vibe-dashboard's SKILL.md so they match the current skill). Audio is added afterwards with stress_audio.py.
"""
import html, json, os, re, subprocess, sys

VIBE, SH, IS, KN, RG, OUT = sys.argv[1:7]
WD = sys.argv[7] if len(sys.argv) > 7 else os.path.dirname(os.path.abspath(OUT))
sh, iss, known = (json.load(open(p, encoding='utf-8')) for p in (SH, IS, KN))
reg = json.load(open(RG, encoding='utf-8')) if os.path.exists(RG) else {}
e = html.escape

def md(t):
    t = e(str(t)); t = re.sub(r'`([^`]+)`', r'<code>\1</code>', t)
    return re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', t)
def li(topic, text): return f'<li><span class="tid">{e(topic)}</span>{text}</li>'
def table(desc, heads, rows, cls=''):
    th = ''.join(f'<th>{h}</th>' for h in heads)
    body = ''.join('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>' for r in rows)
    return f'<div class="table-wrap{(" " + cls) if cls else ""}" data-desc="{e(desc)}"><table><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table></div>'
def callout(lbl, h): return f'<div class="callout"><span class="lbl">{e(lbl)}</span>{h}</div>'
TAGC = {'High': '#fa3899', 'Medium': '#fa9938', 'Low': '#38dafa', 'OK': '#38fa79', 'Change': '#fa3899',
        'Public': '#dafa38', 'Private': '#7938fa', 'Open': '#fa9938', 'Check': '#dafa38', 'Fixed': '#38fa79'}
def tag(v): return f'<span class="tid" style="--tc:{TAGC.get(v, "#38dafa")}">{e(v)}</span>'
def tid(v): return f'<span class="tid">{e(v)}</span>'
def dt(v): return f'<strong class="dt">{e(v)}</strong>'
def link(u): return f'<a href="{e(u)}" target="_blank" rel="noopener">open ↗</a>' if u else '—'

# ---------------- data ----------------
pages = list(sh['pages'])
for k, r in sorted(reg.items()):   # public skill sheets on GitHub Pages: public by design
    pages.insert(2, {'title': f'{r["title"]} skill sheet', 'url': 'https://swami-claude-skills.github.io/claude-skills/' + r['page'],
                     'kind': 'Skill sheet', 'now': 'Public', 'should': 'Public', 'why': f'Published on GitHub Pages {r.get("published", "")}.'})
for p in pages:
    p.setdefault('url', f'https://claude.ai/artifact/{p["id"]}' if p.get('id') else '')
    p['status'] = 'OK' if p['now'] == p['should'] else 'Change'
todo = [p for p in pages if p['status'] == 'Change']
issues = iss['issues']
cnt = {k: sum(1 for i in issues if i['severity'] == k) for k in ('High', 'Medium', 'Low')}
scanned = iss['scanned'][:10]
import datetime
scanned_h = datetime.date.fromisoformat(scanned).strftime('%a %b %-d, %Y')
from zoneinfo import ZoneInfo
ET = ZoneInfo('America/New_York')
TRIGGER = 'trig_01Buvs57icQxnrJwQNqMmYuM'   # "Skill Maintenance update" scheduled task (on demand), fired by the Update now button
def et(d): return d.astimezone(ET).strftime('%a %b %-d, %Y, %-I:%M %p ET')
try: scanned_t = et(datetime.datetime.fromisoformat(iss['scanned']))
except Exception: scanned_t = scanned_h
built_dt = datetime.datetime.now(datetime.timezone.utc); built_t, built_iso = et(built_dt), built_dt.astimezone(ET).isoformat(timespec='seconds')
last_h = sh['history'][-1] if sh.get('history') else None
open_known = [k for k in known if k['status'] != 'Fixed']

STRIP = (f'<div class="stat-bar" id="updBar">'
         f'<span class="st"><span class="st-k">Sharing checked</span>{dt(sh["checked"])}</span>'
         f'<span class="st"><span class="st-k">Skills scanned</span>{dt(scanned_t)}</span>'
         + (f'<span class="st"><span class="st-k">Last change found</span>{dt(last_h["date"])}<span class="st-sub">{e(last_h["page"])}</span></span>' if last_h else '')
         + f'<span class="st"><span class="st-k">Page built</span>{dt(built_t)}</span>'
         '<button class="sk-btn go" id="updNow" type="button" hidden title="Run a fresh check of sharing and the skills, then rebuild this page. Only you see this button.">⟳ Update now</button>'
         '<span class="upd-note" id="updNote" hidden></span></div>'
         '<div class="upd-panel" id="updPanel" hidden role="dialog" aria-label="Start an update">'
         '<div class="upd-ph">Update now: choose the page-check model</div>'
         '<label class="upd-opt"><input type="radio" name="updModel" value="haiku" checked> <strong>Haiku</strong> <span>default · fewest tokens · reads each page\'s sharing</span></label>'
         '<label class="upd-opt"><input type="radio" name="updModel" value="sonnet"> <strong>Sonnet</strong> <span>more tokens · use if a Haiku run marks a page \u201ccouldn\'t read\u201d</span></label>'
         '<div class="upd-pnote">The rest of the update (scan, rebuild, audio, publish) runs on Sonnet. It takes about 5\u201310 minutes; your phone is notified only if a page needs changing or the run fails. Your choice is remembered in this browser.</div>'
         '<div class="upd-pbtns"><button class="sk-btn go" id="updGo" type="button">Start update</button><button class="sk-btn" id="updCancel" type="button">Cancel</button></div></div>'
         '<div class="upd-line" id="updLine" hidden></div>')
# ---------------- sections ----------------
CATS = [('overview', '#38dafa', 'OVERVIEW'), ('sharing', '#38fa79', 'SHARING'), ('issues', '#dafa38', 'ISSUES'),
        ('known', '#fa9938', 'KNOWN'), ('process', '#fa3899', 'PROCESS'), ('reference', '#7938fa', 'REFERENCE')]
S = []
sharing = (f'<p>Every page tied to the skills, how it is shared now, and how it should be. Last checked {dt(sh["checked"])}: '
           f'<strong>{len(pages) - len(todo)}</strong> of <strong>{len(pages)}</strong> match.</p>')
if todo:
    sharing += callout('Pages to change', '<br>'.join(f'● <strong>{e(p["title"])}</strong>: {md(p["why"])}' for p in todo)
                       + '<br>To change one, open it, choose <strong>Share</strong>, then pick Private.')
sharing += f'<div class="callout upd-callout"><span class="lbl">Update now and check log</span>{STRIP}</div>'
sharing += table('Sharing status of each page', ['Page', 'Kind', 'Shared now', 'Should be', 'Status', 'Why', 'Link'],
                 [[f'<strong>{e(p["title"])}</strong>', tid(p['kind']), tag(p['now']), tag(p['should']), tag(p['status']), md(p['why']), link(p['url'])]
                  for p in sorted(pages, key=lambda p: (p['status'] == 'OK', p['kind'], p['title']))])
sharing += table('Sharing history', ['Date', 'Page', 'Change'], [[dt(h['date']), f'<strong>{e(h["page"])}</strong>', md(h['change'])] for h in sh['history']])
S.append(('sharing', 'Sharing Status', 'Who can open each skill page, and what to change', 'Before sharing a link, or after a check', sharing))

S.append(('issues', 'Issues &amp; Gaps', 'Problems found in the skills by the last scan', 'Choosing what to fix next',
          f'<p>Found by a scan of all <strong>{iss["skills"]}</strong> of your skills on {dt(scanned_h)}: '
          f'<strong>{cnt["High"]}</strong> high, <strong>{cnt["Medium"]}</strong> medium and <strong>{cnt["Low"]}</strong> low. '
          'High means two rules for one job or broken output; medium means out of date but harmless; low is tidying.</p>'
          + table('Issues found by the scan', ['Severity', 'Skill', 'Check', 'Finding', 'Fix'],
                  [[tag(i['severity']), f'<strong>{e(i["skill"])}</strong>', tid(i['check']), md(i['finding']), md(i['fix'])] for i in issues])))

S.append(('known', 'Known Items', 'Problems the scan cannot detect, kept by hand', 'Reviewing open work',
          f'<p><strong>{len(open_known)}</strong> open or to check. These need judgment, so they are added and closed by hand.</p>'
          + table('Hand-kept items', ['Item', 'Skill', 'Status', 'What to do'],
                  [[f'<strong>{e(k["item"])}</strong>', md(k['skill']), tag(k['status']), md(k['fix'])] for k in known])))

S.append(('process', 'How It Refreshes', 'How this page stays current', 'Asking for a new check',
          '<ul>' + li('Update now', 'Only you see the <strong>Update now</strong> button, in the <strong>Update now and check log</strong> callout of Sharing Status. It starts your on-demand scheduled task, which reads each page\'s sharing, reruns the scan and rebuilds this page in about 5–10 minutes. Choose the page-check model when you click it: <strong>Haiku</strong> (default, fewest tokens) or <strong>Sonnet</strong>.')
          + li('Ask', 'You can also say <strong>"check skill sharing"</strong> or <strong>"refresh skill maintenance"</strong> in a chat; the artifact-sharing-audit skill does the same steps.')
          + li('Sharing', 'Only a fresh read of each page shows how it is shared, so the check never guesses from titles or old results.')
          + li('Scan', 'A script checks every skill for old tool names, old save locations, dashboard steps older than vibe-dashboard, missing skills, stray files, version lines, size and out-of-date skill sheets.')
          + li('Privacy', 'The page stays private. People under NDA are never named here.')
          + li('Changes', 'Claude cannot change sharing. You change it from each page\'s Share menu, then ask for a re-check.') + '</ul>'))

# ---------------- render ----------------
s = open(os.path.join(VIBE, 'assets/template.html'), encoding='utf-8').read()
rgb = lambda h: ','.join(str(int(h[i:i+2], 16)) for i in (1, 3, 5))
s = re.sub(r'    --cat-overview:#38dafa;.*?\n    --cat-source:#38fa79;.*?\n', ''.join(f'    --cat-{n}:{c};\n' for n, c, _ in CATS), s, count=1)
blocks = ''.join(f'  .cat-{n} .cat-badge{{color:var(--cat-{n});background:rgba({rgb(c)},.10)}}\n  .cat-{n}{{border-left:3px solid var(--cat-{n})}}\n'
                 f'  .toc-chip.tc-{n}{{border-left-color:var(--cat-{n})}}\n  .toc-chip.tc-{n}:hover{{color:var(--cat-{n})}}\n'
                 f'  .toc-tip.tc-{n} .tip-badge{{color:var(--cat-{n});background:rgba({rgb(c)},.10)}}\n' for n, c, _ in CATS)
a, b = s.index('  /* live defs for the template'), s.index('  .chevron{'); s = s[:a] + blocks + s[b:]
s = re.sub(r"  \.toc-tip\.tc-overview \.tip-badge\{[^\n]*\n  \.toc-tip\.tc-source \.tip-badge\{[^\n]*\n", '', s, count=1)
s = s.replace('</style>', '  .dt{color:var(--text);font-weight:700}\n</style>', 1)
s = s.replace('{{PAGE_TITLE}}', 'Skill Maintenance').replace('{{KICKER}}', 'SKILL MAINTENANCE').replace('{{H1_TITLE}}', 'Skill Maintenance')
s = s.replace('{{H1_SUBTITLE}}', 'Sharing status of every skill page, and the problems found in the skills, updated when you click Update now.')
s = s.replace('<span>{{BYLINE_A}}</span>', '<span>Private · for Swami</span>')
s = s.replace('<span>{{BYLINE_B}}</span>', f'<span>Sharing checked {dt(sh["checked"])}</span><span>Skills scanned {dt(scanned_h)}</span>')
s = s.replace('{{MAIL_SUBJECT}}', 'Skill Maintenance')
CAT = {n: badge for n, _, badge in CATS}
s = s.replace('{{SUMMARY_BADGE}}', 'OVERVIEW')
s = s.replace('{{SUMMARY_INTRO}}', 'This page tracks two things about your skills: who can open each page tied to them, and what needs fixing in the skills themselves. Terms with a dotted underline jump to the Glossary.')
s = s.replace('{{SUMMARY_CALLOUT_LABEL}}', 'Right now').replace('{{SUMMARY_CALLOUT_TEXT}}',
    f'<strong>{len(todo)}</strong> page{"s" if len(todo) != 1 else ""} to set Private, <strong>{cnt["High"]}</strong> high issues, and <strong>{len(open_known)}</strong> hand-kept items open.')
UPD_CSS = """  /* status strip + owner-only Update now (fires the on-demand scheduled task) */
  .upd-callout .stat-bar{margin-top:6px}
  .stat-bar{display:flex;flex-wrap:wrap;align-items:center;gap:6px 22px;margin:12px 0 4px;padding:9px 14px;border:1px solid var(--border);border-radius:8px;background:var(--panel-2);font-size:13.5px}
  .stat-bar .st{display:inline-flex;flex-wrap:wrap;align-items:baseline;gap:0 7px;min-width:0}
  .stat-bar .st strong.dt{white-space:nowrap}
  .stat-bar .st-k{font-family:var(--mono);font-size:10px;letter-spacing:1.2px;text-transform:uppercase;color:var(--text-mute)}
  .stat-bar .st-sub{font-family:var(--mono);font-size:11px;color:var(--text-mute)}
  .stat-bar #updNow{margin-left:auto}
  .stat-bar .upd-note{flex-basis:100%;font-family:var(--mono);font-size:11px;color:var(--text-mute)}
  .sk-btn{font-family:var(--mono);font-size:11.5px;letter-spacing:.4px;color:var(--text-dim);background:var(--panel);border:1px solid var(--border);border-radius:6px;padding:6px 11px;cursor:pointer}
  .sk-btn:hover:not(:disabled){border-color:var(--cyan);color:var(--cyan)}
  .sk-btn.go{color:var(--green);border-color:rgba(0,255,136,.45)}
  .sk-btn:disabled{opacity:.4;cursor:not-allowed}
  .sk-btn[hidden],.upd-panel[hidden],.upd-line[hidden],.upd-note[hidden]{display:none}
  .upd-panel{margin:8px 0 4px;padding:12px 14px;border:1px solid rgba(0,255,136,.45);border-radius:8px;background:var(--panel-2);display:flex;flex-direction:column;gap:8px}
  .upd-ph{font-family:var(--mono);font-size:10.5px;letter-spacing:1.5px;text-transform:uppercase;color:var(--green)}
  .upd-opt{display:flex;flex-wrap:wrap;align-items:baseline;gap:4px 8px;font-size:13.5px;color:var(--text);cursor:pointer}
  .upd-opt input{accent-color:var(--green)}
  .upd-opt span{font-family:var(--mono);font-size:11px;color:var(--text-mute)}
  .upd-pnote{font-size:12.5px;color:var(--text-dim)}
  .upd-pbtns{display:flex;gap:8px;flex-wrap:wrap}
  .upd-line{font-family:var(--mono);font-size:12px;line-height:1.55;margin:8px 2px 0;padding:6px 10px;border-radius:6px;border:1px solid var(--border)}
  .upd-line strong.dt{color:var(--text)}
  .upd-line.run{color:#dafa38;border-color:rgba(218,250,56,.45);background:rgba(218,250,56,.06);animation:upd-pulse 2.4s ease-in-out infinite}
  .upd-line.ok{color:#38fa79;border-color:rgba(56,250,121,.45);background:rgba(56,250,121,.06)}
  .upd-line.err{color:#fa3838;border-color:rgba(250,56,56,.5);background:rgba(250,56,56,.07)}
  @keyframes upd-pulse{0%,100%{opacity:1}50%{opacity:.45}}
  @media (prefers-reduced-motion:reduce){.upd-line.run{animation:none}}
"""
UPD_JS = """<script>
/* ===== Update now (owner only): fires the on-demand "Skill Maintenance update" scheduled task
   through the Claude Code Remote connector, passing the chosen page-check model in the run text.
   Progress is read back on reload: a build newer than the request means it finished. ===== */
(() => {
  const TRIGGER = '@TRIGGER@', BUILT = new Date('@BUILT_ISO@'), KEY = 'skillMaintUpdateRequested', MKEY = 'skillMaintModel';
  const $ = id => document.getElementById(id);
  const fmt = (d, o) => d.toLocaleString('en-US', Object.assign({timeZone: 'America/New_York'}, o));
  const when = d => fmt(d, {weekday: 'short'}) + ' ' + fmt(d, {month: 'short', day: 'numeric'}) + ', ' + fmt(d, {hour: 'numeric', minute: '2-digit'}) + ' ET';
  const ls = { get(k){ try { return localStorage.getItem(k); } catch (e) { return null; } },
               set(k, v){ try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch (e) {} } };
  const line = (cls, html) => { const l = $('updLine'); if (!l) return; l.hidden = !html; l.className = 'upd-line' + (cls ? ' ' + cls : ''); l.innerHTML = html || ''; };
  function showState(){
    const r = ls.get(KEY); if (!r) return;
    const req = new Date(r); if (isNaN(req)) { ls.set(KEY, null); return; }
    const mins = (Date.now() - req) / 60000, m = ls.get(MKEY) || 'haiku';
    if (BUILT > req) line('ok', 'Update finished: page rebuilt <strong class="dt">' + when(BUILT) + '</strong> (requested <strong class="dt">' + when(req) + '</strong>, page checks on ' + (m === 'sonnet' ? 'Sonnet' : 'Haiku') + ').');
    else if (mins < 25) line('run', 'Updating… requested <strong class="dt">' + when(req) + '</strong>. It takes about 5–10 minutes; reload this page then.');
    else line('err', 'No new build since the request at <strong class="dt">' + when(req) + '</strong>. Check the notification on your phone, or ask Claude to look at the Skill Maintenance update task.');
    if (BUILT > req && mins > 1440) ls.set(KEY, null);
  }
  (async () => {
    let user = null, owner = false;
    try { user = (window.claude && claude.use) ? await claude.use('user') : null; } catch (e) {}
    try { owner = !!(user && await user.isOwner()); } catch (e) {}
    if (!owner) return;
    const btn = $('updNow'), panel = $('updPanel'); btn.hidden = false; showState();
    const saved = ls.get(MKEY); if (saved) { const r = document.querySelector('input[name="updModel"][value="' + saved + '"]'); if (r) r.checked = true; }
    let mcp = null; try { mcp = await claude.use('mcp'); } catch (e) {}
    if (!mcp) { btn.disabled = true; $('updNote').hidden = false;
      $('updNote').textContent = 'Only you see this. Update now works when this page is opened inside Claude (claude.ai or the Claude app), where it can run your scheduled task.'; return; }
    btn.addEventListener('click', () => { panel.hidden = !panel.hidden; if (!panel.hidden) $('updGo').focus(); });
    $('updCancel').addEventListener('click', () => { panel.hidden = true; btn.focus(); });
    $('updGo').addEventListener('click', async () => {
      const m = (document.querySelector('input[name="updModel"]:checked') || {}).value === 'sonnet' ? 'sonnet' : 'haiku';
      ls.set(MKEY, m); panel.hidden = true; btn.disabled = true; $('updGo').disabled = true;
      const req = new Date(); line('run', 'Starting the update…');
      try {
        await mcp.callTool('Claude Code Remote', 'fire_trigger', {trigger_id: TRIGGER, text: 'Started from the dashboard’s Update now button. Page-check model: ' + m}, {cache: false});
        ls.set(KEY, req.toISOString()); showState();
      } catch (err) {
        btn.disabled = false; $('updGo').disabled = false; const c = err && err.code;
        line('err', c === 'not_granted' || c === 'consent_required' || c === 'approval_required' ? 'Not allowed: allow the Claude Code Remote connector for this page, then try again.'
          : c === 'needs_reauth' || c === 'server_not_connected' ? 'Connect “Claude Code Remote” in claude.ai Settings › Connectors, then try again.'
          : c === 'blocked_by_policy' ? 'Starting scheduled tasks from a page is blocked here. Ask Claude to run the update instead.'
          : c === 'tool_error' ? 'The update task could not be started (it may be turned off or deleted). Ask Claude to check it.'
          : 'Could not start the update (' + (c || 'error') + '). Try again later.');
      }
    });
  })();
})();
</script>
"""
s = s.replace('</style>', UPD_CSS + '</style>', 1)
k = s.rindex('</body>'); s = s[:k] + UPD_JS.replace('@TRIGGER@', TRIGGER).replace('@BUILT_ISO@', built_iso) + s[k:]
rows = ''.join(f'<tr><td><span class="secnum">{i+2:02d}</span></td><td><strong>{t}</strong></td><td class="sec-cat"></td><td>{f}</td><td>{w}</td></tr>\n            '
               for i, (_, t, f, w, _) in enumerate(S))
a = s.index('            <tr><td><span class="secnum">02</span></td><td><strong>{{SEC_A_TITLE}}'); b = s.index('            <!-- one row per remaining section -->')
s = s[:a] + '            ' + rows + s[b:]
s = re.sub(r'            <tr><td><span class="secnum" data-target-title="References">.*?</tr>\n', '', s, count=1)
s = re.sub(r'            <tr><td><span class="secnum" data-target-title="Source Document \(Verbatim\)">.*?</tr>\n', '', s, count=1)
content = ''.join(f'  <div class="section cat-{c}" data-title="{t}" data-cat="{c}">\n    <div class="sec-head"><span class="sec-num">{i+2:02d}</span>'
                  f'<span class="sec-title">{t}</span><span class="cat-badge">{CAT[c]}</span><span class="chevron">▶</span></div>\n'
                  f'    <div class="sec-body">\n      {body}\n    </div>\n  </div>\n\n' for i, (c, t, _, _, body) in enumerate(S))
a, b = s.index('  <!-- SECTION PATTERN'), s.index('  <!-- OPTIONAL (include whenever the dashboard uses terms'); s = s[:a] + content + s[b:]
GL = [('Sharing state', 'Sharing', r'sharing state|shared|Share menu', '', 'Who can open a claude.ai page: Private (only you), anyone with the link, or named people by email invite.'),
      ('Public', 'Sharing', r'Public', '', 'Anyone with the link can open the page, or it is published on GitHub Pages.'),
      ('Private', 'Sharing', r'Private', '', 'Only you can open the page.'),
      ('Draft', 'Sharing', r'drafts?', '', 'A private skill-sheet page where changes are checked before the public copy on GitHub Pages is updated.'),
      ('GitHub Pages', 'Sharing', r'GitHub Pages', '', 'The free web hosting for the public claude-skills repository, where the published skill sheets live.'),
      ('NDA', 'Sharing', r'NDA', '', 'A non-disclosure agreement; people under one are never named on a shared or published page.'),
      ('Skill sheet', 'Skills', r'skill sheets?', '', 'A dashboard explaining one of your skills, made by the skill-dashboard skill.'),
      ('Skill Library', 'Skills', r'Skill Library', '', 'Your public page listing every skill with downloads, rebuilt nightly.'),
      ('Scan', 'Checks', r'scan|scans', 'scan.py', 'The script that checks every skill for known kinds of problems in the same way each time.'),
      ('Severity', 'Checks', r'severity|high|medium|low', '', 'How much an issue matters: high, medium or low.'),
      ('Fingerprint', 'Checks', r'fingerprints?|out-of-date|out of date', '', 'A short code computed from every file in a skill; when it changes, the skill sheet is out of date.'),
      ('Stray files', 'Checks', r'stray files?|cache files?', '__pycache__', 'Leftover cache files that ship inside a skill but do nothing.'),
      ('artifact-sharing-audit', 'Skills', r'artifact-sharing-audit', '', 'The skill that checks sharing and refreshes this page.'),
      ('vibe-dashboard', 'Skills', r'vibe-dashboard', '', 'The skill that defines the design and parts of every dashboard, including this one.')]
tc, PAL = {}, ['#38dafa', '#38fa79', '#dafa38', '#fa9938', '#fa3899', '#ea38fa', '#7938fa', '#3879fa']
for g in GL: tc.setdefault(g[1], PAL[len(tc)])
grows = ''.join(f'<tr data-gterm="{re.sub(r"[^a-z0-9]+", "-", t.lower()).strip("-")}" data-match="{e(m)}" data-code="{e(c)}"><td><strong>{e(t)}</strong></td>'
                f'<td><span class="tid" style="--tc:{tc[tp]}">{e(tp)}</span></td><td>{e(d)}</td><td class="gloss-uses"></td><td class="gloss-count"></td></tr>\n            '
                for t, tp, m, c, d in GL)
s = s.replace('<thead><tr><th>Term</th><th>Definition</th><th>Appears in</th><th>Qty</th></tr></thead>',
              '<thead><tr><th>Term</th><th>Topic</th><th>Definition</th><th>Appears in</th><th>Qty</th></tr></thead>')
a, b = s.index('            <tr data-gterm="{{GLOSS_A_ID}}"'), s.index('            <!-- one row per term -->'); s = s[:a] + '            ' + grows + s[b:]
s = s.replace('click it to land on its row.', 'click it to land on its row. Each term\'s <strong>Topic</strong> tag names what it is about, one color per topic.', 1)
s = s.replace("def = row.cells[1].textContent.trim();",
              "def = ([...row.cells].slice(1).find(c => !c.querySelector('.tid') && !c.matches('.gloss-uses,.gloss-count')) || {textContent:''}).textContent.trim();")
GS = """
/* ---- glossary: start sorted by Topic column (asc) ---- */
(function(){
  const gsec = document.querySelector('.section[data-title="Glossary"]'); if(!gsec) return;
  const table = gsec.querySelector('.table-wrap table'); if(!table || !table.tHead) return;
  const ths = [...table.tHead.rows[0].cells];
  const ti = ths.findIndex(th => { const t = th.childNodes[0]; return t && t.nodeType === 3 && t.nodeValue.trim().toUpperCase() === 'TOPIC'; });
  if(ti >= 0) ths[ti].click();
})();
"""
GS += """
/* ---- sharing table: start sorted by Status column (asc: Change before OK) ---- */
(function(){
  const w = document.querySelector('.table-wrap[data-desc="Sharing status of each page"]'); const table = w && w.querySelector('table'); if(!table || !table.tHead) return;
  const ths = [...table.tHead.rows[0].cells];
  const si = ths.findIndex(th => { const t = th.childNodes[0]; return t && t.nodeType === 3 && t.nodeValue.trim().toUpperCase() === 'STATUS'; });
  if(si >= 0) ths[si].click();
})();
"""
k = s.index('buildFloatingHeaders();', s.index('initSortableTables();')) + len('buildFloatingHeaders();'); s = s[:k] + GS + s[k:]
# drop References and the verbatim section; Glossary in the "reference" category
a, b = s.index('  <!-- REQUIRED (when the dashboard cites external sources)'), s.index('  <!-- OPTIONAL verbatim source section'); s = s[:a] + s[b:]
a = s.index('  <!-- OPTIONAL verbatim source section'); b = s.index('</main>', a); s = s[:a] + s[b:]
s = s.replace('<div class="section cat-source"', '<div class="section cat-reference"').replace('data-cat="source"', 'data-cat="reference"')
s = s.replace('<span class="cat-badge">Source</span>', '<span class="cat-badge">REFERENCE</span>')
s = s.replace('<span class="sec-num">97</span>', f'<span class="sec-num">{len(S)+2:02d}</span>')
s = s.replace('{{VERBATIM_TEXT}}', '')
left = sorted(set(re.findall(r'\{\{[A-Z0-9_]+\}\}', s)))
if left: sys.exit('placeholders left: ' + ', '.join(left))
open(OUT, 'w', encoding='utf-8').write(s)

sk = open(os.path.join(VIBE, 'SKILL.md'), encoding='utf-8').read()
blocks = re.findall(r'```python\n(.*?)```', sk, re.S)
pick = lambda test: next(b for b in blocks if test(b))
open(os.path.join(WD, 'fit_patch.py'), 'w').write(pick(lambda b: 'function bodyWordMin(' in b and 'table-fit patch' in b))
open(os.path.join(WD, 'mindmap_patch.py'), 'w').write(pick(lambda b: '"""mindmap_patch.py' in b))
open(os.path.join(WD, 'stress_audio.py'), 'w').write(pick(lambda b: 'stress_audio.py — run' in b))
for cmd in (['python3', os.path.join(WD, 'fit_patch.py'), OUT], ['python3', os.path.join(VIBE, 'scripts/search_patch.py'), OUT],
            ['python3', os.path.join(WD, 'mindmap_patch.py'), OUT]):
    r = subprocess.run(cmd, capture_output=True, text=True); print(r.stdout.strip() or r.stderr.strip())
    if r.returncode: sys.exit('patch failed: ' + ' '.join(cmd))
print('built', OUT, '· pages', len(pages), '· to change', len(todo), '· issues', len(issues))
