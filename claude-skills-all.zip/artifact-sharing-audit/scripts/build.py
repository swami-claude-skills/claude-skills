#!/usr/bin/env python3
"""build.py — render Swami's private "Skill Maintenance" vibe dashboard.

usage: python3 build.py VIBE_DIR SHARING.json ISSUES.json KNOWN.json REGISTRY.json OUT.html [WORKDIR]

SHARING   pages tied to the skills, how each is shared now and should be, plus a history (written by artifact-sharing-audit)
ISSUES    output of scan.py (mechanical checks over the skills)
KNOWN     hand-kept items the scan cannot find
REGISTRY  claude-skills repo dashboards/index.json (the public skill sheets on GitHub Pages)

Fills the vibe-dashboard template, then applies its table-fit, Search and Mind Map patches (extracted from
vibe-dashboard's SKILL.md so they match the current skill). Audio is added afterwards with stress_audio.py.
"""
import html, json, os, re, subprocess, sys

VIBE, SH, IS, KN, RG, OUT = sys.argv[1:7]
WD = sys.argv[7] if len(sys.argv) > 7 else os.path.dirname(os.path.abspath(OUT))
sh, iss, known = (json.load(open(p, encoding='utf-8')) for p in (SH, IS, KN))
reg = json.load(open(RG, encoding='utf-8')) if os.path.exists(RG) else {}
e = html.escape

def md(t):
    t = e(str(t)); t = re.sub(r'`([^`]+)`', r'<code>\1</code>', t)
    return re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', t)
def li(topic, text): return f'<li><span class="tid">{e(topic)}</span>{text}</li>'
def table(desc, heads, rows, cls=''):
    th = ''.join(f'<th>{h}</th>' for h in heads)
    body = ''.join('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>' for r in rows)
    return f'<div class="table-wrap{(" " + cls) if cls else ""}" data-desc="{e(desc)}"><table><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table></div>'
def callout(lbl, h): return f'<div class="callout"><span class="lbl">{e(lbl)}</span>{h}</div>'
TAGC = {'High': '#fa3899', 'Medium': '#fa9938', 'Low': '#38dafa', 'OK': '#38fa79', 'Change': '#fa3899',
        'Public': '#dafa38', 'Private': '#7938fa', 'Open': '#fa9938', 'Check': '#dafa38', 'Fixed': '#38fa79'}
def tag(v): return f'<span class="tid" style="--tc:{TAGC.get(v, "#38dafa")}">{e(v)}</span>'
def tid(v): return f'<span class="tid">{e(v)}</span>'
def dt(v): return f'<strong class="dt">{e(v)}</strong>'
def link(u): return f'<a href="{e(u)}" target="_blank" rel="noopener">open ↗</a>' if u else '—'

# ---------------- data ----------------
pages = list(sh['pages'])
for k, r in sorted(reg.items()):   # public skill sheets on GitHub Pages: public by design
    pages.insert(2, {'title': f'{r["title"]} skill sheet', 'url': 'https://swami-claude-skills.github.io/claude-skills/' + r['page'],
                     'kind': 'Skill sheet', 'now': 'Public', 'should': 'Public', 'why': f'Published on GitHub Pages {r.get("published", "")}.'})
for p in pages:
    p.setdefault('url', f'https://claude.ai/artifact/{p["id"]}' if p.get('id') else '')
    p['status'] = 'OK' if p['now'] == p['should'] else 'Change'
todo = [p for p in pages if p['status'] == 'Change']
issues = iss['issues']
cnt = {k: sum(1 for i in issues if i['severity'] == k) for k in ('High', 'Medium', 'Low')}
scanned = iss['scanned'][:10]
import datetime
scanned_h = datetime.date.fromisoformat(scanned).strftime('%a %b %-d, %Y')
open_known = [k for k in known if k['status'] != 'Fixed']

# ---------------- sections ----------------
CATS = [('overview', '#38dafa', 'OVERVIEW'), ('sharing', '#38fa79', 'SHARING'), ('issues', '#dafa38', 'ISSUES'),
        ('known', '#fa9938', 'KNOWN'), ('process', '#fa3899', 'PROCESS'), ('reference', '#7938fa', 'REFERENCE')]
S = []
sharing = (f'<p>Every page tied to the skills, how it is shared now, and how it should be. Last checked {dt(sh["checked"])}: '
           f'<strong>{len(pages) - len(todo)}</strong> of <strong>{len(pages)}</strong> match.</p>')
if todo:
    sharing += callout('Pages to change', '<br>'.join(f'● <strong>{e(p["title"])}</strong>: {md(p["why"])}' for p in todo)
                       + '<br>To change one, open it, choose <strong>Share</strong>, then pick Private.')
sharing += table('Sharing status of each page', ['Page', 'Kind', 'Shared now', 'Should be', 'Status', 'Why', 'Link'],
                 [[f'<strong>{e(p["title"])}</strong>', tid(p['kind']), tag(p['now']), tag(p['should']), tag(p['status']), md(p['why']), link(p['url'])]
                  for p in sorted(pages, key=lambda p: (p['status'] == 'OK', p['kind'], p['title']))])
sharing += table('Sharing history', ['Date', 'Page', 'Change'], [[dt(h['date']), f'<strong>{e(h["page"])}</strong>', md(h['change'])] for h in sh['history']])
S.append(('sharing', 'Sharing Status', 'Who can open each skill page, and what to change', 'Before sharing a link, or after a check', sharing))

S.append(('issues', 'Issues &amp; Gaps', 'Problems found in the skills by the last scan', 'Choosing what to fix next',
          f'<p>Found by a scan of all <strong>{iss["skills"]}</strong> of your skills on {dt(scanned_h)}: '
          f'<strong>{cnt["High"]}</strong> high, <strong>{cnt["Medium"]}</strong> medium and <strong>{cnt["Low"]}</strong> low. '
          'High means two rules for one job or broken output; medium means out of date but harmless; low is tidying.</p>'
          + table('Issues found by the scan', ['Severity', 'Skill', 'Check', 'Finding', 'Fix'],
                  [[tag(i['severity']), f'<strong>{e(i["skill"])}</strong>', tid(i['check']), md(i['finding']), md(i['fix'])] for i in issues])))

S.append(('known', 'Known Items', 'Problems the scan cannot detect, kept by hand', 'Reviewing open work',
          f'<p><strong>{len(open_known)}</strong> open or to check. These need judgment, so they are added and closed by hand.</p>'
          + table('Hand-kept items', ['Item', 'Skill', 'Status', 'What to do'],
                  [[f'<strong>{e(k["item"])}</strong>', md(k['skill']), tag(k['status']), md(k['fix'])] for k in known])))

S.append(('process', 'How It Refreshes', 'How this page stays current', 'Asking for a new check',
          '<ul>' + li('Ask', 'Say <strong>"check skill sharing"</strong> or <strong>"refresh skill maintenance"</strong>. The artifact-sharing-audit skill reads each page\'s sharing, reruns the scan and rebuilds this page.')
          + li('Sharing', 'Only a fresh read of each page shows how it is shared, so the check never guesses from titles or old results.')
          + li('Scan', 'A script checks every skill for old tool names, old save locations, dashboard steps older than vibe-dashboard, missing skills, stray files, version lines, size and out-of-date skill sheets.')
          + li('Privacy', 'The page stays private. People under NDA are never named here.')
          + li('Changes', 'Claude cannot change sharing. You change it from each page\'s Share menu, then ask for a re-check.') + '</ul>'))

# ---------------- render ----------------
s = open(os.path.join(VIBE, 'assets/template.html'), encoding='utf-8').read()
rgb = lambda h: ','.join(str(int(h[i:i+2], 16)) for i in (1, 3, 5))
s = re.sub(r'    --cat-overview:#38dafa;.*?\n    --cat-source:#38fa79;.*?\n', ''.join(f'    --cat-{n}:{c};\n' for n, c, _ in CATS), s, count=1)
blocks = ''.join(f'  .cat-{n} .cat-badge{{color:var(--cat-{n});background:rgba({rgb(c)},.10)}}\n  .cat-{n}{{border-left:3px solid var(--cat-{n})}}\n'
                 f'  .toc-chip.tc-{n}{{border-left-color:var(--cat-{n})}}\n  .toc-chip.tc-{n}:hover{{color:var(--cat-{n})}}\n'
                 f'  .toc-tip.tc-{n} .tip-badge{{color:var(--cat-{n});background:rgba({rgb(c)},.10)}}\n' for n, c, _ in CATS)
a, b = s.index('  /* live defs for the template'), s.index('  .chevron{'); s = s[:a] + blocks + s[b:]
s = re.sub(r"  \.toc-tip\.tc-overview \.tip-badge\{[^\n]*\n  \.toc-tip\.tc-source \.tip-badge\{[^\n]*\n", '', s, count=1)
s = s.replace('</style>', '  .dt{color:var(--text);font-weight:700}\n</style>', 1)
s = s.replace('{{PAGE_TITLE}}', 'Skill Maintenance').replace('{{KICKER}}', 'SKILL MAINTENANCE').replace('{{H1_TITLE}}', 'Skill Maintenance')
s = s.replace('{{H1_SUBTITLE}}', 'Sharing status of every skill page, and the problems found in the skills, refreshed when you ask.')
s = s.replace('<span>{{BYLINE_A}}</span>', '<span>Private · for Swami</span>')
s = s.replace('<span>{{BYLINE_B}}</span>', f'<span>Sharing checked {dt(sh["checked"])}</span><span>Skills scanned {dt(scanned_h)}</span>')
s = s.replace('{{MAIL_SUBJECT}}', 'Skill Maintenance')
CAT = {n: badge for n, _, badge in CATS}
s = s.replace('{{SUMMARY_BADGE}}', 'OVERVIEW')
s = s.replace('{{SUMMARY_INTRO}}', 'This page tracks two things about your skills: who can open each page tied to them, and what needs fixing in the skills themselves. Terms with a dotted underline jump to the Glossary.')
s = s.replace('{{SUMMARY_CALLOUT_LABEL}}', 'Right now').replace('{{SUMMARY_CALLOUT_TEXT}}',
    f'<strong>{len(todo)}</strong> page{"s" if len(todo) != 1 else ""} to set Private, <strong>{cnt["High"]}</strong> high issues, and <strong>{len(open_known)}</strong> hand-kept items open.')
rows = ''.join(f'<tr><td><span class="secnum">{i+2:02d}</span></td><td><strong>{t}</strong></td><td class="sec-cat"></td><td>{f}</td><td>{w}</td></tr>\n            '
               for i, (_, t, f, w, _) in enumerate(S))
a = s.index('            <tr><td><span class="secnum">02</span></td><td><strong>{{SEC_A_TITLE}}'); b = s.index('            <!-- one row per remaining section -->')
s = s[:a] + '            ' + rows + s[b:]
s = re.sub(r'            <tr><td><span class="secnum" data-target-title="References">.*?</tr>\n', '', s, count=1)
s = re.sub(r'            <tr><td><span class="secnum" data-target-title="Source Document \(Verbatim\)">.*?</tr>\n', '', s, count=1)
content = ''.join(f'  <div class="section cat-{c}" data-title="{t}" data-cat="{c}">\n    <div class="sec-head"><span class="sec-num">{i+2:02d}</span>'
                  f'<span class="sec-title">{t}</span><span class="cat-badge">{CAT[c]}</span><span class="chevron">▶</span></div>\n'
                  f'    <div class="sec-body">\n      {body}\n    </div>\n  </div>\n\n' for i, (c, t, _, _, body) in enumerate(S))
a, b = s.index('  <!-- SECTION PATTERN'), s.index('  <!-- OPTIONAL (include whenever the dashboard uses terms'); s = s[:a] + content + s[b:]
GL = [('Sharing state', 'Sharing', r'sharing state|shared|Share menu', '', 'Who can open a claude.ai page: Private (only you), anyone with the link, or named people by email invite.'),
      ('Public', 'Sharing', r'Public', '', 'Anyone with the link can open the page, or it is published on GitHub Pages.'),
      ('Private', 'Sharing', r'Private', '', 'Only you can open the page.'),
      ('Draft', 'Sharing', r'drafts?', '', 'A private skill-sheet page where changes are checked before the public copy on GitHub Pages is updated.'),
      ('GitHub Pages', 'Sharing', r'GitHub Pages', '', 'The free web hosting for the public claude-skills repository, where the published skill sheets live.'),
      ('NDA', 'Sharing', r'NDA', '', 'A non-disclosure agreement; people under one are never named on a shared or published page.'),
      ('Skill sheet', 'Skills', r'skill sheets?', '', 'A dashboard explaining one of your skills, made by the skill-dashboard skill.'),
      ('Skill Library', 'Skills', r'Skill Library', '', 'Your public page listing every skill with downloads, rebuilt nightly.'),
      ('Scan', 'Checks', r'scan|scans', 'scan.py', 'The script that checks every skill for known kinds of problems in the same way each time.'),
      ('Severity', 'Checks', r'severity|high|medium|low', '', 'How much an issue matters: high, medium or low.'),
      ('Fingerprint', 'Checks', r'fingerprints?|out-of-date|out of date', '', 'A short code computed from every file in a skill; when it changes, the skill sheet is out of date.'),
      ('Stray files', 'Checks', r'stray files?|cache files?', '__pycache__', 'Leftover cache files that ship inside a skill but do nothing.'),
      ('artifact-sharing-audit', 'Skills', r'artifact-sharing-audit', '', 'The skill that checks sharing and refreshes this page.'),
      ('vibe-dashboard', 'Skills', r'vibe-dashboard', '', 'The skill that defines the design and parts of every dashboard, including this one.')]
tc, PAL = {}, ['#38dafa', '#38fa79', '#dafa38', '#fa9938', '#fa3899', '#ea38fa', '#7938fa', '#3879fa']
for g in GL: tc.setdefault(g[1], PAL[len(tc)])
grows = ''.join(f'<tr data-gterm="{re.sub(r"[^a-z0-9]+", "-", t.lower()).strip("-")}" data-match="{e(m)}" data-code="{e(c)}"><td><strong>{e(t)}</strong></td>'
                f'<td><span class="tid" style="--tc:{tc[tp]}">{e(tp)}</span></td><td>{e(d)}</td><td class="gloss-uses"></td><td class="gloss-count"></td></tr>\n            '
                for t, tp, m, c, d in GL)
s = s.replace('<thead><tr><th>Term</th><th>Definition</th><th>Appears in</th><th>Qty</th></tr></thead>',
              '<thead><tr><th>Term</th><th>Topic</th><th>Definition</th><th>Appears in</th><th>Qty</th></tr></thead>')
a, b = s.index('            <tr data-gterm="{{GLOSS_A_ID}}"'), s.index('            <!-- one row per term -->'); s = s[:a] + '            ' + grows + s[b:]
s = s.replace('click it to land on its row.', 'click it to land on its row. Each term\'s <strong>Topic</strong> tag names what it is about, one color per topic.', 1)
s = s.replace("def = row.cells[1].textContent.trim();",
              "def = ([...row.cells].slice(1).find(c => !c.querySelector('.tid') && !c.matches('.gloss-uses,.gloss-count')) || {textContent:''}).textContent.trim();")
GS = """
/* ---- glossary: start sorted by Topic column (asc) ---- */
(function(){
  const gsec = document.querySelector('.section[data-title="Glossary"]'); if(!gsec) return;
  const table = gsec.querySelector('.table-wrap table'); if(!table || !table.tHead) return;
  const ths = [...table.tHead.rows[0].cells];
  const ti = ths.findIndex(th => { const t = th.childNodes[0]; return t && t.nodeType === 3 && t.nodeValue.trim().toUpperCase() === 'TOPIC'; });
  if(ti >= 0) ths[ti].click();
})();
"""
k = s.index('buildFloatingHeaders();', s.index('initSortableTables();')) + len('buildFloatingHeaders();'); s = s[:k] + GS + s[k:]
# drop References and the verbatim section; Glossary in the "reference" category
a, b = s.index('  <!-- REQUIRED (when the dashboard cites external sources)'), s.index('  <!-- OPTIONAL verbatim source section'); s = s[:a] + s[b:]
a = s.index('  <!-- OPTIONAL verbatim source section'); b = s.index('</main>', a); s = s[:a] + s[b:]
s = s.replace('<div class="section cat-source"', '<div class="section cat-reference"').replace('data-cat="source"', 'data-cat="reference"')
s = s.replace('<span class="cat-badge">Source</span>', '<span class="cat-badge">REFERENCE</span>')
s = s.replace('<span class="sec-num">97</span>', f'<span class="sec-num">{len(S)+2:02d}</span>')
s = s.replace('{{VERBATIM_TEXT}}', '')
left = sorted(set(re.findall(r'\{\{[A-Z0-9_]+\}\}', s)))
if left: sys.exit('placeholders left: ' + ', '.join(left))
open(OUT, 'w', encoding='utf-8').write(s)

sk = open(os.path.join(VIBE, 'SKILL.md'), encoding='utf-8').read()
blocks = re.findall(r'```python\n(.*?)```', sk, re.S)
pick = lambda test: next(b for b in blocks if test(b))
open(os.path.join(WD, 'fit_patch.py'), 'w').write(pick(lambda b: 'function bodyWordMin(' in b and 'table-fit patch' in b))
open(os.path.join(WD, 'mindmap_patch.py'), 'w').write(pick(lambda b: '"""mindmap_patch.py' in b))
open(os.path.join(WD, 'stress_audio.py'), 'w').write(pick(lambda b: 'stress_audio.py — run' in b))
for cmd in (['python3', os.path.join(WD, 'fit_patch.py'), OUT], ['python3', os.path.join(VIBE, 'scripts/search_patch.py'), OUT],
            ['python3', os.path.join(WD, 'mindmap_patch.py'), OUT]):
    r = subprocess.run(cmd, capture_output=True, text=True); print(r.stdout.strip() or r.stderr.strip())
    if r.returncode: sys.exit('patch failed: ' + ' '.join(cmd))
print('built', OUT, '· pages', len(pages), '· to change', len(todo), '· issues', len(issues))
