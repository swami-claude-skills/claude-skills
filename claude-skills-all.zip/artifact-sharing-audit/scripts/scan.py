#!/usr/bin/env python3
"""scan.py — check Swami's own skills for known kinds of staleness and conflict (Skill Maintenance dashboard).

usage: python3 -I scan.py SKILLS_ROOT REGISTRY.json OUT.json

SKILLS_ROOT  folder holding one folder per skill plus Claude's manifest.json (only source "plugin" skills are checked)
REGISTRY     the claude-skills repo's dashboards/index.json (published skill sheets), or a missing path
OUT          issues as JSON: {"scanned": ISO time, "skills": N, "issues": [{skill, check, severity, finding, fix}]}

Each check is mechanical (text and file patterns), so a run is repeatable and needs no judgment.
Severity: High = gives Claude two rules for one job or breaks output; Medium = outdated but harmless; Low = tidy-up.
"""
import json, os, re, sys, hashlib, datetime

root, reg_path, out = sys.argv[1:4]
manifest = json.load(open(os.path.join(root, 'manifest.json'), encoding='utf-8'))
mine = sorted(s['name'] for s in manifest['skills']
              if s.get('source') == 'plugin' and os.path.isfile(os.path.join(root, s['name'], 'SKILL.md')))
installed = {s['name'] for s in manifest['skills']}
registry = json.load(open(reg_path, encoding='utf-8')) if os.path.exists(reg_path) else {}

def fingerprint(folder):   # same algorithm as the skill-dashboard skill's fingerprint.py
    h = hashlib.sha256()
    for dp, dn, fn in os.walk(folder):
        dn[:] = sorted(d for d in dn if not d.startswith('.'))
        for f in sorted(fn):
            if f.startswith('.'): continue
            p = os.path.join(dp, f); rel = os.path.relpath(p, folder).replace(os.sep, '/')
            h.update(rel.encode() + b'\0'); h.update(open(p, 'rb').read()); h.update(b'\0')
    return 'sha256:' + h.hexdigest()[:16]

issues = []
def add(skill, check, sev, finding, fix): issues.append(dict(skill=skill, check=check, severity=sev, finding=finding, fix=fix))
def files_of(folder):
    for dp, dn, fn in os.walk(folder):
        for f in fn: yield os.path.join(dp, f)

for n in mine:
    folder = os.path.join(root, n)
    md = open(os.path.join(folder, 'SKILL.md'), encoding='utf-8').read()
    texts = {}
    for p in files_of(folder):
        if p.endswith(('.md', '.py', '.txt', '.html', '.json', '.command', '.cmd', '.ps1', '.sh', '.manifest')):
            try: texts[os.path.relpath(p, folder)] = open(p, encoding='utf-8').read()
            except Exception: pass

    # 1. old tool names and save locations (this app uses SendUserFile, AskUserQuestion and the working directory)
    for old, new in (('present_files', 'SendUserFile'), ('ask_user_input_v0', 'AskUserQuestion')):
        hits = [f for f, t in texts.items() if old in t and new not in t]   # naming both = old one kept as an alternative, fine
        if hits:
            add(n, 'Old tool name', 'Medium', f'Mentions `{old}` in {", ".join(sorted(hits))}.', f'Use `{new}` (keep the old name only as an alternative).')
    for f, t in texts.items():
        for m in re.finditer(r'[^\n]*/mnt/user-data/outputs[^\n]*', t):
            line = m.group(0)
            if re.search(r'\bnot\b|never|overrid|instead of|rather than|fallback', line, re.I): continue   # lines that warn against it are fine
            add(n, 'Old save location', 'High' if n != 'vibe-dashboard' else 'Low',
                f'{f}: still saves to `/mnt/user-data/outputs/` ("{line.strip()[:90]}").',
                'Write in the working directory and publish as an artifact, per vibe-dashboard.')
            break

    # 2. dashboard hand-off predates vibe-dashboard's Search section and Mind Map
    # launch pads, prompt makers and add-in palettes are vibe-styled but have no Search section or Mind Map by design
    builds = n not in ('vibe-dashboard', 'vibe-launchpad', 'vibe-promptmaker', 'fusion-palette-addin') and re.search(r'template\.html|Dashboard Summary', md)
    if builds and not re.search(r'search_patch|Search section|Mind Map|mindmap', md, re.I) and 'follow its current version' not in md \
            and 'workflow in full' not in md:
        add(n, 'Dashboard steps out of date', 'Medium',
            'Builds a vibe dashboard but never mentions the Search section (02), the Mind Map, or the current patches.',
            'Bring its dashboard step in line with vibe-dashboard, as done for makerworld-reviews and facebook-comments.')

    # 3. skills it names that aren't installed
    for m in sorted(set(re.findall(r'`([a-z0-9]+(?:-[a-z0-9]+)+)`', md))):
        if m in installed or m == n: continue
        if re.search(r'(?<![\w-])' + re.escape(m) + r' skill', md):
            add(n, 'Missing skill', 'High', f'Refers to a `{m}` skill that is not installed.', f'Add `{m}`, or remove it from {n}.')

    # 4. stray files shipped in the skill and its download
    stray = [os.path.relpath(p, folder) for p in files_of(folder) if '__pycache__' in p or p.endswith(('.pyc', '.DS_Store'))]
    if stray:
        add(n, 'Stray files', 'Low', f'{len(stray)} cache file(s) ship with the skill: {", ".join(stray[:3])}.', 'Delete them from the skill folder.')

    # 5. no version line
    if not re.search(r'^version:|\bversion\s*[:=]\s*["\']?\d+\.\d+', md, re.I | re.M):
        add(n, 'No version', 'Low', 'SKILL.md has no version number.', 'Add a version line so changes can be traced.')

    # 6. very large SKILL.md
    kb = len(md.encode()) / 1024
    if kb > 30:
        add(n, 'Very large SKILL.md', 'Low', f'SKILL.md is {kb:.0f} KB, all of it loaded every time the skill runs.',
            'Move long code blocks or reference material into scripts/ or references/ files.')

    # 7. acronyms spelled with spaces (vibe-dashboard: never "A I" or "C A M")
    for f, t in texts.items():
        if re.search(r'"(?:C A M|A I|C N C|P L A)"', t) and 'never' not in t[max(0, t.find('"A I"') - 120):t.find('"A I"') + 10].lower():
            add(n, 'Acronym rule conflict', 'Medium', f'{f} tells the voice to spell acronyms with spaces ("C A M", "A I").',
                'Say acronyms in solid capitals (CAM as the word "cam"), per vibe-dashboard Pronunciation.')

    # 8. skill sheet: missing, or out of date
    r = registry.get(n)
    if not r:
        add(n, 'No skill sheet', 'Low', 'Has no published skill sheet yet.', 'Make one with the skill-dashboard skill.')
    elif fingerprint(folder) != r.get('fingerprint'):
        add(n, 'Skill sheet out of date', 'Medium', 'The skill changed after its sheet was published.', 'Run skill-dashboard update, then publish.')

# 9. Fusion add-in conflicts between skills
def read(path):
    try: return open(path, encoding='utf-8').read()
    except Exception: return ''
pal = os.path.join(root, 'fusion-palette-addin')
if os.path.isdir(pal):
    inst = read(os.path.join(pal, 'assets', 'install-macos.command'))
    if 'rsync' in inst and '--delete' in inst:
        add('fusion-palette-addin', 'Installer rule conflict', 'High',
            'Its bundled macOS installer uses `rsync --delete`; fusion-addin-scaffold says not to rely on rsync, and fusion-addin-installer requires excluding __pycache__ and .DS_Store.',
            'Replace the bundled installers with fusion-addin-installer output.')
    pm, sm = read(os.path.join(pal, 'assets', 'manifest.json')), read(os.path.join(root, 'fusion-addin-scaffold', 'references', 'templates.md'))
    a = re.search(r'"autodeskProduct"\s*:\s*"([^"]+)"', pm); b = re.search(r'"autodeskProduct"\s*:\s*"([^"]+)"', sm)
    if a and b and a.group(1) != b.group(1):
        add('fusion-palette-addin', 'Manifest disagreement', 'Medium',
            f'Palette manifest says autodeskProduct "{a.group(1)}"; the scaffold template says "{b.group(1)}".',
            'Pick one manifest standard and use it in both skills.')

# 10. Comet support differs between the browser skills (informational)
comet = {n: ('not supported' in open(os.path.join(root, n, 'SKILL.md'), encoding='utf-8').read().split('Comet', 1)[-1][:80].lower())
         for n in mine if 'Comet' in open(os.path.join(root, n, 'SKILL.md'), encoding='utf-8').read()}
if len(set(comet.values())) > 1:
    add(', '.join(sorted(comet)), 'Comet support differs', 'Low',
        'Supported: ' + (', '.join(k for k, v in comet.items() if not v) or 'none') + '; not supported: ' + (', '.join(k for k, v in comet.items() if v) or 'none') + '.',
        'Intentional if Facebook differs; just confirm it is deliberate.')

order = {'High': 0, 'Medium': 1, 'Low': 2}
issues.sort(key=lambda i: (order[i['severity']], i['skill'], i['check']))
json.dump({'scanned': datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'), 'skills': len(mine), 'issues': issues},
          open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print(json.dumps({'skills': len(mine), 'issues': len(issues),
                  'by_severity': {k: sum(1 for i in issues if i['severity'] == k) for k in order}}))
