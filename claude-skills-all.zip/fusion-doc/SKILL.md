---
name: "fusion-doc"
description: "Build Swami's Fusion Doc dashboard: a vibe-dashboard page documenting one Autodesk Fusion command/toolpath from a tab→group→parameter JSON plus its Autodesk product-documentation URL, with an in-page Input section. When run with no inputs, ask for the JSON and URL first, then build."
---

# Fusion Doc dashboard

Makes one self-contained, published HTML dashboard in Swami's locked **vibe-dashboard** design system. It documents a single Autodesk Fusion command or CAM toolpath dialog (e.g. 2D Offset Roughing, Adaptive Clearing, Extrude). It is built from:

1. a **parameter JSON**: tabs → groups → parameter names, in dialog order;
2. the **URL of the command's Autodesk product-documentation page** (help.autodesk.com).

The page renders itself in the browser from two embedded JSON blocks: the doc JSON and a notes JSON that Claude writes. That is how the **Input** section works: a viewer can load a different JSON or URL in the page and every data-driven section rebuilds.

Use this whenever Swami runs `/fusion-doc` (with or without inputs), asks for a "fusion doc", a Fusion parameter or reference dashboard from a JSON of a dialog's tabs/settings, or uploads such a JSON with a help.autodesk.com link. For other dashboards, use vibe-dashboard.

## Sections (always, in this order)

| # | Section | Contents |
|---|---|---|
| 01 | Dashboard Summary | Intro, "Start here" callout, and the "What each section covers" table: # / Section / **Category** (coloured pill matching each section's badge) / Focus / Use When. |
| 02 | Search | vibe-dashboard's Search section (added by the build script). |
| 03 | Input | Product-documentation URL field, JSON file picker, paste box, **load & rebuild**, **reset to original**, a "currently loaded" summary, and a JSON-format callout. |
| 04 | Parameter Map at a Glance | "Tabs at a glance" table and "Every group and its parameters" table. |
| 05 | Parameter Hierarchy | Collapsible tree: command → tab → group → parameter. The tabs / groups / expand all / collapse all buttons stay sticky. Cyan **[NN]** links jump to a tab or group table, and parameter links jump to their row and flash it. Hover tooltips show a one-line description ending in a dim "(click for more…)". |
| … | `<Tab> tab` (one per tab) | Intro plus cross-references; one table per group (Parameter / What it does / tip). A *uniform* tab, where every group has the same ≤4 fields (like Heights → From/Offset), gets one non-sortable table instead. |
| … | Extra sections from notes | For example a setup workflow. |
| … | Mind Map | vibe-dashboard's Mind Map (added by the build script). |
| … | Glossary | From `notes.glossary`. |
| … | References | Only when there is a URL or other references. |
| last | Source Document (Verbatim) | The JSON exactly as loaded. |

Plus the audio overview player under the header.

**Everything starts collapsed**: sections, table/callout items and every tree node. Never add `open`.

## Inputs

- **No inputs.** If `/fusion-doc` arrives without a JSON, **build nothing yet**: no example, placeholder or empty dashboard. Reply with one short message asking Swami to attach (or paste) the parameter JSON and paste the command's help.autodesk.com URL, then wait. Once the JSON arrives, run the Workflow below and publish the dashboard for that command.
- **JSON.** The canonical shape is:
  ```json
  {"operation": "2D Offset Roughing", "url": "https://help.autodesk.com/…",
   "tabs": {"Tool": {"Tool": ["Tool","Coolant"], "Feed & Speed": ["Spindle Speed"]}}}
  ```
  `url` is optional. Swami makes this JSON with a command he runs in the **Autodesk Assistant** AI inside Fusion (he will document the exact command later). If Swami's JSON has a different shape, normalise it to this one and say in one line how you mapped it. If he gives only a URL, try WebFetch on the page and build the JSON from its tab, group and parameter headings. Show him the JSON before building. If the fetch fails, ask him for the JSON.
- **URL.** If the JSON arrives without a URL (and it has no `url` key) and he's present, ask once. If he's not present, build without it: the page then has no References section and no Autodesk Help link in the byline.

## Workflow

1. **Read and normalise** the JSON. Save it as `doc.json` in the scratchpad.
2. **Research.** WebFetch the documentation URL and use it to ground the descriptions. help.autodesk.com pages are script-heavy and may come back thin. If they do, use general Fusion knowledge and say so in an "About these notes" callout (in an extra section, or as a tab callout).
3. **Write `notes.json`** following the schema below:
   - one `[what it does, tip]` for **every** parameter;
   - a `desc` for every group;
   - an `intro`, a `related` cross-reference sentence, and `focus`/`when` for every tab;
   - usually one extra section with a step-by-step setup workflow. Write it as a **no-sort** table (Step / Task / What to do / Where), with `<th data-keep="1">Where</th>` so the Where column stays one line;
   - a `glossary` of 10–20 terms a reader meets on the page (see the schema). Each `match` must hit the rendered page's body text outside the summary (tab intros, descriptions, tips or extra sections); names in tables and the tree don't count, because they never link.

   Write every cross-reference with an exact section title ("Linking tab", "Parameter Hierarchy"). The page auto-links those and appends `[NN]`.
4. **Build:** find vibe-dashboard and run the build script below (saved as `$S/fd/fusion_doc_build.py`). It reads the template straight from vibe-dashboard; there is no separate template step.
   ```bash
   S=<scratchpad>; mkdir -p $S/fd
   # the vibe-dashboard skill's install path varies (/mnt/skills/plugins/…, /root/.claude/skills/synced/…/…), so find it:
   V=$(dirname "$(find /mnt/skills /root/.claude/skills -path '*vibe-dashboard/SKILL.md' 2>/dev/null | head -1)")
   python3 -I $S/fd/fusion_doc_build.py "$V" $S/fd/doc.json $S/fd/notes.json /home/claude/fusion-<command-slug>-doc.html $S/fd
   ```
   The output goes in the **working directory**, not `/mnt/user-data/outputs`, so publishing needs no approval prompt. The script also applies vibe-dashboard's table-fit, Search and Mind Map patches (extracted from its SKILL.md, so they match its current version) and saves `stress_audio.py` in `$S/fd`. If it prints **NO GLOSSARY**, add `notes.glossary` and rebuild.
5. **Audio overview.** The sections are drawn in the browser, so take the outline from a rendered copy:
   ```bash
   node -e "const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage();await p.goto('file://'+process.argv[1]);await p.waitForTimeout(1500);require('fs').writeFileSync(process.argv[2],await p.content());await b.close()})()" /home/claude/fusion-<command-slug>-doc.html $S/fd/rendered.html
   python3 "$V/scripts/audio_overview.py" extract $S/fd/rendered.html
   ```
   (If `require('playwright')` fails, run it with `NODE_PATH=$(npm root -g)`.) Write `narration.txt` per vibe-dashboard's "Audio overview" rules (each section by number then header, including Search, Mind Map, Glossary, References and Source Document; follow its Pronunciation table), run `python3 $S/fd/stress_audio.py "$V" audit narration.txt` and mark any wrong stress, then `python3 $S/fd/stress_audio.py "$V" build <page> narration.txt <page>`. If the recording can't be made, follow vibe-dashboard's browser-voice fallback. The player hides itself when a different command is loaded through Input, since the narration describes the original one.
6. **Verify** in headless Chromium with Playwright (`file://` works) at 1000 px and 1440 px. Check:
   - no `pageerror`;
   - no `checkCategoryColours` console warning;
   - every `.pt-leaf` resolves to a row (the check below returns 0);
   - no table wider than its section, every summary row linked, and no glossary term with a zero count;
   - a screenshot of 01 and the Parameter Hierarchy opened looks right;
   - vibe-dashboard's privacy check passes.
   ```js
   [...document.querySelectorAll('.pt-leaf')].filter(l=>{const s=sections.find(x=>x.dataset.title===l.dataset.tab+' tab');const u=s.querySelector('.table-wrap[data-uniform]');const w=u||[...s.querySelectorAll('.table-wrap[data-group]')].find(w=>w.dataset.group===l.dataset.group);const k=u?l.dataset.group:l.dataset.param;return !w||![...w.querySelectorAll('tbody tr')].some(r=>r.dataset.key===k)}).length
   ```
7. **Publish** with the Artifact tool from the working-directory path, `icon: "gear"`. Declare **no capabilities**: the Input section uses only browser storage. Reply with one line about the page.

**Follow-up edits:** change `notes.json` or `doc.json`, rebuild, re-record the audio if the sections changed (otherwise carry the `AUDIO-OVERVIEW` block over from the published page), and republish the same path. Never hand-edit the generated sections in the HTML; they are rendered from the JSON at load time. If the scratchpad is gone, read the published page and recover the JSON from `<script id="fd-doc">` and `<script id="fd-notes">`.

## notes.json schema

All keys are optional except `operation` and `tabs`. Keys marked *(HTML)* may contain inline HTML such as `<strong>`; every other value is plain text.

```json
{
  "operation": "2D Offset Roughing",          // must equal doc.operation
  "title": "2D Offset Roughing",              // H1 (default: operation)
  "page_title": "2D Offset Roughing",         // <title>: a 2–4 word name, no dash or explainer (default: title, else operation)
  "subtitle": "Every parameter, tab by tab — 101 fields explained with roughing tips",
  "kicker": "FUSION CAM REFERENCE",           // UPPERCASE page-type tag (default FUSION DOC REFERENCE)
  "workspace": "Manufacture workspace",       // byline: "Autodesk Fusion · <workspace>"
  "doc_url": "https://help.autodesk.com/view/fusion360/ENU/?guid=…",
  "doc_label": "2D Pocket reference",         // link text for the doc URL
  "source_name": "fusion-2d-offset-roughing-parameters.json",
  "tip_label": "Roughing tip",                // header of the tip column (default "Tip")
  "summary_intro": "… (HTML)",
  "start_here": "… (HTML)",
  "tabs": {
    "Tool": {
      "intro": "The cutter, coolant, and every feed and speed the operation uses. (HTML)",
      "related": "Ramp and lead feeds set here drive the moves defined in Linking tab. (HTML)",
      "focus": "Tool, coolant, speeds and feeds",   // summary-table Focus
      "when":  "Setting chipload, RPM and entry feeds", // summary-table Use When
      "groups": {
        "Feed & Speed": {
          "desc": "Spindle speed, chipload and every feedrate the operation uses.",
          "params": {"Feed per Tooth": ["Chipload — material removed per flute per revolution. …", "The most important number for tool life."]}
        }
      },
      "callouts": [{"label": "Check order", "text": "… (HTML)"}]
    },
    "Heights": {                                // a UNIFORM tab: every group has the same fields
      "group_label": "Height", "table_desc": "Height levels, From and Offset",
      "param_desc": {"From": "The reference the height is measured from.", "Offset": "Distance above (+) or below (−) that reference."},
      "uniform_note": "The order top-to-bottom is always Clearance → Retract → Feed → Top → Bottom.",
      "groups": {"Clearance Height": {"desc": "First height the tool rapids to …", "params": {"From": "Retract height", "Offset": "+10 mm or more."}}}
    }
  },
  "extra_sections": [
    {"title": "Roughing Setup Workflow", "category": "workflow", "badge": "WORKFLOW",
     "focus": "Step-by-step order for a first setup", "when": "Setting up the op from scratch",
     "html": "<p>…</p><div class=\"table-wrap no-sort\" data-desc=\"Setup steps, in order\">…</div>"}
  ],
  "references": [{"source": "…", "covers": "…", "url": "https://…", "label": "open page"}],
  "glossary": [{"term": "Stepover", "match": "stepovers?", "code": "", "def": "How far the tool moves sideways between passes."}]
}
```

- **Parameter values.** Normal tabs take `[what, tip]`; the first sentence of `what` becomes the tree tooltip. Uniform tabs take the typical value as a string.
- **Extra-section HTML.** Use only vibe building blocks: `<p>`, `<ul>`, `.callout`, `.resource`, and `.table-wrap` (with `data-desc`, plus `no-sort` when order matters).

## Built-in behaviour

The page handles these by itself; don't re-implement them.

- **Category colours are automatic.** Overview (and the Mind Map) is cyan; Input, Glossary, References and Source are magenta; tabs take green, yellow, orange, blue, violet, then generated hues; extras are pink. Search keeps the distinct colour its patch picked at build time, and the runtime colours avoid it.
- **Static sections.** Search, Mind Map and Glossary are written into the page by the build script and vibe-dashboard's patches. The renderer keeps them, puts them in place (Search second, Mind Map and Glossary before References) and numbers them with the rest.
- **Names never become links.** Parameter, group and tree names carry `class="nolink"`, so they never auto-link to a section, even one called "Input".
- **What the Input section loads:** it validates the JSON and saves it per browser (localStorage, falling back to `window.name`), then reloads. Descriptions carry over by exact tab, group and parameter names, and a "Descriptions coverage" callout says how many matched.
- **Different command loaded:** extras, `summary_intro`, title and kicker are hidden, because they were written for the original command. "reset to original" restores the built-in JSON.
- **Search:** hits inside closed tree branches open them and land below the sticky tree buttons.
- **Template patches:** the build script also makes names (`class="nolink"`) exempt from section links and the glossary, adds `th[data-keep]` (the column keeps its one-line width when tables auto-fit) and the extra CSS.

## Build script — save as `fusion_doc_build.py`

```python
#!/usr/bin/env python3
"""fusion-doc builder: turns the vibe-dashboard template + doc JSON + notes JSON into a
self-contained Fusion product-documentation dashboard.

usage: python3 -I fusion_doc_build.py VIBE_DIR doc.json notes.json out.html [WORKDIR]
  VIBE_DIR  the vibe-dashboard skill folder (assets/template.html, scripts/search_patch.py, SKILL.md)
  WORKDIR   where vibe-dashboard's patch helpers and stress_audio.py are saved (default: out's folder)

The page renders itself from two embedded JSON blocks (doc + notes) before the
template's own scripts run, so its Input section can load a different JSON / URL
in the browser and rebuild every data-driven section. The Search, Mind Map and
Glossary sections are static (added by vibe-dashboard's own patches); the renderer
keeps them and numbers them in place. Audio is added afterwards (see SKILL.md).
"""
import json, sys, os, re, html, subprocess

VIBE, doc_path, notes_path, out_path = sys.argv[1:5]
WD = sys.argv[5] if len(sys.argv) > 5 else os.path.dirname(os.path.abspath(out_path))
s = open(os.path.join(VIBE, 'assets', 'template.html'), encoding='utf-8').read()
doc = json.load(open(doc_path, encoding='utf-8'))
notes = json.load(open(notes_path, encoding='utf-8'))
assert 'fd-render' not in s, 'template already built'

def rep(old, new, label, count=1):
    global s
    assert old in s, 'anchor not found: ' + label
    s = s.replace(old, new, count)

def js_json(obj):
    return json.dumps(obj, ensure_ascii=False).replace('</', '<\\/')

# ---------------------------------------------------------------- header
a = s.index('<header>'); b = s.index('</header>') + len('</header>')
s = s[:a] + '''<header>
  <div class="kicker" id="fdKicker">FUSION DOC REFERENCE</div>
  <h1><span id="fdTitle"></span> <br><span class="sub" id="fdSub"></span></h1>
  <div class="byline" id="fdByline"></div>
</header>''' + s[b:]
# <title> is the artifact's name in the gallery: a plain name, never "X — Fusion Doc — Swami"
import re as _re
_pt = notes.get('page_title') or notes.get('title') or doc.get('operation') or 'Fusion Doc'
assert _re.search(r'<title>.*?</title>', s), 'anchor not found: title'
s = _re.sub(r'<title>.*?</title>', lambda m: '<title>' + _pt.replace('&','&amp;').replace('<','&lt;') + '</title>', s, count=1)
rep('{{MAIL_SUBJECT}}', 'Fusion doc dashboard', 'mail subject')

# ---------------------------------------------------------------- main: static skeleton, the rest is rendered by JS
# The Dashboard Summary stub lets vibe-dashboard's Search and Mind Map patches find their place; the renderer
# rebuilds the summary and inserts every data-driven section around the static Search, Mind Map and Glossary.
E = html.escape
GLOSS = notes.get('glossary') or []
grows = ''.join('            <tr data-gterm="%s" data-match="%s" data-code="%s"><td><strong>%s</strong></td><td>%s</td><td class="gloss-uses"></td><td class="gloss-count"></td></tr>\n'
                % (re.sub(r'[^a-z0-9]+', '-', g['term'].lower()).strip('-'), E(g.get('match', '')), E(g.get('code', '')), E(g['term']), E(g['def'])) for g in GLOSS)
ga = s.index('  <div class="section cat-source" data-title="Glossary"'); gb = s.index('  <!-- REQUIRED (when the dashboard cites external sources)')
gsec = s[ga:gb]
gsec = gsec[:gsec.index('            <tr data-gterm="{{GLOSS_A_ID}}"')] + grows + gsec[gsec.index('            <!-- one row per term -->'):]
gsec = gsec.replace('<span class="sec-num">97</span>', '<span class="sec-num">02</span>')
gsec = gsec.replace('<span class="cat-badge">Source</span>', '<span class="cat-badge">SOURCE</span>')
SKEL = '''
  <div class="section cat-overview" data-title="Dashboard Summary" data-cat="overview">
    <div class="sec-head"><span class="sec-num">01</span><span class="sec-title">Dashboard Summary</span><span class="cat-badge">OVERVIEW</span><span class="chevron">▶</span></div>
    <div class="sec-body">
      <div class="table-wrap" data-desc="What each section covers">
        <table>
          <thead><tr><th>#</th><th>Section</th><th>Category</th><th>Focus</th><th>Use When</th></tr></thead>
          <tbody>
            <tr><td><span class="secnum">01</span></td><td><strong>Dashboard Summary</strong></td><td class="sec-cat"></td><td>This overview and the section index</td><td>Getting oriented</td></tr>
            <tr><td><span class="secnum" data-target-title="Glossary"></span></td><td><strong>Glossary</strong></td><td class="sec-cat"></td><td>Term definitions with jump links both ways</td><td>A term is unfamiliar, or you want every place it's used</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

''' + (gsec if GLOSS else '')
a = s.index('<main id="content">') + len('<main id="content">'); b = s.index('</main>')
s = s[:a] + SKEL + s[b:]

# verbatim comes from the rendered doc, as-is (no paragraph doubling)
rep("const VERBATIM = `{{VERBATIM_TEXT}}`;", "const VERBATIM = window.__FD_VERBATIM || '';", 'verbatim const')
rep("VERBATIM.replace(/\\n/g, '\\n\\n')", "VERBATIM", 'verbatim doubling')

# ---------------------------------------------------------------- template script patches
# 1. elements with class "nolink" (parameter / group names) are never auto-linked
assert s.count("p.classList.contains('secnum')") >= 1, 'anchor not found: nolink'
s = s.replace("p.classList.contains('secnum')", "p.classList.contains('secnum')||p.classList.contains('nolink')", 1)
rep("const SKIPCLS = ['secref','secnum',", "const SKIPCLS = ['nolink','secref','secnum',", 'glossary nolink')
# 2. table auto-fit: <th data-keep> columns keep their natural one-line width
rep('''    // round, then if the total exceeds the wrapper, trim the excess off the''',
'''    // columns whose header has data-keep stay at their natural one-line width;
    // the difference is taken from the widest other non-first column.
    const hdr = table.tHead.rows[0].cells;
    for(let ci=1; ci<ncol; ci++){
      if(!hdr[ci].dataset.keep || widths[ci] >= natural[ci] + 18) continue;
      let need = natural[ci] + 18 - widths[ci]; widths[ci] = natural[ci] + 18;
      const donors = widths.map((w,i)=>({w,i})).filter(o=>o.i>0 && !hdr[o.i].dataset.keep).sort((x,y)=>y.w-x.w);
      for(const d of donors){ if(need<=0) break; const cut=Math.min(need, widths[d.i]-120); if(cut>0){ widths[d.i]-=cut; need-=cut; } }
    }
    // round, then if the total exceeds the wrapper, trim the excess off the''', 'data-keep fit')
rep("const order = rounded.map((w,ci)=>({w,ci})).filter(o=>o.ci>0).sort",
    "const order = rounded.map((w,ci)=>({w,ci})).filter(o=>o.ci>0 && !hdr[o.ci].dataset.keep).sort", 'data-keep trim')
# 3b. a search hit inside a closed tree branch opens that branch first
rep("  m.classList.add('active');",
    "  m.classList.add('active');\n  for(let dd=m.closest('details'); dd; dd=dd.parentElement.closest('details')) dd.open=true;", 'focusMatch details')
# 3. search hits inside the hierarchy tree clear its sticky button bar
rep('  return {anchor, line: line + 12};',
    "  const ptBar = m.closest('.pt-tree') && m.closest('.sec-body').querySelector('.pt-bar');\n"
    "  if(ptBar) line += h(ptBar);   // sticky tree buttons\n"
    '  return {anchor, line: line + 12};', 'hitTarget pt-bar')

# ---------------------------------------------------------------- CSS
CSS = r'''
  /* ================= fusion-doc additions ================= */
  .cat-pill{display:inline-block;font-family:var(--mono);font-size:10px;letter-spacing:1.5px;text-transform:uppercase;
    padding:2px 9px;border-radius:20px;border:1px solid var(--pc);color:var(--pc);
    background:color-mix(in srgb, var(--pc) 10%, transparent);white-space:nowrap}
  /* input section */
  .fd-input{display:grid;gap:12px;margin:14px 0;padding:16px;border:1px solid var(--border);border-radius:8px;background:var(--panel-2)}
  .fd-row{display:flex;flex-wrap:wrap;gap:8px 12px;align-items:center}
  .fd-row>label{font-family:var(--mono);font-size:11px;letter-spacing:1.2px;text-transform:uppercase;color:var(--text-mute);min-width:200px}
  .fd-input input[type=url],.fd-input textarea{flex:1;min-width:220px;background:var(--bg);color:var(--text);border:1px solid var(--border);
    border-radius:6px;padding:8px 10px;font-family:var(--mono);font-size:12.5px}
  .fd-input textarea{width:100%;min-height:96px;resize:vertical;flex-basis:100%}
  .fd-input input:focus,.fd-input textarea:focus{outline:none;border-color:var(--cyan)}
  .fd-input input[type=file]{font-family:var(--mono);font-size:12px;color:var(--text-dim)}
  .fd-input input[type=file]::file-selector-button{background:var(--panel);border:1px solid var(--border);color:var(--text-dim);
    font-family:var(--mono);font-size:12px;padding:7px 11px;border-radius:6px;cursor:pointer;margin-right:10px}
  .fd-input input[type=file]::file-selector-button:hover{border-color:var(--cyan);color:var(--cyan)}
  .fd-input .tool-btn:disabled{opacity:.4;cursor:default;border-color:var(--border);color:var(--text-mute)}
  .fd-status{font-family:var(--mono);font-size:12px;color:var(--text-mute)}
  .fd-status.ok{color:var(--cat-overview,#38dafa)} .fd-status.err{color:#fa3899}
  .fd-kv{display:grid;grid-template-columns:max-content 1fr;gap:6px 16px;margin:14px 0;font-size:13.5px}
  .fd-kv dt{font-family:var(--mono);font-size:11px;letter-spacing:1.2px;text-transform:uppercase;color:var(--text-mute);padding-top:2px}
  .fd-kv dd{margin:0;color:var(--text-dim);word-break:break-word}
  .fd-kv a{color:var(--cyan)}
  .fd-schema{font-family:var(--mono);font-size:12px;line-height:1.5;color:var(--text-dim);background:var(--bg);border:1px solid var(--border);
    border-radius:6px;padding:10px 12px;margin:8px 0 0;white-space:pre;overflow-x:auto}
  /* parameter hierarchy tree */
  .pt-bar{display:flex;flex-wrap:wrap;gap:6px;margin:14px -20px 12px;padding:8px 20px;
    position:sticky;top:calc(var(--stack-h,0px) + var(--sechead-h,0px));z-index:6;
    background:var(--panel);border-bottom:1px solid transparent}
  .pt-bar.stuck{border-bottom-color:var(--border);box-shadow:0 6px 14px rgba(0,0,0,.35)}
  .pt-tree{font-family:var(--mono);font-size:13px}
  .pt-node>summary{list-style:none;cursor:pointer;display:flex;align-items:baseline;gap:10px;padding:4px 8px;border-radius:4px;user-select:none}
  .pt-node>summary::-webkit-details-marker{display:none}
  .pt-node>summary::before{content:'▸';color:var(--text-mute);display:inline-block;width:10px;transition:transform .15s}
  .pt-node[open]>summary::before{transform:rotate(90deg);color:var(--cyan)}
  .pt-node>summary:hover{background:var(--panel-2)}
  .pt-name{color:var(--text)}
  .pt-root>summary .pt-name{color:var(--cyan);font-weight:600}
  .pt-count{font-size:11px;color:var(--text-mute)}
  .pt-kids,.pt-leaves{margin:0 0 0 13px;padding-left:12px;border-left:1px solid var(--border)}
  .pt-tab>summary .pt-name{font-weight:600;color:var(--tc)}
  .pt-tab>.pt-kids{border-left-color:var(--tc)}
  .pt-leaves{list-style:none;padding-top:2px;padding-bottom:4px}
  .pt-leaves li{color:var(--text-dim);padding:2px 8px;font-size:12.5px}
  .pt-leaves li::before{content:none}
  .pt-go,.pt-leaf{color:var(--cyan);cursor:pointer;border-bottom:1px dotted var(--cyan-line)}
  .pt-go:hover,.pt-leaf:hover{border-bottom-style:solid;text-shadow:0 0 8px var(--cyan-dim)}
  .pt-go{font-size:12px}
  @keyframes ptFlash{0%,40%{background:rgba(0,229,255,.22)}100%{background:transparent}}
  .pt-flash>td,.pt-flash .citem-head{animation:ptFlash 2.2s ease-out}
  .pt-tip{position:fixed;z-index:60;max-width:min(320px,calc(100vw - 24px));background:var(--panel-2);border:1px solid var(--border);
    border-left:3px solid var(--cyan);border-radius:8px;padding:9px 12px;box-shadow:0 10px 28px rgba(0,0,0,.5);pointer-events:none;display:none}
  .pt-tip.show{display:block}
  .pt-tip .pt-tip-head{font-family:var(--mono);font-size:10px;letter-spacing:1.2px;text-transform:uppercase;color:var(--text-mute);margin-bottom:4px}
  .pt-tip .pt-tip-name{font-family:var(--mono);font-size:12.5px;color:var(--text);margin-bottom:4px}
  .pt-tip .pt-tip-text{font-family:var(--sans);font-size:13px;line-height:1.45;color:var(--text-dim)}
  .fd-other .audio-bar{display:none}
  .pt-tip .pt-tip-more{font-family:var(--mono);font-size:11px;font-style:italic;color:var(--text-mute);margin-top:6px}
</style>'''
rep('</style>', CSS, 'css')

# ---------------------------------------------------------------- render script (runs before the template's script)
RENDER = r'''<script id="fd-doc" type="application/json">__DOC__</script>
<script id="fd-notes" type="application/json">__NOTES__</script>
<script id="fd-render">
/* ======== fusion-doc renderer: builds every section from DOC + NOTES ======== */
(function(){
  const DEFAULT_DOC = JSON.parse(document.getElementById('fd-doc').textContent);
  const NOTES = JSON.parse(document.getElementById('fd-notes').textContent);
  const KEY = 'fusion-doc:' + (NOTES.key || NOTES.operation || 'default');

  function validate(d){
    if(!d || typeof d !== 'object' || Array.isArray(d)) return {ok:false, msg:'JSON must be an object.'};
    if(!d.tabs || typeof d.tabs !== 'object' || Array.isArray(d.tabs) || !Object.keys(d.tabs).length)
      return {ok:false, msg:'Missing "tabs": an object of tab → group → [parameters].'};
    for(const [t,g] of Object.entries(d.tabs)){
      if(!g || typeof g !== 'object' || Array.isArray(g) || !Object.keys(g).length) return {ok:false, msg:`Tab "${t}" must be an object of groups.`};
      for(const [gn,ps] of Object.entries(g))
        if(!Array.isArray(ps) || !ps.length || ps.some(p=>typeof p !== 'string')) return {ok:false, msg:`Group "${t} › ${gn}" must be a non-empty array of parameter names.`};
    }
    return {ok:true};
  }
  function readStored(){
    try{ const v = localStorage.getItem(KEY); if(v) return JSON.parse(v); }catch(e){}
    try{ if(window.name && window.name.startsWith(KEY+'=')) return JSON.parse(window.name.slice(KEY.length+1)); }catch(e){}
    return null;
  }
  function save(obj){
    const txt = JSON.stringify(obj);
    let ok = false;
    try{ localStorage.setItem(KEY, txt); ok = localStorage.getItem(KEY) === txt; }catch(e){}
    if(!ok){ try{ window.name = KEY + '=' + txt; ok = true; }catch(e){} }
    if(ok) location.reload();
    return ok;
  }
  function reset(){
    try{ localStorage.removeItem(KEY); }catch(e){}
    try{ if(window.name && window.name.startsWith(KEY+'=')) window.name=''; }catch(e){}
    location.reload();
  }
  const stored = readStored();
  const custom = !!(stored && stored.doc && validate(stored.doc).ok);
  const STATE = custom
    ? {doc:stored.doc, url:stored.url || '', name:stored.name || 'uploaded JSON', custom:true}
    : {doc:DEFAULT_DOC, url:(stored && stored.url) || NOTES.doc_url || DEFAULT_DOC.url || '', name:NOTES.source_name || 'embedded JSON', custom:false};
  if(stored && !custom && stored.url) STATE.urlOnly = true;
  const doc = STATE.doc;
  const OP = doc.operation || 'Fusion command';
  const sameOp = !custom || (NOTES.operation && OP === NOTES.operation);
  if(!sameOp) document.documentElement.classList.add('fd-other');   // the audio describes the original command

  /* static sections (Search, Mind Map, Glossary) come from the vibe-dashboard patches; keep them */
  const MAIN = document.getElementById('content');
  const STATIC = {}, SROW = {};
  MAIN.querySelectorAll(':scope > .section').forEach(sec => { if(sec.dataset.title !== 'Dashboard Summary') STATIC[sec.dataset.title] = sec; });
  MAIN.querySelectorAll('.section[data-title="Dashboard Summary"] tbody tr').forEach(r => {
    const c = r.cells; if(c.length >= 5) SROW[c[1].textContent.trim()] = [c[3].textContent.trim(), c[4].textContent.trim()]; });

  /* ---------- helpers ---------- */
  const esc = t => String(t ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const slug = t => String(t).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'') || 'x';
  const first = t => { t = String(t||'').replace(/\s+/g,' ').trim(); const m = t.match(/^.*?[.!?](?=\s|$)/); return m ? m[0] : t; };
  const plural = (n,w) => n + ' ' + w + (n===1 ? '' : 's');
  const andList = a => a.length < 2 ? a.join('') : a.slice(0,-1).join(', ') + ' and ' + a[a.length-1];
  const TABS = Object.keys(doc.tabs);
  const tabTitle = t => t + ' tab';
  const NT = t => (NOTES.tabs || {})[t] || {};
  const NG = (t,g) => (NT(t).groups || {})[g] || {};
  const NP = (t,g,p) => (NG(t,g).params || {})[p];
  const groupsOf = t => doc.tabs[t];
  const countTab = t => Object.values(groupsOf(t)).reduce((n,ps)=>n+ps.length, 0);
  const TOTAL = TABS.reduce((n,t)=>n+countTab(t), 0);
  const NGROUPS = TABS.reduce((n,t)=>n+Object.keys(groupsOf(t)).length, 0);
  const isUniform = t => {
    const lists = Object.values(groupsOf(t)); if(lists.length < 2 || lists[0].length > 4) return false;
    const k = JSON.stringify(lists[0]); return lists.every(l => JSON.stringify(l) === k);
  };
  let matched = 0;
  TABS.forEach(t => Object.entries(groupsOf(t)).forEach(([g,ps]) => ps.forEach(p => { if(NP(t,g,p) !== undefined) matched++; })));

  /* ---------- categories + colours ---------- */
  const PAL = {cyan:'#38dafa', green:'#38fa79', yellow:'#dafa38', orange:'#fa9938', pink:'#fa3899', magenta:'#ea38fa', violet:'#7938fa', blue:'#3879fa'};
  const hue = hex => { const n=parseInt(hex.slice(1),16), r=(n>>16&255)/255, g=(n>>8&255)/255, b=(n&255)/255, mx=Math.max(r,g,b), mn=Math.min(r,g,b), d=mx-mn;
    if(!d) return 0; let h = mx===r ? ((g-b)/d)%6 : mx===g ? (b-r)/d+2 : (r-g)/d+4; return (h*60+360)%360; };
  const hsl2hex = (h,s,l) => { s/=100; l/=100; const k=n=>(n+h/30)%12, a=s*Math.min(l,1-l), f=n=>l-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1)));
    return '#'+[f(0),f(8),f(4)].map(x=>Math.round(x*255).toString(16).padStart(2,'0')).join(''); };
  const used = [];
  const searchCol = getComputedStyle(document.documentElement).getPropertyValue('--cat-search').trim();
  if(searchCol) used.push(searchCol);
  function nextColour(pref){
    for(const c of pref){ if(!used.includes(c)){ used.push(c); return c; } }
    let best=0, bestD=-1;
    for(let h=0; h<360; h++){ const d = Math.min(...used.map(c=>{ const x=Math.abs(hue(c)-h); return Math.min(x,360-x); })); if(d>bestD){ bestD=d; best=h; } }
    const c = hsl2hex(best, 95, 60); used.push(c); return c;
  }
  const CATS = {};
  const addCat = (name, pref) => { if(!CATS[name]) CATS[name] = nextColour(pref); return name; };
  addCat('overview', [PAL.cyan]);
  addCat('source', [PAL.magenta]);
  const TABCAT = {};
  TABS.forEach(t => TABCAT[t] = addCat('tab-'+slug(t), [PAL.green, PAL.yellow, PAL.orange, PAL.blue, PAL.violet]));
  const EXTRAS = sameOp ? (NOTES.extra_sections || []) : [];
  EXTRAS.forEach(x => addCat(slug(x.category || 'workflow'), [PAL.pink]));
  let css = ':root{' + Object.entries(CATS).map(([n,c])=>`--cat-${n}:${c};`).join('') + '}\n';
  for(const [n,c] of Object.entries(CATS)){
    const v = parseInt(c.slice(1),16), rgb = [(v>>16)&255,(v>>8)&255,v&255].join(',');
    css += `.cat-${n} .cat-badge{color:var(--cat-${n});background:rgba(${rgb},.10)}
.cat-${n}{border-left:3px solid var(--cat-${n})}
.toc-chip.tc-${n}{border-left-color:var(--cat-${n})}
.toc-chip.tc-${n}:hover{color:var(--cat-${n})}
.toc-tip.tc-${n} .tip-badge{color:var(--cat-${n});background:rgba(${rgb},.10)}\n`;
  }
  const st = document.createElement('style'); st.id = 'fd-cats'; st.textContent = css; document.head.appendChild(st);

  /* ---------- section plan + numbering ---------- */
  const plan = [];
  const add = (title, cat, badge, build, summary) => plan.push({title, cat, badge, build, summary});
  const addStatic = title => { const el = STATIC[title]; if(!el) return;
    plan.push({title, cat: el.dataset.cat, badge: (el.querySelector('.cat-badge')?.textContent || '').trim(), el, summary: SROW[title] || ['', '']}); };
  const NUM = {}; const num = title => NUM[title];
  add('Dashboard Summary', 'overview', 'OVERVIEW', buildSummary, ['This overview and the section index', 'Getting oriented']);
  addStatic('Search');
  add('Input', 'source', 'INPUT', buildInput, ['Load a different parameter JSON and documentation URL', 'Documenting another Fusion command']);
  add('Parameter Map at a Glance', 'overview', 'OVERVIEW', buildMap, ['Counts and full parameter list per tab and group', 'Finding which tab a setting lives on']);
  add('Parameter Hierarchy', 'overview', 'OVERVIEW', buildTree, ['Collapsible tree: command → tab → group → parameter', 'Seeing the structure at a glance']);
  TABS.forEach(t => add(tabTitle(t), TABCAT[t], t.toUpperCase(), () => buildTab(t),
    [NT(t).focus || andList(Object.keys(groupsOf(t))), NT(t).when || `Working in the ${t} tab`]));
  EXTRAS.forEach(x => add(x.title, slug(x.category || 'workflow'), (x.badge || x.category || 'WORKFLOW').toUpperCase(), () => x.html,
    [x.focus || '', x.when || '']));
  addStatic('Mind Map');
  addStatic('Glossary');
  if(STATE.url || (NOTES.references||[]).length) add('References', 'source', 'SOURCE', buildRefs, ['Official documentation and other cited sources', 'Checking the original wording']);
  add('Source Document (Verbatim)', 'source', 'SOURCE', () => `      <p style="font-family:var(--mono);font-size:11.5px;color:var(--text-mute)">${esc(STATE.name)} — reproduced exactly as loaded.</p>\n      <pre id="verbatim"></pre>\n`,
    ['The parameter JSON exactly as loaded', 'Checking the raw source']);
  plan.forEach((p,i) => NUM[p.title] = String(i+1).padStart(2,'0'));

  /* ---------- table builder ---------- */
  function table(desc, cols, rows, opt){
    opt = opt || {};
    const attrs = Object.entries(opt.attrs || {}).map(([k,v])=>` ${k}="${esc(v)}"`).join('');
    return `      <div class="table-wrap${opt.noSort?' no-sort':''}" data-desc="${esc(desc)}"${attrs}>\n        <table>\n          <thead><tr>${cols.map(c=>typeof c==='string'?`<th>${c}</th>`:`<th${c.keep?' data-keep="1"':''}>${c.label}</th>`).join('')}</tr></thead>\n          <tbody>\n`
      + rows.map(r => `            <tr${r.key!==undefined?` data-key="${esc(r.key)}"`:''}>${r.cells.map(c=>`<td>${c}</td>`).join('')}</tr>\n`).join('')
      + `          </tbody>\n        </table>\n      </div>\n`;
  }
  const strongNL = t => `<strong class="nolink">${esc(t)}</strong>`;

  /* ---------- 01 summary ---------- */
  function buildSummary(){
    const intro = (sameOp && NOTES.summary_intro) ||
      `A browsable reference for every parameter in Fusion's <strong>${esc(OP)}</strong> — ${TOTAL} fields across the ${andList(TABS.map(tabTitle))}.` +
      (matched ? ` Each parameter has a plain-language description${matched<TOTAL?' where one has been written':''}.` : '');
    let h = `      <p>${intro}</p>\n`;
    const start = (sameOp && NOTES.start_here) ||
      `New here? Parameter Hierarchy shows the whole structure; open the tab you're working in from there. To document another Fusion command, use Input.`;
    h += `      <div class="callout"><span class="lbl">Start here</span>${start}</div>\n`;
    if(custom && matched < TOTAL)
      h += `      <div class="callout"><span class="lbl">Descriptions coverage</span>This JSON was loaded in the browser. Descriptions were written for <strong>${esc(NOTES.operation || 'another command')}</strong> and carry over by matching names — ${matched} of ${TOTAL} parameters have one. Ask Claude to rebuild the dashboard from this JSON for full coverage.</div>\n`;
    const rows = plan.map(p => ({cells:[
      p.title==='Source Document (Verbatim)' ? `<span class="secnum" data-target-title="Source Document (Verbatim)"></span>` : `<span class="secnum">${NUM[p.title]}</span>`,
      `<strong>${esc(p.title)}</strong>`,
      `<span class="cat-pill" style="--pc:var(--cat-${p.cat})">${esc(p.badge)}</span>`,
      esc(p.summary[0]), esc(p.summary[1])]}));
    h += table('What each section covers', ['#','Section',{label:'Category',keep:true},'Focus','Use When'], rows);
    return h;
  }

  /* ---------- input ---------- */
  function buildInput(){
    const src = custom ? `${esc(STATE.name)} (loaded in this browser)` : `${esc(STATE.name)} (built into this page)`;
    const urlCell = STATE.url ? `<a href="${esc(STATE.url)}" target="_blank" rel="noopener">${esc(STATE.url)}</a>` : '<span style="color:var(--text-mute)">none</span>';
    return `      <p>Load the parameter JSON for another Fusion command or toolpath, and paste the link to its Autodesk product-documentation page. The dashboard rebuilds from it: Dashboard Summary, Parameter Map at a Glance, Parameter Hierarchy and every tab section are regenerated. Descriptions carry over wherever tab, group and parameter names match. What you load is remembered in this browser only.</p>
      <div class="fd-input" id="fdInput">
        <div class="fd-row"><label for="fdUrl">Product documentation URL</label><input type="url" id="fdUrl" placeholder="https://help.autodesk.com/view/fusion360/ENU/?guid=…" value="${esc(STATE.url)}"></div>
        <div class="fd-row"><label for="fdFile">Parameter JSON file</label><input type="file" id="fdFile" accept=".json,application/json"></div>
        <div class="fd-row"><textarea id="fdPaste" spellcheck="false" placeholder="…or paste the JSON here"></textarea></div>
        <div class="fd-row"><button class="tool-btn" id="fdLoad">load &amp; rebuild</button><button class="tool-btn" id="fdReset"${(custom||STATE.urlOnly)?'':' disabled'}>reset to original</button><span class="fd-status" id="fdStatus"></span></div>
      </div>
      <dl class="fd-kv">
        <dt>Command</dt><dd>${esc(OP)}</dd>
        <dt>Source</dt><dd>${src}</dd>
        <dt>Size</dt><dd>${plural(TABS.length,'tab')} · ${plural(NGROUPS,'group')} · ${plural(TOTAL,'parameter')}</dd>
        <dt>Documentation</dt><dd>${urlCell}</dd>
        <dt>Descriptions</dt><dd>${matched} of ${TOTAL} parameters</dd>
      </dl>
      <div class="callout"><span class="lbl">JSON format</span>One object: the command name plus tabs → groups → parameter names, in dialog order. An optional "url" key is used as the documentation link.<pre class="fd-schema">{
  "operation": "2D Offset Roughing",
  "url": "https://help.autodesk.com/…",
  "tabs": {
    "Tool": {
      "Tool": ["Tool", "Coolant"],
      "Feed &amp; Speed": ["Spindle Speed", "Cutting Feedrate"]
    },
    "Heights": {
      "Clearance Height": ["From", "Offset"]
    }
  }
}</pre></div>
`;
  }

  /* ---------- parameter map ---------- */
  function buildMap(){
    const sizes = TABS.map(t=>[t,countTab(t)]).sort((a,b)=>b[1]-a[1]);
    let h = `      <p>The command has <strong>${plural(TABS.length,'tab')}</strong>, <strong>${plural(NGROUPS,'group')}</strong> and <strong>${plural(TOTAL,'parameter')}</strong>.`;
    if(sizes.length > 2){ const top = sizes[0][1] + sizes[1][1];
      h += ` <strong>${esc(tabTitle(sizes[0][0]))}</strong> and <strong>${esc(tabTitle(sizes[1][0]))}</strong> hold ${top} of them (${Math.round(100*top/TOTAL)}%) — that's where most of the tuning happens.`; }
    h += `</p>\n`;
    h += table('Tabs at a glance', ['Tab','Groups','Params','What lives there'],
      TABS.map(t => ({cells:[`<strong>${esc(tabTitle(t))}</strong>`, Object.keys(groupsOf(t)).length, countTab(t),
        esc(first(NT(t).intro) || andList(Object.keys(groupsOf(t))))]})));
    const rows = [];
    TABS.forEach(t => Object.entries(groupsOf(t)).forEach(([g,ps]) => rows.push({cells:[strongNL(g), esc(tabTitle(t)), ps.length, esc(ps.join(', '))]})));
    h += table('Every group and its parameters', ['Group','Tab','Params','Parameters'], rows);
    return h;
  }

  /* ---------- hierarchy tree ---------- */
  function buildTree(){
    let h = `      <p>The bare structure of the command, straight from the source JSON: <strong>${esc(OP)}</strong> → <strong>${plural(TABS.length,'tab')}</strong> → <strong>${plural(NGROUPS,'group')}</strong> → <strong>${plural(TOTAL,'parameter')}</strong>, in the same order they appear in Fusion's dialog. Use the buttons to open the tree to the level you want, or click any node to open or close it. Cyan items are links — a <strong>[NN]</strong> jumps to that tab or group's table, and a parameter name jumps to its row. Hover any link for a one-line description.</p>
      <div class="pt-bar"><button class="tool-btn pt-btn" data-pt="tabs">tabs</button><button class="tool-btn pt-btn" data-pt="groups">groups</button><button class="tool-btn pt-btn" data-pt="all">expand all</button><button class="tool-btn pt-btn" data-pt="none">collapse all</button></div>
      <div class="pt-tree">
<details class="pt-node pt-root"><summary><span class="pt-name nolink">${esc(OP)}</span><span class="pt-count">${plural(TABS.length,'tab')} · ${TOTAL} params</span></summary>
<div class="pt-kids">
`;
    TABS.forEach(t => {
      const n = NUM[tabTitle(t)], gs = groupsOf(t);
      h += `<details class="pt-node pt-tab" style="--tc:var(--cat-${TABCAT[t]})"><summary><span class="pt-name nolink">${esc(t)}</span><span class="pt-count">${plural(Object.keys(gs).length,'group')} · ${countTab(t)}</span><span class="pt-go" data-tab="${esc(t)}">[${n}]</span></summary>\n<div class="pt-kids">\n`;
      Object.entries(gs).forEach(([g,ps]) => {
        h += `<details class="pt-node pt-group"><summary><span class="pt-name nolink">${esc(g)}</span><span class="pt-count">${ps.length}</span><span class="pt-go" data-tab="${esc(t)}" data-group="${esc(g)}">[${n}]</span></summary>\n<ul class="pt-leaves">`
          + ps.map(p => `<li><span class="pt-leaf nolink" data-tab="${esc(t)}" data-group="${esc(g)}" data-param="${esc(p)}">${esc(p)}</span></li>`).join('') + `</ul></details>\n`;
      });
      h += `</div></details>\n`;
    });
    return h + `</div></details>\n      </div>\n`;
  }

  /* ---------- tab sections ---------- */
  function buildTab(t){
    const nt = NT(t), gs = groupsOf(t);
    let intro = nt.intro || `Every parameter on Fusion's ${esc(t)} tab, grouped as in the dialog.`;
    if(nt.related) intro += ' ' + nt.related;
    let h = `      <p>${intro}</p>\n`;
    if(isUniform(t)){
      const fields = Object.values(gs)[0];
      const pd = nt.param_desc || {};
      h += `      <p>Every group on this tab has the same ${fields.length===1?'field':'fields'}: ${andList(fields.map(f=>'<strong>'+esc(f)+'</strong>'+(pd[f]?' ('+esc(pd[f]).replace(/\.$/,'')+')':'')))}.${nt.uniform_note ? ' ' + nt.uniform_note : ''}</p>\n`;
      const label = nt.group_label || 'Group';
      h += table(nt.table_desc || `${label}s — ${fields.join(' / ')}`, [label, 'Purpose', ...fields.map(f=>'Typical ' + esc(f))],
        Object.keys(gs).map(g => ({key:g, cells:[strongNL(g), esc(NG(t,g).desc || '—'), ...fields.map(f => { const v = NP(t,g,f); return esc(Array.isArray(v) ? v[0] : (v || '—')); })]})),
        {noSort:true, attrs:{'data-tab':t, 'data-uniform':'1'}});
    } else {
      const tipLabel = nt.tip_label || NOTES.tip_label || 'Tip';
      Object.entries(gs).forEach(([g,ps]) => {
        const anyNote = ps.some(p => NP(t,g,p) !== undefined);
        const anyTip = ps.some(p => { const v = NP(t,g,p); return Array.isArray(v) && v[1]; });
        const cols = ['Parameter'].concat(anyNote ? ['What it does'] : []).concat(anyTip ? [esc(tipLabel)] : []);
        const rows = ps.map(p => { const v = NP(t,g,p), w = Array.isArray(v) ? v : (v ? [v] : []);
          const c = [strongNL(p)]; if(anyNote) c.push(esc(w[0] || '—')); if(anyTip) c.push(esc(w[1] || '—')); return {key:p, cells:c}; });
        h += table(`${g} — ${plural(ps.length,'parameter')}`, cols, rows, {attrs:{'data-tab':t, 'data-group':g}});
      });
    }
    (nt.callouts || []).forEach(c => h += `      <div class="callout"><span class="lbl">${esc(c.label)}</span>${c.text}</div>\n`);
    return h;
  }

  /* ---------- references ---------- */
  function buildRefs(){
    const rows = [];
    if(STATE.url){ let host = ''; try{ host = new URL(STATE.url).hostname; }catch(e){ host = '—'; }
      rows.push({cells:[`<strong>Autodesk Fusion product documentation</strong>`, `${esc(OP)} — official reference for this command's dialog`, esc(host),
        `<a href="${esc(STATE.url)}" target="_blank" rel="noopener">${esc((sameOp && NOTES.doc_label) || 'open page')}</a>`]}); }
    (sameOp ? (NOTES.references || []) : []).forEach(r => { let host=''; try{ host = new URL(r.url).hostname; }catch(e){}
      rows.push({cells:[`<strong>${esc(r.source)}</strong>`, esc(r.covers || ''), esc(host), `<a href="${esc(r.url)}" target="_blank" rel="noopener">${esc(r.label || 'open page')}</a>`]}); });
    return `      <p>Sources behind this dashboard.</p>\n` + table('Cited reference links', ['Source','What it covers','Domain','Webpage'], rows);
  }

  /* ---------- write header + sections ---------- */
  if(custom) document.title = OP;   // keep the published name unless another command was loaded
  document.getElementById('fdKicker').textContent = (sameOp && NOTES.kicker) || 'FUSION DOC REFERENCE';
  document.getElementById('fdTitle').textContent = (sameOp && NOTES.title) || OP;
  document.getElementById('fdSub').textContent = (sameOp && NOTES.subtitle) || `Every parameter, tab by tab — ${TOTAL} fields`;
  const by = ['<span>Autodesk Fusion' + (NOTES.workspace && sameOp ? ' · ' + esc(NOTES.workspace) : '') + '</span>', `<span>Source: ${esc(STATE.name)}</span>`];
  if(STATE.url) by.push(`<span>Autodesk Help: <a href="${esc(STATE.url)}" target="_blank" rel="noopener">${esc((sameOp && NOTES.doc_label) || 'product documentation')}</a></span>`);
  document.getElementById('fdByline').innerHTML = by.join('\n    ');
  MAIN.innerHTML = '';
  plan.forEach(p => {
    if(p.el){ const n = p.el.querySelector('.sec-num'); if(n) n.textContent = NUM[p.title]; MAIN.appendChild(p.el); return; }
    MAIN.insertAdjacentHTML('beforeend', `  <div class="section cat-${p.cat}" data-title="${esc(p.title)}" data-cat="${p.cat}">
    <div class="sec-head"><span class="sec-num">${NUM[p.title]}</span><span class="sec-title">${esc(p.title)}</span><span class="cat-badge">${esc(p.badge)}</span><span class="chevron">▶</span></div>
    <div class="sec-body${p.title==='Source Document (Verbatim)'?' verbatim-body':''}">
${p.build()}    </div>
  </div>
`);
  });
  window.__FD_VERBATIM = JSON.stringify(doc, null, 2);
  window.FD = {STATE, NOTES, KEY, validate, save, reset, NT, NG, NP, isUniform, groupsOf, first, plural, TABCAT};
})();
</script>
'''
RENDER = RENDER.replace('__DOC__', js_json(doc)).replace('__NOTES__', js_json(notes))
k = s.index('<script>', s.index('</footer>')); s = s[:k] + RENDER + s[k:]

# ---------------------------------------------------------------- UI script (after the template's script)
UI = r'''<script id="fd-ui">
/* ======== fusion-doc UI: tree buttons, tree jumps + tooltips, sticky bar, input form ======== */
(function(){
  const F = window.FD, norm = t => (t||'').replace(/\s+/g,' ').trim();
  const esc = t => String(t ?? '').replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));

  /* tree level buttons */
  document.querySelectorAll('.pt-btn').forEach(b => b.addEventListener('click', () => {
    const lvl = b.dataset.pt, tree = b.closest('.sec-body').querySelector('.pt-tree');
    tree.querySelectorAll('.pt-root').forEach(n => n.open = lvl !== 'none');
    tree.querySelectorAll('.pt-tab').forEach(n => n.open = (lvl==='groups' || lvl==='all'));
    tree.querySelectorAll('.pt-group').forEach(n => n.open = lvl === 'all');
  }));

  /* tree → section jumps */
  const secIdx = tab => sections.findIndex(s => s.dataset.title === tab + ' tab');
  function locate(tab, group, param){
    const sec = sections[secIdx(tab)]; if(!sec) return {};
    const uni = sec.querySelector('.table-wrap[data-uniform]');
    const wrap = uni || [...sec.querySelectorAll('.table-wrap[data-group]')].find(w => w.dataset.group === group);
    const item = wrap && wrap.closest('.citem');
    const key = uni ? group : param;
    const row = wrap && key && [...wrap.querySelectorAll('tbody tr')].find(r => r.dataset.key === key);
    return {sec, item, row};
  }
  function go(el, flashEl){
    fitVisibleTables(); syncFloatingHeaders();
    const jump = smooth => { const {anchor,line} = hitTarget(el);
      window.scrollTo({top:Math.max(0, anchor.getBoundingClientRect().top + window.scrollY - line), behavior: smooth ? 'smooth' : 'auto'}); };
    requestAnimationFrame(() => { jump(true); setTimeout(() => { jump(false); syncFloatingHeaders(); }, 800); });
    if(flashEl){ flashEl.classList.remove('pt-flash'); void flashEl.offsetWidth; flashEl.classList.add('pt-flash'); }
  }
  document.addEventListener('click', e => {
    const t = e.target.closest('.pt-go, .pt-leaf'); if(!t) return;
    e.preventDefault(); e.stopPropagation(); tip.classList.remove('show');
    const {tab, group, param} = t.dataset, i = secIdx(tab); if(i < 0) return;
    if(!group){ scrollToSection(i); return; }
    const {sec, item, row} = locate(tab, group, param);
    sec.classList.add('open');
    if(!item){ scrollToSection(i); return; }
    item.classList.add('open');
    const uniform = !!item.querySelector('[data-uniform]');
    const target = (param || uniform) && row ? row : item;
    go(target, target);
  }, true);

  /* tree tooltips */
  const tip = document.createElement('div'); tip.className = 'pt-tip'; document.body.appendChild(tip);
  function content(el){
    const {tab, group, param} = el.dataset, i = secIdx(tab); if(i < 0) return null;
    const nt = F.NT(tab), gs = F.groupsOf(tab), n = sections[i].querySelector('.sec-num')?.textContent.trim();
    if(!group){
      const ng = Object.keys(gs).length, np = Object.values(gs).reduce((a,p)=>a+p.length,0);
      return {head:`Tab · section ${n}`, name:tab + ' tab', text: F.first(nt.intro) || `${F.plural(ng,'group')} and ${F.plural(np,'parameter')}.`};
    }
    const ps = gs[group] || [], ng = F.NG(tab, group);
    if(!param){
      return {head:`${tab} tab · group · ${F.plural(ps.length,'parameter')}`, name:group, text: ng.desc || `${ps.join(', ')}.`};
    }
    const v = F.NP(tab, group, param);
    if(F.isUniform(tab)){
      const pd = (nt.param_desc || {})[param];
      const typ = Array.isArray(v) ? v[0] : v;
      return {head:`${tab} › ${group}`, name:param, text: [pd, typ ? 'Typical: ' + typ : ''].filter(Boolean).join(' ') || 'No description yet.'};
    }
    const w = Array.isArray(v) ? v[0] : v;
    return {head:`${tab} › ${group}`, name:param, text: F.first(w) || 'No description yet.'};
  }
  function place(e){
    const pad = 12, r = tip.getBoundingClientRect(); let x = e.clientX + 14, y = e.clientY + 16;
    if(x + r.width > window.innerWidth - pad) x = Math.max(pad, e.clientX - r.width - 14);
    if(y + r.height > window.innerHeight - pad) y = Math.max(pad, e.clientY - r.height - 14);
    tip.style.left = x + 'px'; tip.style.top = y + 'px';
  }
  document.addEventListener('mouseover', e => {
    const el = e.target.closest('.pt-leaf, .pt-go'); if(!el) return;
    const c = content(el); if(!c){ tip.classList.remove('show'); return; }
    tip.innerHTML = `<div class="pt-tip-head">${esc(c.head)}</div><div class="pt-tip-name">${esc(c.name)}</div><div class="pt-tip-text">${esc(c.text)}</div><div class="pt-tip-more">(click for more…)</div>`;
    tip.style.borderLeftColor = `var(--cat-${F.TABCAT[el.dataset.tab]})`;
    tip.classList.add('show'); place(e);
  });
  document.addEventListener('mousemove', e => { if(tip.classList.contains('show') && e.target.closest('.pt-leaf, .pt-go')) place(e); });
  document.addEventListener('mouseout', e => { const el = e.target.closest('.pt-leaf, .pt-go'); if(el && !el.contains(e.relatedTarget)) tip.classList.remove('show'); });
  window.addEventListener('scroll', () => tip.classList.remove('show'), {passive:true});

  /* sticky tree bar: shadow only while pinned */
  const bars = [...document.querySelectorAll('.pt-bar')];
  const upd = () => bars.forEach(b => { const top = parseFloat(getComputedStyle(b).top) || 0;
    b.classList.toggle('stuck', !!b.offsetParent && Math.abs(b.getBoundingClientRect().top - top) < 1.5 && b.closest('.sec-body').getBoundingClientRect().top < top - 2); });
  window.addEventListener('scroll', upd, {passive:true}); window.addEventListener('resize', upd); upd();

  /* input form */
  const $ = id => document.getElementById(id);
  const status = (msg, cls) => { const s = $('fdStatus'); s.textContent = msg; s.className = 'fd-status' + (cls ? ' ' + cls : ''); };
  let fileText = null, fileName = '';
  $('fdFile').addEventListener('change', e => {
    const f = e.target.files[0]; fileText = null; fileName = '';
    if(!f) return;
    const r = new FileReader();
    r.onload = () => { fileText = r.result; fileName = f.name; status('ready: ' + f.name); };
    r.onerror = () => status('could not read ' + f.name, 'err');
    r.readAsText(f);
  });
  $('fdLoad').addEventListener('click', () => {
    const url = $('fdUrl').value.trim();
    if(url && !/^https?:\/\//i.test(url)){ status('the URL must start with http:// or https://', 'err'); return; }
    const raw = fileText != null ? fileText : $('fdPaste').value.trim();
    let doc = null, name = F.STATE.name;
    if(raw){
      try{ doc = JSON.parse(raw); }catch(err){ status('not valid JSON: ' + err.message, 'err'); return; }
      const v = F.validate(doc); if(!v.ok){ status(v.msg, 'err'); return; }
      name = fileText != null ? fileName : 'pasted JSON';
    }
    if(!doc && url === (F.STATE.url || '')){ status('nothing new to load — choose a file, paste JSON or change the URL', 'err'); return; }
    const out = doc ? {doc, url: url || doc.url || '', name} : (F.STATE.custom ? {doc:F.STATE.doc, url, name:F.STATE.name} : {url});
    status('rebuilding…', 'ok');
    if(!F.save(out)) status('this browser blocked storage — the page cannot remember the new input', 'err');
  });
  $('fdReset').addEventListener('click', () => F.reset());
})();
</script>
</body>'''
rep('</body>', UI, 'ui insert')

assert '{{' not in s, [l for l in s.splitlines() if '{{' in l][:5]
# reserve every palette colour while the Search patch picks its own, so it can't clash with the runtime tab colours
RES = ['#38dafa', '#38fa79', '#dafa38', '#fa9938', '#fa3899', '#ea38fa', '#7938fa', '#3879fa']
k = s.index('--cat-source:'); k = s.index('\n', k) + 1
s = s[:k] + ''.join('    --cat-fdres%d:%s;\n' % (i, c) for i, c in enumerate(RES)) + s[k:]
open(out_path, 'w', encoding='utf-8').write(s)
sk = open(os.path.join(VIBE, 'SKILL.md'), encoding='utf-8').read()
blocks = re.findall(r'`{3}python\n(.*?)`{3}', sk, re.S)
pick = lambda test: next(b for b in blocks if test(b))
os.makedirs(WD, exist_ok=True)
open(os.path.join(WD, 'fit_patch.py'), 'w').write(pick(lambda b: 'function bodyWordMin(' in b and 'table-fit patch' in b))
open(os.path.join(WD, 'mindmap_patch.py'), 'w').write(pick(lambda b: '"""mindmap_patch.py' in b))
open(os.path.join(WD, 'stress_audio.py'), 'w').write(pick(lambda b: 'stress_audio.py — run' in b))
for cmd in (['python3', os.path.join(WD, 'fit_patch.py'), out_path], ['python3', os.path.join(VIBE, 'scripts/search_patch.py'), out_path],
            ['python3', os.path.join(WD, 'mindmap_patch.py'), out_path]):
    r = subprocess.run(cmd, capture_output=True, text=True); print(r.stdout.strip() or r.stderr.strip())
    if r.returncode: sys.exit('patch failed: ' + ' '.join(cmd))
s = open(out_path, encoding='utf-8').read()
s = re.sub(r'    --cat-fdres\d:#[0-9a-f]{6};\n', '', s)
assert 'dataset.keep' in s, 'the table-fit patch dropped the data-keep rule'
open(out_path, 'w', encoding='utf-8').write(s)
if not GLOSS: print('NO GLOSSARY: add notes.glossary (10-20 terms)')
print('built', out_path, '· stress_audio.py saved in', WD)
```

## Changes

- **Nov 9, 2026:** Fixed the build for the current vibe-dashboard template: the build script reads the template directly (the old "Template patch" step is gone) and finds its anchors even where the template changed. Added Search, Mind Map, Glossary (`notes.glossary`), table fitting and the audio overview, which hides when another command is loaded through Input. Noted that the parameter JSON comes from the Autodesk Assistant in Fusion.
