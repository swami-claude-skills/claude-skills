# Installers

Fusion loads add-ins from a specific per-user `AddIns` folder. Non-technical users won't want to find it and drag files by hand, so ship double-clickable installers that copy the add-in there for them. Provide all three so the add-in works on either OS:

- **macOS** — `install-macos.command` (double-clickable in Finder)
- **Windows** — `install-windows.cmd` (double-clickable) which launches `install-windows.ps1` (the actual logic)

Place all three inside the add-in folder itself, alongside the `.py`/`.manifest`. Each script locates its own folder, so it works no matter where the user unzips it. The installers exclude themselves (and `__pycache__`/`.DS_Store`) from what they copy, so the installed add-in stays clean.

## The AddIns destination

- **macOS**: `~/Library/Application Support/Autodesk/Autodesk Fusion 360/API/AddIns/`
- **Windows**: `%APPDATA%\Autodesk\Autodesk Fusion 360\API\AddIns\`

The add-in must land in a subfolder there named exactly like the add-in (matching the `.py`/`.manifest` names), e.g. `AddIns/VisibilityTools/VisibilityTools.py`. Resolve these paths from `$HOME` / `%APPDATA%` — never hard-code an absolute user path.

## Portability notes (learned the hard way)

- **Don't depend on `rsync`** in the macOS script — it isn't guaranteed present. Use `cp -R "$SRC/." "$DEST/"` and then delete the installer files and caches from the destination. `cp` is always there; `rsync` sometimes isn't.
- **Guard for a missing Fusion install.** If the `AddIns` root doesn't exist, print a clear message ("Is Fusion installed for this user?") and exit rather than silently creating folders in the wrong place.
- **Keep a prompt at the end** (`read`/`Read-Host`) so a double-clicked window doesn't vanish before the user reads the result.
- **The `.cmd` bypasses execution policy for one process only** (`-ExecutionPolicy Bypass` on that single invocation) — it does not change any system setting. This is what lets a user run the `.ps1` by double-clicking without touching their machine's policy.
- Set the add-in name in **one place** at the top of each script (a single variable) so renaming the add-in means one edit per file.

## Templates

Replace `VisibilityTools` with the actual add-in name (one spot at the top of each).

### `install-macos.command`

```bash
#!/bin/bash
# Double-click installer for macOS. Copies this add-in into Fusion's AddIns folder.
set -euo pipefail

ADDIN_NAME="VisibilityTools"   # <-- set to the add-in folder name

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST_ROOT="$HOME/Library/Application Support/Autodesk/Autodesk Fusion 360/API/AddIns"
DEST_DIR="$DEST_ROOT/$ADDIN_NAME"

echo "Installing $ADDIN_NAME ..."
echo "  from: $SRC_DIR"
echo "  to:   $DEST_DIR"

if [ ! -d "$DEST_ROOT" ]; then
    echo "AddIns folder not found. Is Fusion installed for this user?"
    echo "Expected: $DEST_ROOT"
    read -r -p "Press Return to close."
    exit 1
fi

rm -rf "$DEST_DIR"
mkdir -p "$DEST_DIR"
cp -R "$SRC_DIR"/. "$DEST_DIR"/
rm -f  "$DEST_DIR"/*.command "$DEST_DIR"/*.ps1 "$DEST_DIR"/*.cmd "$DEST_DIR"/.DS_Store
find "$DEST_DIR" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true

echo ""
echo "Done. In Fusion: Utilities > Add-Ins > Scripts and Add-Ins (Shift+S),"
echo "select \"$ADDIN_NAME\" under Add-Ins, and click Run."
read -r -p "Press Return to close."
```

After creating it, mark it executable so double-click works: `chmod +x install-macos.command`. (On first run some users still need to right-click > Open once, because macOS Gatekeeper flags unsigned `.command` files — mention this to them.)

### `install-windows.ps1`

```powershell
# PowerShell installer for Windows. Copies this add-in into Fusion's AddIns folder.
$AddinName = "VisibilityTools"   # <-- set to the add-in folder name

$ErrorActionPreference = "Stop"

$SrcDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$DestRoot = Join-Path $env:APPDATA "Autodesk\Autodesk Fusion 360\API\AddIns"
$DestDir  = Join-Path $DestRoot $AddinName

Write-Host "Installing $AddinName ..."
Write-Host "  from: $SrcDir"
Write-Host "  to:   $DestDir"

if (-not (Test-Path $DestRoot)) {
    Write-Host "AddIns folder not found. Is Fusion installed for this user?" -ForegroundColor Yellow
    Write-Host "Expected: $DestRoot"
    Read-Host "Press Enter to close"
    exit 1
}

if (Test-Path $DestDir) { Remove-Item $DestDir -Recurse -Force }
New-Item -ItemType Directory -Path $DestDir | Out-Null

$exclude = @("install-windows.ps1", "install-windows.cmd", "install-macos.command", "__pycache__")
Get-ChildItem -Path $SrcDir -Force | Where-Object { $exclude -notcontains $_.Name } | ForEach-Object {
    Copy-Item $_.FullName -Destination $DestDir -Recurse -Force
}

Write-Host ""
Write-Host "Done. In Fusion: Utilities > Add-Ins > Scripts and Add-Ins (Shift+S)," -ForegroundColor Green
Write-Host "select `"$AddinName`" under Add-Ins, and click Run."
Read-Host "Press Enter to close"
```

### `install-windows.cmd`

```bat
@echo off
REM Double-click launcher. Runs the PowerShell installer next to it, bypassing
REM execution policy for this one process only (no system change).
setlocal
set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%install-windows.ps1"
endlocal
```

## Testing what you can

You usually can't run Fusion (or PowerShell/macOS) in the build environment, but you can still catch the common breakers:

- `bash -n install-macos.command` for shell syntax, and — if you can point `$HOME` at a temp dir with a fake `.../API/AddIns` root — actually run it and confirm it copies the right files and excludes the installers/caches.
- For the `.ps1`, if no PowerShell is available, inspect structurally: self-locating `$SrcDir`, `$env:APPDATA` path, the `Test-Path $DestRoot` guard, the clear-then-copy, the exclude list, and balanced braces/parens.
- Confirm every installer names the add-in identically to the `.py`/`.manifest`/folder — a mismatch here is why "it installed but doesn't show up in Fusion."
