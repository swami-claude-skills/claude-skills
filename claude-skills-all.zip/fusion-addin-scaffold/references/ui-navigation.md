# UI Navigation & Manipulation

For productivity add-ins that drive the existing Fusion environment rather than build geometry: firing built-in commands, working with the selection, traversing and filtering existing entities, toggling visibility, reorganizing the browser and timeline, and controlling the viewport.

Table of contents:
1. Firing built-in Fusion commands
2. The current selection
3. Traversing existing entities
4. Visibility (show / hide / isolate)
5. Placing buttons: panels and dropdown menus
6. Icons (required for shortcuts)
7. Keyboard shortcuts
8. Browser tree & naming
9. Timeline
10. Camera / viewport
11. Progress, messages, and user prompts

Assume `app = adsk.core.Application.get()`, `ui = app.userInterface`, and (where a design is needed) `design = app.activeProduct` with `root = design.rootComponent`.

---

## 1. Firing built-in Fusion commands

Any command Fusion ships (Fillet, Align, Measure, Zoom Fit, Save, etc.) has a command definition you can execute programmatically. This is the backbone of many productivity tools — you're automating clicks.

```python
cmd_def = ui.commandDefinitions.itemById('FusionFilletCommand')
if cmd_def:
    cmd_def.execute()
```

The catch is discovering the ID. IDs aren't documented exhaustively and don't always match the menu label. Two reliable ways to find them:

- **Log every command as it runs.** Temporarily subscribe to `ui.commandStarting` and print `args.commandId` while you click the command in Fusion once. That reveals the exact ID.

```python
class CmdSpyHandler(adsk.core.ApplicationCommandEventHandler):
    def notify(self, args):
        app.log('commandStarting: ' + args.commandId)  # or ui.messageBox
```

- **Enumerate them.** Iterate `ui.commandDefinitions` and dump `id` / `name` to find candidates.

Some commands are **modal** — executing them opens their dialog and waits for the user, rather than running headless. If you need a command to run without its dialog, you often can't force it; instead replicate the operation through the geometry/feature API. Note this limitation to the user rather than assuming `.execute()` will silently complete.

Common IDs worth knowing (verify against your version — they can change): `FitCommand` (zoom fit), `SelectCommand`, `FusionSaveCommand`, `VisibilityCommand`.

---

## 2. The current selection

Reading and driving the active selection is central to "act on what I've picked" tools.

```python
sels = ui.activeSelections
count = sels.count
for i in range(count):
    entity = sels.item(i).entity          # BRepBody, BRepFace, Sketch, Occurrence, ...
    print(entity.objectType)              # e.g. 'adsk::fusion::BRepBody'

# Filter what the selection contains
bodies = [sels.item(i).entity for i in range(sels.count)
          if isinstance(sels.item(i).entity, adsk.fusion.BRepBody)]

# Programmatically set the selection
sels.clear()
sels.add(some_entity)
```

To let the user pick interactively *inside your command*, use a selection command input (see command-inputs.md) rather than reading `activeSelections` — the input gives you filtering, prompts, and count limits for free. Read `activeSelections` when you want to act on whatever is *already* selected when the button is pressed.

---

## 3. Traversing existing entities

Productivity tools constantly walk the model to find things. The core collections off `rootComponent`:

```python
root.bRepBodies        # solid/surface bodies in the root
root.sketches          # sketches
root.occurrences       # child component instances (Design/Assembly only)
root.joints
root.constructionPlanes
root.features           # all feature types live under here
design.allComponents    # every unique component definition
```

Recursively walk all occurrences (the whole assembly tree):

```python
def walk(occurrences, depth=0):
    for occ in occurrences:
        yield occ, depth
        yield from walk(occ.childOccurrences, depth + 1)

for occ, depth in walk(root.occurrences):
    print('  ' * depth + occ.name)
```

Bodies live on components, so to collect every body in an assembly, walk occurrences and read `occ.component.bRepBodies` (or `occ.bRepBodies` for the instance-level proxies). Use the proxy (`occ.bRepBodies`) when you need to act on a specific instance's placement; use the component's collection when the definition is what matters.

Filtering by property is just Python:

```python
big = [b for b in root.bRepBodies if b.physicalProperties.mass > 0.1]
visible = [b for b in root.bRepBodies if b.isVisible]
```

---

## 4. Visibility (show / hide / isolate)

Toggling visibility is one of the most-requested productivity actions.

```python
# Hide / show individual entities
body.isVisible = False
sketch.isVisible = True
occ.isVisible = False
construction_plane.isVisible = False

# Hide every sketch
for sk in root.sketches:
    sk.isVisible = False

# "Isolate" pattern: show only the target, hide siblings
for b in root.bRepBodies:
    b.isVisible = (b == target_body)
```

For whole categories (all sketches, all origins, all joints), Fusion also exposes light-bulb toggles via the built-in commands, but iterating `isVisible` as above is the most direct and predictable route from an add-in.

Light-bulb state vs. computed visibility: `isVisible` is the toggle you control; an entity can still be effectively hidden because a parent is off. If a body won't appear after setting `isVisible = True`, check its parent occurrence's visibility too.

### Where each entity type lives

A visibility tool that covers more than bodies needs the right collection for each type. They are *not* all in one place:

```python
root.sketches                 # sketches
root.bRepBodies               # bodies in the root component
root.occurrences              # component instances (see the components note below)
root.constructionPlanes       # construction geometry is THREE collections, not one:
root.constructionAxes
root.constructionPoints
root.joints                   # joints
# Origin geometry: the origin folder's planes/axis/point are construction entities
# on the component; there is no single "origins" collection — toggle the individual
# xYConstructionPlane / xConstructionAxis / originConstructionPoint etc.
```

Two things that trip people up:

- **"Construction folders" aren't API objects.** The browser groups construction geometry and origins into folders visually, but there's no folder object to toggle — you iterate the underlying `constructionPlanes` / `constructionAxes` / `constructionPoints` and set each one's `isVisible`. To cover "construction geometry," chain all three collections.
- **Components vs. occurrences.** A component's visibility is really its *occurrence's* `isVisible`. The same component can appear as several occurrences, each independently visible. So "hide component X" is ambiguous: all instances, or the one the user selected? Support both as separate commands if the user wants both — hide-all-instances walks every occurrence whose `.component` matches; hide-selected toggles just the picked occurrence.

```python
# Hide all instances of a given component
for occ in _all_occurrences(root):        # recursive walk, see §3
    if occ.component == target_component:
        occ.isVisible = False

# Hide only the selected occurrence
selected_occ.isVisible = False
```

### The show/hide/isolate matrix

Once you cover several entity types × several actions (show, hide, isolate), don't hand-write a function per cell — that's a dozen near-identical commands. Drive it from data: one helper that sets visibility across any collection, and a small table mapping (entity type → how to fetch its collection). See `templates.md` → "command factory" for the full pattern that turns this table into buttons automatically.

```python
def set_visibility(items, value):
    """Works for any collection whose members have .isVisible. Returns (ok, failures)."""
    ok, failed = 0, []
    for it in items:
        try:
            it.isVisible = value
            ok += 1
        except Exception as e:
            failed.append('{}: {}'.format(getattr(it, 'name', '?'), e))
    return ok, failed

def construction_geometry(root):
    return list(root.constructionPlanes) + list(root.constructionAxes) + list(root.constructionPoints)

# "Show all X" is set_visibility(fetch(root), True); "Hide all X" is the same with False.
# "Isolate" is: for it in fetch(root): it.isVisible = (it == target)
```

---

## 5. Placing buttons: panels and dropdown menus

The default template drops a button directly into a panel. To put it where it belongs for your tool, target the right workspace and panel — and when you have several related commands, group them under a **dropdown menu** so the panel doesn't get cluttered.

**Directly on a panel:**

```python
ws = ui.workspaces.itemById('FusionSolidEnvironment')      # the DESIGN workspace
panel = ui.allToolbarPanels.itemById('SolidModifyPanel')   # e.g. the MODIFY panel
control = panel.controls.itemById(CMD_ID)
if not control:
    panel.controls.addCommand(cmd_def)
```

**In a dropdown menu on the panel** (a sub-menu that expands to show your commands):

```python
DROPDOWN_ID = 'myToolsDropdown'

panel = ui.allToolbarPanels.itemById('SolidScriptsAddinsPanel')

# Create the dropdown once; reuse it if it already exists.
dropdown = panel.controls.itemById(DROPDOWN_ID)
if not dropdown:
    dropdown = panel.controls.addDropDown(
        'My Tools',                 # visible label
        './resources/mytools',      # folder with the dropdown's own icon (16/32/64 png)
        DROPDOWN_ID)

# Add commands into the dropdown instead of straight onto the panel.
if not dropdown.controls.itemById(CMD_ID):
    dropdown.controls.addCommand(cmd_def)
# Add more commands to the same dropdown:
# dropdown.controls.addCommand(other_cmd_def)
# A separator between groups of commands inside the dropdown:
# dropdown.controls.addSeparator()
```

Teardown must delete the commands **and** the dropdown, deepest first:

```python
def stop(context):
    try:
        panel = ui.allToolbarPanels.itemById('SolidScriptsAddinsPanel')
        dropdown = panel.controls.itemById(DROPDOWN_ID)
        if dropdown:
            ctrl = dropdown.controls.itemById(CMD_ID)
            if ctrl:
                ctrl.deleteMe()
            # delete any other commands you added to the dropdown here, then:
            dropdown.deleteMe()
        cmd_def = ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def:
            cmd_def.deleteMe()
    except:
        ui.messageBox('stop failed:\n{}'.format(traceback.format_exc()))
```

Forgetting to delete the dropdown leaves an empty "My Tools" menu stacking up on every reload — the classic clutter bug for multi-command add-ins.

**Right-click (context) menu** instead of a panel:

```python
class ContextMenuHandler(adsk.core.MarkupEventHandler):
    def notify(self, args):
        args.linearMarkup.controls.addCommand(cmd_def)
# connect via ui.markupContextMenuDisplaying / ui.contextMenuDisplaying
```

Useful workspace IDs: `FusionSolidEnvironment` (Design), `CAMEnvironment` (Manufacture), `FusionRenderEnvironment`. Useful panel IDs: `SolidCreatePanel`, `SolidModifyPanel`, `SolidScriptsAddinsPanel`, `InspectPanel`. Every control **and** dropdown you add needs a matching `deleteMe()` in `stop()`.

---

## 6. Icons (required for shortcuts)

Two independent reasons to give a command an icon: it shows a real button instead of a blank one in the panel/dropdown, and — importantly — **Fusion only lets the user assign a keyboard shortcut to a command that has an icon resource.** A command defined without a resource folder can't be given a shortcut through the UI. So if the user wants a shortcut, an icon is not optional.

**Wiring the icon** — pass a resource *folder* (not a file) as the last argument when defining the button:

```python
cmd_def = ui.commandDefinitions.addButtonDefinition(
    CMD_ID, CMD_NAME, CMD_DESC,
    './resources/command')      # folder, relative to the .py file
```

**What goes in that folder** — Fusion picks the right size for each context (panel, dropdown, tooltip), so supply multiple scales. Two supported formats:

- **PNG** (most common): provide `16x16.png`, `32x32.png`, and `64x64.png` (some setups also use `16x16@2x.png`/`32x32@2x.png` for high-DPI). Exact-named square PNGs at those pixel sizes. This is the safest, most widely compatible choice.
- **SVG**: a single scalable `icon.svg` can be used; Fusion rasterizes it per context. SVG avoids maintaining multiple PNGs and stays crisp at any DPI, but test it — some Fusion versions are pickier about SVG than PNG, so if an SVG icon renders blank, fall back to the PNG set.

```
MyAddin/
├── MyAddin.py
├── MyAddin.manifest
└── resources/
    └── command/
        ├── 16x16.png
        ├── 32x32.png
        ├── 64x64.png
        └── (or) icon.svg
```

If you're generating a placeholder icon programmatically for the user, a simple flat glyph on a transparent background reads best at 16px — avoid fine detail that turns to mush when scaled down. Keep the artwork square and centered with a little padding.

**When generating multiple icons, verify they're distinct — not just present.** After creating them, render all the 16px versions side by side (e.g. composite them onto one strip and upscale it with nearest-neighbor sampling so you can eyeball the pixels) and confirm each glyph is distinguishable *from the others and from the dropdown icon*. Accidentally reusing the same glyph for two commands — or giving a command the same icon as its parent dropdown — is a common, easy-to-miss mistake, because each icon looks fine in isolation; the problem only appears when they sit next to each other in the panel. If two read the same, differentiate one (add a slash, a bracket, a distinguishing mark) and re-render until every icon is unique. This visual check catches what a code review can't.

---

## 7. Keyboard shortcuts

Users assign shortcuts to a command through Fusion's UI — hover the command's button, click the "…" / right-click, and choose **Change Keyboard Shortcut** (or via Preferences). Your add-in's job is to make the command *eligible* and easy to find:

1. **Give the command an icon** (section 6). Without a resource folder, the command has no button to hover and Fusion won't offer a shortcut for it. This is the most common reason "I can't set a shortcut for my add-in."
2. **Put the button somewhere reachable** — a panel or dropdown (section 5), so there's a UI target to right-click.
3. That's it — the user picks the actual key combination themselves. Shortcut assignments are stored in the user's Fusion preferences, persist across sessions, and are **not** something the add-in sets programmatically; there's no supported API to hard-code a specific hotkey, so don't promise one. Instead, tell the user the exact steps to bind it.

If the user asks for a *suggested* shortcut, put it in the command's tooltip/description text so it's discoverable, but the binding itself remains theirs to set:

```python
cmd_def = ui.commandDefinitions.addButtonDefinition(
    CMD_ID, CMD_NAME,
    'Hide all sketches. Tip: assign a shortcut via right-click on this button.',
    './resources/command')
```

So the full recipe for a shortcut-able tool is: **icon folder → button definition pointing at it → placed in a panel/dropdown → tell the user how to bind the key.**

---

## 8. Browser tree & naming

Renaming and reorganizing the browser is classic productivity-tool territory.

```python
# Rename
occ.component.name = 'Bracket-L'
body.name = 'Housing'
sketch.name = 'Base Profile'

# Batch rename by pattern
for i, occ in enumerate(root.occurrences, start=1):
    occ.component.name = 'Part-{:03d}'.format(i)

# Expand/collapse and light-bulb are on the browser via attributes; for grouping,
# operate on the component structure (occurrences) rather than the visual tree.
```

Renaming a component renames its definition (affects all instances); renaming through an occurrence's `.component` is the same thing. If the user wants per-instance labels, that's the occurrence's own `name` (the "Part:1" style suffix is instance identity and is read-only).

---

## 9. Timeline

Parametric documents expose the timeline for reordering, rolling back, and inspecting feature history.

```python
tl = design.timeline
tl.count
tl.markerPosition                 # current rollback position
tl.moveToEnd()
tl.moveToBeginning()

# Inspect / act on a specific item
item = tl.item(3)
item.rollTo(False)                # roll the marker to just after this item
entity = item.entity              # the feature/sketch that timeline node represents

# Roll back, do something, roll to end (a common batch pattern)
tl.moveToBeginning()
# ... operate ...
tl.moveToEnd()
```

Timeline exists only in **parametric** designs; in direct-modeling documents `design.timeline` isn't meaningful. Guard on `design.designType == adsk.fusion.DesignTypes.ParametricDesignType` before touching it.

---

## 10. Camera / viewport

Driving the view is common for "jump to X" tools.

```python
vp = app.activeViewport
cam = vp.camera

# Standard named views
cam.viewOrientation = adsk.core.ViewOrientations.TopViewOrientation
vp.camera = cam                   # reassign to apply — the camera is a value object
vp.fit()                          # zoom to fit

# Manual camera placement
cam.eye = adsk.core.Point3D.create(10, 10, 10)
cam.target = adsk.core.Point3D.create(0, 0, 0)
cam.upVector = adsk.core.Vector3D.create(0, 0, 1)
cam.isSmoothTransition = True
vp.camera = cam                   # MUST reassign; editing cam in place does nothing
```

The single biggest camera gotcha: `vp.camera` returns a **copy**. Mutating it doesn't change the view — you must assign the modified camera back to `vp.camera`. Forgetting the reassignment is why "my camera code runs but nothing moves."

`ViewOrientations` includes `TopViewOrientation`, `FrontViewOrientation`, `RightViewOrientation`, `IsoTopRightViewOrientation`, etc.

---

## 11. Progress, messages, and user prompts

For tools that churn through many entities, give feedback and let the user confirm.

```python
# Yes/no confirmation before a destructive batch action
result = ui.messageBox('Rename 42 components?', 'Confirm',
                       adsk.core.MessageBoxButtonTypes.YesNoButtonType)
if result == adsk.core.DialogResults.DialogYes:
    ...

# Progress bar for long loops
progress = ui.createProgressDialog()
progress.show('Working', 'Processing %v of %m', 0, len(items))
for i, item in enumerate(items):
    if progress.wasCancelled:
        break
    # ... work ...
    progress.progressValue = i + 1
progress.hide()

# Simple text prompt
(value, cancelled) = ui.inputBox('New prefix:', 'Rename', 'Part-')
```

Wrap batch mutations so a mid-loop failure doesn't leave the model half-changed — and remember the four rules from SKILL.md still apply to every command in a UI tool.
