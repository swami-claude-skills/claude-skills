# Error Handling

Fusion swallows unhandled exceptions — an add-in that throws just gets marked "failed to start" with no trace, and a command that throws mid-`execute` often leaves the model half-modified with no message. Good error handling is what turns those silent dead-ends into something diagnosable. This reference goes beyond the bare try/except in the templates.

Table of contents:
1. The layered pattern
2. Reporting: message box vs. log vs. palette
3. Guard clauses (fail early, fail clearly)
4. Transactions: don't leave the model half-changed
5. Batch operations: collect errors, don't abort on the first
6. Distinguishing user-cancel from real failure

---

## 1. The layered pattern

Every handler that Fusion calls (`run`, `stop`, and every `notify`) is a boundary where an exception would otherwise vanish. Wrap each one. The template does this minimally; the fuller pattern separates *expected* problems (bad input, wrong document type — report politely) from *unexpected* ones (a real bug — report with a traceback).

```python
import traceback

class CommandExecuteHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        try:
            run_the_actual_work(args)          # your logic in a plain function
        except UserError as e:
            # Expected, actionable: tell the user plainly, no traceback noise.
            ui.messageBox(str(e), 'Cannot continue')
        except:
            # Unexpected: this is a bug — show the traceback so it can be fixed.
            ui.messageBox('Unexpected error:\n{}'.format(traceback.format_exc()),
                          'Add-in error')


class UserError(Exception):
    """Raise for expected, user-facing problems (bad selection, no active design)."""
    pass
```

Keeping the real work in a separate function (not inline in `notify`) makes it testable and keeps the boundary thin. Raise `UserError('Select at least one body first.')` deep in your logic and it surfaces cleanly at the boundary.

---

## 2. Reporting: message box vs. log vs. palette

Three channels, different jobs:

- **`ui.messageBox(text, title)`** — interrupts the user. Use for things they must see: a validation failure that stopped the command, a confirmation result. Don't use inside a tight loop (it'll fire hundreds of dialogs).
- **`app.log(text)`** — writes to the Text Commands / console palette without interrupting. Use for progress traces, per-item diagnostics in a batch, and the command-ID spying from ui-navigation.md. `app.log('msg', adsk.core.LogLevels.InfoLogLevel, adsk.core.LogTypes.ConsoleLogType)` for control over level/destination.
- **A palette / textbox input** — for a *summary* of a batch run ("38 renamed, 4 skipped: …") that the user should read but that shouldn't be 42 separate dialogs.

Rule of thumb: one message box at the end of an operation, `app.log` for everything during it.

---

## 3. Guard clauses (fail early, fail clearly)

Most command failures aren't exceptions — they're wrong preconditions. Check them up front and return with a clear message instead of letting a `None` propagate into an obscure crash three calls later.

```python
def run_the_actual_work(args):
    product = app.activeProduct
    if not isinstance(product, adsk.fusion.Design):
        raise UserError('Open a Design document first.')
    design = product

    if design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
        raise UserError('This tool needs a parametric design (timeline present).')

    sels = ui.activeSelections
    if sels.count == 0:
        raise UserError('Select one or more bodies, then run the command.')
```

Guarding on document type is the same discipline as rule 3 in SKILL.md — the `CreateNewComponent()`/Part-type trap is really just a missing guard clause.

---

## 4. Transactions: don't leave the model half-changed

If a command makes several edits and fails partway, the user is left with a partial result and a full timeline. Wrap multi-step mutations in a timeline group so a failure can be rolled back as one unit, and so a *successful* run collapses to a single undo step.

```python
design = adsk.fusion.Design.cast(app.activeProduct)
tl = design.timeline
start = tl.markerPosition
try:
    # ... several feature/edit operations ...
    end = tl.markerPosition
    if end > start + 1:
        tl.timelineGroups.add(start, end - 1)   # collapse into one undo-able group
except:
    # Roll the timeline back to where we started so the user isn't left mid-edit.
    tl.markerPosition = start
    raise
```

Timeline groups only exist in parametric designs; in direct mode, do your own cleanup (delete bodies you created) in the `except`. Either way, the goal is: a failed command should leave the document as close as possible to how it started.

---

## 5. Batch operations: collect errors, don't abort on the first

When looping over many entities (rename all, hide all, run X on each selection), one bad item shouldn't kill the whole run. Catch per-item, tally, and report a summary.

```python
succeeded, failed = 0, []
for item in items:
    try:
        do_one(item)
        succeeded += 1
    except Exception as e:
        failed.append('{}: {}'.format(getattr(item, 'name', '?'), e))

summary = '{} succeeded.'.format(succeeded)
if failed:
    summary += '\n{} failed:\n'.format(len(failed)) + '\n'.join(failed[:20])
    if len(failed) > 20:
        summary += '\n… and {} more.'.format(len(failed) - 20)
ui.messageBox(summary, 'Batch complete')
```

This is the difference between "it stopped on component 3 of 40 with a cryptic error" and "37 done, 3 skipped, here's which ones and why."

---

## 6. Distinguishing user-cancel from real failure

Some API calls raise when the user cancels a dialog, and a cancel is not an error — don't show a traceback for it.

```python
(value, cancelled) = ui.inputBox('New prefix:', 'Rename', 'Part-')
if cancelled:
    return                      # silent, expected — not a failure

# For a progress dialog the user aborted:
if progress.wasCancelled:
    ui.messageBox('Cancelled — {} of {} processed.'.format(done, total))
    return
```

Treat cancellation as a normal exit path. Reserving message-box tracebacks for genuine bugs keeps them meaningful — if every cancel throws a scary dialog, the user learns to ignore them.
