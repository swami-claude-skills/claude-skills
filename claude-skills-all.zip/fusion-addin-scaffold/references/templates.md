# Add-in / Script Templates

Table of contents:
1. Manifest
2. command-button (default add-in)
3. simple-script
4. palette (HTML UI)
5. event-only
6. command factory (many similar commands from one table)

Copy the matching template, rename `MyAddin` throughout to the user's name, and fill in the logic. Every template already obeys the four rules from SKILL.md (persistent handlers, full teardown, doc-type awareness where relevant, top-level try/except).

---

## 1. Manifest (`MyAddin.manifest`)

```json
{
    "autodeskProduct": "Fusion360",
    "type": "addin",
    "id": "generate-a-guid-here",
    "author": "",
    "description": { "": "Short description of the add-in." },
    "version": "1.0.0",
    "runOnStartup": false,
    "supportedOS": "windows|mac",
    "editEnabled": true
}
```

`id` should be a unique GUID (any UUID). `runOnStartup: false` means the user launches it manually from the Scripts and Add-Ins dialog; set `true` only if they want it always loaded. For a **script**, set `"type": "script"` and omit startup fields.

---

## 2. command-button (default)

A button in a panel that opens a dialog, collects inputs, and executes. This is the template most requests map to.

```python
import adsk.core
import adsk.fusion
import traceback

# Module-level state — keeps handlers alive and lets stop() clean up.
app = adsk.core.Application.get()
ui = app.userInterface
handlers = []

CMD_ID = 'myAddinCmdId'          # unique across all of Fusion
CMD_NAME = 'My Command'
CMD_DESC = 'What this command does.'
PANEL_ID = 'SolidScriptsAddinsPanel'  # a real panel in the DESIGN workspace


class CommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            cmd = args.command
            inputs = cmd.commandInputs

            # --- define command inputs here ---
            inputs.addValueInput(
                'widthInput', 'Width', 'mm',
                adsk.core.ValueInput.createByReal(5.0)  # 5.0 cm internal
            )

            # Connect execute; append to keep it alive.
            on_execute = CommandExecuteHandler()
            cmd.execute.add(on_execute)
            handlers.append(on_execute)
        except:
            ui.messageBox('commandCreated failed:\n{}'.format(traceback.format_exc()))


class CommandExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            inputs = args.command.commandInputs
            width = inputs.itemById('widthInput').value  # internal units (cm)

            design = app.activeProduct
            if not isinstance(design, adsk.fusion.Design):
                ui.messageBox('Open a Design first.')
                return
            root = design.rootComponent

            # --- do the work here ---
            #   UI / productivity tools -> see ui-navigation.md
            #   geometry / generative tools -> see geometry-recipes.md
            # For a UI tool that acts on the current selection, you can skip
            # command inputs entirely and read ui.activeSelections here instead.

        except:
            ui.messageBox('execute failed:\n{}'.format(traceback.format_exc()))


def run(context):
    try:
        cmd_def = ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def:
            cmd_def.deleteMe()  # clear a stale definition from a prior edit
        cmd_def = ui.commandDefinitions.addButtonDefinition(
            CMD_ID, CMD_NAME, CMD_DESC)  # add './resources/command' as 4th arg for an icon

        on_created = CommandCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        handlers.append(on_created)

        panel = ui.allToolbarPanels.itemById(PANEL_ID)
        control = panel.controls.itemById(CMD_ID)
        if not control:
            panel.controls.addCommand(cmd_def)
    except:
        ui.messageBox('run failed:\n{}'.format(traceback.format_exc()))


def stop(context):
    try:
        panel = ui.allToolbarPanels.itemById(PANEL_ID)
        control = panel.controls.itemById(CMD_ID)
        if control:
            control.deleteMe()

        cmd_def = ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def:
            cmd_def.deleteMe()
    except:
        ui.messageBox('stop failed:\n{}'.format(traceback.format_exc()))
```

Why the `deleteMe()` in `run()`: if a previous session left a command definition registered (common while iterating), re-adding the same ID throws. Clearing first makes the add-in reload cleanly every time.

---

## 3. simple-script (run-once)

```python
import adsk.core
import adsk.fusion
import traceback


def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface

        design = app.activeProduct
        if not isinstance(design, adsk.fusion.Design):
            ui.messageBox('Open a Design first.')
            return
        root = design.rootComponent

        # --- do the work here ---

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))
```

No `stop()`, no handlers, no manifest startup fields. Runs and exits.

---

## 4. palette (HTML UI)

Use when command inputs aren't rich enough and you want a custom HTML panel. The HTML is where dark-theme dashboard styling belongs.

```python
import adsk.core
import adsk.fusion
import traceback
import os

app = adsk.core.Application.get()
ui = app.userInterface
handlers = []

PALETTE_ID = 'myAddinPalette'
PALETTE_NAME = 'My Panel'
# Absolute path built from this add-in's own folder. A bare relative 'palette.html' resolves
# against Fusion's working directory and loads inconsistently between platforms and launch methods.
_HERE = os.path.dirname(os.path.realpath(__file__))
PALETTE_URL = os.path.join(_HERE, 'palette.html')  # or a full https:// URL


class PaletteHTMLHandler(adsk.core.HTMLEventHandler):
    def notify(self, args):
        try:
            data = args.data          # JSON string sent from JS via adsk.fusionSendData
            action = args.action
            # handle messages from the palette here
        except:
            ui.messageBox('palette event failed:\n{}'.format(traceback.format_exc()))


def run(context):
    try:
        palette = ui.palettes.itemById(PALETTE_ID)
        if not palette:
            palette = ui.palettes.add(
                PALETTE_ID, PALETTE_NAME, PALETTE_URL,
                True, True, True, 400, 500)  # visible, showCloseButton, resizable, w, h
            palette.dockingState = adsk.core.PaletteDockingStates.PaletteDockStateRight

            on_html = PaletteHTMLHandler()
            palette.incomingFromHTML.add(on_html)
            handlers.append(on_html)
        else:
            palette.isVisible = True
    except:
        ui.messageBox('run failed:\n{}'.format(traceback.format_exc()))


def stop(context):
    try:
        palette = ui.palettes.itemById(PALETTE_ID)
        if palette:
            palette.deleteMe()
    except:
        ui.messageBox('stop failed:\n{}'.format(traceback.format_exc()))
```

In the palette HTML, call `adsk.fusionSendData(action, jsonString)` to message Python, and register a handler for messages coming back. This is the bridge point for a dashboard-style UI.

---

## 5. event-only

React to application/document events without adding a button. Same handler-persistence rule applies.

```python
import adsk.core
import traceback

app = adsk.core.Application.get()
ui = app.userInterface
handlers = []


class DocOpenedHandler(adsk.core.DocumentEventHandler):
    def notify(self, args):
        try:
            doc = args.document
            # react to the opened document
        except:
            ui.messageBox('event failed:\n{}'.format(traceback.format_exc()))


def run(context):
    try:
        on_opened = DocOpenedHandler()
        app.documentOpened.add(on_opened)
        handlers.append(on_opened)
    except:
        ui.messageBox('run failed:\n{}'.format(traceback.format_exc()))


def stop(context):
    try:
        # Event subscriptions drop when handlers are released; clearing the list is enough,
        # but remove explicitly if you kept references to the events.
        handlers.clear()
    except:
        ui.messageBox('stop failed:\n{}'.format(traceback.format_exc()))
```

---

## 6. command factory (many similar commands from one table)

When a tool needs a dozen near-identical commands — e.g. show/hide/isolate across sketches, bodies, components, construction geometry, joints, origins — do NOT write a handler function per command. That's a wall of copy-paste where every fix has to be made twelve times. Instead, declare the commands as *data* and generate them from a single factory. Adding a new command becomes one row in a table.

The pattern has three parts: (a) one shared handler that dispatches by command id, (b) a spec table describing each command, (c) a build loop in `run()` that creates a button + wires the handler for every row, and a symmetric teardown in `stop()`.

```python
import adsk.core, adsk.fusion, traceback

app = adsk.core.Application.get()
ui = app.userInterface
handlers = []

PANEL_ID = 'SolidScriptsAddinsPanel'


class UserError(Exception):
    pass


# --- reusable primitives -------------------------------------------------
def active_design():
    p = app.activeProduct
    if not isinstance(p, adsk.fusion.Design):
        raise UserError('Open a Design document first.')
    return p

def set_visibility(items, value):
    ok, failed = 0, []
    for it in items:
        try:
            it.isVisible = value
            ok += 1
        except Exception as e:
            failed.append('{}: {}'.format(getattr(it, 'name', '?'), e))
    return ok, failed

def all_occurrences(root):
    def walk(occs):
        for o in occs:
            yield o
            yield from walk(o.childOccurrences)
    return list(walk(root.occurrences))

# Collections keyed by entity type. Each is a function root -> list of togglable items.
FETCH = {
    'sketches':     lambda r: list(r.sketches),
    'bodies':       lambda r: list(r.bRepBodies),
    'components':   lambda r: all_occurrences(r),               # occurrence visibility
    'construction': lambda r: list(r.constructionPlanes) + list(r.constructionAxes) + list(r.constructionPoints),
    'joints':       lambda r: list(r.joints),
}

# --- the command spec table: ONE row per command -------------------------
# (id, label, tooltip, resource_folder, action, entity_key)
# action is 'show' | 'hide' | 'isolate'
COMMAND_SPECS = [
    ('visShowSketches', 'Show Sketches', 'Show all sketches.', './resources/sketches', 'show', 'sketches'),
    ('visHideSketches', 'Hide Sketches', 'Hide all sketches.', './resources/sketches', 'hide', 'sketches'),
    ('visShowBodies',   'Show Bodies',   'Show all bodies.',   './resources/bodies',   'show', 'bodies'),
    ('visHideBodies',   'Hide Bodies',   'Hide all bodies.',   './resources/bodies',   'hide', 'bodies'),
    # ... add construction / joints / components rows the same way ...
]
SPEC_BY_ID = {s[0]: s for s in COMMAND_SPECS}


def run_command(cmd_id):
    _, label, _, _, action, entity_key = SPEC_BY_ID[cmd_id]
    design = active_design()
    items = FETCH[entity_key](design.rootComponent)
    if not items:
        raise UserError('No {} found.'.format(entity_key))

    if action in ('show', 'hide'):
        ok, failed = set_visibility(items, action == 'show')
    elif action == 'isolate':
        target = _first_selected_of(items)          # your selection-matching logic
        if target is None:
            raise UserError('Select one first.')
        ok, failed = set_visibility(items, False)    # hide all...
        target.isVisible = True                      # ...then reveal the target
    msg = '{}: {} updated.'.format(label, ok)
    if failed:
        msg += '\n{} failed:\n'.format(len(failed)) + '\n'.join(failed[:20])
    return msg


# --- one handler for ALL commands, keyed by id ---------------------------
class FactoryCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self, cmd_id):
        super().__init__(); self.cmd_id = cmd_id
    def notify(self, args):
        try:
            h = FactoryExecuteHandler(self.cmd_id)
            args.command.execute.add(h); handlers.append(h)
        except:
            ui.messageBox(traceback.format_exc())

class FactoryExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self, cmd_id):
        super().__init__(); self.cmd_id = cmd_id
    def notify(self, args):
        try:
            msg = run_command(self.cmd_id)
            if msg: ui.messageBox(msg, 'Visibility Tools')
        except UserError as e:
            ui.messageBox(str(e), 'Cannot continue')
        except:
            ui.messageBox('Unexpected error:\n{}'.format(traceback.format_exc()))


def run(context):
    try:
        panel = ui.allToolbarPanels.itemById(PANEL_ID)
        for cmd_id, label, tooltip, resource, _, _ in COMMAND_SPECS:
            old = ui.commandDefinitions.itemById(cmd_id)
            if old: old.deleteMe()
            cmd_def = ui.commandDefinitions.addButtonDefinition(cmd_id, label, tooltip, resource)
            h = FactoryCreatedHandler(cmd_id)
            cmd_def.commandCreated.add(h); handlers.append(h)
            if not panel.controls.itemById(cmd_id):
                panel.controls.addCommand(cmd_def)   # or add into a dropdown; see below
    except:
        ui.messageBox('run failed:\n{}'.format(traceback.format_exc()))


def stop(context):
    try:
        panel = ui.allToolbarPanels.itemById(PANEL_ID)
        for cmd_id, *_ in COMMAND_SPECS:
            ctrl = panel.controls.itemById(cmd_id)
            if ctrl: ctrl.deleteMe()
            cd = ui.commandDefinitions.itemById(cmd_id)
            if cd: cd.deleteMe()
        handlers.clear()
    except:
        ui.messageBox('stop failed:\n{}'.format(traceback.format_exc()))
```

**Nested dropdowns (grouping by entity type).** To organize "Sketches", "Bodies", etc. as sub-menus each holding their Show/Hide commands, create one dropdown per group and add commands into it. `addDropDown` returns a control whose `.controls` collection accepts commands *and* further dropdowns:

```python
groups = {}   # entity_key -> dropdown control
for cmd_id, label, tooltip, resource, action, entity_key in COMMAND_SPECS:
    dd_id = 'grp_' + entity_key
    dd = panel.controls.itemById(dd_id) or groups.get(entity_key)
    if not dd:
        dd = panel.controls.addDropDown(entity_key.title(), './resources/' + entity_key, dd_id)
        groups[entity_key] = dd
    # ... create cmd_def as above ...
    if not dd.controls.itemById(cmd_id):
        dd.controls.addCommand(cmd_def)
```

Teardown then deletes each command, then each group dropdown (deepest first) — the same discipline as a single dropdown, just looped over `groups`. Forgetting to delete the group dropdowns leaves empty menus stacking on reload.

The payoff: adding "Show/Hide Construction Geometry" is two rows in `COMMAND_SPECS` plus an icon folder — no new handler, no teardown edit, no risk of the twelve copies drifting out of sync.
