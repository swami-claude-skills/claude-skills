# Dialogs & Message Boxes

Two different things:

- **Message box** (`ui.messageBox`) — a simple modal popup for a short message or a yes/no-style choice. No custom controls. Use for confirmations, warnings, and results. Covered in §1.
- **Command dialog** (command inputs) — the full input panel with buttons, checkboxes, sliders, dropdowns, tables, etc., that opens when a command runs. Use when you need to collect structured input before doing work. Covered from §2 on.

If all you need is "are you sure?" or "here's what happened," reach for a message box — don't build a command dialog for it. Build a dialog when you need typed values, multiple fields, live selection, or validation.

---

## 1. Message boxes

`ui.messageBox(text, title, buttons, icon)` — only `text` is required. It returns a `DialogResults` value telling you which button was pressed.

```python
# Simplest: just show a message
ui.messageBox('Done.')

# With a title
ui.messageBox('42 components renamed.', 'Batch Rename')

# Yes / No question — branch on the result
res = ui.messageBox('Rename all 42 components?', 'Confirm',
                    adsk.core.MessageBoxButtonTypes.YesNoButtonType,
                    adsk.core.MessageBoxIconTypes.QuestionIconType)
if res == adsk.core.DialogResults.DialogYes:
    ...   # proceed
else:
    return  # user chose No

# Yes / No / Cancel — three-way branch
res = ui.messageBox('Save changes before closing?', 'Unsaved changes',
                    adsk.core.MessageBoxButtonTypes.YesNoCancelButtonType,
                    adsk.core.MessageBoxIconTypes.WarningIconType)
if res == adsk.core.DialogResults.DialogYes:
    save()
elif res == adsk.core.DialogResults.DialogNo:
    pass          # discard
else:
    return        # DialogCancel — abort entirely

# OK / Cancel — proceed-or-abort
res = ui.messageBox('This will delete 8 bodies. Continue?', 'Delete',
                    adsk.core.MessageBoxButtonTypes.OKCancelButtonType,
                    adsk.core.MessageBoxIconTypes.WarningIconType)
if res != adsk.core.DialogResults.DialogOK:
    return
```

**Button-type constants** (`MessageBoxButtonTypes`): `OKButtonType`, `OKCancelButtonType`, `YesNoButtonType`, `YesNoCancelButtonType`, `RetryCancelButtonType`, `AbortRetryIgnoreButtonType`.

**Result constants** (`DialogResults`): `DialogOK`, `DialogCancel`, `DialogYes`, `DialogNo`, `DialogRetry`, `DialogAbort`, `DialogIgnore`.

**Icon constants** (`MessageBoxIconTypes`): `NoIconType`, `InformationIconType`, `QuestionIconType`, `WarningIconType`, `CriticalIconType`.

Always compare the return value against a `DialogResults` constant, not a raw number. And don't put a `ui.messageBox` inside a tight loop — see error-handling.md for why (use `app.log` for per-item output, one message box for the summary). For a text prompt (one line of input) without a full dialog, use `ui.inputBox('Prompt:', 'Title', 'default')`, which returns `(value, cancelled)`.

---

## 2. Command dialogs: inputs

Command inputs are the fields in a command dialog. Add them in the `commandCreated` handler on `cmd.commandInputs`; read them back in `execute` via `inputs.itemById('theId')`. Each input needs a unique `id` string — that's your key for reading the value later.

## Input types

```python
inputs = cmd.commandInputs

# Text box (read-only display or editable)
inputs.addTextBoxCommandInput('noteId', 'Note', 'Some text', 2, True)

# Value input — for dimensions. Takes a ValueInput and a unit string for display.
inputs.addValueInput('lenId', 'Length', 'mm',
                     adsk.core.ValueInput.createByReal(5.0))

# String value (free text)
inputs.addStringValueInput('nameId', 'Name', 'default')

# Integer spinner
inputs.addIntegerSpinnerCommandInput('countId', 'Count', 1, 100, 1, 4)

# Float spinner
inputs.addFloatSpinnerCommandInput('ratioId', 'Ratio', '', 0.0, 10.0, 0.1, 1.0)

# Checkbox
inputs.addBoolValueInput('flagId', 'Enable', True, '', False)

# Dropdown
dd = inputs.addDropDownCommandInput('modeId', 'Mode',
        adsk.core.DropDownStyles.TextListDropDownStyle)
dd.listItems.add('Option A', True)   # True = selected
dd.listItems.add('Option B', False)

# Selection (let the user pick geometry)
sel = inputs.addSelectionInput('faceId', 'Face', 'Select a face')
sel.addSelectionFilter('Faces')
sel.setSelectionLimits(1, 1)

# Slider (drag between a min and max). Value slider:
inputs.addFloatSliderCommandInput('sliderId', 'Amount', 'mm', 0.0, 10.0)
# Integer slider:
inputs.addIntegerSliderCommandInput('stepsId', 'Steps', 1, 20)
# Two-handle range slider: pass hasTwoSliders=True
inputs.addFloatSliderCommandInput('rangeId', 'Range', 'mm', 0.0, 10.0, True)

# Radio button group (pick one from a visible list)
radio = inputs.addRadioButtonGroupCommandInput('alignId', 'Align')
radio.listItems.add('Left', True)      # True = initially selected
radio.listItems.add('Center', False)
radio.listItems.add('Right', False)

# Button row (toolbar-style buttons; isMultiSelect False = behaves like a pick-one)
brow = inputs.addButtonRowCommandInput('sideId', 'Side', False)
brow.listItems.add('Inside', True, './resources/inside')    # label, selected, icon folder
brow.listItems.add('Outside', False, './resources/outside')

# Clickable action button inside the dialog (fires without closing it)
inputs.addBoolValueInput('applyId', 'Apply now', False, './resources/apply')
# ^ with isCheckBox=False it renders as a button; handle it in an inputChanged handler.

# Color / value swatches, direction picker, distance-with-manipulator all exist too:
inputs.addDirectionCommandInput('dirId', 'Direction')
inputs.addDistanceValueCommandInput('distId', 'Depth',
        adsk.core.ValueInput.createByReal(1.0))

# Read-only image (e.g. a diagram in the dialog)
inputs.addImageCommandInput('imgId', '', './resources/diagram.png')

# --- containers to organize a busy dialog ---
# Group: a collapsible titled box holding other inputs
grp = inputs.addGroupCommandInput('advId', 'Advanced')
grp.isExpanded = False
grp_children = grp.children
grp_children.addBoolValueInput('deepId', 'Deep mode', True, '', False)

# Tab: separate pages of inputs
tab = inputs.addTabCommandInput('tab1Id', 'Basic')
tab.children.addValueInput('wId', 'Width', 'mm',
        adsk.core.ValueInput.createByReal(5.0))

# Table: a grid of other inputs (rows you build up)
table = inputs.addTableCommandInput('tblId', 'Items', 3, '1:1:1')
# add cells with table.addCommandInput(childInput, row, col)
```

## Reading values in execute

```python
inputs = args.command.commandInputs

length = inputs.itemById('lenId').value              # float, INTERNAL units (cm)
name   = inputs.itemById('nameId').value             # str
count  = inputs.itemById('countId').value            # int
flag   = inputs.itemById('flagId').value             # bool
mode   = inputs.itemById('modeId').selectedItem.name # str (dropdown)
align  = inputs.itemById('alignId').selectedItem.name # str (radio group)
amount = inputs.itemById('sliderId').valueOne        # float slider (valueTwo for 2nd handle)
steps  = inputs.itemById('stepsId').valueOne         # int slider
face   = inputs.itemById('faceId').selection(0).entity  # first picked entity
# multiple selections:
sel_in = inputs.itemById('faceId')
picked = [sel_in.selection(i).entity for i in range(sel_in.selectionCount)]
```

Sliders expose `valueOne` (and `valueTwo` for a two-handle range), not `.value`. Radio groups and button rows read like dropdowns via `selectedItem` (or iterate `listItems` and check `.isSelected` for multi-select rows).

## Reacting while the dialog is open (inputChanged)

For live behavior — an Apply button, enabling one field when a checkbox is ticked, updating a preview as a slider moves — add an `inputChanged` handler. It fires every time any input changes, *while the dialog is still open*.

```python
class InputChangedHandler(adsk.core.InputChangedEventHandler):
    def notify(self, args):
        changed = args.input                 # the input that just changed
        inputs = args.inputs
        if changed.id == 'flagId':
            # enable/disable another field based on the checkbox
            inputs.itemById('deepId').isEnabled = changed.value
        elif changed.id == 'applyId':
            do_apply(inputs)                 # button pressed — act without closing
```

Connect it in `commandCreated` (`cmd.inputChanged.add(...)`) and append to `handlers`. Use `inputChanged` for interactivity; use `execute` for the final action when the user clicks OK; use `validateInputs` (below) to gate OK.

## The units gotcha (important)

`addValueInput` displays in whatever unit string you pass (`'mm'`, `'in'`, etc.), but the `.value` you read back is **always in Fusion's internal units, which are centimeters** for length (and radians for angles), regardless of the document's display units. So a user typing "50 mm" gives you `5.0`.

- To build geometry, use the internal-unit value directly — the API expects internal units too.
- To display a value to the user in document units, convert with the unitsManager:
  ```python
  um = design.unitsManager
  display = um.formatInternalValue(value, 'mm', True)
  internal = um.evaluateExpression('50 mm')  # -> 5.0
  ```

Mixing these up (treating a `.value` as millimeters) produces geometry 10x too big — a very common bug.

## Validation

To gray out OK until inputs are valid, add a `validateInputs` handler:

```python
class ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def notify(self, args):
        inputs = args.inputs
        if inputs.itemById('lenId').value <= 0:
            args.areInputsValid = False
```

Connect it in `commandCreated` (`cmd.validateInputs.add(...)`) and append to `handlers`.
