# Document Types & Component Creation

The Jan 2026 taxonomy update split Fusion documents into distinct types, and this trips up add-ins that assume a component hierarchy always exists. Guard for it.

## The distinction

- **Design / Assembly** — has a `rootComponent` with an `occurrences` collection. You can create new components as occurrences: `root.occurrences.addNewComponent(adsk.core.Matrix3D.create())`.
- **Part** — a flat, single-component document. There is **no occurrence tree to add into**. Calls that create a new component (`addNewComponent()`, add-in helpers named `CreateNewComponent()`) fail here. Work on `rootComponent` directly instead — add sketches, bodies, and features straight onto it.

## Guard pattern

Check the design type before deciding whether to create occurrences or operate on the root:

```python
design = app.activeProduct
if not isinstance(design, adsk.fusion.Design):
    ui.messageBox('This command needs an active Design.')
    return

design_type = design.designType  # ParametricDesignType or DirectDesignType

root = design.rootComponent

# Safe in any type: operate on the root component directly.
sketches = root.sketches
extrudes = root.features.extrudeFeatures

# Only when you know an occurrence tree exists (Design/Assembly):
try:
    occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
    new_comp = occ.component
except RuntimeError:
    # Part-type or otherwise no occurrence support — fall back to root.
    new_comp = root
```

## Practical rule of thumb

If the add-in's job is "add geometry," prefer operating on `rootComponent` directly — it works across types and avoids the whole issue. Only reach for `occurrences.addNewComponent()` when the user specifically wants a multi-component assembly structure, and in that case verify you're in a Design/Assembly document first and give a clear message if not.

## Parametric vs Direct

`design.designType` also distinguishes **parametric** (timeline/history-based, the default) from **direct** modeling (no history). Some feature operations behave differently or aren't available in direct mode. If a feature call fails unexpectedly, check whether the document is in direct-modeling mode. You can switch a document to parametric with `design.designType = adsk.fusion.DesignTypes.ParametricDesignType` if the workflow requires history.
