# Geometry Recipes

Correct object-model paths for the common "build something" operations. The API nesting is the part that's easy to get wrong from memory — these are the reliable routes. All dimensions are in internal units (cm); see command-inputs.md on units.

Assume `root = design.rootComponent` and `import adsk.core, adsk.fusion`.

## Sketch on a plane

```python
sketches = root.sketches
xy = root.xYConstructionPlane
sketch = sketches.add(xy)
lines = sketch.sketchCurves.sketchLines
```

## Rectangle + extrude (parametric box)

```python
sketch = root.sketches.add(root.xYConstructionPlane)
p0 = adsk.core.Point3D.create(0, 0, 0)
p1 = adsk.core.Point3D.create(width, depth, 0)
sketch.sketchCurves.sketchLines.addTwoPointRectangle(p0, p1)

prof = sketch.profiles.item(0)
extrudes = root.features.extrudeFeatures
ext_input = extrudes.createInput(prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
ext_input.setDistanceExtent(False, adsk.core.ValueInput.createByReal(height))
box = extrudes.add(ext_input)
```

## Circle + extrude (cylinder)

```python
sketch = root.sketches.add(root.xYConstructionPlane)
center = adsk.core.Point3D.create(0, 0, 0)
sketch.sketchCurves.sketchCircles.addByCenterRadius(center, radius)
prof = sketch.profiles.item(0)
ext_input = root.features.extrudeFeatures.createInput(
    prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
ext_input.setDistanceExtent(False, adsk.core.ValueInput.createByReal(height))
root.features.extrudeFeatures.add(ext_input)
```

## User parameters (drive geometry parametrically)

Prefer creating a named user parameter and referencing it by expression, so the model stays editable in the timeline.

```python
params = design.userParameters
w = params.add('boxWidth', adsk.core.ValueInput.createByString('50 mm'),
               'mm', 'Box width')
# Then use ValueInput.createByString('boxWidth') in feature inputs to reference it.
```

`createByString` accepts expressions and units and keeps the parametric link; `createByReal` bakes in a raw number. For a parametric model, favor `createByString` with named parameters.

## Fillet

```python
fillets = root.features.filletFeatures
edge_collection = adsk.core.ObjectCollection.create()
edge_collection.add(some_edge)   # a BRepEdge
fillet_input = fillets.createInput()
fillet_input.addConstantRadiusEdgeSet(
    edge_collection, adsk.core.ValueInput.createByReal(radius), True)
fillets.add(fillet_input)
```

## Pattern gotcha

Circular/rectangular pattern inputs need a valid entity collection and, for circular, an axis. A common failure: patterning a feature whose fillet later fails ("circular pattern fillet failure") because the pattern instances create geometry the fillet can't resolve. If patterning + filleting, fillet the base feature *before* patterning, or pattern the filleted body — order matters.

## Combine / Boolean

```python
combines = root.features.combineFeatures
tools = adsk.core.ObjectCollection.create()
tools.add(tool_body)
combine_input = combines.createInput(target_body, tools)
combine_input.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
combines.add(combine_input)
```

The "inconsistent coedge" error on Combine usually means the input bodies have coincident/overlapping faces or self-intersections. Nudge one body slightly, or repair the source geometry, rather than retrying the same Boolean — retrying identical inputs reproduces the error.

## Message-box debugging

When geometry doesn't appear, dump intermediate state:

```python
ui.messageBox('profiles: {}, bodies: {}'.format(
    sketch.profiles.count, root.bRepBodies.count))
```

Zero profiles usually means an open sketch (endpoints don't meet); zero bodies after an extrude means the profile or extent was wrong.
