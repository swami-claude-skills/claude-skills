---
name: fusion-addin-scaffold
description: Scaffold Autodesk Fusion (formerly Fusion 360) Python add-ins and scripts — manifest, command definitions, event handlers, palettes, icons, installers, and clean teardown. Use whenever the user wants to build, fix, or extend a Fusion add-in or script in Python. Two flavors. First, PRODUCTIVITY / UI TOOLS that navigate or manipulate the existing environment — buttons, panels, dropdowns, built-in commands, visibility toggles, selecting entities, browser tree, renaming, timeline, camera, dialogs and message boxes. Second, GEOMETRY tools that create sketches, bodies, features, parameters. Also for debugging pitfalls like an add-in that won't load, garbage-collected handlers, or CreateNewComponent failing in Part-type docs. Trigger even when the user only describes the behavior (for example "a button that hides all sketches") without saying "scaffold" or "add-in", as long as the target is the Fusion Python API. Do NOT use for Fusion dashboard/HTML deliverables, CAM post-processors, or non-Fusion CAD.
---

# Fusion Add-in Scaffolding (Python)

This skill produces correct, ready-to-run scaffolding for Autodesk Fusion Python add-ins and scripts. Fusion's API has several sharp edges that silently break add-ins — the whole point of scaffolding well is to sidestep those from the first line rather than debug them later.

## First: script or add-in?

Ask (or infer) which the user needs, because the lifecycle differs:

- **Script** — runs once on demand, top to bottom, then exits. No persistent UI. Good for one-off geometry generation, batch edits, exploration. Single file, no `stop()`.
- **Add-in** — loads when Fusion starts (or when the user runs it) and stays resident. Registers UI (buttons, palettes) and reacts to events until stopped. Needs `run()` **and** `stop()`, plus a manifest. Use this whenever there's a button, dialog, or event involved.

When in doubt, build an add-in — it's the superset. The rest of this skill assumes add-in unless the user clearly wants a fire-and-once script.

## The non-negotiable rules (why add-ins break)

These four cause the large majority of "my add-in won't work" reports. Bake them in from the start.

1. **Keep handler references alive.** Fusion connects event handlers by weak reference. If you create a handler and don't store it somewhere persistent, Python garbage-collects it and the event silently never fires. **Always append every handler to a module-level `handlers` list.** This is the single most common cause of "the button appears but clicking does nothing."

2. **Clean up everything in `stop()`.** Delete the controls, command definitions, and palettes you created. If you don't, re-running or reloading the add-in throws "identity already exists" errors, or you get duplicate buttons stacking up in the panel. Every `add`/`create` in `run()` needs a matching delete in `stop()`.

3. **Mind the document type for component creation.** `rootComponent.occurrences.addNewComponent()` requires a **Design** with a component hierarchy. In a **Part**-type document (the flat, single-body type introduced in the Jan 2026 taxonomy update), there is no occurrence tree to add to, so calls like `CreateNewComponent()` / `addNewComponent()` fail. Before creating components, check `design.designType` (or guard for it) and either operate on the root component directly (Part) or create occurrences (Assembly/Design). See `references/document-types.md`.

4. **Wrap the whole entry point in try/except and report via `ui.messageBox`.** Fusion swallows unhandled exceptions and just marks the add-in as failed with no trace. A `traceback.format_exc()` in a message box turns a silent failure into a readable one. This is the floor, not the ceiling — for anything beyond a trivial script, use the layered error handling in `references/error-handling.md` (guard clauses, timeline rollback on partial failure, per-item error collection in batch loops, and treating user-cancel as a normal exit rather than a crash).

## Standard add-in layout

```
MyAddin/
├── MyAddin.manifest    # metadata Fusion reads to list the add-in
├── MyAddin.py          # entry point: run() and stop()
├── install-macos.command      # optional: double-click installer (macOS)
├── install-windows.cmd        # optional: double-click launcher (Windows)
├── install-windows.ps1        # optional: the actual Windows install logic
├── README.txt                 # optional: install steps that travel with the zip
└── resources/          # optional: 16x16.png / 32x32.png / 64x64.png button icons
    └── command/
```

The `.py` and `.manifest` filenames must match the folder name, or Fusion won't recognize it. On disk the folder goes in the Fusion `AddIns` directory (`%APPDATA%\Autodesk\Autodesk Fusion 360\API\AddIns\` on Windows, `~/Library/Application Support/Autodesk/Autodesk Fusion 360/API/AddIns/` on macOS) — mention this to the user but don't assume you can write there.

## Two flavors of add-in

Most Fusion add-ins fall into one of two camps, and they pull from different reference files:

- **Productivity / UI tools** — the common case here. These *manipulate the existing environment* rather than build geometry: adding buttons to panels, firing built-in Fusion commands, toggling visibility, walking and selecting existing entities, reorganizing the browser tree, batch-renaming, adjusting the camera/viewport, reading and reacting to the current selection. They mostly *drive the UI and inspect what's already there*. For these, the workhorse reference is `references/ui-navigation.md`.
- **Geometry / generative tools** — create sketches, bodies, features, parameters. For these, use `references/geometry-recipes.md`.

Many tools mix both, but knowing which camp a request lives in tells you which reference to open first. When the user says things like "a button that hides all sketches," "select every body over X," "run Fillet on my current selection," "rename components by pattern," or "jump the camera to top view" — that's the UI/productivity camp, and geometry recipes are irrelevant.

## How to build

1. Read `references/templates.md` and start from the template that matches the need:
   - **command-button** — the default. A button in a panel that opens a command dialog with inputs, validates them, and executes on OK. This is what most requests reduce to.
   - **simple-script** — run-once, no UI.
   - **palette** — an HTML palette (for richer UI than command inputs allow). Note this bridges to the user's Vibe Coding dashboard style if they want HTML.
   - **event-only** — an add-in that reacts to document/command events without adding its own button.

   For a UI/productivity tool that has no dialog (just a button that acts on the current state), the command-button template still applies — you simply do the work directly in `execute` and often skip adding command inputs entirely.

2. Fill in the logic in the command's `execute` (or `notify`) handler:
   - **UI / productivity tools**: consult `references/ui-navigation.md` for firing built-in commands, selection, traversal, visibility, browser/timeline manipulation, and camera control.
   - **Geometry tools**: consult `references/geometry-recipes.md` for sketches, extrudes, parameters, fillets — the API nesting is easy to get subtly wrong from memory.

3. Add UI for input and feedback where needed:
   - **Message box** for simple confirmations, warnings, and results (`ui.messageBox` with Yes/No, OK/Cancel, etc.) — don't build a dialog just to ask "are you sure?"
   - **Command dialog** when you need structured input: text, value, dropdown, checkbox, radio, slider, button-row, selection, and container inputs (groups/tabs/tables). Add them in `commandCreated`, read them in `execute`, and use an `inputChanged` handler for live behavior (Apply buttons, fields that enable each other).
   - `references/command-inputs.md` is the full catalog for both, plus the value-unit gotcha (value inputs are in internal units — centimeters — regardless of document units) and validation. A UI tool that acts on the current selection often needs no dialog at all — read `ui.activeSelections` instead.

4. Decide on placement and discoverability:
   - **Panel vs. dropdown menu** — a single command can sit directly on a panel; multiple related commands should group under a dropdown menu to avoid clutter. `references/ui-navigation.md` §5 covers both, including the deeper teardown a dropdown needs.
   - **Icon** — supply a resource folder if the command needs a real button, and *especially* if the user wants a keyboard shortcut. Fusion only allows a shortcut on a command that has an icon resource. Provide either a PNG set (`16x16.png`, `32x32.png`, `64x64.png`) or a single scalable `icon.svg`. See §6. When generating icons for *several* commands, render them together at 16px and confirm each is distinct from the others and from the dropdown icon before shipping — reusing a glyph is an easy miss that only shows up when they sit side by side.
   - **Keyboard shortcut** — the add-in can't hard-code a hotkey; it makes the command *eligible* (icon + reachable button) and then tells the user the steps to bind the key themselves. See §7.

5. Apply robust error handling — guard clauses for preconditions, and for multi-step or batch work follow `references/error-handling.md` so a partial failure doesn't leave the model half-changed and a batch reports which items failed rather than dying on the first one.

6. Apply the four rules above without exception.

7. Deliver the files. Match the folder/file names to whatever the user names the add-in. If shortcuts/icons are involved, include the `resources/command/` folder in the deliverable (generate placeholder icons if the user hasn't supplied art — a simple flat glyph reads best at 16px). Unless the user only wants source to read, include the double-click installers (`install-macos.command`, `install-windows.cmd`, `install-windows.ps1`) and `README.txt` so they can install without hand-copying into Fusion's AddIns folder. **Build them with the `fusion-addin-installer` skill**: read its SKILL.md and set its `ADDIN_NAME` to the add-in's name. It covers the executable bit in the zip, Gatekeeper on macOS, and Extract All plus SmartScreen on Windows, and its installers skip caches and wipe the old copy. If they want downloadable files, write them to the outputs directory (zipping the folder is convenient) and present them. If they just want to read the code, a single code block is fine for a small script.

## Naming, versions, and API surface

The product is now just **"Fusion"** (Autodesk dropped "360" over 2024–2025), but the Python package is still imported as `adsk.core` and `adsk.fusion`, and much existing code and community discussion still says "Fusion 360." Don't correct the user's terminology; just produce working code.

If the user asks about a specific API class/method you're unsure exists in the current version, say so and suggest they confirm against the in-product API reference rather than inventing a method signature — a plausible-looking wrong method name is worse than a flagged uncertainty. This matters especially for built-in command IDs (see `references/ui-navigation.md`), which aren't fully documented and can change between versions.

## Vibe Coding note

If this user's other work follows a dark-theme HTML dashboard convention, that styling applies to **palette** UIs (which are HTML) — pass it through there if they want it. Command-input dialogs are native Fusion UI and can't be themed, so don't try. Keep the standard footer/branding out of `.py` source unless asked; put it in palette HTML only.
