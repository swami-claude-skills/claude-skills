---
name: "vibe-dashboard"
description: "Build Swami's signature \"Vibe Coding\" dark-theme HTML dashboard — a single self-contained .html file in the locked #0d0d0f/#00e5ff design system (JetBrains Mono + DM Sans): collapsible numbered sections, sticky TOC chips, sortable tables, a required Dashboard Summary, a required Search section, a spoken audio overview, a zoomable mind map, and a cross-linked Glossary. Use it WHENEVER Swami asks for a vibe dashboard, a dashboard, a reference page, a consultation or session write-up, a breakdown, comparison or explainer page in his style, or wants a post, video, document, files or notes turned into a browsable page — including adding or editing a dashboard's glossary, search, audio overview or mind map. Other skills use it to build their dashboards. For input forms that output text use vibe-promptmaker."
---

# Vibe Dashboard

Swami's dashboards all share ONE locked design system. This skill reproduces it exactly so every page is on-brand and self-contained. Never invent new colors, fonts, or layout patterns — the system is fixed. Vary only the content, the section categories, and the card types.

## Workflow

`SKILL_DIR` below means this skill's folder (the one holding `assets/` and `scripts/`). Every helper is a file in it, run in place; nothing needs copying out of this document:

| Script | Does |
|---|---|
| `scripts/fit_patch.py PAGE` | Table-fit patch (no mid-word breaks, wide first columns) |
| `scripts/search_patch.py PAGE` | Adds or refreshes the Search section (02) |
| `scripts/mindmap_patch.py PAGE` | Adds or refreshes the Mind Map |
| `scripts/comments_sections.py PAGE comments.json` | Comment & review dashboards: the four sections |
| `scripts/audio_overview.py extract PAGE` / `build …` | Page outline for the narration / records the audio |
| `scripts/stress_audio.py SKILL_DIR audit\|build\|plain …` | Noun/verb stress audit and exact-pronunciation recording |
| `scripts/add_fallback.py PAGE narration-plain.txt SKILL_DIR/assets/fallback.html` | Browser-voice player when the recording can't be made |
| `toolbar_patch.py PAGE` (code in "Toolbar patch" below; save it to the working directory) | Show/hide TOC, top, expand all (▲) and collapse all (▼) buttons, and an expand/collapse button on each section header |
| `visuals_patch.py PAGE` (code in "Visuals patch" below; save it to the working directory) | Builds collapsible hierarchy trees from tree sources, plus the diagram/tree CSS and plumbing |

All are idempotent (safe to re-run) and also upgrade dashboards built earlier. **Other skills' builders** (fusion-doc, fusion-doc-json, fusion-cam-settings, vector-bitmap-graphic-finder, and others) copy `fit_patch.py`, `mindmap_patch.py` and `stress_audio.py` from `SKILL_DIR/scripts/`; older copies of those builders extracted them from code blocks in this file, which are gone (Nov 13, 2026).


1. **Get the content.** It comes from a pasted post, uploaded project/CAD/PLC files, a link, a client session, or Swami's own notes. If files are uploaded and not yet in context, read them first (Read / the file-reading skill). If a Google Drive file is referenced, retrieve it. Read everything before structuring.
2. **Structure into sections.** Break the content into logical collapsible sections (typically 4–10). Give each a short title, a running zero-padded number, and a category.
3. **Assign categories.** Categories are named accents that group related sections. Invent them per dashboard from the actual content — there is no fixed list and no cap; use as many or as few as the material warrants. Each category is a `cat-<name>` class mapping to a color + a short UPPERCASE badge label. Reuse the same category across related sections. **Every category's color must be unique and clearly distinguishable** — assign in order from the 8-color palette in the template's CATEGORY ACCENTS comment (cyan, green, yellow, orange, pink, magenta, violet, blue), never repeating a hue; for a 9th+, pick a hue ≥30° from every color already used. A runtime check (`checkCategoryColours`) logs a console warning if any two used category colors are too close — a finished dashboard must produce no such warning. You must define each category's CSS blocks (badge color, section left-edge, TOC chip color, tooltip-badge tint) plus its `--cat-<name>` color var in `:root` — see `references/patterns.md` for the copy-paste block. Do NOT ship generic placeholder category names.
3a. **Pick the glossary terms.** If the dashboard uses jargon, product names, acronyms or field names a reader may not know (most technical dashboards do), include the Glossary section (see "Glossary" under building blocks): one row per term with its color-coded Topic, a one- or two-sentence definition and its matchers. Typically 10–40 terms. Skip it — and delete the section — only when there is genuinely nothing to define.
3b. **Large or index dashboards.** If the page holds a lot of content (roughly 100+ rows/items) or indexes other dashboards and chats, also plan the **index-page columns** and the Search section's second layer (the text of the linked dashboards) — see "Advanced features" below. Build such pages from a Python build script rather than by hand-editing, so they can be regenerated. (The Search section itself is on every dashboard — step 4a.)
4. **Copy the template** `assets/template.html` to the working directory, **apply the table-fit patch** to the copy (`python3 SKILL_DIR/scripts/fit_patch.py PAGE.html`; see "Table-fit patch" below — safe to re-run), then fill placeholders, add/duplicate sections, and delete anything unused (e.g. the verbatim block). **Comment or review dashboards** (built from extracted comments, reviews or replies, by any skill): also write the standard comment JSON and run `scripts/comments_sections.py`, which adds The Post, Discussion at a Glance, Themes & Takeaways and Comment Threads — see "Comment & review dashboards" below.
4a. **Add the Search section (REQUIRED, always).** Once the content sections, Glossary, References and Source Document are in place, run `python3 scripts/search_patch.py PAGE.html` (one command, safe to re-run: a second run refreshes it). It inserts the **Search** section as section 02 right after the Dashboard Summary in its own category colour (the next unused palette colour, or — when all 8 are taken — a colour the page's colour check accepts), renumbers every section after it, adds its row to the section 01 summary table, and adds the generic-subsection patch. Run it before the Mind Map patch. See "Search section" under Advanced features for what it does. Never ship a dashboard without it.
4a1. **Apply the toolbar patch (REQUIRED, always).** Right after the table-fit patch, run the toolbar patch (see "Toolbar patch" below) so the toolbar has the show/hide TOC, top, expand all and collapse all buttons, and each section header gets its own expand/collapse button.
4a2. **Add the Mind Map (REQUIRED, always).** Once the content sections, Glossary and References are in place, run `python3 SKILL_DIR/scripts/mindmap_patch.py PAGE.html` (see "Mind Map patch" below — one command, safe to re-run). It adds the Mind Map section just before the Glossary, numbers it, renumbers the sections after it and adds its row to the section 01 summary table. Optional hints on the markup name list branches and group table rows (see the patch section).
4a3. **Make it visual (REQUIRED wherever it helps).** Swami (Nov 24, 2026): "where appropriate/possible, add collapsible hierarchy trees, diagrams, system diagrams, workflow diagrams, illustrations, images, help documentation screenshots, etc. — make the dashboard more visual so the user can more easily understand things and get at them." Before the Search and Mind Map patches, go section by section and add the visual that explains it best — see "Visuals: diagrams, trees and images" below. Skip a section only when a picture would add nothing (a plain glossary-like list, a short note). Write each tree as a tree source and, on every page with a diagram or tree, run the visuals patch (see "Visuals patch") before the Search and Mind Map patches.
4a4. **Add the Source Document view switch (REQUIRED when the page has a Source Document).** After the Search and Mind Map patches and before the tooltip patch, run the source view patch (see "Source view patch" below). The Source Document then offers Markdown or plain text, opening in Markdown.
4b. **Add the audio overview (REQUIRED).** Every dashboard gets a spoken overview and its player, centered under the header byline — see "Audio overview" below. Write the narration from the finished page, run the noun/verb stress audit on it (see **Noun/verb stress** under Pronunciation), then build with `python3 SKILL_DIR/scripts/stress_audio.py SKILL_DIR build …` (it runs `scripts/audio_overview.py build` with exact-pronunciation support). **If the recording fails, never finish silently and never ship without a player** — follow "When the recording can't be made" under Audio overview: it tells the user why and adds a browser-voice player instead.
4c. **Privacy check (REQUIRED before every publish).** Check for people under NDA and keep them off the page, its narration and its data files — see "Privacy: people under NDA" below.
5. **Save & publish.** Write the file in the working directory (not `/mnt/user-data/outputs/`)
   with a descriptive kebab-case filename (e.g. `stair-stringer-dashboard.html`), then publish it with
   the Artifact tool. Files in the working directory publish without an approval prompt. Declare
   no runtime capabilities — a dashboard needs none — unless the page has a feature that strictly
   requires one (e.g. a download button needs `downloads`; the audio player's owner-only refresh
   button needs the `mcp` grant shown under "Audio overview"). Send the .html as a file too (SendUserFile
   or present_files) only when Swami asks for a standalone copy. One `.html` file; the two Google
   Fonts are the only external dependency (a page with the Search section may also publish its own
   data files next to it — see "Search section").
   **This rule also governs dashboards built "per the vibe-dashboard skill" by other skills**
   (facebook-comments, makerworld-reviews, youtube-transcript, youtube-comments, …): it overrides any
   save location or `/mnt/user-data/outputs/` fallback those calling skills mention.
6. **Version history.** Every published page is backed up nightly to Swami's private GitHub repo automatically. A page built from a script also gets its sources committed there after each change — see "Version history (GitHub)" below.

## The locked design system — DO NOT deviate

**Palette** (CSS vars in `:root`):
`--bg:#0d0d0f` · `--panel:#141418` · `--panel-2:#1a1a20` · `--cyan:#00e5ff` (accent) · `--green:#00ff88` (search-hit glow) · `--text:#e8e8ec` · `--text-dim:#9aa0aa` · `--text-mute:#6a6f78` · `--border:#26262e`. Category accents are `--cat-<name>` vars assigned in order from the 8-color palette — cyan `#38dafa`, green `#38fa79`, yellow `#dafa38`, orange `#fa9938`, pink `#fa3899`, magenta `#ea38fa`, violet `#7938fa`, blue `#3879fa` (see step 3 and `references/patterns.md`). **Orange `#fa9938` also marks owner-only things** (the player's refresh note, owner-only rows, cards and columns) — see "Owner-only content". **The `source` category (Glossary, References, Source Document) is always bright silver `#f2f2f2`** (Swami, Nov 24, 2026), outside the 8-colour palette, so its badge is bright and never clashes with a content category; content categories may use all 8 palette colours. Set by the source colour patch (see "Source colour patch").

**Fonts:** JetBrains Mono (`--mono`, for labels/nums/code/links) + DM Sans (`--sans`, body). Loaded from Google Fonts.

**Non-negotiable behaviors** (all pre-built in the template — keep them intact):
- **Full-width layout.** Every band spans the full width of the browser window — header, TOC bar, toolbar, all sections in `main`, and footer. `main`, `.toc-bar` and `.toolbar` have only side padding (22px), **no `max-width` and no `margin:0 auto` centering cap**. Never reintroduce a fixed content width (e.g. the old `max-width:900px`). Tables still fit their wrapper on open (`fitVisibleTables`), so they now use the full page width too.
- **Header kicker is REQUIRED.** Always include the `.kicker` element above the H1 with a short (1–4 word) UPPERCASE tag naming what kind of page this is (e.g. `CLIENT SESSION`, `TWINCAT PLC BREAKDOWN`, `CAM COMPARISON`, `REVERSE ENGINEERING REFERENCE`). Never leave it blank or delete it.
- **Dashboard Summary is REQUIRED as section 01.** Every dashboard opens with a "Dashboard Summary" section that includes a table titled (via `data-desc`) "What each section covers" — one row per section **including the Dashboard Summary itself (the first row, 01)**, columns **# / Section / Category / Focus / Use When**. The **Category** cell is always left as an empty `<td class="sec-cat"></td>` — `fillSummaryCategories` fills it at runtime with a pill showing the target section's category badge label in that category's own color (copied from the section's badge, so it always matches the dashboard's color coding); never type the category by hand. The "#" cell is a plain `.secnum` span showing the zero-padded section number (e.g. `01`, `02`) — it is NOT a link; navigation is via the clickable section NAME in the Section column (`linkSectionRefs` links it automatically). The table **always ends with pre-wired Glossary, References and "Source Document (Verbatim)" rows** — their numbers are read at runtime (via `data-target-title`) from the number each target section actually displays, and each row auto-drops if its section isn't present. The template ships this as the first section; fill it, don't remove it, and number the real content sections from 02 onward. An optional intro callout is fine; the intro paragraph and the table are not optional.
- **Search section is REQUIRED on every dashboard, as section 02.** Added by `scripts/search_patch.py` (step 4a). It finds anything on the page — list items, paragraphs, callouts, cards, table rows, glossary terms, references, and the Source Document split into passages — by words in any order, start of a word, small typos (including swapped letters), "phrases" and -exclusions, with Show / Category / Section filters, and every result jumps to its spot. It complements the toolbar's quick search; both stay. Index dashboards extend it (see "Search section" under Advanced features).
- **Mind Map is REQUIRED on every dashboard.** Every page carries a "Mind Map" section, just before the Glossary (or References / Source Document when there is no Glossary), in the same category as the Dashboard Summary, added by `mindmap_patch.py`. The map is built at load from the page itself, so it always matches what is shown. Never hand-write it or build its tree in Python; re-run the patch instead (it refreshes the section in place).
- **All sections start COLLAPSED.** Never add the `open` class in markup. This includes the Search section and every one of its sub-items.
- **Sticky stack** (TOC bar + toolbar) sticks to `top:0`; its height is measured at runtime (`getBoundingClientRect().height`, published as the `--stack-h` CSS var) so scroll targets land correctly regardless of wrapping.
- **Three stacked sticky layers.** While scrolling a long table, three headers pin in order below the TOC/toolbar: (1) the main **section header** (`.sec-head`, `position:sticky` at `top:var(--stack-h)`), (2) the **table item header** (`.citem-head`, sticky at `top:calc(var(--stack-h) + var(--sechead-h))`), and (3) the **table column header** (the floating clone, parked below both). Neither `.section` nor `.citem` may use `overflow:hidden` (it would break their sticky headers) — corners are rounded on the header + body instead; keep that. `--stack-h` and `--sechead-h` are measured at runtime; the floating-clone sync (`syncFloatingHeaders`) adds the section- and item-header heights to its park line and only shows the clone once the item header is pinned. **Anything that scrolls to content (search hits especially) must clear ALL of these layers**, not just the TOC/toolbar.
- **Collapsible body items.** Every callout, resource card, table, **bullet list** and generic subsection (`.subsec`, see "Advanced features") in a section body is auto-wrapped by JS in a collapsible shell (`.citem`) with a header showing a uniform `[TAG]` (`[CALLOUT]`/`[RESOURCE]`/`[TABLE]`/`[LIST]`, or a subsection's own tag such as `[SEARCH]`, all one cyan color, left-justified into a shared-width column so descriptions align) and a description. **All items start collapsed.** The tag + description come from the same `deriveSubs` used by the TOC tooltip, so the two always match. Tables take their description from a `data-desc` attribute on the `.table-wrap` (write a logical one per table); callouts use their `.lbl`, resources their `.r-name`, subsections their `data-desc`, and bullet lists their `data-desc` (else `data-mm-label`, else their first few topic IDs joined with ` · `). **Bullet lists (Swami, Nov 13 2026):** every top-level `<ul>`/`<ol>` in a section body becomes its own `[LIST]` item, in page order among the callouts and tables; give each list a short logical `data-desc` (e.g. `<ul data-desc="What to check before cutting">`), like a table. Lists inside a callout, card, table cell, `.subsec`, another list or a tool stay as they are, and `<ul class="no-collapse">` opts one list out (use only when Swami asks). Glossary, Search and Mind Map jumps open the list's item automatically. Author the plain `.callout`/`.resource`/`.table-wrap`/`.subsec`/`<ul>` markup as before — the wrapping is automatic; don't hand-write `.citem`. Keep the wrapping pass and `.citem` CSS intact.
- **Compact TOC with rich hover tooltip.** Chips are compact (number + short title) and wrap inline. Hovering a chip pops a tooltip showing the category badge, the section title, and the list of auto-derived sub-items — every one a clickable link (title scrolls to the section; each sub scrolls to that item and opens it). Tags are bracketed and uniform-colored, left-justified into a column so the text aligns, matching the body headers. The tooltip is positioned by JS (`placeTip`) and clamped to the viewport so it never clips at the left/right (or flips above when it would overflow the bottom). Keep the `deriveSubs`/`buildTip`/`placeTip`/`scrollToAnchor` script and the `.toc-tip` CSS intact. **Hover is hardened — never go back to per-chip `mouseenter`/`mouseleave`.** The tooltip is wired by delegated listeners on the TOC bar (`pointerover` + `mouseover` + `mousemove`), so a missed enter event (pointer already resting on a chip, a host overlay or frame swap) still opens it on the next mouse move; a scroll event hides it only when the page actually moved more than 4px (`tipShownY`), never on a host-fired or zero-distance scroll. Touch/pen: the first tap on a chip shows its tooltip, a second tap jumps, a tap elsewhere closes it; mouse events a tap emulates are ignored (`lastPtr`). Chips are focusable (`tabindex=0`, `role=button`): keyboard focus (`:focus-visible` only — a tap also focuses) shows the tooltip and Enter/Space jumps.
- **Precise jumps.** Every jump (TOC chip, tooltip sub-item, section link, glossary link) goes through `preciseScroll`: it opens and fits whatever is revealed, lands the target just below EVERY pinned layer (TOC/toolbar, plus the section header for sub-items, plus item and column headers for glossary targets), grows an invisible end-of-page spacer (`#endSpacer`) when the target sits too close to the bottom to reach the top, and re-snaps once the smooth scroll settles. `scrollToSection`, `scrollToAnchor` and `jumpToEl` are built on it — never go back to a fixed `stack height + 12` scroll for anything but the section itself.
- **Section titles: `data-title` = the displayed title, encoded once.** Every section's `data-title` must be exactly the text in its `.sec-title`, with `&` written once as `&amp;` — never escape an already-escaped title (a build script that runs `html.escape` on a title already holding `&amp;` produces `&amp;amp;`, and the TOC, section links, summary index and glossary then silently fail to match it). As a safety net the page script opens with `syncSectionTitles`, which resets each `data-title` from its visible `.sec-title` at load. If the copied template's script does not already start with that block, add it as the first thing inside `<script>`:
  ```js
  /* ---- syncSectionTitles: each section's data-title = its visible .sec-title text. ---- */
  document.querySelectorAll('.section').forEach(sec => {
    const t = sec.querySelector('.sec-head .sec-title');
    const v = t ? t.textContent.replace(/\s+/g, ' ').trim() : '';
    if(v && sec.dataset.title !== v) sec.dataset.title = v;
  });
  ```
  Before publishing, check that every row of the section 01 summary table has a working section link.
- **`data-target` navigation, never bare `href` anchors.** TOC chips carry `data-target="<index>"` and scroll via JS. Bare `href="#id"` anchors trigger the artifact sandbox's external-link dialog — do not use them anywhere.
- **Live search** with debounced input, `mark` highlights, prev/next stepping (Enter / Shift-Enter and buttons), `n/total` counter, active hit in green with glow, and a reset "×" that restores scroll position without jumping. The active hit must land just BELOW every pinned layer above it: TOC/toolbar, section header, item header, and (for table rows) the floating column header, never underneath them. A hit inside a sticky header is positioned from that header's container (section / item / table), and the position is re-checked and snapped after the smooth scroll settles. Implemented by `hitTarget` + `focusMatch`; keep them intact and never reintroduce a fixed offset (e.g. stack height + 20) for search hits. On a page with owner-only content, this toolbar search must skip hidden matches (`matches = matches.filter(m => !m.closest('[hidden]'))` just before the first `focusMatch`). This quick toolbar search stays alongside the Search section (section 02), which every dashboard has.
- **Toolbar buttons (Swami, Nov 25, 2026):** a show/hide TOC button (list icon), a **top** button (scrolls to the top of the page), then **expand all** (large up-facing triangle ▲) and **collapse all** (large down-facing triangle ▼) as two separate buttons, then the search box. Every section header with collapsible parts also has a small expand/collapse button, left of the chevron (it keeps its arrows icon), that opens the section and every part in it, or closes all its parts when they are all open (Alt/Option-click on the header does the same). Added by the toolbar patch (see "Toolbar patch").
- **Search reset × sits at the START of the field (Swami, Nov 24, 2026).** The toolbar search's clear button (`#resetBtn`, `.search-reset`) is pinned to the left edge inside the input, not the right. Until the template ships it, patch the copied page once, right after copying the template (two exact replacements in the `<style>`; assert each anchor exists, skip if already applied): in `.search-reset{…}` replace `right:8px;` with `left:8px;`, and in `#search{…}` replace `padding:9px 34px 9px 12px;` with `padding:9px 12px 9px 34px;` (the left padding is always reserved, so typed text never jumps when the × appears). Markup and script stay as they are (the button is absolutely positioned). Apply the same to existing dashboards when they are rebuilt or edited.
- **No system tooltips, ever (Swami, Nov 24, 2026).** Every mouseover tooltip uses the house style (the `.gj-tip` card: panel-2 background, cyan border, soft shadow), never the browser's own `title` tooltip. Write hints as plain `title` attributes if convenient; the tooltip patch (see "Tooltip patch") moves every `title` — in the markup, set later by a script, or an inline `<svg><title>` — to `data-vtip` and shows it in the house style on hover and keyboard focus. Feature tooltips that already have their own styled card (TOC chips, glossary, audio player, Mind Map) keep theirs. A finished page has no element with a `title` attribute after load.
- **Runtime-assembled mailto** on the "Swami" footer link — build the address from parts (`'swami.human' + '@' + 'gmail.com'`); never hard-code it in an `href`.
- **Footer text is exactly:** `Vibe Coding: Swami · AI: Claude` (Swami is the clickable mail link).
- **Pinned column header is aligned AND interactive.** The floating clone uses the live table's fixed layout, identical per-column widths, and the live table's true x offset, so it never shifts left of the columns below it. Clicking a clone header sorts the table (forwarded to the live header, arrows mirrored), and its resizer grips drag/double-click like the live ones. Built into the template.

## Section & card building blocks

Inside a `.sec-body` use these, all pre-styled:
- `<p>` with `<strong>` for emphasis (strong brightens to `--text`).
- `<ul>`/`<li>` — each top-level list is a collapsible `[LIST]` item (see "Collapsible body items"; set a `data-desc`). Bullets are small custom cyan circles `●` (8px, set by `.sec-body li::before` in the template; never go back to `▸`). **Every list item starts with a topic ID:** `<li><span class="tid">Topic</span>content…</li>` — a short (1–3 word) Title Case label naming what the item is about (e.g. `Positioning`, `Counterbore`, `Swami's answer`), shown as a small mono uppercase cyan tag, followed by the item's content. If an item already opens with a lead-in label (`<strong>Scott's plan:</strong> …`, `Workflow: …`), that label becomes the topic ID and is dropped from the text so it isn't repeated; the rest of the item is unchanged. Timestamp links, section links and glossary terms stay in the content as usual. When asked to retrofit topic IDs onto an existing dashboard, add the tags and keep each item's existing content verbatim. Topic IDs are excluded from glossary linking/counting and from section-reference linking (built into the template), so a tag like "Clearance" is never underlined or counted.
- `.callout` — `.lbl` mono uppercase label + text; cyan left border. For key principles / pro tips / methods.
- `.resource` — a card with `.r-name` (mono), `.r-note`, and an optional link. Rename the class per use if it helps (spec / part / step / stat), but the visual pattern is this card.
- `.subsec` — a generic collapsible part for things that are neither callouts, cards nor tables (a tool, a set of controls): `<div class="subsec" data-tag="filters" data-desc="Narrow by type, kind, section and date">…</div>`. Needs the subsection patch — see "Generic subsections" under Advanced features.
- **Tables** — wrap every `<table>` in `<div class="table-wrap" data-desc="…">`. The `data-desc` is the logical description shown in the item's collapsed header and the TOC (e.g. "Cutting parameters", "Regression checklist"). A JS engine floats a clone of the header row just below the sticky TOC/toolbar whenever any part of the table is on screen, so the header stays pinned on **page scroll** — including for short tables that don't scroll internally. (Pure CSS `position:sticky` on `<thead>` only pins inside a scrolling wrapper, so short tables would never pin. The floating clone lives on `document.body` and parks below the section and item headers.) Keep the `buildFloatingHeaders`/`syncFloatingHeaders` script and the `.float-head` CSS intact. Add `class="table-wrap pin-first"` to also freeze the first column for wide tables. **All tables are sortable, resizable, and word-wrapped** — `initSortableTables` adds to every header: a click-to-sort affordance (asc → desc → original) with a clearly visible indicator, and a draggable column-resizer on the right edge (double-click it to fit the column to its widest cell). **On open, every table is sized to fit its wrapper width** (`fitVisibleTables`) — no horizontal scroll; the first column fits its widest entry on one line and the remaining columns share the rest by their natural proportions, word-wrapping as needed, so all columns are visible within the page width. **Tables refit whenever the page width changes** (window or app panel resized after a table was opened — a debounced `resize` handler re-flags and refits them), so a table opened at a narrow width still spans the full width once the page is widened; only a table whose columns the reader dragged or double-clicked by hand (`data-user-sized`) keeps its manual widths. **No column is ever squeezed below its header label:** each column's floor is its one-line header label plus an 8px gap (`HEAD_GAP`) before the sort arrows. If those floors can't all fit, header labels may wrap (`head-wrap` class, mirrored on the pinned clone) and the floor drops to the header's longest word. Only if even that can't fit (e.g. a 5-column table on a phone) does the table scroll sideways on open — labels never sit under the arrows. Dragging a divider resizes **only that column** — every column is pinned to an explicit px width (`table-layout:fixed` + a `<colgroup>`; `setColWidth` keeps the table element exactly as wide as the sum of its columns, so it fits on open yet grows and lets the wrapper scroll when a column is dragged wider). **Resizing a column never changes the table's current sort order or direction** — a drag only touches column widths, never rows. **Long first columns wrap when needed:** if the first column's share plus the other columns' one-line header labels can't fit, header labels wrap, and if the table is still too wide after the other columns reach their floors, the first column wraps too (e.g. long video titles), so the table still opens without sideways scroll. **No mid-word breaks:** every column's floor is also raised to its longest single body word (capped at 160px), so a short column like "Mode" never splits "Independent" into "Independ-ent" — applied only when all those word floors still fit the page; otherwise fitting to the page width wins. Both come from the table-fit patch (step 4). Body cells word-wrap; header labels stay one line; visible dividers separate columns. Keep the `initSortableTables`/`measureColWidth`/`fitVisibleTables` scripts and the refit-on-resize handler, the `<colgroup>` they build, and the sort/resizer/divider CSS intact. Use tables for specs, comparisons, parameter lists, BOMs, etc. Do not put a bare `<table>` directly in a `.sec-body`. **Non-sortable opt-out:** `<div class="table-wrap no-sort" data-desc="…">` keeps the table resizable and pinned but removes sort indicators and click-sort (live and pinned header); use it when Swami asks for a table that must not be sortable (e.g. a list converted to a table whose order matters). **Step tables get a Topic column:** any table with a **Step** column (walkthroughs, procedures, how-tos) also gets a **Topic** column placed immediately before Step (e.g. `# / Topic / Step / When`). Each Topic cell holds a topic ID tag, `<td><span class="tid">Topic</span></td>`, using the same short (1–3 word) Title Case labels as list topic IDs (e.g. `Sketch`, `Cut & keep`, `Joint Origin`), and the Step text stays unchanged. When asked to retrofit this onto an existing dashboard, add the column and tags and keep every other cell verbatim. In table cells, long tags wrap only between words, never mid-word, so they stay inside narrow columns (built into the template).
- **Color-coded category columns.** A table column that classifies rows (Kind, Type, Status) shows each value as a colored tag, `<span class="tid" style="--tc:#hex">Value</span>`, with colors assigned from the 8-color palette in order of first appearance (same value = same color everywhere on the page; add the `.tid[style*="--tc"]` rule from the Glossary bullet once). When Swami wants the table to open grouped by that column, pre-sort the rows in the markup and show the indicator on load: set the header's `data-dir="asc"`, put `▴` in its `.sort-ind`, and mirror it to the pinned clone (`mirrorSortToClone(table, colIndex, 'asc')`) in a `load` handler.
- **Inline section links.** `linkSectionRefs` turns EVERY reference to a section — by name ("Surface & Temperature") or by number ("section 3", "sec. 04", "§2") — into a clickable `.secref` jump-link, everywhere in body text including inside all tables. Automatic; just write references naturally. It only skips existing links and code so nothing is double-linked, and a number with no matching section is left as plain text. **Every** section link anywhere in the body also gets the target's section number appended in square brackets — "Facing **[03]**" — which is itself a clickable jump. Two exceptions: links inside **tables in section 01** (the Dashboard Summary index already shows the number in its # column), and links whose text is already followed by that exact `[NN]` (never double it). A source citation like `[17]` is not a section number and never blocks the suffix. Built into the template. Watch for accidental self-links: a sentence in a section that names that same section (e.g. an intro in the Search section starting "Search …") becomes a link to itself — reword it ("Find anything…").
- **Glossary section** (built into the template; sits just before References). A table titled `data-desc="Glossary of terms"` with columns **Term / Topic / Definition / Appears in / Qty**, cross-linked to the body in both directions — all automatic from the rows you write:
  - **Row markup:** `<tr data-gterm="ID" data-match="REGEX" data-code="EXACT|EXACT"><td><strong>Term</strong></td><td><span class="tid" style="--tc:#38dafa">Topic</span></td><td>Definition</td><td class="gloss-uses"></td><td class="gloss-count"></td></tr>`. `data-gterm` is a short unique kebab-case id. `data-match` is a case-insensitive regex for the term in body **text** (use `|` for alternatives and `s?` for plurals, e.g. `plugins?|plugin bundle`); start and end it with a word character so word boundaries work. `data-code` lists exact `<code>` texts that are this term, `|`-separated (e.g. `SKILL.md|skill.md`). Either matcher may be empty. Leave the last two cells empty — JS fills them. Definitions: plain text, one or two sentences, accurate.
  - **Topic column (REQUIRED, color-coded; always the 2nd column).** Every glossary row gets a topic tag naming what the term is about — a short (1–3 word) Title Case label like list topic IDs (e.g. `Skills`, `Downloads`, `Toolpaths`, `Materials`). Group the terms into a handful of meaningful topics (typically 3–8; several terms share each). **Each topic has its own color**, set inline as `style="--tc:<hex>"` on the tag: assign colors in order of each topic's first appearance down the table from the 8-color palette — cyan `#38dafa`, green `#38fa79`, yellow `#dafa38`, orange `#fa9938`, pink `#fa3899`, magenta `#ea38fa`, violet `#7938fa`, blue `#3879fa` (a 9th+ topic: a hue ≥30° from every color already used); the same topic always gets the same color. Add `<th>Topic</th>` to the header row between Term and Definition, so the header reads Term / Topic / Definition / Appears in / Qty. The template's glossary hover script still reads the definition from the second cell, so patch it once per page: replace `def = row.cells[1].textContent.trim();` with `def = ([...row.cells].slice(1).find(c => !c.querySelector('.tid') && !c.matches('.gloss-uses,.gloss-count')) || {textContent:''}).textContent.trim();` (the term stays `row.cells[0]`). The template does not yet style colored tags, so add this rule once to the page's `<style>`, right after the `li .tid,td .tid{…}` rule: `.tid[style*="--tc"]{color:var(--tc);background:color-mix(in srgb,var(--tc) 9%,transparent);border-color:color-mix(in srgb,var(--tc) 40%,transparent)}` (tags without `--tc`, such as list topic IDs, stay cyan). In the glossary intro paragraph, add one sentence: "Each term's **Topic** tag names what it is about, one color per topic." Topic tags are already excluded from glossary linking and counting. When asked to retrofit this onto an existing dashboard (including an older glossary whose "Topic ID" column sits after Definition), put the Topic column second, name its header Topic, apply the script patch, CSS rule and intro sentence, and keep every other cell verbatim.
  - **Default sort: Topic (ascending).** The glossary table opens pre-sorted by its Topic column so the color-coded tags read as grouped blocks rather than a random mix. After `initSortableTables()` and `buildFloatingHeaders()`, add a self-invoking function that finds the Glossary section's table, locates the Topic header cell, and `.click()`s it once to trigger an ascending sort. **Important:** because `initSortableTables` appends sort-indicator child elements (`▴▾`) inside each `th`, `th.textContent` includes those characters. Match the header by reading only its first text node (`th.childNodes[0]`), not `textContent`. The snippet:
    ```js
    /* ---- glossary: start sorted by Topic column (asc) ---- */
    (function(){
      const gsec = document.querySelector('.section[data-title="Glossary"]');
      if(!gsec) return;
      const table = gsec.querySelector('.table-wrap table');
      if(!table || !table.tHead) return;
      const ths = [...table.tHead.rows[0].cells];
      const ti = ths.findIndex(th => {
        const t = th.childNodes[0];
        return t && t.nodeType === 3 && t.nodeValue.trim().toUpperCase() === 'TOPIC';
      });
      if(ti < 0) return;
      ths[ti].click();
    })();
    ```
    Place it right after `buildFloatingHeaders();` (before `checkCategoryColours`). It is a no-op when there is no Glossary or no Topic column.
  - **Body → glossary:** `linkGlossary` wraps the **first** mention of each term **per content section** in a dotted-underline `.gterm` (only the first, so common words don't underline dozens of times). Hover shows the term, its definition, and "(click term to go to 'Glossary')"; click jumps to the term's row and flashes it green. It skips the summary, Glossary, References and verbatim sections, headings, column headers, section links, pills/badges and callout labels.
  - **Glossary → body:** the **Appears in** cell gets one numbered `.gloss-jump` per section where the term appears, colored by that section's category. Hover previews the section (number, title, category badge), the line with the term highlighted, and the mention count in that section; click opens the section/item, scrolls the term clear of every pinned header and flashes it green.
  - **Qty:** total mentions across the content sections, repeats included (linked or not); sorts numerically. A term with no mentions shows "—" and 0 — reword its matcher or drop the row.
  - **Longest pattern wins** when terms overlap (e.g. "Claude Marketplace" beats "marketplace"); a bad regex logs a console warning and disables text matching, so a finished dashboard must show no such warning.
  - The Dashboard Summary row for the Glossary is pre-wired (`data-target-title="Glossary"`, auto-numbered, auto-dropped if the section is deleted). Mention the Glossary in the summary intro ("terms with a dotted underline jump to the Glossary") when you include one.
- **References section.** When the dashboard cites external sources, include a "References" section immediately before the verbatim section (the template ships it) with a table — columns **Source / Topic / What it covers / Cited in / Domain / Webpage** — one row per cited source, written in citation order:
  - **Source:** `<strong>[n] Publisher</strong>`, where `n` is the citation number used in the body (the source's own numbering when the material has one). The row is `<tr data-ref="n">`.
  - **Topic (REQUIRED, color-coded; always the 2nd column, right of Source):** `<span class="tid" style="--tc:#hex">Topic</span>` — same rules as the Glossary's Topic column: a short (1–3 word) Title Case label naming what the source is about, a handful of topics (typically 3–8; several sources share each), colors assigned from the 8-color palette in order of each topic's first appearance down the table (cyan, green, yellow, orange, pink, magenta, violet, blue; a 9th+ topic gets a hue ≥30° from every color used), same topic = same color. The `.tid[style*="--tc"]` rule ships in the template.
  - **What it covers:** the page's title or subject in plain words. **Cited in:** the exact titles of the sections that cite it, comma-separated (`linkSectionRefs` turns them into section links with `[NN]`), or `—`. **Domain:** host without `www.`. **Webpage:** the real link, `target="_blank" rel="noopener"`, text `open ↗`.
  - **Opens sorted by Topic (ascending).** The template's script clicks the Topic header once at load (after `buildFloatingHeaders();`, matching the header by its first text node, like the Glossary snippet), so the colored tags read as grouped blocks; ▴ shows on Topic and a click cycles desc → original citation order. A no-op when the table has no Topic column.
  - **Clickable citations:** write each `[n]` in the body as `<span class="cite" data-ref="n">[n]</span>` (small mono, hover cyan); a click opens References and jumps to that row (`jumpToEl`). Built into the template.
  - Intro paragraph: say that bracketed numbers are citations that jump to their row, and add "Each source's **Topic** tag names what it is about, one color per topic."
  - When asked to retrofit this onto an existing dashboard, add the Topic column second, the sort script and (when the body has numbered citations) the `.cite` spans and click handler, and keep every other cell verbatim.
- Verbatim/raw-source block — a `.verbatim-body` section with `<pre id="verbatim">`; text is injected from the `VERBATIM` JS string (kept out of markup to avoid re-parsing). Include only when preserving an original post/source; otherwise delete the block and its section.

## Visuals: diagrams, trees and images

Every dashboard should be as visual as its content allows (Swami, Nov 24, 2026). **Reference implementation:** `claude-projects-beta/` in the private repo `swami-claude-skills/vibe-dashboards` — `visuals.py` (SVG helper class, 16 diagrams, tree builder, the CSS and JS below), `build.py` (how they are placed per section), `post.py` (the script patches). Attach and clone it as under "Version history"; adapt rather than rewrite.

**Pick the visual per section:**

| Content | Visual |
|---|---|
| How parts of a system connect | System diagram (boxes, solid arrows for work, dashed for context/reports) |
| A procedure, setup or ramp | Workflow diagram with numbered steps |
| Things that change state | State / lifecycle diagram |
| "Which option fits?" | Decision tree |
| A UI, app or screen | Annotated schematic with numbered orange callouts (labelled "schematic, not a screenshot") — or real screenshots when available |
| Nested parts, menus, settings, file layouts | Collapsible hierarchy tree |
| Comparing a few options on a few traits | Matrix graphic (green kept/good, pink lost/bad) |
| Where cost, time or effort goes | Bar illustration; say "illustrative, not measured" unless the numbers are real |
| A physical part, CAD feature, machine | Illustration, render or photo the user supplied |

**Diagrams — always as SVG images, never inline SVG.** Write each diagram as SVG and embed it as `<img src="data:image/svg+xml;base64,…">`. The page's glossary, section-link and search passes walk text nodes and would inject `<span>`s into inline `<svg>` text, breaking it. Inside the SVG use hard-coded hex colours from the locked palette (CSS vars don't reach an image), panel `#141418` background with rounded corners, box fills at ~10% of their stroke colour, text `#e8e8ec` / dim `#9aa0aa`, font `JetBrains Mono, DejaVu Sans Mono, Menlo, monospace` for titles and `DM Sans, Helvetica Neue, Arial, sans-serif` for notes (an SVG image can't load the page's web fonts). Colour boxes by meaning and reuse the page's category colours where they match.

**Wrapping:** each visual is a generic subsection so it collapses, shows in the TOC tooltip, the Mind Map and Search:
`<div class="subsec" data-tag="diagram" data-desc="System diagram of a project" data-mm-tip="one-sentence summary"><figure class="viz"><div class="viz-scroll"><img src="data:…" alt="…" style="max-width:<svg width>px"></div><figcaption>What to read and how, with citations</figcaption></figure></div>`. Trees use `data-tag="tree"`. Every figure gets real `alt` text and a figcaption that tells the reader how to read it (the caption is what Search and the narration can see). Place a visual right after a section's intro paragraph, or at the end when it summarises the section.

**Collapsible trees (Swami, Nov 24, 2026):** never hand-write the tree markup. Write a **tree source**, a plain nested list, where the tree goes, and let the visuals patch build it:
```html
<ul class="tree-src" data-desc="Map of every menu and control" data-mm-tip="Every menu, button and setting as a collapsible tree." data-intro="Optional lead-in sentence.">
  <li>Project settings<span class="tnote">gear icon</span>
    <ul><li>General</li><li>Memory<span class="tnote">instructions and files</span></li></ul></li>
  <li>Projects page</li>
</ul>
```
- Each `<li>` is a node: its label (inline HTML such as `<code>` is fine), an optional `<span class="tnote">` note, and an optional nested `<ul>` of children. Any number of top-level items and any depth.
- The patch turns it into a `[TREE]` part (`data-desc` is its header; `data-mm-tip` its Mind Map hover summary, always set it; `data-intro` an optional paragraph) with "expand tree" / "collapse tree" buttons. Branches are closed `<details>` showing their child count in curly braces like the Mind Map; leaves are list items, so the Search section finds them, and a jump, Search result or search hit inside a closed branch opens it.
- Look: mono text, dashed `#3a3a46` guide lines, cyan ▸/▾ on branches and cyan ● on leaves, muted notes and counts. Trees usually need no colour key.
- The patch also adds the plumbing every diagram needs (the `[DIAGRAM]` and `[TREE]` tags, glossary skips, and the `figure.viz` and colour-key CSS), so run it on any page with a diagram even when it has no tree. Run it before the Search and Mind Map patches; it is idempotent (a re-run refreshes its CSS and script, and finds no sources left to build).

**Check every diagram by eye before publishing:** render each SVG to PNG (Playwright) and look for labels overlapping boxes, arrows or each other, arrows crossing boxes, and text overflowing its box; fix and re-render until clean. Then the usual browser checks (no console errors at 390/1000/1440 px).

**Images and screenshots:** embed as base64 data URIs (compress with Pillow first). Help-documentation screenshots and vendor images are welcome when they can actually be obtained — files Swami uploads, or images fetched from sites the workspace can reach — always with a caption naming the source. Many docs sites are blocked from the workspace: then draw an annotated schematic instead, label it as such, and tell Swami that uploading screenshots would let them be added. Never fake a screenshot, never use photos of public figures, and keep NDA people out of every image (the privacy scan cannot read pixels, so check images yourself).

**Colour key under every diagram (REQUIRED where colour or line style carries meaning; Swami, Nov 24, 2026).** Each diagram, chart, illustration or colour-coded visual gets a one-line **Key** between the image and its figcaption: one swatch per colour actually used, named by what it means in *that* diagram ("Claude's workspace", "private repo", "largest avoidable cost"), plus a line sample for each line style when the diagram mixes them (solid = done by you or Claude, dashed = automatic or occasional, etc.). Skip it only when colour is pure decoration or the visual uses a single colour (collapsible trees usually need none). Keep colours consistent within a diagram so the key is true, and reuse the page's category colours where the meanings match. The key is HTML (sharp, searchable, wraps on phones), never drawn inside the SVG image. Markup, inside the `figure.viz` after `.viz-scroll`:
`<div class="viz-legend" aria-label="Colour key"><span class="lg-title">Key</span><span class="lg"><i class="lg-sw" style="--c:#38dafa"></i>Claude's workspace</span><span class="lg"><i class="lg-line lg-dashed" style="--c:#9aa0aa"></i>automatic or occasional</span></div>`
Its CSS comes with the visuals patch.

**Hover on diagrams (Swami, Nov 24, 2026).** Every box and arrow in a diagram with a Key shows a house-style tooltip saying what it means in that Key: a box shows its title and its colour's Key label ("4 · BUILD · Key: Claude's work", plus the dashed line's label when the box is dashed); an arrow shows its line style's label ("Arrow · Key: next step"), plus its colour's label when the arrow is coloured. Nothing extra to write: the visuals patch reads each diagram's own SVG at load and lays an invisible copy over the image to catch the pointer, matching boxes to Key swatches by stroke colour and arrows to the solid or dashed line sample. So keep each box's stroke the exact hex of its Key swatch, put the box title as the first text inside the box, and draw arrows as `path`/`line`/`polyline` with `fill="none"` (or a marker). Shapes whose colour isn't in the Key get no tooltip. The tooltip patch shows them, so it must run on the page as usual.
In a Python build, give each diagram function its legend list (`[(colour, label), ('solid'|'dashed', label, colour)]`) and let the figure helper render it (reference: `github-guide/vbase.py` and `gviz.py` LEGENDS in the vibe-dashboards repo). Since the key sits inside `figure.viz`, glossary linking already skips it.

**Narration:** say in one sentence on the summary that most sections carry diagrams or trees; don't describe each picture.

## Comment & review dashboards (REQUIRED pattern)

Any dashboard built from extracted comments, reviews or replies — from facebook-comments, makerworld-reviews, youtube-comments, or any future skill that extracts comments or similar (forum threads, Reddit, Printables, Thingiverse, …) — carries these four sections, right after Search, in this order. The pattern comes from Swami's "Fusion + Claude AI: What the CAM Crowd Says" dashboard (Nov 13, 2026). This section wins over any section layout in a calling skill; a calling skill may add its own extra sections after the four (e.g. MakerWorld's Critical Feedback or Designer Replies), but never replace them.

| Section (default name) | Rename to fit the source | Content |
|---|---|---|
| **The Post** | The Model (MakerWorld), The Video (YouTube), The Thread, … | Intro paragraph (who posted what, where, **bold bright date**), callout with the original post/description text, `.resource` cards for the source page and any key comment (e.g. the author's own follow-up). |
| **Discussion at a Glance** | Reviews at a Glance, Comments at a Glance, … | Bullets (busiest threads, what the post author/designer/uploader did, any notable voice), a **Discussion stats** table (top-level, replies, total, the site's shown count, participants, messages by the owner, with media, date range, plus source-specific rows such as average stars or views), and a **Participants** table (Name linked to profile / Top-level / Replies / Total / First seen, sorted by Total). |
| **Themes & Takeaways** | (keep the name) | Claude's own synthesis, labelled as such in its opening sentence: 3–7 callouts, each naming a recurring position and **who** raised it (names or @handles), plus a final **Open requests** callout for questions nobody really answered. Skip only when there are fewer than 3 messages. |
| **Comment Threads** | Review Threads, … | Every message in **ONE table**, no cap, however many there are (Swami accepts the longer load time for full access). |

**The threads table** (the most important part):
- **Columns, in this order:** `Topic` / `From` / `QTY` / `QTY-TOT` / [source-specific columns, e.g. `Stars`, `Likes`] / `Comment` / `Link`.
- **Topic:** a color-coded tag (`.tid` with `--tc`) on every row. Pick **6–9 topics for this dashboard** from the content (e.g. Praise, Limits, Questions, Setup, Jobs Debate, Reverse Eng); always include **Chatter** (jokes, tags, "sub", asides), which is shown in gray `#9aa0aa`; the others take palette colors in listed order. A list above the table gives each topic, its message count and a one-line meaning.
- **Tagging:** up to about 300 messages, read and tag **every message** on its own. Above that, tag each **thread** from its top comment and the gist of its replies, and re-tag only replies that clearly differ (a joke, an unrelated question, a tag-a-friend).
- **From:** four stacked lines: **name** (+ owner badge: `OP`, `DESIGNER`, `UPLOADER`), `→ parent author` (or `top-level`), `T<thread> · #<order> · <age>`, and the **bold bright date**.
- **QTY** = messages in that row's thread with the **same topic** (matches the rows grouped together); **QTY-TOT** = messages in the **whole thread**.
- **Comment:** `↳` per reply depth, links clickable; a translated message also shows its original in a muted line; media-only messages say so.
- **Link:** `↗` to the exact comment on the site.
- Opens **sorted by Topic** (ascending); two more clicks restore thread order, where a thin line marks each thread's start. The Mind Map groups the table's bubbles by topic (`data-mm-group="0"`).

**How to build it:** never by hand. The calling skill converts its extraction into the **standard comment JSON** below, Claude adds the topics, themes and texts, then `comments_sections.py` writes all four sections, their summary rows, CSS (four new categories in the next unused palette colors), the open-sorted-by-Topic script, and the Source Document text (when the `{{VERBATIM_TEXT}}` placeholder is still there). Order of work:
1. Fill the template (header, Dashboard Summary intro/callout, Glossary, References; leave the four sections' summary rows and `{{VERBATIM_TEXT}}` to the script).
2. `python3 SKILL_DIR/scripts/comments_sections.py PAGE.html comments.json`. Safe to re-run at any stage: it replaces what it added, keeps the four sections right after Search, and renumbers every section in page order.
3. `scripts/fit_patch.py` → `scripts/search_patch.py` → `scripts/mindmap_patch.py` → audio → privacy check, as usual.

**Standard comment JSON** (`comments.json`):
```json
{
  "source": {"platform": "Facebook", "url": "…", "author": "Post author / designer / channel", "author_profile": "…",
             "date_display": "Thu Nov 12, 2026 ~3 PM", "text": "the post / model / video description", "shown_count": 174},
  "labels": {"post": "The Post", "glance": "Discussion at a Glance", "themes": "Themes & Takeaways", "threads": "Comment Threads",
             "item": "comment", "items": "comments", "owner_tag": "OP", "owner_role": "post author", "platform": "Facebook", "post_noun": "post"},
  "approx_times": true,
  "post_intro_html": "…", "post_label": "Original post",
  "resources": [{"name": "…", "note": "…", "url": "…", "link_text": "open ↗"}],
  "glance_intro_html": "…",
  "glance_bullets": [{"tid": "Autodesk voice", "html": "…"}],
  "stats_rows": [["Reactions on the post", "104"]],
  "themes": [{"label": "How people connect it", "html": "… (names who said it) …"}, {"label": "Open requests", "html": "…"}],
  "topics": [{"name": "Praise", "desc": "Positive first-hand reports."}, {"name": "Chatter", "desc": "Jokes, tags and asides."}],
  "extra_columns": ["Stars"],
  "summary_focus": {"post": ["Focus text", "Use when text"]},
  "items": [{"id": "…", "type": "comment|reply", "parent_id": null, "thread_root_id": "…", "depth": 0, "order": 1,
             "author": {"name": "…", "profile_url": "…"}, "relative_time": "22h", "date_display": "Thu Nov 12, 2026 ~3 PM",
             "date_short": "Thu Nov 12 ~3 PM", "sort_time": "2026-11-12T15:48", "text": "…", "text_original": null, "language": null,
             "has_media": false, "permalink": "…", "topic": "Praise", "extra": {"Stars": "★★★★☆"}}]
}
```
- `items` are in the site's thread order (each top-level item followed by its replies); `order` is 1…N in that order. `type` is `comment` for top-level, `reply` otherwise; `thread_root_id` is the top-level item's id; `parent_id` the exact item answered.
- Only `source`, `topics`, `themes` and `items` (with id, type, parent_id, thread_root_id, depth, order, author.name, text, permalink, topic) are required; everything else is optional and drops out when missing. `approx_times: true` labels times as approximate. `post_intro_html`, `glance_*`, `themes[].html` and `resources[].note_html` are HTML written by Claude; every other text is escaped by the script.
- HTML in theme callouts may carry citations (`<span class="cite" data-ref="n">[n]</span>`) to the References table.
- The script checks the data (unique ids, every reply's parent exists, every item has a listed topic) and stops with a message if not.

**Checks before delivering** (in addition to the usual ones): the threads table has exactly one row per item; it opens with ▴ on Topic; QTY ≤ QTY-TOT on every row; no column narrower than its words at 1000 and 1440 px; no console errors.

The builder is `scripts/comments_sections.py`.

## Advanced features (large and index dashboards)

These grew out of Swami's "AI in Fusion Chats" index dashboard. Use them when a page holds a lot of content, indexes other dashboards and chats, or when Swami asks. **Reference implementation:** the folder `ai-in-fusion-chats/` in Swami's private GitHub repo `swami-claude-skills/vibe-dashboards` — `build.py` (page generator, including every patch below), `search.js` (the Search section), `refresh.py` (nightly data refresh, privacy scan, skeleton strip). Attach it with the Claude Code Remote `add_repo` tool (owner `swami-claude-skills`, repo `vibe-dashboards`) and clone it; adapt the code rather than rewriting it. The same files are also readable from the live artifact (its page source and its published `refresh.txt`).

### Generic subsections

To split a section that is a tool or a group of controls into collapsible parts, wrap each part in `<div class="subsec" data-tag="TAG" data-desc="Description">…</div>`. Each becomes a `.citem` with `[TAG]` and its description, exactly like callouts and tables, and appears in the TOC tooltip. Callouts, cards and tables nested inside a `.subsec` are not wrapped again. Until the template ships it, patch the page once (three exact replacements; assert each anchor exists):
1. In `deriveSubs`, replace
   `body.querySelectorAll('.callout, .resource, .table-wrap').forEach(el => {\n    let kind, text;\n    if(el.classList.contains('callout')){`
   with
   `body.querySelectorAll('.subsec, .callout, .resource, .table-wrap').forEach(el => {\n    let kind, text;\n    if(el.parentElement.closest('.subsec')) return;\n    if(el.classList.contains('subsec')){\n      kind = el.dataset.tag || 'part';\n      text = (el.dataset.desc || 'Part').trim();\n    } else if(el.classList.contains('callout')){`
2. Extend `const TAG_CH = {callout:'CALLOUT', resource:'RESOURCE', table:'TABLE'};` with each tag used (e.g. `search:'SEARCH', filters:'FILTERS'`).
3. (Optional) after the wrapper's `head.addEventListener('click', …);` line add `if(s.el.dataset.open) item.classList.add('open');` — but do not use `data-open` by default: every item starts collapsed.

### Owner-only content

Some things should show only to Swami (links to his private chats, an index of his own pages, admin boxes). The page asks the runtime who is viewing — no capability needed:
```js
(async () => { try {
  const u = window.claude ? await window.claude.use('user') : null;
  if(!(u && await u.isOwner())) return;
  /* reveal owner-only rows, cards and columns here, then refit */
  if(window.fitVisibleTables) fitVisibleTables();
  if(window.syncFloatingHeaders) syncFloatingHeaders();
} catch(e){} })();
```
- **Rows:** `<tr class="owner-only" hidden>` plus `<span class="owner-tag" title="Only you can see this row">only you</span>` after the first cell's label; orange row tint and left bar. Revealed by the block above.
- **Cards:** `<div class="resource owner-only">`; after the wrapping pass give its `.citem` shell `owner-only-item` + `hidden` (orange border and an "only you" tag on its header), reveal for the owner. The TOC tooltip skips sub-items inside `[hidden]` and shows owner ones in orange.
- **Columns:** `<th class="own-col">` and `<td class="own-col">`. Detach those cells **before** the table engine starts (stash them per table), so other viewers' tables are built without the column; for the owner, append them back, rebuild the floating headers, re-run the sort/resizer setup for that header and refit. The header is orange (`#fa9938`, with `!important` so the pinned clone matches) with a hover tooltip: "Only you can see this column. It links to …".
- **Never mention owner-only items** in the page's body text or the audio narration.
- **Owner-only is NOT private:** the content still sits in the page source that anyone with the link can read. Never use it for anything under NDA or otherwise confidential (see "Privacy").

### Index dashboards (a dashboard of dashboards)

When a page indexes Swami's chats and the dashboards they produced:
- Every table that lists chats has a **Chat ID** column (the chat's short id in `<strong data-cid="…">`), a **Dashboard** column, and an owner-only **Chat** column (link to `https://claude.ai/chat/<id>`). Link cells read exactly `open ↗`; there are no other links in the ID columns.
- **Dashboard link tooltips:** each dashboard link carries `data-dh="<artifactId>"`; hovering it shows that dashboard's full header (kicker, title, subtitle) from a `DASH_HEADS` map embedded at build time (generated as `heads.json` by `refresh.py extract`). The Dashboard column header (`th.dh-col`) gets a hint tooltip: "Hover any open ↗ link in this column to see that dashboard's full header."
- Before saying a chat has no dashboard, look for it (the account's artifact list, the chat itself); if one exists but isn't published, give Swami the chat link so he can publish it.
- The master table's Kind column is color-coded and opens sorted by Kind (see "Color-coded category columns").

### Search section (advanced full-text search)

A dedicated section, numbered **02** right after the Dashboard Summary, titled **Search**, with its own category color. It complements (does not replace) the toolbar's quick search. **Every dashboard has it** — added by `scripts/search_patch.py` (workflow step 4a).

**The standard version (`search_patch.py`, every dashboard):** a one-line intro ("Find anything on this page: …"), then four collapsible parts, all starting collapsed: `[SEARCH]` "Search box and results" (input, clear button, status line "Searching **N** items on this page · plus **P** passages of the source document", results); `[FILTERS]` "Narrow by type, category, and section" (Show chips — Notes, Table rows, Glossary terms, References, Source document — with live counts; Category chips in each section category's own colour; a Section select); `[TABLE]` "How to write a query" (`no-sort`; its examples are filled at load from this page's most-used glossary terms); `[CALLOUT]` "What it covers". Matching is layer 1 below; the Source Document's `<pre>` is split into passages at load so a result can jump to the exact spot. Results group by type, each showing its type, a title that jumps there (`jumpToEl`), a highlighted snippet, the section link "Title [NN]" and the section's category tag. Search box UI (Nov 2026, built into `search_patch.py`): the box's text and placeholder are green; the search box row is sticky, pinning just under the `[SEARCH]` item header while the results scroll; each result group (Notes 8, Table rows 18, …) is a collapsible header with a ▶ arrow and its hit count, all collapsed at first and again on every new search ("Show all" keeps a group open); "expand all" / "collapse all" buttons for the result groups sit right of "clear" (collapse all scrolls back to the search box and puts the cursor in it); and the "Try" chips include no typo example, since it reads as a misspelling. Re-running `search_patch.py` on an older dashboard refreshes its Search section to this version. The patch also keeps the toolbar quick search out of the results and adds "Search" to the Glossary's `EXCLUDE` set. Don't name the section in body text ("search the …"), since `linkSectionRefs` would turn the word into a link to it.

**The index-dashboard version** (pages that index other dashboards and chats) adds date filters, Kind chips, layer 2 and the owner-only refresh box. It is hand-built from the reference implementation (`search.js`); `search_patch.py` leaves a page alone when it already has a hand-made `#xs` section. Its layout:

— a one-line intro ("Find anything on this page, plus the full text of every dashboard it links to.") and a `#xs` container holding four collapsible parts, all starting collapsed:
1. `[SEARCH]` "Search box and results" (`.subsec`): the input + clear button, a status line ("Searching **N** items on this page · plus **P** passages from **D** dashboards, refreshed **date**"), and the results.
2. `[FILTERS]` "Narrow by type, kind, section and date" (`.subsec`): Show chips (result types, with live counts), Kind chips (in the Kind colors), a Section select, From/To month inputs, and the note "Filters work with or without words in the box. With an empty box, they list the matching chats."
3. `[TABLE]` "How to write a search" (`no-sort`): To do this / Type / Example — several words, start of a word, forgiven typo, exact phrase, leave a word out, Enter opens the best match.
4. `[CALLOUT]` "What gets searched and when it updates" — this page, inside the dashboards, nightly updates; the owner-only nightly-refresh box (last run, candidate new dashboards to add) sits inside it.

**Matching (layer 1 — this page):** built in the browser at load from the page itself, so it always matches what is shown: chat records, every table row, callout, card, list item, paragraph, glossary term and reference (skipping section 01, the Search section, the Mind Map section, owner-only cells, and anything hidden for this viewer). Inverted index of normalized tokens (lowercase, accents stripped). All words must match, in any order; the start of a word is enough (2+ letters); a simple stem joins plurals and endings (s/es/ies/ing/ed); typo tolerance kicks in **only when a word matches nothing as typed** — same first letter, edit distance ≤1 (≤2 for words of 8+ letters), preferring words that just add dropped letters (filet → fillet) — and the results then say "similar spellings are included: …"; `"quotes"` match an exact phrase; `-word` excludes; a small alias map (f360 → fusion). Rank title hits above body hits, exact above prefix above typo.

**Results:** grouped by type with counts (e.g. Chats, Findings, Open questions, Glossary terms, Elsewhere on this page, Inside the dashboards); each shows the bold bright date, the colored kind tag, a title button that jumps to the item (`jumpToEl` — opens its section and item, clears every pinned layer, flashes it), a snippet with highlighted hits, the section link "Title [NN]", the dashboard `↗` link (with its header tooltip), and the owner-only chat link. Show the top few per group with "Show all N". Enter opens the best result. With an empty box, show "Try" example chips and a one-line tip.

**Layer 2 — inside the linked dashboards:** `search-index.json` is published next to the page through the Artifact `files` map and fetched with `fetch('search-index.json')`: `{meta:{refreshed, dashboards, passages}, p:[{d:artifactId, n:secNum, t:secTitle, x:text}]}`, ~900-character passages per section of every linked dashboard (verbatim text included; audio, styles and scripts stripped). Results group by dashboard: three passages, then "+ N more passages in this dashboard". `heads.json` (dashboard headers) is published alongside.

**Nightly refresh (scheduled task).** Linked dashboards change, so a scheduled task (fresh session, auto approval, push notification) keeps the data current: read the page and its published files (`refresh.py` is published as `refresh.txt`, text/plain, so the task can fetch it); read every linked dashboard (`Artifact` read with `path: "index.html"`, in parallel batches); run `refresh.py extract DASHDIR dashmap.json OUTDIR --exclude PRIVATE.json`; list possible new dashboards/chats for Swami to approve (`refresh.json`, shown only to him in the callout — never added automatically); strip the publish skeleton from the saved page (`refresh.py strip`, so it republishes byte-identical); run the privacy scan; republish the page unchanged with the data files and **no** `capabilities` field; commit to GitHub. Its prompt carries the private exclusion list (see "Privacy").

**Rebuilding a page that has audio.** When a build script regenerates the page, carry the existing `AUDIO-OVERVIEW` block over from the live page (cut it from the saved live copy, insert it before `</header>`) instead of re-recording, unless the narration needs to change.

## Audio overview

Every dashboard carries a single-speaker spoken overview (female voice — Kokoro `af_heart`, generated offline) embedded as an MP3 data URI, played by a locked player centered under the byline. **The player shows no label and no link** — only its controls. Never hand-write the player: `scripts/audio_overview.py` inserts it from `assets/audio-player.html` between `<!-- AUDIO-OVERVIEW:BEGIN -->` / `<!-- AUDIO-OVERVIEW:END -->` markers (just before `</header>`), and replaces that block on any re-run.

**Player features (all built into the snippet — keep them):** go to start / end; jump −10 / −5 / +5 / +10 s, colour-coded (±5 green `#38fa79`, ±10 magenta `#ea38fa`); play/pause; click-to-seek track; time display that toggles on click between total time (cyan `#38dafa`) and time remaining (orange `#fa9938`, shown with a leading −); playback-speed pop-up menu (0.5×–2×, check on current, arrow keys + Esc); volume control — mute button plus a slider, remembered per viewer in browser storage (on iOS, which ignores page volume, only mute shows); a styled mouseover tooltip on every control showing its hot key. Hot keys (ignored while typing in a field such as the dashboard search): ←/→ 5 s, Shift+←/→ 10 s, Home/End, K play/pause, `<`/`>` slower/faster, M mute, `−`/`+` volume down/up 10%.

**Writing the narration.** 2–3 minutes (~300–400 words) by default; for a large dashboard, or when Swami asks for fuller coverage of its breadth and depth, about 4 minutes (~650–700 words). One speaker, plain spoken English describing the dashboard as it stands: what the page is, then each section in order and what a reader finds there, ending with the glossary if present. **Every section is introduced by its number, then its header, before anything else** — "Section one, Dashboard Summary. …", "Section five, The Timeline Debate. …" — with the number said as a word and the header as displayed (say "and" for "&", "versus" for "vs"). Cover every section, including the summary, the Search section, the Mind Map, Glossary, References and Source Document. For Search (section two), say in a sentence or two that you can type a few words to find anything on the page, in any order and with small typos forgiven, narrow the results with filters, and click a result to jump to it. For the Mind Map, say in a sentence or two that it shows the whole page as bubbles you can open, hover for a summary, and click to jump to that spot. For the Source Document, say it opens formatted and can be switched to plain text. One paragraph per thought — paragraph breaks become short pauses. Write years and counts as they should be said, and avoid symbols, URLs and markdown. **Never mention owner-only features** (owner-only columns, rows, links or the refresh button) and never name anyone under NDA. Follow **Pronunciation** below for acronyms and tricky words. Use `python3 scripts/audio_overview.py extract PAGE.html` to get the page's text outline to write from.

**Pronunciation (REQUIRED — the narration text is spelled for the voice, not the reader).** The Kokoro voice reads the narration literally, so write these respellings in `narration.txt` (never in the page itself):

| Say | Write in the narration | Kokoro phonemes |
|---|---|---|
| fillet = "fil-LET" (LET rhymes with "get"); plural "fil-LETS" | `fillette` / `fillettes` | fɪlˈɛt / fɪlˈɛts |
| PLA = "pee el ay", no pauses between letters, long A | `pee-ell-eh` | pˈiːˈɛlˈeɪ |
| PETG = "pee ee tee gee", long E, G said "gee", no pauses | `pee-ee-tee-gee` | pˈiːˈiːtˈiːdʒˈiː |
| AI = "ay eye" (long A, as in "ate") | `AI` (solid capitals) | ˌeɪˈaɪ |
| CNC, WCS, US, STL, MCP and other letter-by-letter acronyms | solid capitals: `CNC`, `WCS`, `MCP` | letter names |
| CAD = the word "cad" (rhymes with "fad"); 3D CAD = "three dee cad" | `cad`, `three D cad` | kˈæd |
| CAM = the word "cam" (rhymes with "ram") | `cam` | kˈæm |
| live (adjective) = long I, rhymes with "hive" | `lyve` | lˈaɪv |
| callout = "call" as in "ball" + "out", no pause; plural "call-outs" | `call-out` / `call-outs` | kˈɔːlˈaʊt |
| AU (Autodesk University) | `Autodesk University` (write it out) | — |
| records (verb) = "ree-CORDS", stress on the 2nd syllable (noun "REK-erds" stays as is) | `[records](/ɹᵻkˈɔːɹdz/)` when the voice gets it wrong | ɹᵻkˈɔːɹdz |
| research (noun) = "REE-search", stress on the 1st syllable | `[research](/ɹˈiːsɜːtʃ/)` | ɹˈiːsɜːtʃ |
| preflight = "PREE-flite", stress on the 1st syllable (the voice says "prih-FLITE") | `[preflight](/pɹˈiːflaɪt/)` | pɹˈiːflaɪt |

Rules behind the table:
- **Never separate letters with spaces** (`A I`, `C N C`, `P L A`): a lone "A" is read as "uh". **Never use dots** (`P.L.A.`, `P.E.T.G.`): dots make the voice pause between letters. Plain solid capitals work for most acronyms; the hyphenated respellings above are for the ones the voice would otherwise say as a word (solid `PLA` comes out "plah", solid `PETG` "petg").
- "fillet" written plainly is read the French way, "fi-LAY" — always write `fillette`.
- "callout" written plainly is read "KAL-out" (kˈælaʊt) — always write `call-out`; the hyphen keeps "call" as in "ball" without a pause (a space, `call out`, adds a word break).
- **Letters or a word? There is no spelling rule; it depends on how people say it.** Written in solid capitals, the voice spells an acronym letter by letter (AI → ay-eye, CNC, CAD → see-ay-dee, CAM → see-ay-em) unless it already knows it as a word (NASA). So: an acronym people say as letters → leave it in solid capitals (`AI`); an acronym people say as a word → write that word in lower case (`cad`, `cam`); one the voice says as a word but people spell out → a hyphenated respelling (`pee-ell-eh`). When unsure how an acronym is said, ask Swami and add it to the table.
- For any other word or acronym in doubt, check it before building: `Kokoro(...).tokenizer.phonemize(text, 'en-us')` (kokoro_onnx, model files in `~/.cache/vibe-audio`) — test it inside a short phrase from the narration, since context can change the result — and make sure every syllable comes out as intended. Add any new rule Swami gives to this table.
- **Noun/verb stress (REQUIRED).** Two-syllable words that can be a noun or a verb take their stress by part of speech: **verb → stress on the 2nd syllable** (re-CORDS, pro-DUCE, ob-JECT, con-VERT, up-DATE), **noun or adjective → stress on the 1st syllable** (REC-ords, PRO-duce, OB-ject, CON-vert, REE-search, UP-date). The voice does not reliably pick the stress from context — in "Fathom records and summarizes Zoom sessions" it said the noun "REK-erds" — and plain respellings (hyphens, extra letters) often make it stress both syllables, so fix these with exact phonemes instead:
  - **Markup:** write `[word](/phonemes/)` in `narration.txt`, e.g. `[records](/ɹᵻkˈɔːɹdz/)` or `[research](/ɹˈiːsɜːtʃ/)`. `ˈ` goes before the stressed syllable; take the rest from the voice's own phonemes for the word (the audit prints them) and move only the stress mark and the vowels it changes (verb first syllables usually reduce to `ᵻ`/`ə`). Never use the markup in the page itself.
  - **Audit every narration before building:** `python3 SKILL_DIR/scripts/stress_audio.py SKILL_DIR audit narration.txt` lists every such word in its sentence with the syllable the voice will stress (marked words show "(marked)"). Decide noun or verb from the sentence and mark each wrong one, then re-run the audit until all are right. The list covers the common stress-shifting words; also check any other two-syllable noun/verb word you notice.
  - **Build with the helper:** `python3 SKILL_DIR/scripts/stress_audio.py SKILL_DIR build PAGE.html narration.txt PAGE.html [--trigger … --artifact …]` — same arguments and result as `scripts/audio_overview.py build`, plus the markup (paragraphs without markup are spoken exactly as before). `SKILL_DIR` is this skill's folder (the one holding `scripts/`). The helper is `scripts/stress_audio.py` in this skill; run it in place, no copying needed.

**Building.**
```
python3 scripts/audio_overview.py build PAGE.html narration.txt PAGE.html \
        [--trigger trig_... --artifact https://claude.ai/artifact/...]
```
First run installs `kokoro-onnx` + `soundfile` (pip) and downloads the model (~350 MB, GitHub releases) to `~/.cache/vibe-audio`; ffmpeg encodes 64 kbps mono MP3 (~0.5 MB per minute). It prints the audio length. Re-running replaces the old audio and keeps any refresh settings already in the page.

### When the recording can't be made

The recording needs code execution with network access: `pip` must reach PyPI (kokoro-onnx, soundfile) and the first run must download the voice model from GitHub's file servers (`release-assets.githubusercontent.com` / `objects.githubusercontent.com`), which many accounts' default network setting blocks even when github.com itself is allowed. ffmpeg must also be present. If `build` exits with an error (or code execution isn't available at all), do all three of these — the dashboard still ships, with a player:

1. **Find the cause** from the error text, in one line:
   - pip can't install packages → code execution has no network access.
   - the model download fails (curl error, 403, "could not resolve host" on a githubusercontent.com address) → the network setting doesn't allow GitHub's file servers.
   - `ffmpeg` not found → this environment has no ffmpeg.
   - no code execution at all → code execution is turned off.
   Try once more only if the error looks temporary (timeout, connection reset); never loop.
2. **Add the browser-voice player** in place of the recording. It reads the same narration aloud with the viewer's browser voice (it differs from computer to computer; no downloads, works on any plan). Use the narration with the Kokoro-only respellings put back to normal words — `pee-ell-eh` → `PLA`, `pee-ee-tee-gee` → `PETG`, `fillette(s)` → `fillet(s)`, `lyve` → `live`, `call-out(s)` → `callout(s)`, and every `[word](/phonemes/)` → `word` (`python3 SKILL_DIR/scripts/stress_audio.py SKILL_DIR plain narration.txt narration-plain.txt` does this one) — keep everything else. Then run `python3 SKILL_DIR/scripts/add_fallback.py PAGE.html narration-plain.txt SKILL_DIR/assets/fallback.html` (the player snippet is `assets/fallback.html`). It goes between the same `AUDIO-OVERVIEW` markers before `</header>`, so a later successful `build` replaces it automatically. Do not wire the owner-only refresh button or declare any capability for it.
3. **Tell the user plainly**, in the reply that delivers the dashboard (not on the page): the audio overview couldn't be recorded here and why (the one-line cause), the page reads it with the browser's own voice instead, and how to get the recorded voice — in Claude, **Settings › Capabilities**: turn on code execution ("Create and edit files"), and set network access to allow `release-assets.githubusercontent.com` and `objects.githubusercontent.com` (package managers plus specific domains), or All domains; on Team/Enterprise an organization owner sets this under Organization settings › Capabilities. Then ask Claude to "add the audio overview" to the dashboard. For a missing ffmpeg, say that instead of the settings advice.

The browser-voice player: play/pause, start over, previous/next paragraph, speed (0.75×–1.5×), a paragraph counter, and hot keys K, ←/→ and Home (ignored while typing). It picks an English female system voice when one exists, speaks sentence by sentence (long utterances stall in some browsers), and disables itself in a browser without speech.





### Owner-only refresh button

The player has a hidden ↻ button that regenerates the audio overview from the page as it currently stands. It appears **only when the viewer is the artifact's owner (Swami)** (`user.isOwner()`), and clicking it fires Swami's own scheduled task through the Claude Code Remote connector — a connector that only runs scheduled tasks belonging to the caller's account, so no one else can trigger it even with the page's code. Everyone else sees the player without the button.

Wire it on every dashboard, after the first publish (the artifact URL is needed):
1. Find the reusable scheduled task named **"Vibe dashboard — refresh audio overview"** with the Claude Code Remote `list_triggers` tool. If it does not exist, create it with `create_trigger` (no schedule — run-on-demand only; `initiation: human_request`; push notifications on) using the prompt in `references/audio-refresh-task.md`. One task serves every dashboard.
2. Re-run `build` with `--trigger <its trig_ id> --artifact <the artifact's URL>` and republish to the same file path with
   `capabilities: {mcp: {servers: [{server: "Claude Code Remote", tools: ["fire_trigger"]}]}}`.
   This is the one capability a dashboard declares; declare nothing else.
3. Tell Swami the first click asks him once to allow the connector for that page.

### Refreshing an existing dashboard

This is what the scheduled task runs (and what to do when Swami asks to "update the audio overview" on a published dashboard): read the artifact (`Artifact` action `read` with the URL, then `read` with `path: "index.html"` for the full file; proceed only if Swami is a writer), run `extract` on it, write a fresh narration of the page as it is now (following **Writing the narration** — each section announced by number, then header — and **Pronunciation** above), run the noun/verb stress audit and fix it, run `python3 SKILL_DIR/scripts/stress_audio.py SKILL_DIR build PAGE narration OUT` (the existing trigger/artifact settings carry over), and publish OUT to the same `url` **without** a `capabilities` field so the declared grant is kept. Change nothing else on the page.

## Privacy: people under NDA

Swami has clients under NDA. **Before publishing or republishing any dashboard** — and before writing its narration, search data or any published data file — check memory for people marked as under NDA / privacy exclusion (his preferences name them; their people files hold their identifiers: aliases, product and file names, profile links).
- **On every page that isn't solely for that client, leave them out entirely:** names, aliases, product and file names, photos, links, recordings and quotes. A page that is about such a client (a session write-up for them) is fine to build, but tell Swami to share it only by email invitation, never "Anyone with the link".
- **Owner-only hiding is not privacy** — hidden content stays in the page source.
- **The exclusion list is private.** It is a JSON file `{"people":[{"name", "reason", "facebook", "terms":[…]}]}` kept at a private working path — never published, never committed to GitHub, never written into a skill (skills are published to a public repo). A scheduled task that publishes a page carries the list in its own prompt (private to the account) and writes it to a private path at the start of each run.
- **Scan gate.** Run `refresh.py scan EXCLUDE.json FILE…` (reference implementation; case-insensitive, separators optional, letter boundaries, digits allowed after a term so "Widget01" still matches "Widget") on the page, its narration and every data file before each publish and commit. Any hit stops the publish. Check hits for false positives ("grace period", "graceful") before acting on them.
- **Never name an excluded person** in a published file, publish label or description, commit message, scheduled task's final line, or skill text; refer to an exclusion only as "1 item excluded for privacy".
- **When Swami names someone new to exclude:** add them to memory (their people file and the preferences line), add their terms to the private list and to every scheduled task that publishes (`update_trigger`), re-scan his pages (list all artifacts; read each with `path: "index.html"` in parallel batches — a subagent keeps the bulk reads out of the main context; scan), and give him a table of every page that mentions them — title, link, updated date, sharing state (an Artifact `read` without `path` states it), "about them" vs "mentions them" — so he can change sharing from each page's Share menu. Reply in chat; don't publish that table.

## Version history (GitHub)

Swami's private repo `swami-claude-skills/vibe-dashboards` keeps every version of every page.
- **Automatic:** the scheduled task "Vibe dashboards — nightly GitHub backup" saves each artifact created or changed that day into `pages/<title-slug>--<artifactId>/` (all its published files) and updates `manifest.json` (id → title, link, updated date, folder; deleted pages are marked `"gone"`, never removed), using `tools/backup.py`. Nothing to do per dashboard.
- **Script-built dashboards:** keep their sources in their own folder (`<kebab-name>/`: `index.html` as published, `build.py`, any `.js` modules, `narration.txt`, `data/*.json`) and commit after every change published in a chat: `add_repo` (owner `swami-claude-skills`, repo `vibe-dashboards`, access `push`), `git clone --depth 1`, confirm the repo is still private (`gh api repos/swami-claude-skills/vibe-dashboards --jq .private` must print `true`; otherwise commit nothing and tell Swami), run the privacy scan on the changed files, commit with a short note (no client names) ending `Co-Authored-By: Claude …`, push to `main`, and verify `git ls-remote origin main` equals `git rev-parse HEAD`. Push large first-time uploads in batches. Never commit an exclusion list.
- **Restoring:** open the file on GitHub, click History, pick the version; Claude republishes it to the same artifact URL.
- **Access:** if `add_repo` says the repo isn't reachable, the Claude GitHub app lacks access — Swami adds the repo under github.com/settings/installations → Claude → Repository access (GitHub first asks him to confirm by email). The account's GitHub email is not his main inbox.

## Self-contained files

Dashboards must be single files. For images, embed as base64 data URIs. If images are large, compress first with Python/Pillow before embedding. No external CSS/JS beyond the Google Fonts link. (Exception: a page with the Search section publishes its own data files beside it through the Artifact `files` map and fetches them by relative URL.)

## Placeholders in the template

`{{PAGE_TITLE}}` (browser tab) · `{{KICKER}}` (small cyan mono eyebrow — REQUIRED, always fill it, never leave blank or delete the element) · `{{H1_TITLE}}` + `{{H1_SUBTITLE}}` · `{{BYLINE_A/B/…}}` (author, group, post link, type — never a copyright mark; no `©`, no `© Swami`) · the REQUIRED Dashboard Summary section: `{{SUMMARY_BADGE}}` (category badge), `{{SUMMARY_INTRO}}` (what the dashboard covers), `{{SUMMARY_CALLOUT_LABEL}}` + `{{SUMMARY_CALLOUT_TEXT}}` (optional intro callout — delete the `.callout` if unused), and the "What each section covers" table rows `{{SEC_x_TITLE/FOCUS/WHEN}}` (add one row per other section, each with an empty `<td class="sec-cat"></td>` Category cell right after the Section cell — JS fills it) · per-section `{{SECTION_N_TITLE}}` + `{{BADGE_N}}` (content sections, numbered from 02) · `{{VERBATIM_TEXT}}` · `{{MAIL_SUBJECT}}` (email subject line) · the Glossary rows `{{GLOSS_x_ID/MATCH/CODE/TERM/DEF}}` (one row per term, each plus a color-coded Topic cell between the Term and the Definition — see "Glossary section"; delete the section and leave the summary row — it auto-drops — if there is nothing to define) · the References section rows `{{REF_x_NUM/SOURCE/TOPIC/TOPIC_COLOR/COVERS/CITED_IN/DOMAIN/URL}}` (one per cited source, with a color-coded Topic cell right after Source — see "References section"; drop the section if the dashboard cites nothing). See `references/patterns.md` for a filled example section and category-naming guidance.

## Toolbar patch (REQUIRED until the template ships it)

Swami (Nov 25, 2026): the toolbar has a **show/hide TOC** button, then **expand all** and **collapse all** as two separate buttons (Nov 24's single toggle is retired), and every section gets its own expand/collapse button. Order, left to right: hide TOC, top, expand all, collapse all, search box, prev / counter / next.
- **Show/hide TOC** (`#tocToggle`, list icon): hides the TOC chip bar so the pinned stack is just the toolbar (on a phone the TOC can fill most of the screen). Label flips to "show TOC" and turns cyan while hidden; `--stack-h` is re-measured so every pinned layer and jump still lands right. The choice is remembered per viewer in browser storage (try/catch).
- **Top** (`#toTop`, arrow-to-bar icon): scrolls smoothly to the top of the page.
- **Expand all / collapse all** (`#expandAll`, `#collapseAll`, large filled up-facing ▲ and down-facing ▼ triangles, in the button's colour): open or close every section and every part in it.
- **Section expand/collapse** (`.sec-all`, added at load to every section header that holds collapsible parts, left of the chevron): opens the section and every part in it; when all its parts are already open, closes them (the section stays open; a click on the header closes it). Alt/Option-click on a section header does the same. Its icon (arrows apart / arrows together, not the toolbar's triangles) and tooltip follow the section's state however parts open or close (by hand, a jump, a search hit).
- All buttons have hover tooltips (`title`). Icons are small inline stroke SVGs in `currentColor`.

Apply it right after copying the template (with the table-fit patch), and to any existing dashboard when it is rebuilt or edited: save the block below as `toolbar_patch.py` in the working directory and run `python3 toolbar_patch.py PAGE.html`. It is idempotent ("already applied" on a second run), upgrades pages made with the single toggle from Nov 24 or the earlier two-button version (and a trial "toolbar extra" block, such as the Skill Library's), and stops with an error, changing nothing, if its anchors have moved.

```python
#!/usr/bin/env python3
"""Vibe-dashboard toolbar patch v3 (idempotent).
- Toolbar, left to right: 'hide TOC' (list icon; choice remembered per viewer), 'top' (scrolls to the top of
  the page), 'expand all' (large up-facing triangle), 'collapse all' (large down-facing triangle), then the
  search box. Two separate expand/collapse buttons (Swami, Nov 25, 2026).
- Every section header that holds collapsible parts gets a small expand/collapse button (left of the chevron):
  it opens the section and every part in it, or, when everything in it is already open, closes all its parts
  (the section itself stays open). Alt/Option-click on a section header does the same. Its icon follows the
  section's state however parts open or close.
Works on a fresh template copy and upgrades pages made with toolbar patch v1 (one-button toggle) or v2.
Usage: python3 toolbar_patch.py PAGE.html"""
import re, sys
p = sys.argv[1]; s = open(p).read()
if '/* ---- toolbar patch v3 js ---- */' in s:
    print('toolbar: already applied'); sys.exit()

ICO = '<svg class="ico{c}" viewBox="0 0 24 24" aria-hidden="true">{d}</svg>'
I_UP = '<svg class="ico tri" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3L22.5 20.5H1.5Z"/></svg>'
I_DN = '<svg class="ico tri" viewBox="0 0 24 24" aria-hidden="true"><path d="M1.5 3.5H22.5L12 21Z"/></svg>'
I_TOP = ICO.format(c='', d='<path d="M5 4h14M12 21V9M7 14l5-5 5 5"/>')
I_TOC = ICO.format(c='', d='<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1.3"/><circle cx="4.5" cy="12" r="1.3"/><circle cx="4.5" cy="18" r="1.3"/>')
BTNS = (f'<button class="tool-btn" id="tocToggle" aria-pressed="true" title="Hide the table of contents to see more of the page">{I_TOC}<span class="tl">hide TOC</span></button>\n'
        f'    <button class="tool-btn" id="toTop" title="Go to the top of the page">{I_TOP}<span class="tl">top</span></button>\n'
        f'    <button class="tool-btn" id="expandAll" title="Open every section and every part in it">{I_UP}<span class="tl">expand all</span></button>\n'
        f'    <button class="tool-btn" id="collapseAll" title="Close every section and every part in it">{I_DN}<span class="tl">collapse all</span></button>')

# 1. markup: whatever TOC / toggle / expand / collapse buttons are there -> the three buttons
m = re.search(r'(?:<button class="tool-btn" id="tocToggle".*?</button>\s*)?(?:<button class="tool-btn" id="toTop".*?</button>\s*)?'
              r'(?:<button class="tool-btn" id="toggleAll".*?</button>|<button class="tool-btn" id="expandAll".*?</button>\s*<button class="tool-btn" id="collapseAll".*?</button>)', s, re.S)
assert m, 'toolbar buttons not found'
s = s[:m.start()] + BTNS + s[m.end():]

# 2. CSS (drop any older copy first, including a trial 'toolbar extra' block)
s = re.sub(r"\n  /\* ---- toolbar patch css ---- \*/.*?/\* ---- end toolbar patch css ---- \*/", "", s, flags=re.S)
s = re.sub(r"\n  /\* ---- toolbar extra css ---- \*/.*?/\* ---- end toolbar extra css ---- \*/", "", s, flags=re.S)
CSS = """
  /* ---- toolbar patch css ---- */
  .tool-btn{display:inline-flex;align-items:center;gap:6px;white-space:nowrap}
  .tool-btn .ico,.sec-all .ico{width:14px;height:14px;flex:none;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
  .tool-btn .ico circle{fill:currentColor;stroke:none}
  .tool-btn .ico.tri{width:16px;height:16px;fill:currentColor;stroke:none}
  #tocToggle .tl{min-width:8ch}
  #tocToggle[aria-pressed="false"]{color:var(--cyan);border-color:rgba(0,229,255,.45)}
  body.toc-hidden .toc-bar{display:none}
  .sec-all{display:inline-flex;align-items:center;justify-content:center;width:28px;height:26px;flex:none;padding:0;
    background:transparent;border:1px solid var(--border);border-radius:6px;color:var(--text-mute);cursor:pointer}
  .sec-all:hover,.sec-all:focus-visible{border-color:var(--cyan);color:var(--cyan)}
  .sec-all .i-col{display:none} .sec-all.all-open .i-col{display:block} .sec-all.all-open .i-exp{display:none}
  .sec-all.all-open{color:var(--cyan);border-color:rgba(0,229,255,.35)}
  /* ---- end toolbar patch css ---- */"""
a = '  .tool-btn:hover{border-color:var(--cyan);color:var(--cyan)}'
assert a in s; s = s.replace(a, a + CSS, 1)

# 3. JS: replace the template's two listeners, or v1's one-button toggle, with the two buttons + section buttons
JS_ALL = r"""/* ---- toolbar patch v3 js ---- */
/* top of page */
document.getElementById('toTop').addEventListener('click', () => window.scrollTo({top: 0, behavior: 'smooth'}));
/* expand all / collapse all: two buttons */
document.getElementById('expandAll').addEventListener('click', () => {
  sections.forEach(s => s.classList.add('open')); document.querySelectorAll('.citem').forEach(c => c.classList.add('open'));
  fitVisibleTables(); syncFloatingHeaders(); });
document.getElementById('collapseAll').addEventListener('click', () => {
  sections.forEach(s => s.classList.remove('open')); document.querySelectorAll('.citem').forEach(c => c.classList.remove('open'));
  syncFloatingHeaders(); });
/* per-section expand/collapse: a small button in each section header (and Alt/Option-click on the header) */
(function(){
  const ICO = d => '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true">' + d + '</svg>';
  const EXP = ICO('<path d="M7 9l5-5 5 5M7 15l5 5 5-5"/>').replace('class="ico"', 'class="ico i-exp"');
  const COL = ICO('<path d="M7 4l5 5 5-5M7 20l5-5 5 5"/>').replace('class="ico"', 'class="ico i-col"');
  const parts = sec => [...sec.querySelectorAll('.citem')];
  const allOpen = sec => sec.classList.contains('open') && parts(sec).every(c => c.classList.contains('open'));
  function toggle(sec){
    if(allOpen(sec)){ parts(sec).forEach(c => c.classList.remove('open')); }
    else { sec.classList.add('open'); parts(sec).forEach(c => c.classList.add('open')); fitVisibleTables(); }
    syncFloatingHeaders(); syncAll();
  }
  function sync(b){
    const o = allOpen(b.closest('.section'));
    if(b.classList.contains('all-open') === o && b.dataset.synced) return;
    b.dataset.synced = '1'; b.classList.toggle('all-open', o);
    b.setAttribute('aria-label', o ? 'Collapse every part of this section' : 'Expand this section and every part in it');
    b.title = o ? 'Close every part of this section (or Alt/Option-click the header)' : 'Open this section and every part in it (or Alt/Option-click the header)';
  }
  const btns = [];
  sections.forEach(sec => {
    const head = sec.querySelector('.sec-head'); if(!head || !parts(sec).length) return;
    const b = document.createElement('button'); b.type = 'button'; b.className = 'sec-all'; b.innerHTML = EXP + COL;
    b.addEventListener('click', e => { e.stopPropagation(); toggle(sec); });
    head.insertBefore(b, head.querySelector('.chevron')); btns.push(b);
  });
  function syncAll(){ btns.forEach(sync); }
  document.addEventListener('click', e => {
    if(!e.altKey) return;
    const head = e.target.closest && e.target.closest('.section .sec-head'); if(!head || e.target.closest('.sec-all')) return;
    const sec = head.closest('.section'); if(!parts(sec).length) return;
    e.preventDefault(); e.stopPropagation(); toggle(sec);
  }, true);
  new MutationObserver(syncAll).observe(document.getElementById('content') || document.body, {subtree:true, attributes:true, attributeFilter:['class']});
  syncAll();
})();
/* ---- end toolbar patch v3 js ---- */
"""
s = re.sub(r"/\* ---- toolbar extra js ---- \*/.*?/\* ---- end toolbar extra js ---- \*/\n", "", s, flags=re.S)
m = (re.search(r"/\* ---- toolbar patch v2 js ---- \*/.*?/\* ---- end toolbar patch v2 js ---- \*/\n", s, re.S)
     or re.search(r"/\* ---- one expand/collapse toggle .*?\nsyncToggleAll\(\);\n", s, re.S))
if m:
    s = s[:m.start()] + JS_ALL + s[m.end():]
else:
    m1 = re.search(r"document\.getElementById\('expandAll'\)\.addEventListener\('click'.*?\n", s)
    m2 = re.search(r"document\.getElementById\('collapseAll'\)\.addEventListener\('click'.*?\n", s)
    assert m1 and m2, 'expand/collapse listeners not found'
    s = s[:m1.start()] + JS_ALL + s[m2.end():]

# 4. JS: TOC show/hide (drop an older copy first)
s = re.sub(r"\n/\* ---- show/hide TOC .*?\n\}\)\(\);\n", "\n", s, flags=re.S)
JS_TOC = r"""
/* ---- show/hide TOC (toolbar button left of expand all / collapse all); remembered per viewer ---- */
(function(){
  const btn = document.getElementById('tocToggle'); if(!btn) return;
  const lab = btn.querySelector('.tl');
  function apply(hidden, save){
    document.body.classList.toggle('toc-hidden', hidden);
    btn.setAttribute('aria-pressed', hidden ? 'false' : 'true');
    lab.textContent = hidden ? 'show TOC' : 'hide TOC';
    btn.title = hidden ? 'Show the table of contents' : 'Hide the table of contents to see more of the page';
    const tip = document.querySelector('.toc-tip'); if(tip) tip.classList.remove('show');
    updateStackH();
    try{ syncFloatingHeaders(); }catch(e){}  /* not yet defined on first load */
    if(save){ try{ localStorage.setItem('vibe-toc-hidden', hidden ? '1' : '0'); }catch(e){} }
  }
  btn.addEventListener('click', () => apply(!document.body.classList.contains('toc-hidden'), true));
  let saved = null; try{ saved = localStorage.getItem('vibe-toc-hidden'); }catch(e){}
  if(saved === '1') apply(true, false);
})();
"""
a = "if(document.fonts && document.fonts.ready) document.fonts.ready.then(updateStackH);\n"
assert a in s; s = s.replace(a, a + JS_TOC, 1)
open(p, 'w').write(s); print('toolbar: applied (v3: top button, triangle expand/collapse, section buttons)')
```

## Source colour patch (REQUIRED until the template ships it)

The template gives the `source` category palette green, which can clash with a content category, and a build that rewrites the category CSS can drop its rules so the Glossary/References badges fall back to dim grey. Run this on every dashboard after the content and category CSS are final (and on existing dashboards when they are rebuilt or edited): save the block as `source_colour_patch.py` in the working directory and run `python3 source_colour_patch.py PAGE.html`. It sets `--cat-source:#f2f2f2`, rewrites the five `cat-source` rules (badge tinted at 12%), and fixes a template bug in `checkCategoryColours` that flagged any hueless colour as clashing with everything (Δhue −639°). Idempotent. A finished page must still show no colour warning in the console.

```python
#!/usr/bin/env python3
"""Vibe-dashboard 'source' category colour patch (idempotent).
The source category (Glossary, References, Source Document) gets its own bright silver-white
#f2f2f2, outside the 8-colour palette, so its badge is bright and never clashes with content categories.
Sets --cat-source and (re)writes the five cat-source CSS rules.
Usage: python3 source_colour_patch.py PAGE.html"""
import re, sys
p = sys.argv[1]; s = open(p).read()
COL, TINT = '#f2f2f2', 'rgba(242,242,242,.12)'  # pure neutral: no hue, so it never clashes
# 1. colour var (replace or add)
if re.search(r'--cat-source:#[0-9a-fA-F]{6};', s):
    s = re.sub(r'--cat-source:#[0-9a-fA-F]{6};', f'--cat-source:{COL};', s)
else:
    m = re.search(r'(    --cat-[a-z]+:#[0-9a-fA-F]{6};[^\n]*\n)(?!    --cat-)', s)
    assert m, 'no --cat- vars found'
    s = s[:m.end()] + f'    --cat-source:{COL};      /* source: bright silver, outside the palette */\n' + s[m.end():]
# 2. CSS rules: drop old ones (and an older patch's comment), add the full set once
s = s.replace('  /* ---- source category colour ---- */\n', '')
s = re.sub(r'\n[ \t]*(?:\.toc-tip\.tc-source \.tip-badge|\.cat-source \.cat-badge|\.cat-source|\.toc-chip\.tc-source(?::hover)?)\{[^}]*\}', '', s)
RULES = (f'\n  .cat-source .cat-badge{{color:var(--cat-source);background:{TINT}}}'
         '\n  .cat-source{border-left:3px solid var(--cat-source)}'
         '\n  .toc-chip.tc-source{border-left-color:var(--cat-source)}'
         '\n  .toc-chip.tc-source:hover{color:var(--cat-source)}'
         f'\n  .toc-tip.tc-source .tip-badge{{color:var(--cat-source);background:{TINT}}}')
i = s.index('</style>')
s = s[:i] + '  /* ---- source category colour ---- */' + RULES + '\n' + s[i:]
# 3. fix the template's colour check: a hueless colour (hue -1) must count as far from every hue
OLD = "let hd = (a.hue<0||b.hue<0) ? 999 : Math.abs(a.hue-b.hue); if(hd>180) hd=360-hd;"
NEW = "let hd = 999; if(a.hue>=0 && b.hue>=0){ hd = Math.abs(a.hue-b.hue); if(hd>180) hd = 360-hd; }"
if OLD in s: s = s.replace(OLD, NEW)
open(p, 'w').write(s); print('source colour: set to', COL)
```

## Source view patch (REQUIRED until the template ships it)

Swami (Nov 24, 2026): the Source Document (Verbatim) section offers **Markdown** or **plain text**, and opens in **Markdown**. A small `Markdown | Plain text` switch sits above the source.
- **Markdown** renders the source: front matter (as a code box), headings, bullet lists (house cyan ●), numbered lists, tables, code blocks, quotes, bold, italic, code and links (https only, opening in a new tab). Single line breaks and leading indents are kept, so plain-text sources (comment threads, transcripts, pasted posts) still read correctly.
- **Plain text** is the original `<pre>`, unchanged.
- The Search section's "Source document" results jump to the same line in whichever view is showing. The toolbar quick search skips the hidden view. Section links, the Glossary and the `[LIST]` wrapping never touch the rendered markdown (the patch's script runs after them).

Run it on every dashboard that has a Source Document, after the Search and Mind Map patches and before the tooltip patch, and on existing dashboards when they are rebuilt or edited: save the block as `source_view_patch.py` in the working directory and run `python3 source_view_patch.py PAGE.html`. Idempotent (a second run refreshes it); a page with no Source Document is left alone. Check in a browser that the switch shows Markdown at load, that a Search result for the source lands on the right line, and that there are no console errors.

```python
#!/usr/bin/env python3
"""Vibe-dashboard Source Document view patch (idempotent; a re-run refreshes it).
Adds a 'Markdown | Plain text' switch to the Source Document (Verbatim) section, set to Markdown at load.
- Markdown: the source rendered (front matter, headings, lists, tables, code blocks, quotes, bold, italic,
  code, links). Single line breaks are kept and leading indents preserved, so plain-text sources
  (comment threads, transcripts) still read correctly.
- Plain text: the original <pre>, unchanged.
Search section results for the source jump to the same spot in whichever view is showing; the toolbar
quick search skips the hidden view. Runs after every other page script, so section links, the glossary
and the [LIST] wrapping never touch the rendered markdown.
Usage: python3 source_view_patch.py PAGE.html"""
import re, sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()
if 'class="section' not in s or 'verbatim-body' not in s:
    print('source view: no Source Document section, nothing to do'); sys.exit(0)

CSS = r'''  /* SRCVIEW:CSS:BEGIN */
  .src-view{display:inline-flex;margin:4px 0 10px;border:1px solid var(--border);border-radius:7px;overflow:hidden}
  .src-view button{font-family:var(--mono);font-size:11.5px;padding:5px 12px;background:var(--panel);color:var(--text-dim);border:0;cursor:pointer}
  .src-view button + button{border-left:1px solid var(--border)}
  .src-view button:hover{color:var(--text)}
  .src-view button.on{background:rgba(0,229,255,.12);color:var(--cyan)}
  .md-view{font-family:var(--sans);font-size:14px;line-height:1.65;color:var(--text);background:var(--panel-2);
    border:1px solid var(--border);border-radius:8px;padding:6px 20px 14px;max-height:520px;overflow:auto;overflow-wrap:anywhere}
  .md-view::-webkit-scrollbar{width:8px;height:8px}
  .md-view::-webkit-scrollbar-thumb{background:var(--border);border-radius:4px}
  .md-view h1,.md-view h2,.md-view h3,.md-view h4,.md-view h5,.md-view h6{font-family:var(--mono);color:var(--cyan);line-height:1.35;margin:18px 0 8px}
  .md-view h1{font-size:19px}.md-view h2{font-size:16.5px;border-bottom:1px solid var(--border);padding-bottom:4px}
  .md-view h3{font-size:14.5px}.md-view h4,.md-view h5,.md-view h6{font-size:13px;color:var(--text)}
  .md-view p{margin:8px 0}
  .md-view ul{margin:6px 0 6px 4px}
  .md-view ol{margin:6px 0;padding-left:26px;list-style:decimal}
  .md-view li{margin:4px 0}
  .md-view ol>li{padding-left:4px}
  .md-view ol>li::before{content:none}
  .md-view ol>li::marker{color:var(--cyan);font-family:var(--mono);font-size:12px}
  .md-view code{font-family:var(--mono);font-size:12.5px;background:var(--panel);border:1px solid var(--border);border-radius:4px;padding:0 4px}
  .md-view pre.md-code{font-family:var(--mono);font-size:12.5px;line-height:1.55;background:var(--panel);border:1px solid var(--border);
    border-radius:6px;padding:12px 14px;margin:10px 0;white-space:pre;overflow-x:auto;max-height:none;color:var(--text-dim)}
  .md-view pre.md-code code{background:none;border:0;padding:0}
  .md-view pre.md-fm{border-color:rgba(242,242,242,.25);white-space:pre-wrap}
  .md-view blockquote{margin:8px 0;padding:2px 14px;border-left:3px solid var(--cyan);color:var(--text-dim)}
  .md-view hr{border:0;border-top:1px solid var(--border);margin:16px 0}
  .md-view a{color:var(--cyan)}
  .md-view .md-tbl{overflow-x:auto;margin:10px 0}
  .md-view table{border-collapse:collapse;font-size:13px}
  .md-view th,.md-view td{border:1px solid var(--border);padding:5px 9px;text-align:left;vertical-align:top}
  .md-view th{font-family:var(--mono);font-size:12px;color:var(--cyan);background:var(--panel)}
  .md-view .gflash{outline:2px solid var(--green);outline-offset:2px}
  /* SRCVIEW:CSS:END */
'''

JS = r'''<script>/* SRCVIEW:JS:BEGIN — Source Document: Markdown | Plain text (source_view_patch.py) */
(function(){
  const body = document.querySelector('.section .verbatim-body'); if(!body) return;
  const pre = body.querySelector('pre'); if(!pre) return;
  const SRC = (typeof VERBATIM === 'string' && VERBATIM.trim()) ? VERBATIM : pre.textContent;
  if(!SRC.trim()) return;
  const esc = t => t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  function inline(t){
    const keep = [];
    const hold = h => '\u0000' + (keep.push(h) - 1) + '\u0000';
    t = t.replace(/(`+)([\s\S]*?[^`])\1(?!`)/g, (m, a, c) => hold('<code>' + esc(c.trim()) + '</code>'));
    t = t.replace(/!\[([^\]]*)\]\(([^)\s]+)[^)]*\)/g, (m, a, u) => hold(/^https?:/i.test(u)
      ? '<a href="' + esc(u) + '" target="_blank" rel="noopener">[image: ' + esc(a || u) + ']</a>' : esc('[image: ' + (a || u) + ']')));
    t = t.replace(/\[([^\]]+)\]\(([^)\s]+)[^)]*\)/g, (m, a, u) => /^https?:/i.test(u)
      ? hold('<a href="' + esc(u) + '" target="_blank" rel="noopener">') + a + hold('</a>') : a);
    t = t.replace(/<(https?:\/\/[^>\s]+)>/g, (m, u) => hold('<a href="' + esc(u) + '" target="_blank" rel="noopener">' + esc(u) + '</a>'));
    t = esc(t);
    t = t.replace(/\*\*(?=\S)([\s\S]*?\S)\*\*/g, '<strong>$1</strong>').replace(/__(?=\S)([\s\S]*?\S)__/g, '<strong>$1</strong>');
    t = t.replace(/(^|[^*\w])\*(?=\S)([^*]*?\S)\*(?!\*)/g, '$1<em>$2</em>').replace(/(^|[^_\w])_(?=\S)([^_]*?\S)_(?![_\w])/g, '$1<em>$2</em>');
    t = t.replace(/~~(?=\S)([\s\S]*?\S)~~/g, '<del>$1</del>');
    return t.replace(/\u0000(\d+)\u0000/g, (m, i) => keep[+i]);
  }
  const brk = (lines, l0) => lines.map((l, k) => { if(!l.trim()) return ''; const m = l.match(/^[ \t]+/); const ind = m ? m[0].replace(/\t/g,'    ').length : 0;
    return '<span data-line="' + (l0 + k) + '">' + (ind ? '<span style="display:inline-block;width:' + (ind * 0.5) + 'em"></span>' : '') + inline(l.trim()) + '</span>'; }).filter(Boolean).join('<br>');
  const lines = SRC.replace(/\r\n?/g, '\n').split('\n');
  const isHr = l => /^ {0,3}([-*_])( *\1){2,} *$/.test(l);
  const isFence = l => /^ {0,3}(`{3,}|~{3,})/.exec(l);
  const listRe = /^(\s*)([-*+]|\d{1,9}[.)])\s+(.*)$/;
  const cells = l => l.trim().replace(/^\||\|$/g, '').split(/(?<!\\)\|/).map(c => c.trim().replace(/\\\|/g, '|'));
  const isSep = l => /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(l) && l.includes('-');
  const startsBlock = (l, n) => !l.trim() || /^ {0,3}#{1,6}\s/.test(l) || isFence(l) || /^ {0,3}>/.test(l) || listRe.test(l) || isHr(l)
    || (l.includes('|') && n !== undefined && isSep(n));
  function blocks(L, base){
    let out = '', i = 0;
    const at = k => ' data-line="' + (base + k) + '"';
    if(base === 0 && /^---\s*$/.test(L[0] || '')){                 // YAML front matter
      const e = L.findIndex((l, k) => k > 0 && /^(---|\.\.\.)\s*$/.test(l));
      if(e > 0){ out += '<pre class="md-code md-fm"' + at(0) + '><code>' + esc(L.slice(0, e + 1).join('\n')) + '</code></pre>'; i = e + 1; }
    }
    while(i < L.length){
      const l = L[i];
      if(!l.trim()){ i++; continue; }
      const f = isFence(l);
      if(f){ const j0 = i; const mark = f[1][0], n = f[1].length; const buf = []; i++;
        while(i < L.length && !new RegExp('^ {0,3}' + (mark === '`' ? '`' : '~') + '{' + n + ',}\\s*$').test(L[i])) buf.push(L[i++]);
        i++; out += '<pre class="md-code"' + at(j0) + '><code>' + esc(buf.join('\n')) + '</code></pre>'; continue; }
      let m = /^ {0,3}(#{1,6})\s+(.*?)\s*#*\s*$/.exec(l);
      if(m){ out += '<h' + m[1].length + at(i) + '>' + inline(m[2]) + '</h' + m[1].length + '>'; i++; continue; }
      if(isHr(l)){ out += '<hr' + at(i) + '>'; i++; continue; }
      if(/^ {0,3}>/.test(l)){ const j0 = i, buf = [];
        while(i < L.length && /^ {0,3}>/.test(L[i])) buf.push(L[i++].replace(/^ {0,3}> ?/, ''));
        out += '<blockquote' + at(j0) + '>' + blocks(buf, base + j0) + '</blockquote>'; continue; }
      if(l.includes('|') && i + 1 < L.length && isSep(L[i + 1])){
        const j0 = i, head = cells(l); i += 2; let h = '<div class="md-tbl"' + at(j0) + '><table><thead><tr>' + head.map(c => '<th>' + inline(c) + '</th>').join('') + '</tr></thead><tbody>';
        while(i < L.length && L[i].trim() && L[i].includes('|')){ const r = cells(L[i]); h += '<tr' + at(i) + '>' + head.map((x, k) => '<td>' + inline(r[k] || '') + '</td>').join('') + '</tr>'; i++; }
        out += h + '</tbody></table></div>'; continue; }
      m = listRe.exec(l);
      if(m){ const j0 = i, ind = m[1].replace(/\t/g, '    ').length, ord = /\d/.test(m[2]);
        let h = '';
        while(i < L.length){
          const mm = listRe.exec(L[i]);
          if(!mm || mm[1].replace(/\t/g, '    ').length !== ind || /\d/.test(mm[2]) !== ord) break;
          const li0 = i, item = [mm[3]]; i++;
          while(i < L.length){
            const x = L[i];
            if(!x.trim()){ const nx = L[i + 1]; if(nx !== undefined && nx.trim() && (nx.match(/^\s*/)[0].length > ind)) { item.push(''); i++; continue; } break; }
            const xm = listRe.exec(x);
            if(xm && xm[1].replace(/\t/g, '    ').length <= ind) break;
            if(!xm && !/^\s/.test(x) && startsBlock(x, L[i + 1])) break;
            item.push(x.replace(new RegExp('^\\s{0,' + (ind + 4) + '}'), '')); i++;
          }
          const firstBlock = item.findIndex((x, k) => k > 0 && (startsBlock(x, item[k + 1]) && x.trim()));
          const textPart = firstBlock < 0 ? item : item.slice(0, firstBlock), rest = firstBlock < 0 ? [] : item.slice(firstBlock);
          h += '<li' + at(li0) + '>' + brk(textPart, base + li0) + (rest.length ? blocks(rest, base + li0 + firstBlock) : '') + '</li>';
          while(i < L.length && !L[i].trim() && L[i + 1] !== undefined){ const nm = listRe.exec(L[i + 1]); if(nm && nm[1].replace(/\t/g,'    ').length === ind) i++; else break; }
        }
        const st = ord ? parseInt(m[2], 10) : 1;
        out += (ord ? '<ol class="no-collapse"' + (st !== 1 ? ' start="' + st + '"' : '') : '<ul class="no-collapse"') + at(j0) + '>' + h + (ord ? '</ol>' : '</ul>'); continue; }
      const j0 = i, buf = [l]; i++;
      while(i < L.length && L[i].trim() && !startsBlock(L[i], L[i + 1])) buf.push(L[i++]);
      out += '<p' + at(j0) + '>' + brk(buf, base + j0) + '</p>';
    }
    return out;
  }
  const md = document.createElement('div'); md.className = 'md-view'; md.innerHTML = blocks(lines, 0);
  const sw = document.createElement('div'); sw.className = 'src-view'; sw.setAttribute('role', 'group');
  sw.innerHTML = '<button type="button" data-v="md" title="Show the source formatted as markdown">Markdown</button>'
               + '<button type="button" data-v="txt" title="Show the source exactly as written, as plain text">Plain text</button>';
  pre.parentNode.insertBefore(sw, pre); pre.parentNode.insertBefore(md, pre);
  function show(v){ md.hidden = v !== 'md'; pre.hidden = v === 'md';
    sw.querySelectorAll('button').forEach(b => { const on = b.dataset.v === v; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); }); }
  sw.addEventListener('click', e => { const b = e.target.closest('button[data-v]'); if(b){ e.stopPropagation(); show(b.dataset.v); } });
  show('md');
  /* Search results for a source passage: in Markdown view, jump to the same spot in the rendered text. */
  const doubled = SRC !== pre.textContent && pre.textContent === SRC.replace(/\n/g, '\n\n');
  if(typeof jumpToEl === 'function'){
    const orig = jumpToEl;
    jumpToEl = function(el){
      if(el && !md.hidden && pre.contains(el)){
        const r = document.createRange(); r.setStart(pre, 0); r.setEnd(el, 0);
        const before = r.toString(), lead = (el.textContent.match(/^\s*/) || [''])[0];
        let line = (before + lead).split('\n').length - 1; if(doubled) line = Math.floor(line / 2);
        let best = null;
        md.querySelectorAll('[data-line]').forEach(x => { if(+x.dataset.line <= line) best = x; });
        return orig(best || md);
      }
      return orig(el);
    };
  }
})();
/* SRCVIEW:JS:END */</script>
'''

# remove an earlier copy, then add the current one
s = re.sub(r'  /\* SRCVIEW:CSS:BEGIN \*/.*?/\* SRCVIEW:CSS:END \*/\n', '', s, flags=re.S)
s = re.sub(r'<script>/\* SRCVIEW:JS:BEGIN.*?/\* SRCVIEW:JS:END \*/</script>\n', '', s, flags=re.S)
i = s.index('</style>'); s = s[:i] + CSS + s[i:]
i = s.rindex('</body>'); s = s[:i] + JS + s[i:]
# toolbar quick search: skip whichever view is hidden
OLD = "node.nodeType===1 && node.tagName!=='SCRIPT'"
NEW = "node.nodeType===1 && !node.hidden && node.tagName!=='SCRIPT'"
if NEW not in s:
    assert OLD in s, 'quick-search walkText anchor not found'
    s = s.replace(OLD, NEW, 1)
open(p, 'w', encoding='utf-8').write(s); print('source view: applied (default Markdown)')
```

## Tooltip patch (REQUIRED until the template ships it)

Run on every dashboard as the last patch before the audio overview (after Search, Mind Map and any other patch that adds buttons), and on existing dashboards when they are rebuilt or edited: save the block as `tooltip_patch.py` in the working directory and run `python3 tooltip_patch.py PAGE.html`. Idempotent. It needs no per-element markup: a MutationObserver converts `title` attributes as they appear, and updates a showing tooltip when a script changes its text (e.g. a toggle button's label). Check in a browser that `document.querySelectorAll('[title]').length` is 0 after load and after clicking a few buttons.

```python
#!/usr/bin/env python3
"""Vibe-dashboard tooltip patch (idempotent): no system (browser) tooltips anywhere.
Every element's title attribute, present at load or set later by a script, is moved to data-vtip
and shown in the house tooltip style (the .gj-tip card: panel-2 background, cyan border, soft shadow),
on hover and on keyboard focus, clamped to the viewport. Inline <svg><title> elements are moved too.
Usage: python3 tooltip_patch.py PAGE.html"""
import sys
p = sys.argv[1]; s = open(p).read()
if '/* ---- house-style tooltips' in s:
    print('tooltips: already applied'); sys.exit()
CSS = """
  /* ---- house-style tooltips (replace every system title tooltip) ---- */
  .vtip{max-width:300px;font-size:12.5px;line-height:1.45;color:var(--text);padding:7px 10px;z-index:95}
"""
assert '</style>' in s
i = s.index('</style>'); s = s[:i] + CSS + s[i:]
JS = r"""
/* ---- house-style tooltips: move every title attribute to data-vtip and show it in the .gj-tip style ---- */
(function(){
  const tip = document.createElement('div');
  tip.className = 'gj-tip vtip'; tip.setAttribute('role', 'tooltip');
  document.body.appendChild(tip);
  let cur = null;
  function place(el){
    const r = el.getBoundingClientRect();
    tip.style.left = '0px'; tip.style.top = '0px';
    const w = tip.offsetWidth, h = tip.offsetHeight;
    let x = Math.max(8, Math.min(r.left + r.width / 2 - w / 2, innerWidth - w - 8));
    let y = r.bottom + 8; if(y + h > innerHeight - 8) y = Math.max(8, r.top - h - 8);
    tip.style.left = x + 'px'; tip.style.top = y + 'px';
  }
  function show(el){ cur = el; tip.textContent = el.dataset.vtip; place(el); tip.classList.add('show'); }
  function hide(){ cur = null; tip.classList.remove('show'); }
  function conv(el){
    if(!el || el.nodeType !== 1) return;
    if(el.tagName.toLowerCase() === 'title' && el.closest('svg')){          /* inline <svg><title> */
      const host = el.parentNode; const t = el.textContent.trim(); el.remove();
      if(host && t){ host.dataset.vtip = t; }
      return;
    }
    if(!el.hasAttribute('title')) return;
    const t = el.getAttribute('title'); el.removeAttribute('title');
    if(!t.trim()) return;
    el.dataset.vtip = t;
    if(!el.hasAttribute('aria-label') && !el.textContent.trim()) el.setAttribute('aria-label', t);
    if(el === cur){ tip.textContent = t; place(el); }
  }
  document.querySelectorAll('[title], svg title').forEach(conv);
  new MutationObserver(ms => {
    for(const m of ms){
      if(m.type === 'attributes'){ conv(m.target); continue; }
      m.addedNodes.forEach(n => { if(n.nodeType !== 1) return; conv(n); n.querySelectorAll && n.querySelectorAll('[title], svg title').forEach(conv); });
    }
  }).observe(document.documentElement, {subtree:true, childList:true, attributes:true, attributeFilter:['title']});
  document.addEventListener('pointerover', e => {
    const el = e.target.closest && e.target.closest('[data-vtip]');
    if(el){ if(el !== cur) show(el); } else if(cur) hide();
  }, true);
  document.addEventListener('focusin', e => { const el = e.target.closest && e.target.closest('[data-vtip]'); if(el && el.matches(':focus-visible')) show(el); });
  document.addEventListener('focusout', hide);
  document.addEventListener('keydown', e => { if(e.key === 'Escape') hide(); });
  addEventListener('scroll', () => { if(cur) hide(); }, {passive:true});
})();
"""
j = s.rindex('</script>'); s = s[:j] + JS + s[j:]
open(p, 'w').write(s); print('tooltips: applied')
```

## Visuals patch (REQUIRED on every page with a diagram or tree)

Swami (Nov 24, 2026): every dashboard draws hierarchy trees the same way. Save the block as `visuals_patch.py` in the working directory and run `python3 visuals_patch.py PAGE.html` after the content (with its tree sources and diagrams) is in place and before the Search and Mind Map patches. It prints how many trees it built. Tree sources quoted inside a `<script>`, `<pre>` or `<textarea>` (an example in a Source Document) are left alone. Check in a browser that every branch starts closed, the two buttons open and close the whole tree, and a Search result for a deep leaf opens its branches and lands on it.

```python
#!/usr/bin/env python3
"""Vibe-dashboard visuals patch (idempotent; a re-run refreshes the CSS and script).
1. Turns every tree source in the page into a collapsible hierarchy tree:
     <ul class="tree-src" data-desc="Map of every menu" data-mm-tip="one-sentence summary" data-intro="optional lead-in">
       <li>Label<span class="tnote">short note</span>
         <ul><li>Child</li><li>Child<span class="tnote">note</span></li></ul></li>
     </ul>
   becomes a [TREE] part (.subsec data-tag="tree") with "expand tree" / "collapse tree" buttons. Branches are
   <details> (all closed), showing their child count in curly braces like the Mind Map; leaves are list items, so the
   Search section finds them. Labels and notes may hold inline HTML (code, strong, links).
2. Adds the page plumbing for diagrams and trees: [DIAGRAM]/[TREE] tags, glossary skips, the .viz figure and
   colour-key CSS, the tree CSS, and opening every closed branch that holds a jump, Search result or search hit.
3. Diagram hover: every box and arrow in a diagram with a colour key shows, in the house tooltip style, what it
   means in that Key (boxes by stroke colour, arrows by solid or dashed line).
Usage: python3 visuals_patch.py PAGE.html"""
import html, re, sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()

# ---------- 1. tree sources -> trees ----------
def parse(src):
    roots, stack, cur = [], [], None      # stack of open <li> nodes
    for m in re.finditer(r'<(/?)(ul|li)\b[^>]*>|([^<]+|<(?!/?(?:ul|li)\b)[^>]*>)', src, re.I):
        close, tag, text = m.group(1), (m.group(2) or '').lower(), m.group(3)
        if text is not None:
            if stack and not stack[-1]['done']: stack[-1]['raw'] += text
            continue
        if tag == 'li' and not close:
            n = {'raw': '', 'kids': [], 'done': False}
            (stack[-1]['kids'] if stack else roots).append(n); stack.append(n)
        elif tag == 'li': stack.pop()
        elif tag == 'ul' and not close and stack: stack[-1]['done'] = True
    return roots
def split(raw):
    notes = re.findall(r'<span class="tnote">(.*?)</span>', raw, re.S)
    lab = re.sub(r'<span class="tnote">.*?</span>', '', raw, flags=re.S)
    return ' '.join(lab.split()), ' '.join(' '.join(notes).split())
def render(nodes):
    out, leaves = [], []
    def flush():
        if leaves: out.append('<ul class="tleaves">' + ''.join(leaves) + '</ul>'); leaves.clear()
    for n in nodes:
        lab, note = split(n['raw']); nt = f'<span class="tnote">{note}</span>' if note else ''
        if n['kids']:
            flush()
            out.append(f'<details class="tnode"><summary class="tree-sum"><span class="tlab">{lab}</span>{nt}'
                       f'<span class="tcount">{len(n["kids"])}</span></summary><div class="tkids">{render(n["kids"])}</div></details>')
        else: leaves.append(f'<li class="tleaf"><span class="tlab">{lab}</span>{nt}</li>')
    flush(); return ''.join(out)
def attr(tag, name):
    m = re.search(name + r'="([^"]*)"', tag); return m.group(1) if m else ''
n_trees = 0
def first_source(s):   # skip examples quoted inside <script>, <pre>, <textarea> (e.g. a Source Document)
    shut = [(b.start(), b.end()) for b in re.finditer(r'<(script|pre|textarea)\b.*?</\1>', s, re.S | re.I)]
    for m in re.finditer(r'<ul\b[^>]*class="tree-src"[^>]*>', s):
        if not any(a <= m.start() < b for a, b in shut): return m
while True:
    m = first_source(s)
    if not m: break
    depth, i = 0, m.start()
    for t in re.finditer(r'<(/?)ul\b[^>]*>', s[m.start():]):
        depth += -1 if t.group(1) else 1
        if depth == 0: end = m.start() + t.end(); break
    else: sys.exit('visuals: a tree-src list is not closed')
    head = m.group(0); body = s[m.end():end - len('</ul>')]
    desc, tip, intro = attr(head, 'data-desc') or 'Hierarchy tree', attr(head, 'data-mm-tip'), attr(head, 'data-intro')
    roots = parse(body)
    if not roots: sys.exit(f'visuals: tree "{desc}" has no items')
    ctl = ('<div class="tree-ctl"><button class="tool-btn tree-btn" data-tree="open" title="Open every branch of this tree">expand tree</button>'
           '<button class="tool-btn tree-btn" data-tree="close" title="Close every branch of this tree">collapse tree</button></div>')
    tree = (f'<div class="subsec" data-tag="tree" data-desc="{desc}"' + (f' data-mm-tip="{tip}"' if tip else '') + '>'
            + (f'<p>{intro}</p>' if intro else '') + f'<div class="tree-box">{ctl}<div class="tree">{render(roots)}</div></div></div>')
    s = s[:m.start()] + tree + s[end:]; n_trees += 1

# ---------- 2. plumbing ----------
CSS = """  /* VISUALS:CSS:BEGIN */
  figure.viz{margin:6px 0 4px}
  .viz-scroll{overflow-x:auto}
  .viz img{display:block;width:100%;min-width:720px;height:auto}
  figure.viz figcaption{font-size:13px;color:var(--text-dim);margin:8px 2px 0;line-height:1.5}
  .viz-legend{display:flex;flex-wrap:wrap;align-items:center;gap:6px 16px;margin:10px 2px 0;font-size:12.5px;color:var(--text-dim)}
  .viz-legend .lg-title{font-family:var(--mono);font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:var(--text-mute)}
  .viz-legend .lg{display:inline-flex;align-items:center;gap:7px}
  .viz-legend .lg-sw{width:13px;height:13px;border-radius:4px;border:1.5px solid var(--c);background:color-mix(in srgb,var(--c) 22%,transparent);flex:none}
  .viz-legend .lg-line{width:26px;height:0;border-top:2px solid var(--c);flex:none}
  .viz-legend .lg-dashed{border-top-style:dashed}
  .tree-ctl{display:flex;gap:8px;margin:4px 0 10px}
  .tree{font-family:var(--mono);font-size:12.5px;line-height:1.55}
  .tree .tkids{margin-left:6px;padding-left:12px;border-left:1px dashed #3a3a46}
  .tree summary{cursor:pointer;list-style:none;padding:3px 0;color:var(--text)}
  .tree summary::-webkit-details-marker{display:none}
  .tree summary::before{content:'▸';color:var(--cyan);display:inline-block;width:16px}
  .tree details[open]>summary::before{content:'▾'}
  .tree summary:hover .tlab{color:var(--cyan)}
  .sec-body .tree ul.tleaves{margin:0;padding:0}
  .sec-body .tree li.tleaf{margin:0;padding:3px 0 3px 16px;color:var(--text)}
  .sec-body .tree li.tleaf::before{left:2px;top:.95em}
  .tree .tnote{color:var(--text-mute);margin-left:10px;font-size:11.5px}
  .tree .tcount{color:var(--text-mute);margin-left:8px;font-size:11px}
  .tree .tcount::before{content:'{'} .tree .tcount::after{content:'}'}
  .viz-hotwrap{position:relative;width:100%;min-width:720px}
  .viz-hot{position:absolute;inset:0;width:100%;height:100%;opacity:0;pointer-events:none}
  .viz-hot .vh-box{pointer-events:all;cursor:help}
  .viz-hot .vh-arrow{pointer-events:stroke;cursor:help}
  /* VISUALS:CSS:END */
"""
JS = r"""<script>/* VISUALS:JS:BEGIN (visuals_patch.py) */
function openDetailsFor(el){ let d = el && el.closest && el.closest('details'); while(d){ d.open = true; d = d.parentElement && d.parentElement.closest('details'); } }
document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('.tree-btn'); if(!b) return;
  e.stopPropagation();
  const open = b.dataset.tree === 'open';
  b.closest('.tree-box').querySelectorAll('.tree details').forEach(d => d.open = open);
}, true);
if(typeof jumpToEl === 'function'){ const _j = jumpToEl; jumpToEl = function(el){ openDetailsFor(el); return _j.apply(this, arguments); }; }
(function(){ const c = document.getElementById('content'); if(!c) return;
  new MutationObserver(ms => { for(const m of ms) for(const n of m.addedNodes) if(n.nodeName === 'MARK') openDetailsFor(n); })
    .observe(c, {childList:true, subtree:true}); })();
/* Diagram hover: each box and arrow in a diagram (figure.viz) shows what it means in that diagram's Key, in the house
   tooltip style. The diagram's own SVG is laid over the image as an invisible copy (no text, so page passes and searches
   ignore it); boxes match a Key swatch by stroke colour, arrows match the Key's solid or dashed line sample. */
(function(){
  const NS = 'http://www.w3.org/2000/svg';
  const norm = c => { c = String(c || '').trim().toLowerCase(); if(/^#[0-9a-f]{3}$/.test(c)) c = '#' + [...c.slice(1)].map(x => x + x).join(''); return c; };
  const sty = (el, k) => el.getAttribute(k) || ((el.getAttribute('style') || '').match(new RegExp('(?:^|;)\\s*' + k + '\\s*:\\s*([^;]+)')) || [])[1] || '';
  const dashed = el => { for(let e = el; e && e.getAttribute; e = e.parentNode){ const d = sty(e, 'stroke-dasharray'); if(d && d !== 'none') return true; } return false; };
  const stroke = el => { for(let e = el; e && e.getAttribute; e = e.parentNode){ const c = sty(e, 'stroke'); if(c && c !== 'none') return norm(c); } return ''; };
  function hover(fig){
    const img = fig.querySelector('img[src^="data:image/svg+xml"]'), lg = fig.querySelector('.viz-legend');
    if(!img || !lg || fig.querySelector('.viz-hot')) return;
    const sw = new Map(); let solidLab = '', dashLab = '';
    lg.querySelectorAll('.lg').forEach(l => { const i = l.querySelector('i'); if(!i) return; const lab = l.textContent.replace(/\s+/g, ' ').trim();
      if(i.classList.contains('lg-sw')) sw.set(norm(i.style.getPropertyValue('--c')), lab);
      else if(i.classList.contains('lg-dashed')) dashLab = lab; else if(i.classList.contains('lg-line')) solidLab = lab; });
    let src;
    try{ const u = img.getAttribute('src'), d = u.slice(u.indexOf(',') + 1);
      src = /;base64,/.test(u) ? new TextDecoder().decode(Uint8Array.from(atob(d), c => c.charCodeAt(0))) : decodeURIComponent(d); }catch(e){ return; }
    const svg = new DOMParser().parseFromString(src, 'image/svg+xml').documentElement;
    if(!svg || svg.nodeName.toLowerCase() !== 'svg') return;
    const vb = (svg.getAttribute('viewBox') || '').trim().split(/[\s,]+/).map(Number);
    const W = vb.length === 4 ? vb[2] : parseFloat(svg.getAttribute('width')), H = vb.length === 4 ? vb[3] : parseFloat(svg.getAttribute('height'));
    if(!(W > 0 && H > 0)) return;
    const texts = [...svg.querySelectorAll('text')].map(t => ({x: parseFloat(t.getAttribute('x')) || 0, y: parseFloat(t.getAttribute('y')) || 0, s: t.textContent.replace(/\s+/g, ' ').trim()}));
    const inDefs = el => !!el.closest('defs,marker,clipPath,mask,pattern,symbol');
    svg.querySelectorAll('rect,circle,ellipse').forEach(el => {
      if(inDefs(el)) return;
      const n = el.nodeName.toLowerCase(), f = k => parseFloat(el.getAttribute(k)) || 0;
      const box = n === 'rect' ? [f('x'), f('y'), f('width'), f('height')]
                : [f('cx') - (f('r') || f('rx')), f('cy') - (f('r') || f('ry')), 2 * (f('r') || f('rx')), 2 * (f('r') || f('ry'))];
      if(box[2] >= W * 0.9 && box[3] >= H * 0.8) return;                       // the background panel
      const lab = sw.get(stroke(el)); if(!lab) return;
      const t = texts.find(t => t.s && t.x >= box[0] - 2 && t.x <= box[0] + box[2] + 2 && t.y >= box[1] && t.y <= box[1] + box[3] + 2);
      const opt = dashed(el) && dashLab ? ' (' + dashLab + ')' : '';
      el.setAttribute('class', 'vh-box'); el.setAttribute('data-vtip', (t ? t.s + ' · ' : '') + 'Key: ' + lab + opt);
    });
    svg.querySelectorAll('path,line,polyline').forEach(el => {
      if(inDefs(el) || !stroke(el)) return;
      if(el.nodeName.toLowerCase() === 'path' && !(sty(el, 'fill') === 'none' || el.getAttribute('marker-end') || el.getAttribute('marker-start'))) return;
      const col = sw.get(stroke(el)), line = dashed(el) ? dashLab : solidLab;
      const lab = [col, line].filter(Boolean).join(', '); if(!lab) return;
      el.setAttribute('class', 'vh-arrow'); el.setAttribute('data-vtip', 'Arrow · Key: ' + lab);
      el.setAttribute('stroke-width', '14'); el.removeAttribute('marker-end'); el.removeAttribute('marker-start');
    });
    if(!svg.querySelector('[data-vtip]')) return;
    svg.querySelectorAll('text,title,desc,image,foreignObject,script').forEach(e => e.remove());
    const ov = document.importNode(svg, true);
    ov.setAttribute('class', 'viz-hot'); ov.setAttribute('aria-hidden', 'true'); ov.removeAttribute('width'); ov.removeAttribute('height');
    if(vb.length !== 4) ov.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
    const wrap = document.createElement('div'); wrap.className = 'viz-hotwrap';
    if(img.style.maxWidth){ wrap.style.maxWidth = img.style.maxWidth; img.style.maxWidth = ''; }
    img.parentNode.insertBefore(wrap, img); wrap.appendChild(img); wrap.appendChild(ov);
  }
  document.querySelectorAll('figure.viz').forEach(f => { try{ hover(f); }catch(e){} });
})();
/* VISUALS:JS:END */</script>
"""
s = re.sub(r'  /\* VISUALS:CSS:BEGIN \*/.*?/\* VISUALS:CSS:END \*/\n', '', s, flags=re.S)
s = re.sub(r'<script>/\* VISUALS:JS:BEGIN.*?/\* VISUALS:JS:END \*/</script>\n', '', s, flags=re.S)
i = s.index('</style>'); s = s[:i] + CSS + s[i:]
i = s.rindex('</body>'); s = s[:i] + JS + s[i:]
m = re.search(r"const TAG_CH = \{[^}]*\}", s); assert m, 'TAG_CH not found'
add = ''.join(f", {k}:'{v}'" for k, v in (('diagram', 'DIAGRAM'), ('tree', 'TREE')) if f"{k}:'" not in m.group(0))
if add: s = s[:m.end() - 1] + add + s[m.end() - 1:]
m = re.search(r"SKIPCLS = \[[^\]]*\]", s); assert m, 'SKIPCLS not found'
add = ''.join(f",'{k}'" for k in ('tree-sum', 'tree-ctl', 'viz') if f"'{k}'" not in m.group(0))
if add: s = s[:m.end() - 1] + add + s[m.end() - 1:]
open(p, 'w', encoding='utf-8').write(s)
print(f'visuals: applied ({n_trees} tree(s) built)')
```

## Built-in fixes

The template already includes the References Topic sort and clickable `[n]` citations, the `syncSectionTitles` title guard (see "Section titles" above), the pinned-header fix (aligned, sortable, resizable clone + `no-sort` opt-out), the `[NN]` section-number brackets, and topic-ID (`.tid`) styling/exclusions. Older versions of this skill required a patch script for those — that is no longer needed; do not re-add it. The patches still required are the table-fit patch, the Search patch (`scripts/search_patch.py`, which includes the subsection patch), the Mind Map patch (both below), the toolbar patch (above), the visuals patch on pages with a diagram or tree (above), and, on other pages that use `.subsec`, the subsection patch ("Generic subsections").

## Table-fit patch (REQUIRED until the template ships it)

The template's `fitVisibleTables` can still (a) open a wide table with sideways scroll when its first column holds long one-line text (e.g. video titles), and (b) squeeze a short column below its longest word so words break mid-word ("Independ-ent", "Connecte-d"). This patch fixes both: it adds `bodyWordMin` (narrowest a column can be without breaking a word), raises each column's floor to that width when all floors still fit, wraps header labels when the first column's share would overflow, and lets the first column wrap as a last resort. It is idempotent (prints "already applied" on a second run) and stops with an error, changing nothing, if the template's code has moved — if that happens, apply the same four changes by hand.

Run `python3 SKILL_DIR/scripts/fit_patch.py PAGE.html` right after copying the template (also safe on an existing dashboard built from this template).

After building, check that every table opens inside the page width at a desktop width (e.g. 1000 px and 1440 px window width) and that no short column breaks a word in half. Also run a few searches in the Search section (a plain word, a typo, a "phrase", a -exclusion, a filter with an empty box) and check phone width (390 px) for sideways scroll.

## Mind Map patch (REQUIRED on every dashboard)

A NotebookLM-style map of the whole page, first built as a test on the Claude Surfaces Compared dashboard and adopted for every dashboard (Nov 2026). The patch adds everything — section, summary row, CSS and script — and stays idempotent: a second run prints "refreshed" and replaces the CSS, the section body and the script with the version below, leaving the section's number and position alone. Run `python3 SKILL_DIR/scripts/mindmap_patch.py PAGE.html` after the content sections are final (and after the table-fit and Search patches), before writing the audio narration. It also works on an existing dashboard built from this template.

**What the patch does on first run**
- Inserts the **Mind Map** section just before Glossary (else References, else Source Document (Verbatim), else the end of `main`), in the Dashboard Summary's category, numbers it after the last section before it, and renumbers every section after it consecutively (this also fixes the template's 97/98/99 placeholders).
- Adds the summary row "Mind Map · Clickable map of every section, table row, list item, and callout · Seeing the whole page at a glance, or jumping straight to a detail" just above the Glossary row; its number fills at runtime (`data-target-title="Mind Map"`).
- Keeps the toolbar search out of the map's SVG (marking text inside `<svg>` would break it) and adds "Mind Map" to the Glossary's `EXCLUDE` set so its intro text is never term-linked or counted.

**What the map shows** (built in the browser at load from the page, so it always matches it)
- Root: the page name (the `<title>` before " — Swami"); its hover card shows the H1 subtitle.
- One branch per section (except the Mind Map itself), labelled `Title [NN] {children}` and coloured with that section's own category colour. Its hover card shows the section's Focus from the section 01 summary table.
- Inside each section: list items (labelled by their topic ID), table rows (labelled by the first cell; hover shows the other cells as "Header: value"), resource cards, subsections and callouts. A section's lists, and its tables when there is more than one block, get their own sub-branch (`Key points {n}` or the table's `data-desc {n}`). Section 01 lists one bubble per summary-table row (hover: Focus · Use when) plus its callouts. Glossary, References, Source Document and Search are single bubbles. Owner-only and hidden content is never mapped.
- Every branch label ends with its number of children in curly braces; final bubbles have none.
- **Optional hints:** `<ul data-mm-label="Features">` names a list's branch (default "Key points"); `<div class="subsec" data-mm-tip="…">` sets a subsection bubble's hover summary (default: its first paragraph or hint line, else a digest of its text — set it on tool or control parts, whose text is mostly labels); `<div class="table-wrap" data-mm-group="1" data-mm-group-label="Only in {v}">` groups a table's rows into sub-branches by that column (0-based), with `{v}` replaced by the value.

**Behaviour** (all built into the script)
- Bubbles: click the › arrow to open or close a branch (the bubble stays put on screen); click the name to jump to that spot (opens the section and item, clears every pinned layer, flashes it green — `jumpToEl` / `scrollToSection`); hover for a card in the page's `.gj-tip` style. **Every bubble has a hover card** — one with no summary still shows its title, where a click goes, and its branch line (fixed Nov 3 2026: subsection bubbles used to get no summary and therefore no card).
- Opens **fitted** to its frame. The frame's height is the space left under the pinned TOC/toolbar, section header and map toolbar, so it can always be seen whole.
- Drag to pan (a drag never counts as a click). Ctrl/⌘ + scroll or trackpad pinch zooms at the cursor; plain scroll still scrolls the page. Two-finger pinch on touch screens. Zoom 5%–300%.
- Double-click empty space = fit. Shift + click a bubble (or the space near one) = zoom to every item in the closest branch (a bubble with children: its own branch, opened if closed; a final bubble: its parent's branch). **zoom region** button, or Alt/Option + drag = drag a box and zoom to it (Esc cancels). Zooms land in the part of the frame actually on screen.
- **Sticky toolbar** (pins under the section header): expand all, collapse all (then fit), − / zoom % / +, fit, zoom region, reset view (100%, map start at the left). Every control has a hover card with what it does and its shortcut.
- A non-sticky hint line sits right after the intro paragraph; the intro includes "HOVER OVER CONTROL FOR TOOLTIP." in faint green.

**Search section:** every page has one; its page index skips the Mind Map section (`title === 'Mind Map'`), like section 01 (`search_patch.py` does this).

The patch is `scripts/mindmap_patch.py`.

After the patch, check in a browser: the map opens fitted, every section appears as a branch with the right `[NN]`, a few bubbles jump to the right place, and the console shows no errors or warnings.

## Search scroll logic (reference)

If a dashboard's script is ever rebuilt or merged, the `hitTarget` / `focusMatch` reference code is in `references/search-scroll.md`.