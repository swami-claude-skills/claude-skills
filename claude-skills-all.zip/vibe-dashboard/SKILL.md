---
name: "vibe-dashboard"
description: "Build Swami's signature \"Vibe Coding\" dark-theme HTML dashboard — a single self-contained .html file with the locked #0d0d0f/#00e5ff design system (JetBrains Mono + DM Sans), collapsible numbered sections, sticky TOC chips with hover tooltips, live search, sortable and resizable tables, a required Dashboard Summary, a spoken audio overview with its player, and an optional cross-linked Glossary of terms. Use this WHENEVER Swami asks for a vibe dashboard, a dashboard, a reference page, a consultation or session write-up, a breakdown, comparison or explainer page in his style, or wants a post, video, document, files or notes turned into a browsable page — including when he asks to add or edit a glossary on a dashboard, or to add, update or refresh a dashboard's audio overview. It is also the delivery format other skills use when they build a dashboard. For pages that are mostly outbound links use vibe-launchpad; for input forms that output text use vibe-promptmaker."
---

# Vibe Dashboard

Swami's dashboards all share ONE locked design system. This skill reproduces it exactly so every page is on-brand and self-contained. Never invent new colors, fonts, or layout patterns — the system is fixed. Vary only the content, the section categories, and the card types.

## Workflow

1. **Get the content.** It comes from a pasted post, uploaded project/CAD/PLC files, a link, a client session, or Swami's own notes. If files are uploaded and not yet in context, read them first (Read / the file-reading skill). If a Google Drive file is referenced, retrieve it. Read everything before structuring.
2. **Structure into sections.** Break the content into logical collapsible sections (typically 4–10). Give each a short title, a running zero-padded number, and a category.
3. **Assign categories.** Categories are named accents that group related sections. Invent them per dashboard from the actual content — there is no fixed list and no cap; use as many or as few as the material warrants. Each category is a `cat-<name>` class mapping to a color + a short UPPERCASE badge label. Reuse the same category across related sections. **Every category's color must be unique and clearly distinguishable** — assign in order from the 8-color palette in the template's CATEGORY ACCENTS comment (cyan, green, yellow, orange, pink, magenta, violet, blue), never repeating a hue; for a 9th+, pick a hue ≥30° from every color already used. A runtime check (`checkCategoryColours`) logs a console warning if any two used category colors are too close — a finished dashboard must produce no such warning. You must define each category's CSS blocks (badge color, section left-edge, TOC chip color, tooltip-badge tint) plus its `--cat-<name>` color var in `:root` — see `references/patterns.md` for the copy-paste block. Do NOT ship generic placeholder category names.
3a. **Pick the glossary terms.** If the dashboard uses jargon, product names, acronyms or field names a reader may not know (most technical dashboards do), include the Glossary section (see "Glossary" under building blocks): one row per term with its color-coded Topic, a one- or two-sentence definition and its matchers. Typically 10–40 terms. Skip it — and delete the section — only when there is genuinely nothing to define.
4. **Copy the template** `assets/template.html` to the working directory, then fill placeholders, add/duplicate sections, and delete anything unused (e.g. the verbatim block).
4a. **Add the audio overview (REQUIRED).** Every dashboard gets a spoken overview and its player, centered under the header byline — see "Audio overview" below. Write the narration from the finished page, then run `scripts/audio_overview.py build`. **If the recording fails, never finish silently and never ship without a player** — follow "When the recording can't be made" under Audio overview: it tells the user why and adds a browser-voice player instead.
5. **Save & publish.** Write the file in the working directory (not `/mnt/user-data/outputs/`)
   with a descriptive kebab-case filename (e.g. `stair-stringer-dashboard.html`), then publish it with
   the Artifact tool. Files in the working directory publish without an approval prompt. Declare
   no runtime capabilities — a dashboard needs none — unless the page has a feature that strictly
   requires one (e.g. a download button needs `downloads`; the audio player's owner-only refresh
   button needs the `mcp` grant shown under "Audio overview"). Send the .html as a file too (SendUserFile
   or present_files) only when Swami asks for a standalone copy. One `.html` file; the two Google
   Fonts are the only external dependency.
   **This rule also governs dashboards built "per the vibe-dashboard skill" by other skills**
   (facebook-comments, makerworld-reviews, youtube-transcript, youtube-comments, …): it overrides any
   save location or `/mnt/user-data/outputs/` fallback those calling skills mention.

## The locked design system — DO NOT deviate

**Palette** (CSS vars in `:root`):
`--bg:#0d0d0f` · `--panel:#141418` · `--panel-2:#1a1a20` · `--cyan:#00e5ff` (accent) · `--green:#00ff88` (search-hit glow) · `--text:#e8e8ec` · `--text-dim:#9aa0aa` · `--text-mute:#6a6f78` · `--border:#26262e`. Category accents are `--cat-<name>` vars assigned in order from the 8-color palette — cyan `#38dafa`, green `#38fa79`, yellow `#dafa38`, orange `#fa9938`, pink `#fa3899`, magenta `#ea38fa`, violet `#7938fa`, blue `#3879fa` (see step 3 and `references/patterns.md`).

**Fonts:** JetBrains Mono (`--mono`, for labels/nums/code/links) + DM Sans (`--sans`, body). Loaded from Google Fonts.

**Non-negotiable behaviors** (all pre-built in the template — keep them intact):
- **Full-width layout.** Every band spans the full width of the browser window — header, TOC bar, toolbar, all sections in `main`, and footer. `main`, `.toc-bar` and `.toolbar` have only side padding (22px), **no `max-width` and no `margin:0 auto` centering cap**. Never reintroduce a fixed content width (e.g. the old `max-width:900px`). Tables still fit their wrapper on open (`fitVisibleTables`), so they now use the full page width too.
- **Header kicker is REQUIRED.** Always include the `.kicker` element above the H1 with a short (1–4 word) UPPERCASE tag naming what kind of page this is (e.g. `CLIENT SESSION`, `TWINCAT PLC BREAKDOWN`, `CAM COMPARISON`, `REVERSE ENGINEERING REFERENCE`). Never leave it blank or delete it.
- **Dashboard Summary is REQUIRED as section 01.** Every dashboard opens with a "Dashboard Summary" section that includes a table titled (via `data-desc`) "What each section covers" — one row per section **including the Dashboard Summary itself (the first row, 01)**, columns **# / Section / Category / Focus / Use When**. The **Category** cell is always left as an empty `<td class="sec-cat"></td>` — `fillSummaryCategories` fills it at runtime with a pill showing the target section's category badge label in that category's own color (copied from the section's badge, so it always matches the dashboard's color coding); never type the category by hand. The "#" cell is a plain `.secnum` span showing the zero-padded section number (e.g. `01`, `02`) — it is NOT a link; navigation is via the clickable section NAME in the Section column (`linkSectionRefs` links it automatically). The table **always ends with pre-wired Glossary, References and "Source Document (Verbatim)" rows** — their numbers are read at runtime (via `data-target-title`) from the number each target section actually displays, and each row auto-drops if its section isn't present. The template ships this as the first section; fill it, don't remove it, and number the real content sections from 02 onward. An optional intro callout is fine; the intro paragraph and the table are not optional.
- **All sections start COLLAPSED.** Never add the `open` class in markup.
- **Sticky stack** (TOC bar + toolbar) sticks to `top:0`; its height is measured at runtime (`getBoundingClientRect().height`, published as the `--stack-h` CSS var) so scroll targets land correctly regardless of wrapping.
- **Three stacked sticky layers.** While scrolling a long table, three headers pin in order below the TOC/toolbar: (1) the main **section header** (`.sec-head`, `position:sticky` at `top:var(--stack-h)`), (2) the **table item header** (`.citem-head`, sticky at `top:calc(var(--stack-h) + var(--sechead-h))`), and (3) the **table column header** (the floating clone, parked below both). Neither `.section` nor `.citem` may use `overflow:hidden` (it would break their sticky headers) — corners are rounded on the header + body instead; keep that. `--stack-h` and `--sechead-h` are measured at runtime; the floating-clone sync (`syncFloatingHeaders`) adds the section- and item-header heights to its park line and only shows the clone once the item header is pinned. **Anything that scrolls to content (search hits especially) must clear ALL of these layers**, not just the TOC/toolbar.
- **Collapsible body items.** Every callout, resource card, and table in a section body is auto-wrapped by JS in a collapsible shell (`.citem`) with a header showing a uniform `[TAG]` (`[CALLOUT]`/`[RESOURCE]`/`[TABLE]`, all one cyan color, left-justified into a shared-width column so descriptions align) and a description. **All items start collapsed.** The tag + description come from the same `deriveSubs` used by the TOC tooltip, so the two always match. Tables take their description from a `data-desc` attribute on the `.table-wrap` (write a logical one per table); callouts use their `.lbl`, resources their `.r-name`. Author the plain `.callout`/`.resource`/`.table-wrap` markup as before — the wrapping is automatic; don't hand-write `.citem`. Keep the wrapping pass and `.citem` CSS intact.
- **Compact TOC with rich hover tooltip.** Chips are compact (number + short title) and wrap inline. Hovering a chip pops a tooltip showing the category badge, the section title, and the list of auto-derived sub-items — every one a clickable link (title scrolls to the section; each sub scrolls to that item and opens it). Tags are bracketed and uniform-colored, left-justified into a column so the text aligns, matching the body headers. The tooltip is positioned by JS (`placeTip`) and clamped to the viewport so it never clips at the left/right (or flips above when it would overflow the bottom). Keep the `deriveSubs`/`buildTip`/`placeTip`/`scrollToAnchor` script and the `.toc-tip` CSS intact. **Hover is hardened — never go back to per-chip `mouseenter`/`mouseleave`.** The tooltip is wired by delegated listeners on the TOC bar (`pointerover` + `mouseover` + `mousemove`), so a missed enter event (pointer already resting on a chip, a host overlay or frame swap) still opens it on the next mouse move; a scroll event hides it only when the page actually moved more than 4px (`tipShownY`), never on a host-fired or zero-distance scroll. Touch/pen: the first tap on a chip shows its tooltip, a second tap jumps, a tap elsewhere closes it; mouse events a tap emulates are ignored (`lastPtr`). Chips are focusable (`tabindex=0`, `role=button`): keyboard focus (`:focus-visible` only — a tap also focuses) shows the tooltip and Enter/Space jumps.
- **Precise jumps.** Every jump (TOC chip, tooltip sub-item, section link, glossary link) goes through `preciseScroll`: it opens and fits whatever is revealed, lands the target just below EVERY pinned layer (TOC/toolbar, plus the section header for sub-items, plus item and column headers for glossary targets), grows an invisible end-of-page spacer (`#endSpacer`) when the target sits too close to the bottom to reach the top, and re-snaps once the smooth scroll settles. `scrollToSection`, `scrollToAnchor` and `jumpToEl` are built on it — never go back to a fixed `stack height + 12` scroll for anything but the section itself.
- **Section titles: `data-title` = the displayed title, encoded once.** Every section's `data-title` must be exactly the text in its `.sec-title`, with `&` written once as `&amp;` — never escape an already-escaped title (a build script that runs `html.escape` on a title already holding `&amp;` produces `&amp;amp;`, and the TOC, section links, summary index and glossary then silently fail to match it). As a safety net the page script opens with `syncSectionTitles`, which resets each `data-title` from its visible `.sec-title` at load. If the copied template's script does not already start with that block, add it as the first thing inside `<script>`:
  ```js
  /* ---- syncSectionTitles: each section's data-title = its visible .sec-title text. ---- */
  document.querySelectorAll('.section').forEach(sec => {
    const t = sec.querySelector('.sec-head .sec-title');
    const v = t ? t.textContent.replace(/\s+/g, ' ').trim() : '';
    if(v && sec.dataset.title !== v) sec.dataset.title = v;
  });
  ```
  Before publishing, check that every row of the section 01 summary table has a working section link.
- **`data-target` navigation, never bare `href` anchors.** TOC chips carry `data-target="<index>"` and scroll via JS. Bare `href="#id"` anchors trigger the artifact sandbox's external-link dialog — do not use them anywhere.
- **Live search** with debounced input, `mark` highlights, prev/next stepping (Enter / Shift-Enter and buttons), `n/total` counter, active hit in green with glow, and a reset "×" that restores scroll position without jumping. The active hit must land just BELOW every pinned layer above it: TOC/toolbar, section header, item header, and (for table rows) the floating column header, never underneath them. A hit inside a sticky header is positioned from that header's container (section / item / table), and the position is re-checked and snapped after the smooth scroll settles. Implemented by `hitTarget` + `focusMatch`; keep them intact and never reintroduce a fixed offset (e.g. stack height + 20) for search hits.
- **Runtime-assembled mailto** on the "Swami" footer link — build the address from parts (`'swami.human' + '@' + 'gmail.com'`); never hard-code it in an `href`.
- **Footer text is exactly:** `Vibe Coding: Swami · AI: Claude` (Swami is the clickable mail link).
- **Pinned column header is aligned AND interactive.** The floating clone uses the live table's fixed layout, identical per-column widths, and the live table's true x offset, so it never shifts left of the columns below it. Clicking a clone header sorts the table (forwarded to the live header, arrows mirrored), and its resizer grips drag/double-click like the live ones. Built into the template.

## Section & card building blocks

Inside a `.sec-body` use these, all pre-styled:
- `<p>` with `<strong>` for emphasis (strong brightens to `--text`).
- `<ul>`/`<li>` — bullets are small custom cyan circles `●` (8px, set by `.sec-body li::before` in the template; never go back to `▸`). **Every list item starts with a topic ID:** `<li><span class="tid">Topic</span>content…</li>` — a short (1–3 word) Title Case label naming what the item is about (e.g. `Positioning`, `Counterbore`, `Swami's answer`), shown as a small mono uppercase cyan tag, followed by the item's content. If an item already opens with a lead-in label (`<strong>Scott's plan:</strong> …`, `Workflow: …`), that label becomes the topic ID and is dropped from the text so it isn't repeated; the rest of the item is unchanged. Timestamp links, section links and glossary terms stay in the content as usual. When asked to retrofit topic IDs onto an existing dashboard, add the tags and keep each item's existing content verbatim. Topic IDs are excluded from glossary linking/counting and from section-reference linking (built into the template), so a tag like "Clearance" is never underlined or counted.
- `.callout` — `.lbl` mono uppercase label + text; cyan left border. For key principles / pro tips / methods.
- `.resource` — a card with `.r-name` (mono), `.r-note`, and an optional link. Rename the class per use if it helps (spec / part / step / stat), but the visual pattern is this card.
- **Tables** — wrap every `<table>` in `<div class="table-wrap" data-desc="…">`. The `data-desc` is the logical description shown in the item's collapsed header and the TOC (e.g. "Cutting parameters", "Regression checklist"). A JS engine floats a clone of the header row just below the sticky TOC/toolbar whenever any part of the table is on screen, so the header stays pinned on **page scroll** — including for short tables that don't scroll internally. (Pure CSS `position:sticky` on `<thead>` only pins inside a scrolling wrapper, so short tables would never pin. The floating clone lives on `document.body` and parks below the section and item headers.) Keep the `buildFloatingHeaders`/`syncFloatingHeaders` script and the `.float-head` CSS intact. Add `class="table-wrap pin-first"` to also freeze the first column for wide tables. **All tables are sortable, resizable, and word-wrapped** — `initSortableTables` adds to every header: a click-to-sort affordance (asc → desc → original) with a clearly visible indicator, and a draggable column-resizer on the right edge (double-click it to fit the column to its widest cell). **On open, every table is sized to fit its wrapper width** (`fitVisibleTables`) — no horizontal scroll; the first column fits its widest entry on one line and the remaining columns share the rest by their natural proportions, word-wrapping as needed, so all columns are visible within the page width. **Tables refit whenever the page width changes** (window or app panel resized after a table was opened — a debounced `resize` handler re-flags and refits them), so a table opened at a narrow width still spans the full width once the page is widened; only a table whose columns the reader dragged or double-clicked by hand (`data-user-sized`) keeps its manual widths. **No column is ever squeezed below its header label:** each column's floor is its one-line header label plus an 8px gap (`HEAD_GAP`) before the sort arrows. If those floors can't all fit, header labels may wrap (`head-wrap` class, mirrored on the pinned clone) and the floor drops to the header's longest word. Only if even that can't fit (e.g. a 5-column table on a phone) does the table scroll sideways on open — labels never sit under the arrows. Dragging a divider resizes **only that column** — every column is pinned to an explicit px width (`table-layout:fixed` + a `<colgroup>`; `setColWidth` keeps the table element exactly as wide as the sum of its columns, so it fits on open yet grows and lets the wrapper scroll when a column is dragged wider). **Resizing a column never changes the table's current sort order or direction** — a drag only touches column widths, never rows. Body cells word-wrap; header labels stay one line; visible dividers separate columns. Keep the `initSortableTables`/`measureColWidth`/`fitVisibleTables` scripts and the refit-on-resize handler, the `<colgroup>` they build, and the sort/resizer/divider CSS intact. Use tables for specs, comparisons, parameter lists, BOMs, etc. Do not put a bare `<table>` directly in a `.sec-body`. **Non-sortable opt-out:** `<div class="table-wrap no-sort" data-desc="…">` keeps the table resizable and pinned but removes sort indicators and click-sort (live and pinned header); use it when Swami asks for a table that must not be sortable (e.g. a list converted to a table whose order matters). **Step tables get a Topic column:** any table with a **Step** column (walkthroughs, procedures, how-tos) also gets a **Topic** column placed immediately before Step (e.g. `# / Topic / Step / When`). Each Topic cell holds a topic ID tag, `<td><span class="tid">Topic</span></td>`, using the same short (1–3 word) Title Case labels as list topic IDs (e.g. `Sketch`, `Cut & keep`, `Joint Origin`), and the Step text stays unchanged. When asked to retrofit this onto an existing dashboard, add the column and tags and keep every other cell verbatim. In table cells, long tags wrap only between words, never mid-word, so they stay inside narrow columns (built into the template).
- **Inline section links.** `linkSectionRefs` turns EVERY reference to a section — by name ("Surface & Temperature") or by number ("section 3", "sec. 04", "§2") — into a clickable `.secref` jump-link, everywhere in body text including inside all tables. Automatic; just write references naturally. It only skips existing links and code so nothing is double-linked, and a number with no matching section is left as plain text. **Every** section link anywhere in the body also gets the target's section number appended in square brackets — "Facing **[03]**" — which is itself a clickable jump. Two exceptions: links inside **tables in section 01** (the Dashboard Summary index already shows the number in its # column), and links whose text is already followed by that exact `[NN]` (never double it). A source citation like `[17]` is not a section number and never blocks the suffix. Built into the template.
- **Glossary section** (built into the template; sits just before References). A table titled `data-desc="Glossary of terms"` with columns **Term / Topic / Definition / Appears in / Qty**, cross-linked to the body in both directions — all automatic from the rows you write:
  - **Row markup:** `<tr data-gterm="ID" data-match="REGEX" data-code="EXACT|EXACT"><td><strong>Term</strong></td><td><span class="tid" style="--tc:#38dafa">Topic</span></td><td>Definition</td><td class="gloss-uses"></td><td class="gloss-count"></td></tr>`. `data-gterm` is a short unique kebab-case id. `data-match` is a case-insensitive regex for the term in body **text** (use `|` for alternatives and `s?` for plurals, e.g. `plugins?|plugin bundle`); start and end it with a word character so word boundaries work. `data-code` lists exact `<code>` texts that are this term, `|`-separated (e.g. `SKILL.md|skill.md`). Either matcher may be empty. Leave the last two cells empty — JS fills them. Definitions: plain text, one or two sentences, accurate.
  - **Topic column (REQUIRED, color-coded; always the 2nd column).** Every glossary row gets a topic tag naming what the term is about — a short (1–3 word) Title Case label like list topic IDs (e.g. `Skills`, `Downloads`, `Toolpaths`, `Materials`). Group the terms into a handful of meaningful topics (typically 3–8; several terms share each). **Each topic has its own color**, set inline as `style="--tc:<hex>"` on the tag: assign colors in order of each topic's first appearance down the table from the 8-color palette — cyan `#38dafa`, green `#38fa79`, yellow `#dafa38`, orange `#fa9938`, pink `#fa3899`, magenta `#ea38fa`, violet `#7938fa`, blue `#3879fa` (a 9th+ topic: a hue ≥30° from every color already used); the same topic always gets the same color. Add `<th>Topic</th>` to the header row between Term and Definition, so the header reads Term / Topic / Definition / Appears in / Qty. The template's glossary hover script still reads the definition from the second cell, so patch it once per page: replace `def = row.cells[1].textContent.trim();` with `def = ([...row.cells].slice(1).find(c => !c.querySelector('.tid') && !c.matches('.gloss-uses,.gloss-count')) || {textContent:''}).textContent.trim();` (the term stays `row.cells[0]`). The template does not yet style colored tags, so add this rule once to the page's `<style>`, right after the `li .tid,td .tid{…}` rule: `.tid[style*="--tc"]{color:var(--tc);background:color-mix(in srgb,var(--tc) 9%,transparent);border-color:color-mix(in srgb,var(--tc) 40%,transparent)}` (tags without `--tc`, such as list topic IDs, stay cyan). In the glossary intro paragraph, add one sentence: "Each term's **Topic** tag names what it is about, one color per topic." Topic tags are already excluded from glossary linking and counting. When asked to retrofit this onto an existing dashboard (including an older glossary whose "Topic ID" column sits after Definition), put the Topic column second, name its header Topic, apply the script patch, CSS rule and intro sentence, and keep every other cell verbatim.
  - **Default sort: Topic (ascending).** The glossary table opens pre-sorted by its Topic column so the color-coded tags read as grouped blocks rather than a random mix. After `initSortableTables()` and `buildFloatingHeaders()`, add a self-invoking function that finds the Glossary section's table, locates the Topic header cell, and `.click()`s it once to trigger an ascending sort. **Important:** because `initSortableTables` appends sort-indicator child elements (`▴▾`) inside each `th`, `th.textContent` includes those characters. Match the header by reading only its first text node (`th.childNodes[0]`), not `textContent`. The snippet:
    ```js
    /* ---- glossary: start sorted by Topic column (asc) ---- */
    (function(){
      const gsec = document.querySelector('.section[data-title="Glossary"]');
      if(!gsec) return;
      const table = gsec.querySelector('.table-wrap table');
      if(!table || !table.tHead) return;
      const ths = [...table.tHead.rows[0].cells];
      const ti = ths.findIndex(th => {
        const t = th.childNodes[0];
        return t && t.nodeType === 3 && t.nodeValue.trim().toUpperCase() === 'TOPIC';
      });
      if(ti < 0) return;
      ths[ti].click();
    })();
    ```
    Place it right after `buildFloatingHeaders();` (before `checkCategoryColours`). It is a no-op when there is no Glossary or no Topic column.
  - **Body → glossary:** `linkGlossary` wraps the **first** mention of each term **per content section** in a dotted-underline `.gterm` (only the first, so common words don't underline dozens of times). Hover shows the term, its definition, and "(click term to go to 'Glossary')"; click jumps to the term's row and flashes it green. It skips the summary, Glossary, References and verbatim sections, headings, column headers, section links, pills/badges and callout labels.
  - **Glossary → body:** the **Appears in** cell gets one numbered `.gloss-jump` per section where the term appears, colored by that section's category. Hover previews the section (number, title, category badge), the line with the term highlighted, and the mention count in that section; click opens the section/item, scrolls the term clear of every pinned header and flashes it green.
  - **Qty:** total mentions across the content sections, repeats included (linked or not); sorts numerically. A term with no mentions shows "—" and 0 — reword its matcher or drop the row.
  - **Longest pattern wins** when terms overlap (e.g. "Claude Marketplace" beats "marketplace"); a bad regex logs a console warning and disables text matching, so a finished dashboard must show no such warning.
  - The Dashboard Summary row for the Glossary is pre-wired (`data-target-title="Glossary"`, auto-numbered, auto-dropped if the section is deleted). Mention the Glossary in the summary intro ("terms with a dotted underline jump to the Glossary") when you include one.
- **References section.** When the dashboard cites external sources, include a "References" section immediately before the verbatim section (the template ships it) with a table — columns Source / What it covers / Domain / Webpage — the Webpage cell holding the real `target="_blank"` link. One row per cited source.
- Verbatim/raw-source block — a `.verbatim-body` section with `<pre id="verbatim">`; text is injected from the `VERBATIM` JS string (kept out of markup to avoid re-parsing). Include only when preserving an original post/source; otherwise delete the block and its section.

## Audio overview

Every dashboard carries a single-speaker spoken overview (female voice — Kokoro `af_heart`, generated offline) embedded as an MP3 data URI, played by a locked player centered under the byline. **The player shows no label and no link** — only its controls. Never hand-write the player: `scripts/audio_overview.py` inserts it from `assets/audio-player.html` between `<!-- AUDIO-OVERVIEW:BEGIN -->` / `<!-- AUDIO-OVERVIEW:END -->` markers (just before `</header>`), and replaces that block on any re-run.

**Player features (all built into the snippet — keep them):** go to start / end; jump −10 / −5 / +5 / +10 s, colour-coded (±5 green `#38fa79`, ±10 magenta `#ea38fa`); play/pause; click-to-seek track; time display that toggles on click between total time (cyan `#38dafa`) and time remaining (orange `#fa9938`, shown with a leading −); playback-speed pop-up menu (0.5×–2×, check on current, arrow keys + Esc); volume control — mute button plus a slider, remembered per viewer in browser storage (on iOS, which ignores page volume, only mute shows); a styled mouseover tooltip on every control showing its hot key. Hot keys (ignored while typing in a field such as the dashboard search): ←/→ 5 s, Shift+←/→ 10 s, Home/End, K play/pause, `<`/`>` slower/faster, M mute, `−`/`+` volume down/up 10%.

**Writing the narration.** 2–3 minutes (~300–400 words), one speaker, plain spoken English describing the dashboard as it stands: what the page is, then each section in order and what a reader finds there, ending with the glossary if present. **Every section is introduced by its number, then its header, before anything else** — "Section one, Dashboard Summary. …", "Section five, The Timeline Debate. …" — with the number said as a word and the header as displayed (say "and" for "&", "versus" for "vs"). Cover every section, including the summary, Glossary, References and Source Document. One paragraph per thought — paragraph breaks become short pauses. Write years and counts as they should be said, and avoid symbols, URLs and markdown. Follow **Pronunciation** below for acronyms and tricky words. Use `python3 scripts/audio_overview.py extract PAGE.html` to get the page's text outline to write from.

**Pronunciation (REQUIRED — the narration text is spelled for the voice, not the reader).** The Kokoro voice reads the narration literally, so write these respellings in `narration.txt` (never in the page itself):

| Say | Write in the narration | Kokoro phonemes |
|---|---|---|
| fillet = "fil-LET" (LET rhymes with "get"); plural "fil-LETS" | `fillette` / `fillettes` | fɪlˈɛt / fɪlˈɛts |
| PLA = "pee el ay", no pauses between letters, long A | `pee-ell-eh` | pˈiːˈɛlˈeɪ |
| PETG = "pee ee tee gee", long E, G said "gee", no pauses | `pee-ee-tee-gee` | pˈiːˈiːtˈiːdʒˈiː |
| AI = "ay eye" (long A, as in "ate") | `AI` (solid capitals) | ˌeɪˈaɪ |
| CNC, WCS, US, STL and other letter-by-letter acronyms | solid capitals: `CNC`, `WCS` | letter names |
| CAD = the word "cad" (rhymes with "fad"); 3D CAD = "three dee cad" | `cad`, `three D cad` | kˈæd |
| CAM = the word "cam" (rhymes with "ram") | `cam` | kˈæm |
| live (adjective) = long I, rhymes with "hive" | `lyve` | lˈaɪv |
| callout = "call" as in "ball" + "out", no pause; plural "call-outs" | `call-out` / `call-outs` | kˈɔːlˈaʊt |

Rules behind the table:
- **Never separate letters with spaces** (`A I`, `C N C`, `P L A`): a lone "A" is read as "uh". **Never use dots** (`P.L.A.`, `P.E.T.G.`): dots make the voice pause between letters. Plain solid capitals work for most acronyms; the hyphenated respellings above are for the ones the voice would otherwise say as a word (solid `PLA` comes out "plah", solid `PETG` "petg").
- "fillet" written plainly is read the French way, "fi-LAY" — always write `fillette`.
- "callout" written plainly is read "KAL-out" (kˈælaʊt) — always write `call-out`; the hyphen keeps "call" as in "ball" without a pause (a space, `call out`, adds a word break).
- For any other word or acronym in doubt, check it before building: `Kokoro(...).tokenizer.phonemize(text, 'en-us')` (kokoro_onnx, model files in `~/.cache/vibe-audio`) — test it inside a short phrase from the narration, since context can change the result — and make sure every syllable comes out as intended. Add any new rule Swami gives to this table.

**Building.**
```
python3 scripts/audio_overview.py build PAGE.html narration.txt PAGE.html \
        [--trigger trig_... --artifact https://claude.ai/artifact/...]
```
First run installs `kokoro-onnx` + `soundfile` (pip) and downloads the model (~350 MB, GitHub releases) to `~/.cache/vibe-audio`; ffmpeg encodes 64 kbps mono MP3 (~0.5 MB per minute). It prints the audio length. Re-running replaces the old audio and keeps any refresh settings already in the page.

### When the recording can't be made

The recording needs code execution with network access: `pip` must reach PyPI (kokoro-onnx, soundfile) and the first run must download the voice model from GitHub's file servers (`release-assets.githubusercontent.com` / `objects.githubusercontent.com`), which many accounts' default network setting blocks even when github.com itself is allowed. ffmpeg must also be present. If `build` exits with an error (or code execution isn't available at all), do all three of these — the dashboard still ships, with a player:

1. **Find the cause** from the error text, in one line:
   - pip can't install packages → code execution has no network access.
   - the model download fails (curl error, 403, "could not resolve host" on a githubusercontent.com address) → the network setting doesn't allow GitHub's file servers.
   - `ffmpeg` not found → this environment has no ffmpeg.
   - no code execution at all → code execution is turned off.
   Try once more only if the error looks temporary (timeout, connection reset); never loop.
2. **Add the browser-voice player** in place of the recording. It reads the same narration aloud with the viewer's browser voice (it differs from computer to computer; no downloads, works on any plan). Use the narration with the Kokoro-only respellings put back to normal words — `pee-ell-eh` → `PLA`, `pee-ee-tee-gee` → `PETG`, `fillette(s)` → `fillet(s)`, `lyve` → `live`, `call-out(s)` → `callout(s)` — keep everything else. Save the snippet below as `fallback.html` and the script below as `add_fallback.py` (both verbatim), then run `python3 add_fallback.py PAGE.html narration.txt fallback.html`. It goes between the same `AUDIO-OVERVIEW` markers before `</header>`, so a later successful `build` replaces it automatically. Do not wire the owner-only refresh button or declare any capability for it.
3. **Tell the user plainly**, in the reply that delivers the dashboard (not on the page): the audio overview couldn't be recorded here and why (the one-line cause), the page reads it with the browser's own voice instead, and how to get the recorded voice — in Claude, **Settings › Capabilities**: turn on code execution ("Create and edit files"), and set network access to allow `release-assets.githubusercontent.com` and `objects.githubusercontent.com` (package managers plus specific domains), or All domains; on Team/Enterprise an organization owner sets this under Organization settings › Capabilities. Then ask Claude to "add the audio overview" to the dashboard. For a missing ffmpeg, say that instead of the settings advice.

The browser-voice player: play/pause, start over, previous/next paragraph, speed (0.75×–1.5×), a paragraph counter, and hot keys K, ←/→ and Home (ignored while typing). It picks an English female system voice when one exists, speaks sentence by sentence (long utterances stall in some browsers), and disables itself in a browser without speech.

`fallback.html`:
```html
<!-- AUDIO-OVERVIEW:BEGIN browser-voice fallback (replaced by audio_overview.py build when a recording can be made) -->
<style>
.ao-fb{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:8px;width:max-content;max-width:100%;margin:18px auto 0;padding:8px 14px;background:var(--panel-2);border:1px solid var(--border);border-radius:999px;font-family:var(--mono);font-size:12px;color:var(--text-dim)}
.ao-fb button{font:inherit;color:var(--text-dim);background:transparent;border:1px solid var(--border);border-radius:999px;min-width:32px;height:32px;padding:0 10px;cursor:pointer}
.ao-fb button:hover:not(:disabled){color:var(--cyan);border-color:var(--cyan)}
.ao-fb button:disabled{opacity:.4;cursor:not-allowed}
.ao-fb .ao-play{width:40px;height:40px;color:var(--cyan);border-color:rgba(0,229,255,.5);font-size:14px}
.ao-fb .ao-skip{color:#38fa79;border-color:rgba(56,250,121,.45)}
.ao-fb .ao-pos{min-width:58px;text-align:center;color:#38dafa}
</style>
<div class="ao-fb" id="aoFb" role="group" aria-label="Audio overview" title="Audio overview, read aloud by this browser's built-in voice (the voice differs from computer to computer)">
  <button type="button" class="ao-restart" aria-label="Start over" title="Start over (Home)">⏮</button>
  <button type="button" class="ao-skip ao-prev" aria-label="Previous paragraph" title="Previous paragraph (←)">‹</button>
  <button type="button" class="ao-play" aria-label="Play" title="Play / pause (K)">▶</button>
  <button type="button" class="ao-skip ao-next" aria-label="Next paragraph" title="Next paragraph (→)">›</button>
  <span class="ao-pos" aria-live="off"></span>
  <button type="button" class="ao-rate" aria-label="Speed" title="Speed (click to change)">1×</button>
</div>
<script type="application/json" id="aoFbText">__PARAGRAPHS_JSON__</script>
<script>
(() => {
  const bar = document.getElementById('aoFb'), P = JSON.parse(document.getElementById('aoFbText').textContent || '[]');
  const $ = s => bar.querySelector(s), play = $('.ao-play'), pos = $('.ao-pos'), rateB = $('.ao-rate');
  const S = window.speechSynthesis;
  if (!S || !window.SpeechSynthesisUtterance || !P.length) {
    bar.title = 'This browser cannot read the overview aloud.'; bar.querySelectorAll('button').forEach(b => b.disabled = true); pos.textContent = '—'; return;
  }
  const RATES = [0.75, 1, 1.25, 1.5]; let rate = 1, i = 0, playing = false, gen = 0, voice = null;
  const PREF = ['Samantha', 'Ava', 'Allison', 'Susan', 'Aria', 'Jenny', 'Zira', 'Google US English', 'Google UK English Female', 'Karen', 'Moira', 'Tessa', 'Serena'];
  const pickVoice = () => { const v = S.getVoices().filter(x => /^en([-_]|$)/i.test(x.lang));
    for (const n of PREF) { const m = v.find(x => x.name.includes(n)); if (m) return m; }
    return v.find(x => /female/i.test(x.name)) || v.find(x => x.default) || v[0] || null; };
  const loadVoice = () => { voice = pickVoice(); };
  loadVoice(); if (S.addEventListener) S.addEventListener('voiceschanged', loadVoice);
  const show = () => { pos.textContent = Math.min(i + 1, P.length) + ' / ' + P.length; play.textContent = playing ? '❚❚' : '▶'; play.setAttribute('aria-label', playing ? 'Pause' : 'Play'); };
  const sentences = t => (t.match(/[^.!?]+[.!?]+["')\]]*\s*|[^.!?]+$/g) || [t]).map(s => s.trim()).filter(Boolean);
  // speak sentence by sentence (long utterances stall in some browsers); pause = stop and resume at the paragraph
  function speakFrom(k) {
    S.cancel(); const my = ++gen; i = Math.max(0, Math.min(k, P.length - 1)); playing = true; show();
    let q = sentences(P[i]), j = 0;
    const next = () => {
      if (my !== gen) return;
      if (j < q.length) { const u = new SpeechSynthesisUtterance(q[j++]); if (voice) u.voice = voice; u.lang = voice ? voice.lang : 'en-US'; u.rate = rate; u.onend = next; u.onerror = next; S.speak(u); }
      else if (i < P.length - 1) { i++; show(); setTimeout(() => { if (my === gen) { q = sentences(P[i]); j = 0; next(); } }, 450); }
      else { playing = false; i = 0; show(); }
    };
    next();
  }
  const stop = () => { gen++; S.cancel(); playing = false; show(); };
  play.addEventListener('click', () => playing ? stop() : speakFrom(i));
  $('.ao-restart').addEventListener('click', () => playing ? speakFrom(0) : (i = 0, show()));
  $('.ao-prev').addEventListener('click', () => playing ? speakFrom(i - 1) : (i = Math.max(0, i - 1), show()));
  $('.ao-next').addEventListener('click', () => playing ? speakFrom(i + 1) : (i = Math.min(P.length - 1, i + 1), show()));
  rateB.addEventListener('click', () => { rate = RATES[(RATES.indexOf(rate) + 1) % RATES.length]; rateB.textContent = rate + '×'; if (playing) speakFrom(i); });
  document.addEventListener('keydown', e => {
    const t = e.target; if (e.ctrlKey || e.metaKey || e.altKey || (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)))) return;
    if (e.key === 'k' || e.key === 'K') { e.preventDefault(); play.click(); }
    else if (e.key === 'ArrowRight' && playing) { e.preventDefault(); $('.ao-next').click(); }
    else if (e.key === 'ArrowLeft' && playing) { e.preventDefault(); $('.ao-prev').click(); }
    else if (e.key === 'Home' && playing) { e.preventDefault(); $('.ao-restart').click(); }
  });
  addEventListener('pagehide', () => S.cancel());
  show();
})();
</script>
<!-- AUDIO-OVERVIEW:END -->
```

`add_fallback.py`:
```python
import json, sys, re
page_path, narr_path, snip_path = sys.argv[1:4]
paras = [' '.join(p.split()) for p in re.split(r'\n\s*\n|\n', open(narr_path, encoding='utf8').read()) if p.strip()]
block = open(snip_path, encoding='utf8').read().strip().replace('__PARAGRAPHS_JSON__', json.dumps(paras, ensure_ascii=False).replace('</', '<\\/'))
page = open(page_path, encoding='utf8').read()
B, E = '<!-- AUDIO-OVERVIEW:BEGIN', '<!-- AUDIO-OVERVIEW:END -->'
i = page.find(B)
if i >= 0: j = page.find(E, i) + len(E); page = page[:i] + block + page[j:]
else: k = page.find('</header>'); page = page[:k] + block + '\n' + page[k:]
open(page_path, 'w', encoding='utf8').write(page); print('browser-voice player added,', len(paras), 'paragraphs')
```

### Owner-only refresh button

The player has a hidden ↻ button that regenerates the audio overview from the page as it currently stands. It appears **only when the viewer is the artifact's owner (Swami)** (`user.isOwner()`), and clicking it fires Swami's own scheduled task through the Claude Code Remote connector — a connector that only runs scheduled tasks belonging to the caller's account, so no one else can trigger it even with the page's code. Everyone else sees the player without the button.

Wire it on every dashboard, after the first publish (the artifact URL is needed):
1. Find the reusable scheduled task named **"Vibe dashboard — refresh audio overview"** with the Claude Code Remote `list_triggers` tool. If it does not exist, create it with `create_trigger` (no schedule — run-on-demand only; `initiation: human_request`; push notifications on) using the prompt in `references/audio-refresh-task.md`. One task serves every dashboard.
2. Re-run `build` with `--trigger <its trig_ id> --artifact <the artifact's URL>` and republish to the same file path with
   `capabilities: {mcp: {servers: [{server: "Claude Code Remote", tools: ["fire_trigger"]}]}}`.
   This is the one capability a dashboard declares; declare nothing else.
3. Tell Swami the first click asks him once to allow the connector for that page.

### Refreshing an existing dashboard

This is what the scheduled task runs (and what to do when Swami asks to "update the audio overview" on a published dashboard): read the artifact (`Artifact` action `read` with the URL, then `read` with `path: "index.html"` for the full file; proceed only if Swami is a writer), run `extract` on it, write a fresh narration of the page as it is now (following **Writing the narration** — each section announced by number, then header — and **Pronunciation** above), run `build PAGE narration OUT` (the existing trigger/artifact settings carry over), and publish OUT to the same `url` **without** a `capabilities` field so the declared grant is kept. Change nothing else on the page.

## Self-contained files

Dashboards must be single files. For images, embed as base64 data URIs. If images are large, compress first with Python/Pillow before embedding. No external CSS/JS beyond the Google Fonts link.

## Placeholders in the template

`{{PAGE_TITLE}}` (browser tab) · `{{KICKER}}` (small cyan mono eyebrow — REQUIRED, always fill it, never leave blank or delete the element) · `{{H1_TITLE}}` + `{{H1_SUBTITLE}}` · `{{BYLINE_A/B/…}}` (author, group, post link, type — never a copyright mark; no `©`, no `© Swami`) · the REQUIRED Dashboard Summary section: `{{SUMMARY_BADGE}}` (category badge), `{{SUMMARY_INTRO}}` (what the dashboard covers), `{{SUMMARY_CALLOUT_LABEL}}` + `{{SUMMARY_CALLOUT_TEXT}}` (optional intro callout — delete the `.callout` if unused), and the "What each section covers" table rows `{{SEC_x_TITLE/FOCUS/WHEN}}` (add one row per other section, each with an empty `<td class="sec-cat"></td>` Category cell right after the Section cell — JS fills it) · per-section `{{SECTION_N_TITLE}}` + `{{BADGE_N}}` (content sections, numbered from 02) · `{{VERBATIM_TEXT}}` · `{{MAIL_SUBJECT}}` (email subject line) · the Glossary rows `{{GLOSS_x_ID/MATCH/CODE/TERM/DEF}}` (one row per term, each plus a color-coded Topic cell between the Term and the Definition — see "Glossary section"; delete the section and leave the summary row — it auto-drops — if there is nothing to define) · the References section rows `{{REF_x_SOURCE/COVERS/DOMAIN/URL/LINKTEXT}}` (one per cited source; drop the section if the dashboard cites nothing). See `references/patterns.md` for a filled example section and category-naming guidance.

## Built-in fixes (no patch step)

The template already includes the `syncSectionTitles` title guard (see "Section titles" above), the pinned-header fix (aligned, sortable, resizable clone + `no-sort` opt-out), the `[NN]` section-number brackets, and topic-ID (`.tid`) styling/exclusions. Older versions of this skill required running a patch script on every copy — that is no longer needed; do not re-add it.

## Search scroll logic (reference)

If a dashboard's script is ever rebuilt or merged, the `hitTarget` / `focusMatch` reference code is in `references/search-scroll.md`.