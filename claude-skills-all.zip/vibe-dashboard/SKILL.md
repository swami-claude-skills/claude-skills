---
name: "vibe-dashboard"
description: "Build Swami's signature \"Vibe Coding\" dark-theme HTML dashboard — a single self-contained .html file in the locked #0d0d0f/#00e5ff design system (JetBrains Mono + DM Sans): collapsible numbered sections, sticky TOC chips, sortable tables, a required Dashboard Summary, a required Search section, a spoken audio overview, a zoomable mind map, and a cross-linked Glossary. Use it WHENEVER Swami asks for a vibe dashboard, a dashboard, a reference page, a consultation or session write-up, a breakdown, comparison or explainer page in his style, or wants a post, video, document, files or notes turned into a browsable page — including adding or editing a dashboard's glossary, search, audio overview or mind map. Other skills use it to build their dashboards. For pages that are mostly links use vibe-launchpad; for input forms that output text use vibe-promptmaker."
---

# Vibe Dashboard

Swami's dashboards all share ONE locked design system. This skill reproduces it exactly so every page is on-brand and self-contained. Never invent new colors, fonts, or layout patterns — the system is fixed. Vary only the content, the section categories, and the card types.

## Workflow

1. **Get the content.** It comes from a pasted post, uploaded project/CAD/PLC files, a link, a client session, or Swami's own notes. If files are uploaded and not yet in context, read them first (Read / the file-reading skill). If a Google Drive file is referenced, retrieve it. Read everything before structuring.
2. **Structure into sections.** Break the content into logical collapsible sections (typically 4–10). Give each a short title, a running zero-padded number, and a category.
3. **Assign categories.** Categories are named accents that group related sections. Invent them per dashboard from the actual content — there is no fixed list and no cap; use as many or as few as the material warrants. Each category is a `cat-<name>` class mapping to a color + a short UPPERCASE badge label. Reuse the same category across related sections. **Every category's color must be unique and clearly distinguishable** — assign in order from the 8-color palette in the template's CATEGORY ACCENTS comment (cyan, green, yellow, orange, pink, magenta, violet, blue), never repeating a hue; for a 9th+, pick a hue ≥30° from every color already used. A runtime check (`checkCategoryColours`) logs a console warning if any two used category colors are too close — a finished dashboard must produce no such warning. You must define each category's CSS blocks (badge color, section left-edge, TOC chip color, tooltip-badge tint) plus its `--cat-<name>` color var in `:root` — see `references/patterns.md` for the copy-paste block. Do NOT ship generic placeholder category names.
3a. **Pick the glossary terms.** If the dashboard uses jargon, product names, acronyms or field names a reader may not know (most technical dashboards do), include the Glossary section (see "Glossary" under building blocks): one row per term with its color-coded Topic, a one- or two-sentence definition and its matchers. Typically 10–40 terms. Skip it — and delete the section — only when there is genuinely nothing to define.
3b. **Large or index dashboards.** If the page holds a lot of content (roughly 100+ rows/items) or indexes other dashboards and chats, also plan the **index-page columns** and the Search section's second layer (the text of the linked dashboards) — see "Advanced features" below. Build such pages from a Python build script rather than by hand-editing, so they can be regenerated. (The Search section itself is on every dashboard — step 4a.)
4. **Copy the template** `assets/template.html` to the working directory, **apply the table-fit patch** to the copy (see "Table-fit patch" below — one command, safe to re-run), then fill placeholders, add/duplicate sections, and delete anything unused (e.g. the verbatim block).
4a. **Add the Search section (REQUIRED, always).** Once the content sections, Glossary, References and Source Document are in place, run `python3 scripts/search_patch.py PAGE.html` (one command, safe to re-run: a second run refreshes it). It inserts the **Search** section as section 02 right after the Dashboard Summary in its own category colour (the next unused palette colour, or — when all 8 are taken — a colour the page's colour check accepts), renumbers every section after it, adds its row to the section 01 summary table, and adds the generic-subsection patch. Run it before the Mind Map patch. See "Search section" under Advanced features for what it does. Never ship a dashboard without it.
4a2. **Add the Mind Map (REQUIRED, always).** Once the content sections, Glossary and References are in place, run `python3 mindmap_patch.py PAGE.html` (see "Mind Map patch" below — save it from this file, one command, safe to re-run). It adds the Mind Map section just before the Glossary, numbers it, renumbers the sections after it and adds its row to the section 01 summary table. Optional hints on the markup name list branches and group table rows (see the patch section).
4b. **Add the audio overview (REQUIRED).** Every dashboard gets a spoken overview and its player, centered under the header byline — see "Audio overview" below. Write the narration from the finished page, run the noun/verb stress audit on it (see **Noun/verb stress** under Pronunciation), then build with `stress_audio.py build` (it runs `scripts/audio_overview.py build` with exact-pronunciation support). **If the recording fails, never finish silently and never ship without a player** — follow "When the recording can't be made" under Audio overview: it tells the user why and adds a browser-voice player instead.
4c. **Privacy check (REQUIRED before every publish).** Check for people under NDA and keep them off the page, its narration and its data files — see "Privacy: people under NDA" below.
5. **Save & publish.** Write the file in the working directory (not `/mnt/user-data/outputs/`)
   with a descriptive kebab-case filename (e.g. `stair-stringer-dashboard.html`), then publish it with
   the Artifact tool. Files in the working directory publish without an approval prompt. Declare
   no runtime capabilities — a dashboard needs none — unless the page has a feature that strictly
   requires one (e.g. a download button needs `downloads`; the audio player's owner-only refresh
   button needs the `mcp` grant shown under "Audio overview"). Send the .html as a file too (SendUserFile
   or present_files) only when Swami asks for a standalone copy. One `.html` file; the two Google
   Fonts are the only external dependency (a page with the Search section may also publish its own
   data files next to it — see "Search section").
   **This rule also governs dashboards built "per the vibe-dashboard skill" by other skills**
   (facebook-comments, makerworld-reviews, youtube-transcript, youtube-comments, …): it overrides any
   save location or `/mnt/user-data/outputs/` fallback those calling skills mention.
6. **Version history.** Every published page is backed up nightly to Swami's private GitHub repo automatically. A page built from a script also gets its sources committed there after each change — see "Version history (GitHub)" below.

## The locked design system — DO NOT deviate

**Palette** (CSS vars in `:root`):
`--bg:#0d0d0f` · `--panel:#141418` · `--panel-2:#1a1a20` · `--cyan:#00e5ff` (accent) · `--green:#00ff88` (search-hit glow) · `--text:#e8e8ec` · `--text-dim:#9aa0aa` · `--text-mute:#6a6f78` · `--border:#26262e`. Category accents are `--cat-<name>` vars assigned in order from the 8-color palette — cyan `#38dafa`, green `#38fa79`, yellow `#dafa38`, orange `#fa9938`, pink `#fa3899`, magenta `#ea38fa`, violet `#7938fa`, blue `#3879fa` (see step 3 and `references/patterns.md`). **Orange `#fa9938` also marks owner-only things** (the player's refresh note, owner-only rows, cards and columns) — see "Owner-only content".

**Fonts:** JetBrains Mono (`--mono`, for labels/nums/code/links) + DM Sans (`--sans`, body). Loaded from Google Fonts.

**Non-negotiable behaviors** (all pre-built in the template — keep them intact):
- **Full-width layout.** Every band spans the full width of the browser window — header, TOC bar, toolbar, all sections in `main`, and footer. `main`, `.toc-bar` and `.toolbar` have only side padding (22px), **no `max-width` and no `margin:0 auto` centering cap**. Never reintroduce a fixed content width (e.g. the old `max-width:900px`). Tables still fit their wrapper on open (`fitVisibleTables`), so they now use the full page width too.
- **Header kicker is REQUIRED.** Always include the `.kicker` element above the H1 with a short (1–4 word) UPPERCASE tag naming what kind of page this is (e.g. `CLIENT SESSION`, `TWINCAT PLC BREAKDOWN`, `CAM COMPARISON`, `REVERSE ENGINEERING REFERENCE`). Never leave it blank or delete it.
- **Dashboard Summary is REQUIRED as section 01.** Every dashboard opens with a "Dashboard Summary" section that includes a table titled (via `data-desc`) "What each section covers" — one row per section **including the Dashboard Summary itself (the first row, 01)**, columns **# / Section / Category / Focus / Use When**. The **Category** cell is always left as an empty `<td class="sec-cat"></td>` — `fillSummaryCategories` fills it at runtime with a pill showing the target section's category badge label in that category's own color (copied from the section's badge, so it always matches the dashboard's color coding); never type the category by hand. The "#" cell is a plain `.secnum` span showing the zero-padded section number (e.g. `01`, `02`) — it is NOT a link; navigation is via the clickable section NAME in the Section column (`linkSectionRefs` links it automatically). The table **always ends with pre-wired Glossary, References and "Source Document (Verbatim)" rows** — their numbers are read at runtime (via `data-target-title`) from the number each target section actually displays, and each row auto-drops if its section isn't present. The template ships this as the first section; fill it, don't remove it, and number the real content sections from 02 onward. An optional intro callout is fine; the intro paragraph and the table are not optional.
- **Search section is REQUIRED on every dashboard, as section 02.** Added by `scripts/search_patch.py` (step 4a). It finds anything on the page — list items, paragraphs, callouts, cards, table rows, glossary terms, references, and the Source Document split into passages — by words in any order, start of a word, small typos (including swapped letters), "phrases" and -exclusions, with Show / Category / Section filters, and every result jumps to its spot. It complements the toolbar's quick search; both stay. Index dashboards extend it (see "Search section" under Advanced features).
- **Mind Map is REQUIRED on every dashboard.** Every page carries a "Mind Map" section, just before the Glossary (or References / Source Document when there is no Glossary), in the same category as the Dashboard Summary, added by `mindmap_patch.py`. The map is built at load from the page itself, so it always matches what is shown. Never hand-write it or build its tree in Python; re-run the patch instead (it refreshes the section in place).
- **All sections start COLLAPSED.** Never add the `open` class in markup. This includes the Search section and every one of its sub-items.
- **Sticky stack** (TOC bar + toolbar) sticks to `top:0`; its height is measured at runtime (`getBoundingClientRect().height`, published as the `--stack-h` CSS var) so scroll targets land correctly regardless of wrapping.
- **Three stacked sticky layers.** While scrolling a long table, three headers pin in order below the TOC/toolbar: (1) the main **section header** (`.sec-head`, `position:sticky` at `top:var(--stack-h)`), (2) the **table item header** (`.citem-head`, sticky at `top:calc(var(--stack-h) + var(--sechead-h))`), and (3) the **table column header** (the floating clone, parked below both). Neither `.section` nor `.citem` may use `overflow:hidden` (it would break their sticky headers) — corners are rounded on the header + body instead; keep that. `--stack-h` and `--sechead-h` are measured at runtime; the floating-clone sync (`syncFloatingHeaders`) adds the section- and item-header heights to its park line and only shows the clone once the item header is pinned. **Anything that scrolls to content (search hits especially) must clear ALL of these layers**, not just the TOC/toolbar.
- **Collapsible body items.** Every callout, resource card, table and generic subsection (`.subsec`, see "Advanced features") in a section body is auto-wrapped by JS in a collapsible shell (`.citem`) with a header showing a uniform `[TAG]` (`[CALLOUT]`/`[RESOURCE]`/`[TABLE]`, or a subsection's own tag such as `[SEARCH]`, all one cyan color, left-justified into a shared-width column so descriptions align) and a description. **All items start collapsed.** The tag + description come from the same `deriveSubs` used by the TOC tooltip, so the two always match. Tables take their description from a `data-desc` attribute on the `.table-wrap` (write a logical one per table); callouts use their `.lbl`, resources their `.r-name`, subsections their `data-desc`. Author the plain `.callout`/`.resource`/`.table-wrap`/`.subsec` markup as before — the wrapping is automatic; don't hand-write `.citem`. Keep the wrapping pass and `.citem` CSS intact.
- **Compact TOC with rich hover tooltip.** Chips are compact (number + short title) and wrap inline. Hovering a chip pops a tooltip showing the category badge, the section title, and the list of auto-derived sub-items — every one a clickable link (title scrolls to the section; each sub scrolls to that item and opens it). Tags are bracketed and uniform-colored, left-justified into a column so the text aligns, matching the body headers. The tooltip is positioned by JS (`placeTip`) and clamped to the viewport so it never clips at the left/right (or flips above when it would overflow the bottom). Keep the `deriveSubs`/`buildTip`/`placeTip`/`scrollToAnchor` script and the `.toc-tip` CSS intact. **Hover is hardened — never go back to per-chip `mouseenter`/`mouseleave`.** The tooltip is wired by delegated listeners on the TOC bar (`pointerover` + `mouseover` + `mousemove`), so a missed enter event (pointer already resting on a chip, a host overlay or frame swap) still opens it on the next mouse move; a scroll event hides it only when the page actually moved more than 4px (`tipShownY`), never on a host-fired or zero-distance scroll. Touch/pen: the first tap on a chip shows its tooltip, a second tap jumps, a tap elsewhere closes it; mouse events a tap emulates are ignored (`lastPtr`). Chips are focusable (`tabindex=0`, `role=button`): keyboard focus (`:focus-visible` only — a tap also focuses) shows the tooltip and Enter/Space jumps.
- **Precise jumps.** Every jump (TOC chip, tooltip sub-item, section link, glossary link) goes through `preciseScroll`: it opens and fits whatever is revealed, lands the target just below EVERY pinned layer (TOC/toolbar, plus the section header for sub-items, plus item and column headers for glossary targets), grows an invisible end-of-page spacer (`#endSpacer`) when the target sits too close to the bottom to reach the top, and re-snaps once the smooth scroll settles. `scrollToSection`, `scrollToAnchor` and `jumpToEl` are built on it — never go back to a fixed `stack height + 12` scroll for anything but the section itself.
- **Section titles: `data-title` = the displayed title, encoded once.** Every section's `data-title` must be exactly the text in its `.sec-title`, with `&` written once as `&amp;` — never escape an already-escaped title (a build script that runs `html.escape` on a title already holding `&amp;` produces `&amp;amp;`, and the TOC, section links, summary index and glossary then silently fail to match it). As a safety net the page script opens with `syncSectionTitles`, which resets each `data-title` from its visible `.sec-title` at load. If the copied template's script does not already start with that block, add it as the first thing inside `<script>`:
  ```js
  /* ---- syncSectionTitles: each section's data-title = its visible .sec-title text. ---- */
  document.querySelectorAll('.section').forEach(sec => {
    const t = sec.querySelector('.sec-head .sec-title');
    const v = t ? t.textContent.replace(/\s+/g, ' ').trim() : '';
    if(v && sec.dataset.title !== v) sec.dataset.title = v;
  });
  ```
  Before publishing, check that every row of the section 01 summary table has a working section link.
- **`data-target` navigation, never bare `href` anchors.** TOC chips carry `data-target="<index>"` and scroll via JS. Bare `href="#id"` anchors trigger the artifact sandbox's external-link dialog — do not use them anywhere.
- **Live search** with debounced input, `mark` highlights, prev/next stepping (Enter / Shift-Enter and buttons), `n/total` counter, active hit in green with glow, and a reset "×" that restores scroll position without jumping. The active hit must land just BELOW every pinned layer above it: TOC/toolbar, section header, item header, and (for table rows) the floating column header, never underneath them. A hit inside a sticky header is positioned from that header's container (section / item / table), and the position is re-checked and snapped after the smooth scroll settles. Implemented by `hitTarget` + `focusMatch`; keep them intact and never reintroduce a fixed offset (e.g. stack height + 20) for search hits. On a page with owner-only content, this toolbar search must skip hidden matches (`matches = matches.filter(m => !m.closest('[hidden]'))` just before the first `focusMatch`). This quick toolbar search stays alongside the Search section (section 02), which every dashboard has.
- **Runtime-assembled mailto** on the "Swami" footer link — build the address from parts (`'swami.human' + '@' + 'gmail.com'`); never hard-code it in an `href`.
- **Footer text is exactly:** `Vibe Coding: Swami · AI: Claude` (Swami is the clickable mail link).
- **Pinned column header is aligned AND interactive.** The floating clone uses the live table's fixed layout, identical per-column widths, and the live table's true x offset, so it never shifts left of the columns below it. Clicking a clone header sorts the table (forwarded to the live header, arrows mirrored), and its resizer grips drag/double-click like the live ones. Built into the template.

## Section & card building blocks

Inside a `.sec-body` use these, all pre-styled:
- `<p>` with `<strong>` for emphasis (strong brightens to `--text`).
- `<ul>`/`<li>` — bullets are small custom cyan circles `●` (8px, set by `.sec-body li::before` in the template; never go back to `▸`). **Every list item starts with a topic ID:** `<li><span class="tid">Topic</span>content…</li>` — a short (1–3 word) Title Case label naming what the item is about (e.g. `Positioning`, `Counterbore`, `Swami's answer`), shown as a small mono uppercase cyan tag, followed by the item's content. If an item already opens with a lead-in label (`<strong>Scott's plan:</strong> …`, `Workflow: …`), that label becomes the topic ID and is dropped from the text so it isn't repeated; the rest of the item is unchanged. Timestamp links, section links and glossary terms stay in the content as usual. When asked to retrofit topic IDs onto an existing dashboard, add the tags and keep each item's existing content verbatim. Topic IDs are excluded from glossary linking/counting and from section-reference linking (built into the template), so a tag like "Clearance" is never underlined or counted.
- `.callout` — `.lbl` mono uppercase label + text; cyan left border. For key principles / pro tips / methods.
- `.resource` — a card with `.r-name` (mono), `.r-note`, and an optional link. Rename the class per use if it helps (spec / part / step / stat), but the visual pattern is this card.
- `.subsec` — a generic collapsible part for things that are neither callouts, cards nor tables (a tool, a set of controls): `<div class="subsec" data-tag="filters" data-desc="Narrow by type, kind, section and date">…</div>`. Needs the subsection patch — see "Generic subsections" under Advanced features.
- **Tables** — wrap every `<table>` in `<div class="table-wrap" data-desc="…">`. The `data-desc` is the logical description shown in the item's collapsed header and the TOC (e.g. "Cutting parameters", "Regression checklist"). A JS engine floats a clone of the header row just below the sticky TOC/toolbar whenever any part of the table is on screen, so the header stays pinned on **page scroll** — including for short tables that don't scroll internally. (Pure CSS `position:sticky` on `<thead>` only pins inside a scrolling wrapper, so short tables would never pin. The floating clone lives on `document.body` and parks below the section and item headers.) Keep the `buildFloatingHeaders`/`syncFloatingHeaders` script and the `.float-head` CSS intact. Add `class="table-wrap pin-first"` to also freeze the first column for wide tables. **All tables are sortable, resizable, and word-wrapped** — `initSortableTables` adds to every header: a click-to-sort affordance (asc → desc → original) with a clearly visible indicator, and a draggable column-resizer on the right edge (double-click it to fit the column to its widest cell). **On open, every table is sized to fit its wrapper width** (`fitVisibleTables`) — no horizontal scroll; the first column fits its widest entry on one line and the remaining columns share the rest by their natural proportions, word-wrapping as needed, so all columns are visible within the page width. **Tables refit whenever the page width changes** (window or app panel resized after a table was opened — a debounced `resize` handler re-flags and refits them), so a table opened at a narrow width still spans the full width once the page is widened; only a table whose columns the reader dragged or double-clicked by hand (`data-user-sized`) keeps its manual widths. **No column is ever squeezed below its header label:** each column's floor is its one-line header label plus an 8px gap (`HEAD_GAP`) before the sort arrows. If those floors can't all fit, header labels may wrap (`head-wrap` class, mirrored on the pinned clone) and the floor drops to the header's longest word. Only if even that can't fit (e.g. a 5-column table on a phone) does the table scroll sideways on open — labels never sit under the arrows. Dragging a divider resizes **only that column** — every column is pinned to an explicit px width (`table-layout:fixed` + a `<colgroup>`; `setColWidth` keeps the table element exactly as wide as the sum of its columns, so it fits on open yet grows and lets the wrapper scroll when a column is dragged wider). **Resizing a column never changes the table's current sort order or direction** — a drag only touches column widths, never rows. **Long first columns wrap when needed:** if the first column's share plus the other columns' one-line header labels can't fit, header labels wrap, and if the table is still too wide after the other columns reach their floors, the first column wraps too (e.g. long video titles), so the table still opens without sideways scroll. **No mid-word breaks:** every column's floor is also raised to its longest single body word (capped at 160px), so a short column like "Mode" never splits "Independent" into "Independ-ent" — applied only when all those word floors still fit the page; otherwise fitting to the page width wins. Both come from the table-fit patch (step 4). Body cells word-wrap; header labels stay one line; visible dividers separate columns. Keep the `initSortableTables`/`measureColWidth`/`fitVisibleTables` scripts and the refit-on-resize handler, the `<colgroup>` they build, and the sort/resizer/divider CSS intact. Use tables for specs, comparisons, parameter lists, BOMs, etc. Do not put a bare `<table>` directly in a `.sec-body`. **Non-sortable opt-out:** `<div class="table-wrap no-sort" data-desc="…">` keeps the table resizable and pinned but removes sort indicators and click-sort (live and pinned header); use it when Swami asks for a table that must not be sortable (e.g. a list converted to a table whose order matters). **Step tables get a Topic column:** any table with a **Step** column (walkthroughs, procedures, how-tos) also gets a **Topic** column placed immediately before Step (e.g. `# / Topic / Step / When`). Each Topic cell holds a topic ID tag, `<td><span class="tid">Topic</span></td>`, using the same short (1–3 word) Title Case labels as list topic IDs (e.g. `Sketch`, `Cut & keep`, `Joint Origin`), and the Step text stays unchanged. When asked to retrofit this onto an existing dashboard, add the column and tags and keep every other cell verbatim. In table cells, long tags wrap only between words, never mid-word, so they stay inside narrow columns (built into the template).
- **Color-coded category columns.** A table column that classifies rows (Kind, Type, Status) shows each value as a colored tag, `<span class="tid" style="--tc:#hex">Value</span>`, with colors assigned from the 8-color palette in order of first appearance (same value = same color everywhere on the page; add the `.tid[style*="--tc"]` rule from the Glossary bullet once). When Swami wants the table to open grouped by that column, pre-sort the rows in the markup and show the indicator on load: set the header's `data-dir="asc"`, put `▴` in its `.sort-ind`, and mirror it to the pinned clone (`mirrorSortToClone(table, colIndex, 'asc')`) in a `load` handler.
- **Inline section links.** `linkSectionRefs` turns EVERY reference to a section — by name ("Surface & Temperature") or by number ("section 3", "sec. 04", "§2") — into a clickable `.secref` jump-link, everywhere in body text including inside all tables. Automatic; just write references naturally. It only skips existing links and code so nothing is double-linked, and a number with no matching section is left as plain text. **Every** section link anywhere in the body also gets the target's section number appended in square brackets — "Facing **[03]**" — which is itself a clickable jump. Two exceptions: links inside **tables in section 01** (the Dashboard Summary index already shows the number in its # column), and links whose text is already followed by that exact `[NN]` (never double it). A source citation like `[17]` is not a section number and never blocks the suffix. Built into the template. Watch for accidental self-links: a sentence in a section that names that same section (e.g. an intro in the Search section starting "Search …") becomes a link to itself — reword it ("Find anything…").
- **Glossary section** (built into the template; sits just before References). A table titled `data-desc="Glossary of terms"` with columns **Term / Topic / Definition / Appears in / Qty**, cross-linked to the body in both directions — all automatic from the rows you write:
  - **Row markup:** `<tr data-gterm="ID" data-match="REGEX" data-code="EXACT|EXACT"><td><strong>Term</strong></td><td><span class="tid" style="--tc:#38dafa">Topic</span></td><td>Definition</td><td class="gloss-uses"></td><td class="gloss-count"></td></tr>`. `data-gterm` is a short unique kebab-case id. `data-match` is a case-insensitive regex for the term in body **text** (use `|` for alternatives and `s?` for plurals, e.g. `plugins?|plugin bundle`); start and end it with a word character so word boundaries work. `data-code` lists exact `<code>` texts that are this term, `|`-separated (e.g. `SKILL.md|skill.md`). Either matcher may be empty. Leave the last two cells empty — JS fills them. Definitions: plain text, one or two sentences, accurate.
  - **Topic column (REQUIRED, color-coded; always the 2nd column).** Every glossary row gets a topic tag naming what the term is about — a short (1–3 word) Title Case label like list topic IDs (e.g. `Skills`, `Downloads`, `Toolpaths`, `Materials`). Group the terms into a handful of meaningful topics (typically 3–8; several terms share each). **Each topic has its own color**, set inline as `style="--tc:<hex>"` on the tag: assign colors in order of each topic's first appearance down the table from the 8-color palette — cyan `#38dafa`, green `#38fa79`, yellow `#dafa38`, orange `#fa9938`, pink `#fa3899`, magenta `#ea38fa`, violet `#7938fa`, blue `#3879fa` (a 9th+ topic: a hue ≥30° from every color already used); the same topic always gets the same color. Add `<th>Topic</th>` to the header row between Term and Definition, so the header reads Term / Topic / Definition / Appears in / Qty. The template's glossary hover script still reads the definition from the second cell, so patch it once per page: replace `def = row.cells[1].textContent.trim();` with `def = ([...row.cells].slice(1).find(c => !c.querySelector('.tid') && !c.matches('.gloss-uses,.gloss-count')) || {textContent:''}).textContent.trim();` (the term stays `row.cells[0]`). The template does not yet style colored tags, so add this rule once to the page's `<style>`, right after the `li .tid,td .tid{…}` rule: `.tid[style*="--tc"]{color:var(--tc);background:color-mix(in srgb,var(--tc) 9%,transparent);border-color:color-mix(in srgb,var(--tc) 40%,transparent)}` (tags without `--tc`, such as list topic IDs, stay cyan). In the glossary intro paragraph, add one sentence: "Each term's **Topic** tag names what it is about, one color per topic." Topic tags are already excluded from glossary linking and counting. When asked to retrofit this onto an existing dashboard (including an older glossary whose "Topic ID" column sits after Definition), put the Topic column second, name its header Topic, apply the script patch, CSS rule and intro sentence, and keep every other cell verbatim.
  - **Default sort: Topic (ascending).** The glossary table opens pre-sorted by its Topic column so the color-coded tags read as grouped blocks rather than a random mix. After `initSortableTables()` and `buildFloatingHeaders()`, add a self-invoking function that finds the Glossary section's table, locates the Topic header cell, and `.click()`s it once to trigger an ascending sort. **Important:** because `initSortableTables` appends sort-indicator child elements (`▴▾`) inside each `th`, `th.textContent` includes those characters. Match the header by reading only its first text node (`th.childNodes[0]`), not `textContent`. The snippet:
    ```js
    /* ---- glossary: start sorted by Topic column (asc) ---- */
    (function(){
      const gsec = document.querySelector('.section[data-title="Glossary"]');
      if(!gsec) return;
      const table = gsec.querySelector('.table-wrap table');
      if(!table || !table.tHead) return;
      const ths = [...table.tHead.rows[0].cells];
      const ti = ths.findIndex(th => {
        const t = th.childNodes[0];
        return t && t.nodeType === 3 && t.nodeValue.trim().toUpperCase() === 'TOPIC';
      });
      if(ti < 0) return;
      ths[ti].click();
    })();
    ```
    Place it right after `buildFloatingHeaders();` (before `checkCategoryColours`). It is a no-op when there is no Glossary or no Topic column.
  - **Body → glossary:** `linkGlossary` wraps the **first** mention of each term **per content section** in a dotted-underline `.gterm` (only the first, so common words don't underline dozens of times). Hover shows the term, its definition, and "(click term to go to 'Glossary')"; click jumps to the term's row and flashes it green. It skips the summary, Glossary, References and verbatim sections, headings, column headers, section links, pills/badges and callout labels.
  - **Glossary → body:** the **Appears in** cell gets one numbered `.gloss-jump` per section where the term appears, colored by that section's category. Hover previews the section (number, title, category badge), the line with the term highlighted, and the mention count in that section; click opens the section/item, scrolls the term clear of every pinned header and flashes it green.
  - **Qty:** total mentions across the content sections, repeats included (linked or not); sorts numerically. A term with no mentions shows "—" and 0 — reword its matcher or drop the row.
  - **Longest pattern wins** when terms overlap (e.g. "Claude Marketplace" beats "marketplace"); a bad regex logs a console warning and disables text matching, so a finished dashboard must show no such warning.
  - The Dashboard Summary row for the Glossary is pre-wired (`data-target-title="Glossary"`, auto-numbered, auto-dropped if the section is deleted). Mention the Glossary in the summary intro ("terms with a dotted underline jump to the Glossary") when you include one.
- **References section.** When the dashboard cites external sources, include a "References" section immediately before the verbatim section (the template ships it) with a table — columns **Source / Topic / What it covers / Cited in / Domain / Webpage** — one row per cited source, written in citation order:
  - **Source:** `<strong>[n] Publisher</strong>`, where `n` is the citation number used in the body (the source's own numbering when the material has one). The row is `<tr data-ref="n">`.
  - **Topic (REQUIRED, color-coded; always the 2nd column, right of Source):** `<span class="tid" style="--tc:#hex">Topic</span>` — same rules as the Glossary's Topic column: a short (1–3 word) Title Case label naming what the source is about, a handful of topics (typically 3–8; several sources share each), colors assigned from the 8-color palette in order of each topic's first appearance down the table (cyan, green, yellow, orange, pink, magenta, violet, blue; a 9th+ topic gets a hue ≥30° from every color used), same topic = same color. The `.tid[style*="--tc"]` rule ships in the template.
  - **What it covers:** the page's title or subject in plain words. **Cited in:** the exact titles of the sections that cite it, comma-separated (`linkSectionRefs` turns them into section links with `[NN]`), or `—`. **Domain:** host without `www.`. **Webpage:** the real link, `target="_blank" rel="noopener"`, text `open ↗`.
  - **Opens sorted by Topic (ascending).** The template's script clicks the Topic header once at load (after `buildFloatingHeaders();`, matching the header by its first text node, like the Glossary snippet), so the colored tags read as grouped blocks; ▴ shows on Topic and a click cycles desc → original citation order. A no-op when the table has no Topic column.
  - **Clickable citations:** write each `[n]` in the body as `<span class="cite" data-ref="n">[n]</span>` (small mono, hover cyan); a click opens References and jumps to that row (`jumpToEl`). Built into the template.
  - Intro paragraph: say that bracketed numbers are citations that jump to their row, and add "Each source's **Topic** tag names what it is about, one color per topic."
  - When asked to retrofit this onto an existing dashboard, add the Topic column second, the sort script and (when the body has numbered citations) the `.cite` spans and click handler, and keep every other cell verbatim.
- Verbatim/raw-source block — a `.verbatim-body` section with `<pre id="verbatim">`; text is injected from the `VERBATIM` JS string (kept out of markup to avoid re-parsing). Include only when preserving an original post/source; otherwise delete the block and its section.

## Advanced features (large and index dashboards)

These grew out of Swami's "AI in Fusion Chats" index dashboard. Use them when a page holds a lot of content, indexes other dashboards and chats, or when Swami asks. **Reference implementation:** the folder `ai-in-fusion-chats/` in Swami's private GitHub repo `swami-claude-skills/vibe-dashboards` — `build.py` (page generator, including every patch below), `search.js` (the Search section), `refresh.py` (nightly data refresh, privacy scan, skeleton strip). Attach it with the Claude Code Remote `add_repo` tool (owner `swami-claude-skills`, repo `vibe-dashboards`) and clone it; adapt the code rather than rewriting it. The same files are also readable from the live artifact (its page source and its published `refresh.txt`).

### Generic subsections

To split a section that is a tool or a group of controls into collapsible parts, wrap each part in `<div class="subsec" data-tag="TAG" data-desc="Description">…</div>`. Each becomes a `.citem` with `[TAG]` and its description, exactly like callouts and tables, and appears in the TOC tooltip. Callouts, cards and tables nested inside a `.subsec` are not wrapped again. Until the template ships it, patch the page once (three exact replacements; assert each anchor exists):
1. In `deriveSubs`, replace
   `body.querySelectorAll('.callout, .resource, .table-wrap').forEach(el => {\n    let kind, text;\n    if(el.classList.contains('callout')){`
   with
   `body.querySelectorAll('.subsec, .callout, .resource, .table-wrap').forEach(el => {\n    let kind, text;\n    if(el.parentElement.closest('.subsec')) return;\n    if(el.classList.contains('subsec')){\n      kind = el.dataset.tag || 'part';\n      text = (el.dataset.desc || 'Part').trim();\n    } else if(el.classList.contains('callout')){`
2. Extend `const TAG_CH = {callout:'CALLOUT', resource:'RESOURCE', table:'TABLE'};` with each tag used (e.g. `search:'SEARCH', filters:'FILTERS'`).
3. (Optional) after the wrapper's `head.addEventListener('click', …);` line add `if(s.el.dataset.open) item.classList.add('open');` — but do not use `data-open` by default: every item starts collapsed.

### Owner-only content

Some things should show only to Swami (links to his private chats, an index of his own pages, admin boxes). The page asks the runtime who is viewing — no capability needed:
```js
(async () => { try {
  const u = window.claude ? await window.claude.use('user') : null;
  if(!(u && await u.isOwner())) return;
  /* reveal owner-only rows, cards and columns here, then refit */
  if(window.fitVisibleTables) fitVisibleTables();
  if(window.syncFloatingHeaders) syncFloatingHeaders();
} catch(e){} })();
```
- **Rows:** `<tr class="owner-only" hidden>` plus `<span class="owner-tag" title="Only you can see this row">only you</span>` after the first cell's label; orange row tint and left bar. Revealed by the block above.
- **Cards:** `<div class="resource owner-only">`; after the wrapping pass give its `.citem` shell `owner-only-item` + `hidden` (orange border and an "only you" tag on its header), reveal for the owner. The TOC tooltip skips sub-items inside `[hidden]` and shows owner ones in orange.
- **Columns:** `<th class="own-col">` and `<td class="own-col">`. Detach those cells **before** the table engine starts (stash them per table), so other viewers' tables are built without the column; for the owner, append them back, rebuild the floating headers, re-run the sort/resizer setup for that header and refit. The header is orange (`#fa9938`, with `!important` so the pinned clone matches) with a hover tooltip: "Only you can see this column. It links to …".
- **Never mention owner-only items** in the page's body text or the audio narration.
- **Owner-only is NOT private:** the content still sits in the page source that anyone with the link can read. Never use it for anything under NDA or otherwise confidential (see "Privacy").

### Index dashboards (a dashboard of dashboards)

When a page indexes Swami's chats and the dashboards they produced:
- Every table that lists chats has a **Chat ID** column (the chat's short id in `<strong data-cid="…">`), a **Dashboard** column, and an owner-only **Chat** column (link to `https://claude.ai/chat/<id>`). Link cells read exactly `open ↗`; there are no other links in the ID columns.
- **Dashboard link tooltips:** each dashboard link carries `data-dh="<artifactId>"`; hovering it shows that dashboard's full header (kicker, title, subtitle) from a `DASH_HEADS` map embedded at build time (generated as `heads.json` by `refresh.py extract`). The Dashboard column header (`th.dh-col`) gets a hint tooltip: "Hover any open ↗ link in this column to see that dashboard's full header."
- Before saying a chat has no dashboard, look for it (the account's artifact list, the chat itself); if one exists but isn't published, give Swami the chat link so he can publish it.
- The master table's Kind column is color-coded and opens sorted by Kind (see "Color-coded category columns").

### Search section (advanced full-text search)

A dedicated section, numbered **02** right after the Dashboard Summary, titled **Search**, with its own category color. It complements (does not replace) the toolbar's quick search. **Every dashboard has it** — added by `scripts/search_patch.py` (workflow step 4a).

**The standard version (`search_patch.py`, every dashboard):** a one-line intro ("Find anything on this page: …"), then four collapsible parts, all starting collapsed: `[SEARCH]` "Search box and results" (input, clear button, status line "Searching **N** items on this page · plus **P** passages of the source document", results); `[FILTERS]` "Narrow by type, category, and section" (Show chips — Notes, Table rows, Glossary terms, References, Source document — with live counts; Category chips in each section category's own colour; a Section select); `[TABLE]` "How to write a query" (`no-sort`; its examples are filled at load from this page's most-used glossary terms); `[CALLOUT]` "What it covers". Matching is layer 1 below; the Source Document's `<pre>` is split into passages at load so a result can jump to the exact spot. Results group by type, each showing its type, a title that jumps there (`jumpToEl`), a highlighted snippet, the section link "Title [NN]" and the section's category tag. Search box UI (Nov 2026, built into `search_patch.py`): the box's text and placeholder are green; the search box row is sticky, pinning just under the `[SEARCH]` item header while the results scroll; each result group (Notes 8, Table rows 18, …) is a collapsible header with a ▶ arrow and its hit count, all collapsed at first and again on every new search ("Show all" keeps a group open); "expand all" / "collapse all" buttons for the result groups sit right of "clear" (collapse all scrolls back to the search box and puts the cursor in it); and the "Try" chips include no typo example, since it reads as a misspelling. Re-running `search_patch.py` on an older dashboard refreshes its Search section to this version. The patch also keeps the toolbar quick search out of the results and adds "Search" to the Glossary's `EXCLUDE` set. Don't name the section in body text ("search the …"), since `linkSectionRefs` would turn the word into a link to it.

**The index-dashboard version** (pages that index other dashboards and chats) adds date filters, Kind chips, layer 2 and the owner-only refresh box. It is hand-built from the reference implementation (`search.js`); `search_patch.py` leaves a page alone when it already has a hand-made `#xs` section. Its layout:

— a one-line intro ("Find anything on this page, plus the full text of every dashboard it links to.") and a `#xs` container holding four collapsible parts, all starting collapsed:
1. `[SEARCH]` "Search box and results" (`.subsec`): the input + clear button, a status line ("Searching **N** items on this page · plus **P** passages from **D** dashboards, refreshed **date**"), and the results.
2. `[FILTERS]` "Narrow by type, kind, section and date" (`.subsec`): Show chips (result types, with live counts), Kind chips (in the Kind colors), a Section select, From/To month inputs, and the note "Filters work with or without words in the box. With an empty box, they list the matching chats."
3. `[TABLE]` "How to write a search" (`no-sort`): To do this / Type / Example — several words, start of a word, forgiven typo, exact phrase, leave a word out, Enter opens the best match.
4. `[CALLOUT]` "What gets searched and when it updates" — this page, inside the dashboards, nightly updates; the owner-only nightly-refresh box (last run, candidate new dashboards to add) sits inside it.

**Matching (layer 1 — this page):** built in the browser at load from the page itself, so it always matches what is shown: chat records, every table row, callout, card, list item, paragraph, glossary term and reference (skipping section 01, the Search section, the Mind Map section, owner-only cells, and anything hidden for this viewer). Inverted index of normalized tokens (lowercase, accents stripped). All words must match, in any order; the start of a word is enough (2+ letters); a simple stem joins plurals and endings (s/es/ies/ing/ed); typo tolerance kicks in **only when a word matches nothing as typed** — same first letter, edit distance ≤1 (≤2 for words of 8+ letters), preferring words that just add dropped letters (filet → fillet) — and the results then say "similar spellings are included: …"; `"quotes"` match an exact phrase; `-word` excludes; a small alias map (f360 → fusion). Rank title hits above body hits, exact above prefix above typo.

**Results:** grouped by type with counts (e.g. Chats, Findings, Open questions, Glossary terms, Elsewhere on this page, Inside the dashboards); each shows the bold bright date, the colored kind tag, a title button that jumps to the item (`jumpToEl` — opens its section and item, clears every pinned layer, flashes it), a snippet with highlighted hits, the section link "Title [NN]", the dashboard `↗` link (with its header tooltip), and the owner-only chat link. Show the top few per group with "Show all N". Enter opens the best result. With an empty box, show "Try" example chips and a one-line tip.

**Layer 2 — inside the linked dashboards:** `search-index.json` is published next to the page through the Artifact `files` map and fetched with `fetch('search-index.json')`: `{meta:{refreshed, dashboards, passages}, p:[{d:artifactId, n:secNum, t:secTitle, x:text}]}`, ~900-character passages per section of every linked dashboard (verbatim text included; audio, styles and scripts stripped). Results group by dashboard: three passages, then "+ N more passages in this dashboard". `heads.json` (dashboard headers) is published alongside.

**Nightly refresh (scheduled task).** Linked dashboards change, so a scheduled task (fresh session, auto approval, push notification) keeps the data current: read the page and its published files (`refresh.py` is published as `refresh.txt`, text/plain, so the task can fetch it); read every linked dashboard (`Artifact` read with `path: "index.html"`, in parallel batches); run `refresh.py extract DASHDIR dashmap.json OUTDIR --exclude PRIVATE.json`; list possible new dashboards/chats for Swami to approve (`refresh.json`, shown only to him in the callout — never added automatically); strip the publish skeleton from the saved page (`refresh.py strip`, so it republishes byte-identical); run the privacy scan; republish the page unchanged with the data files and **no** `capabilities` field; commit to GitHub. Its prompt carries the private exclusion list (see "Privacy").

**Rebuilding a page that has audio.** When a build script regenerates the page, carry the existing `AUDIO-OVERVIEW` block over from the live page (cut it from the saved live copy, insert it before `</header>`) instead of re-recording, unless the narration needs to change.

## Audio overview

Every dashboard carries a single-speaker spoken overview (female voice — Kokoro `af_heart`, generated offline) embedded as an MP3 data URI, played by a locked player centered under the byline. **The player shows no label and no link** — only its controls. Never hand-write the player: `scripts/audio_overview.py` inserts it from `assets/audio-player.html` between `<!-- AUDIO-OVERVIEW:BEGIN -->` / `<!-- AUDIO-OVERVIEW:END -->` markers (just before `</header>`), and replaces that block on any re-run.

**Player features (all built into the snippet — keep them):** go to start / end; jump −10 / −5 / +5 / +10 s, colour-coded (±5 green `#38fa79`, ±10 magenta `#ea38fa`); play/pause; click-to-seek track; time display that toggles on click between total time (cyan `#38dafa`) and time remaining (orange `#fa9938`, shown with a leading −); playback-speed pop-up menu (0.5×–2×, check on current, arrow keys + Esc); volume control — mute button plus a slider, remembered per viewer in browser storage (on iOS, which ignores page volume, only mute shows); a styled mouseover tooltip on every control showing its hot key. Hot keys (ignored while typing in a field such as the dashboard search): ←/→ 5 s, Shift+←/→ 10 s, Home/End, K play/pause, `<`/`>` slower/faster, M mute, `−`/`+` volume down/up 10%.

**Writing the narration.** 2–3 minutes (~300–400 words) by default; for a large dashboard, or when Swami asks for fuller coverage of its breadth and depth, about 4 minutes (~650–700 words). One speaker, plain spoken English describing the dashboard as it stands: what the page is, then each section in order and what a reader finds there, ending with the glossary if present. **Every section is introduced by its number, then its header, before anything else** — "Section one, Dashboard Summary. …", "Section five, The Timeline Debate. …" — with the number said as a word and the header as displayed (say "and" for "&", "versus" for "vs"). Cover every section, including the summary, the Search section, the Mind Map, Glossary, References and Source Document. For Search (section two), say in a sentence or two that you can type a few words to find anything on the page, in any order and with small typos forgiven, narrow the results with filters, and click a result to jump to it. For the Mind Map, say in a sentence or two that it shows the whole page as bubbles you can open, hover for a summary, and click to jump to that spot. One paragraph per thought — paragraph breaks become short pauses. Write years and counts as they should be said, and avoid symbols, URLs and markdown. **Never mention owner-only features** (owner-only columns, rows, links or the refresh button) and never name anyone under NDA. Follow **Pronunciation** below for acronyms and tricky words. Use `python3 scripts/audio_overview.py extract PAGE.html` to get the page's text outline to write from.

**Pronunciation (REQUIRED — the narration text is spelled for the voice, not the reader).** The Kokoro voice reads the narration literally, so write these respellings in `narration.txt` (never in the page itself):

| Say | Write in the narration | Kokoro phonemes |
|---|---|---|
| fillet = "fil-LET" (LET rhymes with "get"); plural "fil-LETS" | `fillette` / `fillettes` | fɪlˈɛt / fɪlˈɛts |
| PLA = "pee el ay", no pauses between letters, long A | `pee-ell-eh` | pˈiːˈɛlˈeɪ |
| PETG = "pee ee tee gee", long E, G said "gee", no pauses | `pee-ee-tee-gee` | pˈiːˈiːtˈiːdʒˈiː |
| AI = "ay eye" (long A, as in "ate") | `AI` (solid capitals) | ˌeɪˈaɪ |
| CNC, WCS, US, STL, MCP and other letter-by-letter acronyms | solid capitals: `CNC`, `WCS`, `MCP` | letter names |
| CAD = the word "cad" (rhymes with "fad"); 3D CAD = "three dee cad" | `cad`, `three D cad` | kˈæd |
| CAM = the word "cam" (rhymes with "ram") | `cam` | kˈæm |
| live (adjective) = long I, rhymes with "hive" | `lyve` | lˈaɪv |
| callout = "call" as in "ball" + "out", no pause; plural "call-outs" | `call-out` / `call-outs` | kˈɔːlˈaʊt |
| AU (Autodesk University) | `Autodesk University` (write it out) | — |
| records (verb) = "ree-CORDS", stress on the 2nd syllable (noun "REK-erds" stays as is) | `[records](/ɹᵻkˈɔːɹdz/)` when the voice gets it wrong | ɹᵻkˈɔːɹdz |
| research (noun) = "REE-search", stress on the 1st syllable | `[research](/ɹˈiːsɜːtʃ/)` | ɹˈiːsɜːtʃ |

Rules behind the table:
- **Never separate letters with spaces** (`A I`, `C N C`, `P L A`): a lone "A" is read as "uh". **Never use dots** (`P.L.A.`, `P.E.T.G.`): dots make the voice pause between letters. Plain solid capitals work for most acronyms; the hyphenated respellings above are for the ones the voice would otherwise say as a word (solid `PLA` comes out "plah", solid `PETG` "petg").
- "fillet" written plainly is read the French way, "fi-LAY" — always write `fillette`.
- "callout" written plainly is read "KAL-out" (kˈælaʊt) — always write `call-out`; the hyphen keeps "call" as in "ball" without a pause (a space, `call out`, adds a word break).
- For any other word or acronym in doubt, check it before building: `Kokoro(...).tokenizer.phonemize(text, 'en-us')` (kokoro_onnx, model files in `~/.cache/vibe-audio`) — test it inside a short phrase from the narration, since context can change the result — and make sure every syllable comes out as intended. Add any new rule Swami gives to this table.
- **Noun/verb stress (REQUIRED).** Two-syllable words that can be a noun or a verb take their stress by part of speech: **verb → stress on the 2nd syllable** (re-CORDS, pro-DUCE, ob-JECT, con-VERT, up-DATE), **noun or adjective → stress on the 1st syllable** (REC-ords, PRO-duce, OB-ject, CON-vert, REE-search, UP-date). The voice does not reliably pick the stress from context — in "Fathom records and summarizes Zoom sessions" it said the noun "REK-erds" — and plain respellings (hyphens, extra letters) often make it stress both syllables, so fix these with exact phonemes instead:
  - **Markup:** write `[word](/phonemes/)` in `narration.txt`, e.g. `[records](/ɹᵻkˈɔːɹdz/)` or `[research](/ɹˈiːsɜːtʃ/)`. `ˈ` goes before the stressed syllable; take the rest from the voice's own phonemes for the word (the audit prints them) and move only the stress mark and the vowels it changes (verb first syllables usually reduce to `ᵻ`/`ə`). Never use the markup in the page itself.
  - **Audit every narration before building:** `python3 stress_audio.py SKILL_DIR audit narration.txt` lists every such word in its sentence with the syllable the voice will stress (marked words show "(marked)"). Decide noun or verb from the sentence and mark each wrong one, then re-run the audit until all are right. The list covers the common stress-shifting words; also check any other two-syllable noun/verb word you notice.
  - **Build with the helper:** `python3 stress_audio.py SKILL_DIR build PAGE.html narration.txt PAGE.html [--trigger … --artifact …]` — same arguments and result as `scripts/audio_overview.py build`, plus the markup (paragraphs without markup are spoken exactly as before). `SKILL_DIR` is this skill's folder (the one holding `scripts/`). Save the helper below as `stress_audio.py` in the working directory (not in the skill folder):
```python
#!/usr/bin/env python3
"""stress_audio.py — run the vibe-dashboard audio_overview.py with exact-pronunciation markup and a noun/verb
stress audit.  Usage:
  python3 stress_audio.py SKILL_DIR audit NARRATION.txt
  python3 stress_audio.py SKILL_DIR build PAGE.html NARRATION.txt OUT.html [--trigger ..] [--artifact ..]
  python3 stress_audio.py SKILL_DIR plain NARRATION.txt OUT.txt     (markup -> plain words, for the browser-voice player)
Markup in the narration: [word](/phonemes/) speaks exactly those Kokoro phonemes, e.g. [records](/ɹᵻkˈɔːɹdz/).
"""
import os, re, sys
SKILL = sys.argv[1]; sys.path.insert(0, os.path.join(SKILL, 'scripts'))
import audio_overview as ao
MARK = re.compile(r'\[([^\]]+)\]\(/([^/]+)/\)')
# two-syllable words whose stress moves: noun/adjective = 1st syllable, verb = 2nd syllable
STRESS = ('record object project permit conduct contest convert produce progress subject increase decrease export import '
          'insert protest contract conflict refuse rebel combat compound console content convict desert extract perfect '
          'reject survey update upgrade upload download transfer transport discount escort torment suspect address '
          'research default digest present impact implant intern invite misprint object perfume prefix proceeds '
          'segment torment upset construct consort convoy decrease discharge exploit finance incline insult '
          'outlaw permit rebound recall redo refill refund rehash relay remake replay reprint reset retake '
          'retread rewind rewrite').split()
STEMS = sorted(set(STRESS), key=len, reverse=True)
WORD = re.compile(r'\b(' + '|'.join(STEMS) + r')(s|es|ed|ing|d)?\b', re.I)

def _tts():
    ao._ensure_tts()
    from kokoro_onnx import Kokoro
    return Kokoro(os.path.join(ao.CACHE, 'kokoro.onnx'), os.path.join(ao.CACHE, 'voices.bin'))

def _vowel_stress(ph):
    """which vowel group carries the primary stress: 1, 2 … (0 if none)"""
    groups = re.findall(r'[ˈˌ]?[ɑɐæʌɔəɚɛɜɪiɨʊuoeaᵻɒ][ːɑɐæʌɔəɚɛɜɪiɨʊuoeaᵻɒ]*', ph)
    for n, g in enumerate(groups, 1):
        if g.startswith('ˈ'): return n
    return 0

def audit(path):
    k = _tts(); txt = open(path, encoding='utf8').read()
    marked = [(m.group(1), m.group(2)) for m in MARK.finditer(txt)]
    plain = MARK.sub(lambda m: m.group(1), txt); hits = 0
    for sent in re.split(r'(?<=[.!?])\s+', plain):
        words = sent.split(); ph = k.tokenizer.phonemize(sent, 'en-us').split()
        for m in WORD.finditer(sent):
            hits += 1
            i = len(sent[:m.start()].split())
            p = ph[i] if i < len(ph) and len(ph) == len(words) else k.tokenizer.phonemize(m.group(0), 'en-us')
            fix = next((ph2 for w2, ph2 in marked if w2.lower() == m.group(0).lower()), None)
            if fix: p = fix + ' (marked)'
            st = _vowel_stress(p)
            print(f'{m.group(0):12} said {p:16} stress on syllable {st or "?"}  ←  {sent.strip()[:110]}')
    print(f'{hits} noun/verb stress word(s) found. Noun or adjective → syllable 1; verb → syllable 2. '
          'Fix any wrong one with [word](/phonemes/).')

def speak(text, mp3_path):
    """audio_overview.speak with [word](/phonemes/) support (paragraphs without markup are spoken exactly as before)"""
    if not MARK.search(text): return _orig(text, mp3_path)
    k = _tts(); import numpy as np, soundfile as sf, subprocess, tempfile
    paras = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]
    parts, sr = [], 24000
    for p in paras:
        p = ' '.join(p.split())
        if MARK.search(p):
            out, last = [], 0
            for m in MARK.finditer(p):
                if p[last:m.start()].strip(): out.append(k.tokenizer.phonemize(p[last:m.start()], 'en-us'))
                out.append(m.group(2)); last = m.end()
            if p[last:].strip(): out.append(k.tokenizer.phonemize(p[last:], 'en-us'))
            s, sr = k.create(' '.join(o.strip() for o in out), voice=ao.VOICE, speed=1.0, lang='en-us', is_phonemes=True)
        else:
            s, sr = k.create(p, voice=ao.VOICE, speed=1.0, lang='en-us')
        parts += [s, np.zeros(int(sr * 0.55), dtype=s.dtype)]
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, 'a.wav'); sf.write(wav, np.concatenate(parts), sr)
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-ac', '1', '-b:a', '64k', mp3_path], check=True)
    dur = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', mp3_path],
                         capture_output=True, text=True).stdout.strip()
    return float(dur or 0)
_orig, ao.speak = ao.speak, speak

cmd, args = sys.argv[2], sys.argv[3:]
if cmd == 'audit': audit(args[0])
elif cmd == 'plain': open(args[1], 'w', encoding='utf8').write(MARK.sub(lambda m: m.group(1), open(args[0], encoding='utf8').read()))
elif cmd == 'build':
    trig = art = None
    if '--trigger' in args: trig = args[args.index('--trigger') + 1]
    if '--artifact' in args: art = args[args.index('--artifact') + 1]
    ao.build(args[0], args[1], args[2], trig, art)
else: sys.exit(__doc__)
```

**Building.**
```
python3 scripts/audio_overview.py build PAGE.html narration.txt PAGE.html \
        [--trigger trig_... --artifact https://claude.ai/artifact/...]
```
First run installs `kokoro-onnx` + `soundfile` (pip) and downloads the model (~350 MB, GitHub releases) to `~/.cache/vibe-audio`; ffmpeg encodes 64 kbps mono MP3 (~0.5 MB per minute). It prints the audio length. Re-running replaces the old audio and keeps any refresh settings already in the page.

### When the recording can't be made

The recording needs code execution with network access: `pip` must reach PyPI (kokoro-onnx, soundfile) and the first run must download the voice model from GitHub's file servers (`release-assets.githubusercontent.com` / `objects.githubusercontent.com`), which many accounts' default network setting blocks even when github.com itself is allowed. ffmpeg must also be present. If `build` exits with an error (or code execution isn't available at all), do all three of these — the dashboard still ships, with a player:

1. **Find the cause** from the error text, in one line:
   - pip can't install packages → code execution has no network access.
   - the model download fails (curl error, 403, "could not resolve host" on a githubusercontent.com address) → the network setting doesn't allow GitHub's file servers.
   - `ffmpeg` not found → this environment has no ffmpeg.
   - no code execution at all → code execution is turned off.
   Try once more only if the error looks temporary (timeout, connection reset); never loop.
2. **Add the browser-voice player** in place of the recording. It reads the same narration aloud with the viewer's browser voice (it differs from computer to computer; no downloads, works on any plan). Use the narration with the Kokoro-only respellings put back to normal words — `pee-ell-eh` → `PLA`, `pee-ee-tee-gee` → `PETG`, `fillette(s)` → `fillet(s)`, `lyve` → `live`, `call-out(s)` → `callout(s)`, and every `[word](/phonemes/)` → `word` (`python3 stress_audio.py SKILL_DIR plain narration.txt narration-plain.txt` does this one) — keep everything else. Save the snippet below as `fallback.html` and the script below as `add_fallback.py` (both verbatim), then run `python3 add_fallback.py PAGE.html narration.txt fallback.html`. It goes between the same `AUDIO-OVERVIEW` markers before `</header>`, so a later successful `build` replaces it automatically. Do not wire the owner-only refresh button or declare any capability for it.
3. **Tell the user plainly**, in the reply that delivers the dashboard (not on the page): the audio overview couldn't be recorded here and why (the one-line cause), the page reads it with the browser's own voice instead, and how to get the recorded voice — in Claude, **Settings › Capabilities**: turn on code execution ("Create and edit files"), and set network access to allow `release-assets.githubusercontent.com` and `objects.githubusercontent.com` (package managers plus specific domains), or All domains; on Team/Enterprise an organization owner sets this under Organization settings › Capabilities. Then ask Claude to "add the audio overview" to the dashboard. For a missing ffmpeg, say that instead of the settings advice.

The browser-voice player: play/pause, start over, previous/next paragraph, speed (0.75×–1.5×), a paragraph counter, and hot keys K, ←/→ and Home (ignored while typing). It picks an English female system voice when one exists, speaks sentence by sentence (long utterances stall in some browsers), and disables itself in a browser without speech.

`fallback.html`:
```html
<!-- AUDIO-OVERVIEW:BEGIN browser-voice fallback (replaced by audio_overview.py build when a recording can be made) -->
<style>
.ao-fb{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:8px;width:max-content;max-width:100%;margin:18px auto 0;padding:8px 14px;background:var(--panel-2);border:1px solid var(--border);border-radius:999px;font-family:var(--mono);font-size:12px;color:var(--text-dim)}
.ao-fb button{font:inherit;color:var(--text-dim);background:transparent;border:1px solid var(--border);border-radius:999px;min-width:32px;height:32px;padding:0 10px;cursor:pointer}
.ao-fb button:hover:not(:disabled){color:var(--cyan);border-color:var(--cyan)}
.ao-fb button:disabled{opacity:.4;cursor:not-allowed}
.ao-fb .ao-play{width:40px;height:40px;color:var(--cyan);border-color:rgba(0,229,255,.5);font-size:14px}
.ao-fb .ao-skip{color:#38fa79;border-color:rgba(56,250,121,.45)}
.ao-fb .ao-pos{min-width:58px;text-align:center;color:#38dafa}
</style>
<div class="ao-fb" id="aoFb" role="group" aria-label="Audio overview" title="Audio overview, read aloud by this browser's built-in voice (the voice differs from computer to computer)">
  <button type="button" class="ao-restart" aria-label="Start over" title="Start over (Home)">⏮</button>
  <button type="button" class="ao-skip ao-prev" aria-label="Previous paragraph" title="Previous paragraph (←)">‹</button>
  <button type="button" class="ao-play" aria-label="Play" title="Play / pause (K)">▶</button>
  <button type="button" class="ao-skip ao-next" aria-label="Next paragraph" title="Next paragraph (→)">›</button>
  <span class="ao-pos" aria-live="off"></span>
  <button type="button" class="ao-rate" aria-label="Speed" title="Speed (click to change)">1×</button>
</div>
<script type="application/json" id="aoFbText">__PARAGRAPHS_JSON__</script>
<script>
(() => {
  const bar = document.getElementById('aoFb'), P = JSON.parse(document.getElementById('aoFbText').textContent || '[]');
  const $ = s => bar.querySelector(s), play = $('.ao-play'), pos = $('.ao-pos'), rateB = $('.ao-rate');
  const S = window.speechSynthesis;
  if (!S || !window.SpeechSynthesisUtterance || !P.length) {
    bar.title = 'This browser cannot read the overview aloud.'; bar.querySelectorAll('button').forEach(b => b.disabled = true); pos.textContent = '—'; return;
  }
  const RATES = [0.75, 1, 1.25, 1.5]; let rate = 1, i = 0, playing = false, gen = 0, voice = null;
  const PREF = ['Samantha', 'Ava', 'Allison', 'Susan', 'Aria', 'Jenny', 'Zira', 'Google US English', 'Google UK English Female', 'Karen', 'Moira', 'Tessa', 'Serena'];
  const pickVoice = () => { const v = S.getVoices().filter(x => /^en([-_]|$)/i.test(x.lang));
    for (const n of PREF) { const m = v.find(x => x.name.includes(n)); if (m) return m; }
    return v.find(x => /female/i.test(x.name)) || v.find(x => x.default) || v[0] || null; };
  const loadVoice = () => { voice = pickVoice(); };
  loadVoice(); if (S.addEventListener) S.addEventListener('voiceschanged', loadVoice);
  const show = () => { pos.textContent = Math.min(i + 1, P.length) + ' / ' + P.length; play.textContent = playing ? '❚❚' : '▶'; play.setAttribute('aria-label', playing ? 'Pause' : 'Play'); };
  const sentences = t => (t.match(/[^.!?]+[.!?]+["')\]]*\s*|[^.!?]+$/g) || [t]).map(s => s.trim()).filter(Boolean);
  // speak sentence by sentence (long utterances stall in some browsers); pause = stop and resume at the paragraph
  function speakFrom(k) {
    S.cancel(); const my = ++gen; i = Math.max(0, Math.min(k, P.length - 1)); playing = true; show();
    let q = sentences(P[i]), j = 0;
    const next = () => {
      if (my !== gen) return;
      if (j < q.length) { const u = new SpeechSynthesisUtterance(q[j++]); if (voice) u.voice = voice; u.lang = voice ? voice.lang : 'en-US'; u.rate = rate; u.onend = next; u.onerror = next; S.speak(u); }
      else if (i < P.length - 1) { i++; show(); setTimeout(() => { if (my === gen) { q = sentences(P[i]); j = 0; next(); } }, 450); }
      else { playing = false; i = 0; show(); }
    };
    next();
  }
  const stop = () => { gen++; S.cancel(); playing = false; show(); };
  play.addEventListener('click', () => playing ? stop() : speakFrom(i));
  $('.ao-restart').addEventListener('click', () => playing ? speakFrom(0) : (i = 0, show()));
  $('.ao-prev').addEventListener('click', () => playing ? speakFrom(i - 1) : (i = Math.max(0, i - 1), show()));
  $('.ao-next').addEventListener('click', () => playing ? speakFrom(i + 1) : (i = Math.min(P.length - 1, i + 1), show()));
  rateB.addEventListener('click', () => { rate = RATES[(RATES.indexOf(rate) + 1) % RATES.length]; rateB.textContent = rate + '×'; if (playing) speakFrom(i); });
  document.addEventListener('keydown', e => {
    const t = e.target; if (e.ctrlKey || e.metaKey || e.altKey || (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)))) return;
    if (e.key === 'k' || e.key === 'K') { e.preventDefault(); play.click(); }
    else if (e.key === 'ArrowRight' && playing) { e.preventDefault(); $('.ao-next').click(); }
    else if (e.key === 'ArrowLeft' && playing) { e.preventDefault(); $('.ao-prev').click(); }
    else if (e.key === 'Home' && playing) { e.preventDefault(); $('.ao-restart').click(); }
  });
  addEventListener('pagehide', () => S.cancel());
  show();
})();
</script>
<!-- AUDIO-OVERVIEW:END -->
```

`add_fallback.py`:
```python
import json, sys, re
page_path, narr_path, snip_path = sys.argv[1:4]
paras = [' '.join(p.split()) for p in re.split(r'\n\s*\n|\n', open(narr_path, encoding='utf8').read()) if p.strip()]
block = open(snip_path, encoding='utf8').read().strip().replace('__PARAGRAPHS_JSON__', json.dumps(paras, ensure_ascii=False).replace('</', '<\\/'))
page = open(page_path, encoding='utf8').read()
B, E = '<!-- AUDIO-OVERVIEW:BEGIN', '<!-- AUDIO-OVERVIEW:END -->'
i = page.find(B)
if i >= 0: j = page.find(E, i) + len(E); page = page[:i] + block + page[j:]
else: k = page.find('</header>'); page = page[:k] + block + '\n' + page[k:]
open(page_path, 'w', encoding='utf8').write(page); print('browser-voice player added,', len(paras), 'paragraphs')
```

### Owner-only refresh button

The player has a hidden ↻ button that regenerates the audio overview from the page as it currently stands. It appears **only when the viewer is the artifact's owner (Swami)** (`user.isOwner()`), and clicking it fires Swami's own scheduled task through the Claude Code Remote connector — a connector that only runs scheduled tasks belonging to the caller's account, so no one else can trigger it even with the page's code. Everyone else sees the player without the button.

Wire it on every dashboard, after the first publish (the artifact URL is needed):
1. Find the reusable scheduled task named **"Vibe dashboard — refresh audio overview"** with the Claude Code Remote `list_triggers` tool. If it does not exist, create it with `create_trigger` (no schedule — run-on-demand only; `initiation: human_request`; push notifications on) using the prompt in `references/audio-refresh-task.md`. One task serves every dashboard.
2. Re-run `build` with `--trigger <its trig_ id> --artifact <the artifact's URL>` and republish to the same file path with
   `capabilities: {mcp: {servers: [{server: "Claude Code Remote", tools: ["fire_trigger"]}]}}`.
   This is the one capability a dashboard declares; declare nothing else.
3. Tell Swami the first click asks him once to allow the connector for that page.

### Refreshing an existing dashboard

This is what the scheduled task runs (and what to do when Swami asks to "update the audio overview" on a published dashboard): read the artifact (`Artifact` action `read` with the URL, then `read` with `path: "index.html"` for the full file; proceed only if Swami is a writer), run `extract` on it, write a fresh narration of the page as it is now (following **Writing the narration** — each section announced by number, then header — and **Pronunciation** above), run the noun/verb stress audit and fix it, run `stress_audio.py SKILL_DIR build PAGE narration OUT` (the existing trigger/artifact settings carry over), and publish OUT to the same `url` **without** a `capabilities` field so the declared grant is kept. Change nothing else on the page.

## Privacy: people under NDA

Swami has clients under NDA. **Before publishing or republishing any dashboard** — and before writing its narration, search data or any published data file — check memory for people marked as under NDA / privacy exclusion (his preferences name them; their people files hold their identifiers: aliases, product and file names, profile links).
- **On every page that isn't solely for that client, leave them out entirely:** names, aliases, product and file names, photos, links, recordings and quotes. A page that is about such a client (a session write-up for them) is fine to build, but tell Swami to share it only by email invitation, never "Anyone with the link".
- **Owner-only hiding is not privacy** — hidden content stays in the page source.
- **The exclusion list is private.** It is a JSON file `{"people":[{"name", "reason", "facebook", "terms":[…]}]}` kept at a private working path — never published, never committed to GitHub, never written into a skill (skills are published to a public repo). A scheduled task that publishes a page carries the list in its own prompt (private to the account) and writes it to a private path at the start of each run.
- **Scan gate.** Run `refresh.py scan EXCLUDE.json FILE…` (reference implementation; case-insensitive, separators optional, letter boundaries, digits allowed after a term so "Widget01" still matches "Widget") on the page, its narration and every data file before each publish and commit. Any hit stops the publish. Check hits for false positives ("grace period", "graceful") before acting on them.
- **Never name an excluded person** in a published file, publish label or description, commit message, scheduled task's final line, or skill text; refer to an exclusion only as "1 item excluded for privacy".
- **When Swami names someone new to exclude:** add them to memory (their people file and the preferences line), add their terms to the private list and to every scheduled task that publishes (`update_trigger`), re-scan his pages (list all artifacts; read each with `path: "index.html"` in parallel batches — a subagent keeps the bulk reads out of the main context; scan), and give him a table of every page that mentions them — title, link, updated date, sharing state (an Artifact `read` without `path` states it), "about them" vs "mentions them" — so he can change sharing from each page's Share menu. Reply in chat; don't publish that table.

## Version history (GitHub)

Swami's private repo `swami-claude-skills/vibe-dashboards` keeps every version of every page.
- **Automatic:** the scheduled task "Vibe dashboards — nightly GitHub backup" saves each artifact created or changed that day into `pages/<title-slug>--<artifactId>/` (all its published files) and updates `manifest.json` (id → title, link, updated date, folder; deleted pages are marked `"gone"`, never removed), using `tools/backup.py`. Nothing to do per dashboard.
- **Script-built dashboards:** keep their sources in their own folder (`<kebab-name>/`: `index.html` as published, `build.py`, any `.js` modules, `narration.txt`, `data/*.json`) and commit after every change published in a chat: `add_repo` (owner `swami-claude-skills`, repo `vibe-dashboards`, access `push`), `git clone --depth 1`, confirm the repo is still private (`gh api repos/swami-claude-skills/vibe-dashboards --jq .private` must print `true`; otherwise commit nothing and tell Swami), run the privacy scan on the changed files, commit with a short note (no client names) ending `Co-Authored-By: Claude …`, push to `main`, and verify `git ls-remote origin main` equals `git rev-parse HEAD`. Push large first-time uploads in batches. Never commit an exclusion list.
- **Restoring:** open the file on GitHub, click History, pick the version; Claude republishes it to the same artifact URL.
- **Access:** if `add_repo` says the repo isn't reachable, the Claude GitHub app lacks access — Swami adds the repo under github.com/settings/installations → Claude → Repository access (GitHub first asks him to confirm by email). The account's GitHub email is not his main inbox.

## Self-contained files

Dashboards must be single files. For images, embed as base64 data URIs. If images are large, compress first with Python/Pillow before embedding. No external CSS/JS beyond the Google Fonts link. (Exception: a page with the Search section publishes its own data files beside it through the Artifact `files` map and fetches them by relative URL.)

## Placeholders in the template

`{{PAGE_TITLE}}` (browser tab) · `{{KICKER}}` (small cyan mono eyebrow — REQUIRED, always fill it, never leave blank or delete the element) · `{{H1_TITLE}}` + `{{H1_SUBTITLE}}` · `{{BYLINE_A/B/…}}` (author, group, post link, type — never a copyright mark; no `©`, no `© Swami`) · the REQUIRED Dashboard Summary section: `{{SUMMARY_BADGE}}` (category badge), `{{SUMMARY_INTRO}}` (what the dashboard covers), `{{SUMMARY_CALLOUT_LABEL}}` + `{{SUMMARY_CALLOUT_TEXT}}` (optional intro callout — delete the `.callout` if unused), and the "What each section covers" table rows `{{SEC_x_TITLE/FOCUS/WHEN}}` (add one row per other section, each with an empty `<td class="sec-cat"></td>` Category cell right after the Section cell — JS fills it) · per-section `{{SECTION_N_TITLE}}` + `{{BADGE_N}}` (content sections, numbered from 02) · `{{VERBATIM_TEXT}}` · `{{MAIL_SUBJECT}}` (email subject line) · the Glossary rows `{{GLOSS_x_ID/MATCH/CODE/TERM/DEF}}` (one row per term, each plus a color-coded Topic cell between the Term and the Definition — see "Glossary section"; delete the section and leave the summary row — it auto-drops — if there is nothing to define) · the References section rows `{{REF_x_NUM/SOURCE/TOPIC/TOPIC_COLOR/COVERS/CITED_IN/DOMAIN/URL}}` (one per cited source, with a color-coded Topic cell right after Source — see "References section"; drop the section if the dashboard cites nothing). See `references/patterns.md` for a filled example section and category-naming guidance.

## Built-in fixes

The template already includes the References Topic sort and clickable `[n]` citations, the `syncSectionTitles` title guard (see "Section titles" above), the pinned-header fix (aligned, sortable, resizable clone + `no-sort` opt-out), the `[NN]` section-number brackets, and topic-ID (`.tid`) styling/exclusions. Older versions of this skill required a patch script for those — that is no longer needed; do not re-add it. The patches still required are the table-fit patch, the Search patch (`scripts/search_patch.py`, which includes the subsection patch), the Mind Map patch (both below), and, on other pages that use `.subsec`, the subsection patch ("Generic subsections").

## Table-fit patch (REQUIRED until the template ships it)

The template's `fitVisibleTables` can still (a) open a wide table with sideways scroll when its first column holds long one-line text (e.g. video titles), and (b) squeeze a short column below its longest word so words break mid-word ("Independ-ent", "Connecte-d"). This patch fixes both: it adds `bodyWordMin` (narrowest a column can be without breaking a word), raises each column's floor to that width when all floors still fit, wraps header labels when the first column's share would overflow, and lets the first column wrap as a last resort. It is idempotent (prints "already applied" on a second run) and stops with an error, changing nothing, if the template's code has moved — if that happens, apply the same four changes by hand.

Save this as `fit_patch.py` in the working directory (not in the skill folder) and run `python3 fit_patch.py PAGE.html` right after copying the template (also safe on an existing dashboard built from this template):

```python
import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
if 'function bodyWordMin(' in s:
    print('table-fit patch: already applied'); sys.exit()
R = [
("    const wrapHeads = headMin.reduce((a,b)=>a+b, 0) > avail;",
"""    // (also wrap when the first column's share plus the other one-line headers overflow)
    const wrapHeads = headMin.reduce((a,b)=>a+b, 0) > avail ||
      Math.min(natural[0], Math.round(avail * 0.4)) + headMin.slice(1).reduce((a,b)=>a+b, 0) > avail;"""),
("""    const widths = natural.slice();
    const sumNat = natural.reduce((a,b)=>a+b, 0);""",
"""    // never squeeze a body column below its longest single word (no mid-word breaks),
    // capped so one very long token can't hog the table
    // (only when all those floors still fit the page; otherwise fitting to width wins)
    { const wm = headMin.map((h,ci) => Math.max(h, Math.min(160, bodyWordMin(table, ci))));
      if(wm.reduce((a,b)=>a+b, 0) <= avail) headMin = wm; }
    const widths = natural.slice();
    const sumNat = natural.reduce((a,b)=>a+b, 0);"""),
("""      for(const o of order){ if(over<=0) break; const cut=Math.max(0, Math.min(over, rounded[o.ci]-headMin[o.ci])); rounded[o.ci]-=cut; over-=cut; }
    }""",
"""      for(const o of order){ if(over<=0) break; const cut=Math.max(0, Math.min(over, rounded[o.ci]-headMin[o.ci])); rounded[o.ci]-=cut; over-=cut; }
      // still over (long one-line first column, e.g. video titles): let col 0 wrap too
      if(over > 0){ const cut = Math.max(0, Math.min(over, rounded[0] - headMin[0])); rounded[0] -= cut; over -= cut; }
    }"""),
("function fitVisibleTables(){",
"""/* narrowest a column's body cells can be without breaking inside a word */
function bodyWordMin(table, ci){
  let max = 0;
  [...table.tBodies[0].rows].forEach(r => {
    const c = r.cells[ci]; if(!c) return;
    const m = c.cloneNode(true), cs = getComputedStyle(c);
    m.style.cssText = 'position:absolute;left:-9999px;top:-9999px;white-space:normal;overflow-wrap:normal;word-break:normal;width:min-content;visibility:hidden;';
    m.style.font = cs.font; m.style.padding = cs.padding; m.style.letterSpacing = cs.letterSpacing;
    document.body.appendChild(m); max = Math.max(max, m.getBoundingClientRect().width); m.remove();
  });
  return Math.ceil(max) + 2;
}
function fitVisibleTables(){"""),
]
for old, new in R:
    if s.count(old) != 1:
        sys.exit('table-fit patch: anchor not found (template changed?) — ' + old.strip()[:60])
    s = s.replace(old, new, 1)
open(p, 'w', encoding='utf-8').write(s)
print('table-fit patch: applied')
```

After building, check that every table opens inside the page width at a desktop width (e.g. 1000 px and 1440 px window width) and that no short column breaks a word in half. Also run a few searches in the Search section (a plain word, a typo, a "phrase", a -exclusion, a filter with an empty box) and check phone width (390 px) for sideways scroll.

## Mind Map patch (REQUIRED on every dashboard)

A NotebookLM-style map of the whole page, first built as a test on the Claude Surfaces Compared dashboard and adopted for every dashboard (Nov 2026). The patch adds everything — section, summary row, CSS and script — and stays idempotent: a second run prints "refreshed" and replaces the CSS, the section body and the script with the version below, leaving the section's number and position alone. Save it as `mindmap_patch.py` in the working directory (not in the skill folder) and run `python3 mindmap_patch.py PAGE.html` after the content sections are final (and after the table-fit and Search patches), before writing the audio narration. It also works on an existing dashboard built from this template.

**What the patch does on first run**
- Inserts the **Mind Map** section just before Glossary (else References, else Source Document (Verbatim), else the end of `main`), in the Dashboard Summary's category, numbers it after the last section before it, and renumbers every section after it consecutively (this also fixes the template's 97/98/99 placeholders).
- Adds the summary row "Mind Map · Clickable map of every section, table row, list item, and callout · Seeing the whole page at a glance, or jumping straight to a detail" just above the Glossary row; its number fills at runtime (`data-target-title="Mind Map"`).
- Keeps the toolbar search out of the map's SVG (marking text inside `<svg>` would break it) and adds "Mind Map" to the Glossary's `EXCLUDE` set so its intro text is never term-linked or counted.

**What the map shows** (built in the browser at load from the page, so it always matches it)
- Root: the page name (the `<title>` before " — Swami"); its hover card shows the H1 subtitle.
- One branch per section (except the Mind Map itself), labelled `Title [NN] {children}` and coloured with that section's own category colour. Its hover card shows the section's Focus from the section 01 summary table.
- Inside each section: list items (labelled by their topic ID), table rows (labelled by the first cell; hover shows the other cells as "Header: value"), resource cards, subsections and callouts. A section's lists, and its tables when there is more than one block, get their own sub-branch (`Key points {n}` or the table's `data-desc {n}`). Section 01 lists one bubble per summary-table row (hover: Focus · Use when) plus its callouts. Glossary, References, Source Document and Search are single bubbles. Owner-only and hidden content is never mapped.
- Every branch label ends with its number of children in curly braces; final bubbles have none.
- **Optional hints:** `<ul data-mm-label="Features">` names a list's branch (default "Key points"); `<div class="subsec" data-mm-tip="…">` sets a subsection bubble's hover summary (default: its first paragraph or hint line, else a digest of its text — set it on tool or control parts, whose text is mostly labels); `<div class="table-wrap" data-mm-group="1" data-mm-group-label="Only in {v}">` groups a table's rows into sub-branches by that column (0-based), with `{v}` replaced by the value.

**Behaviour** (all built into the script)
- Bubbles: click the › arrow to open or close a branch (the bubble stays put on screen); click the name to jump to that spot (opens the section and item, clears every pinned layer, flashes it green — `jumpToEl` / `scrollToSection`); hover for a card in the page's `.gj-tip` style. **Every bubble has a hover card** — one with no summary still shows its title, where a click goes, and its branch line (fixed Nov 3 2026: subsection bubbles used to get no summary and therefore no card).
- Opens **fitted** to its frame. The frame's height is the space left under the pinned TOC/toolbar, section header and map toolbar, so it can always be seen whole.
- Drag to pan (a drag never counts as a click). Ctrl/⌘ + scroll or trackpad pinch zooms at the cursor; plain scroll still scrolls the page. Two-finger pinch on touch screens. Zoom 5%–300%.
- Double-click empty space = fit. Shift + click a bubble (or the space near one) = zoom to every item in the closest branch (a bubble with children: its own branch, opened if closed; a final bubble: its parent's branch). **zoom region** button, or Alt/Option + drag = drag a box and zoom to it (Esc cancels). Zooms land in the part of the frame actually on screen.
- **Sticky toolbar** (pins under the section header): expand all, collapse all (then fit), − / zoom % / +, fit, zoom region, reset view (100%, map start at the left). Every control has a hover card with what it does and its shortcut.
- A non-sticky hint line sits right after the intro paragraph; the intro includes "HOVER OVER CONTROL FOR TOOLTIP." in faint green.

**Search section:** every page has one; its page index skips the Mind Map section (`title === 'Mind Map'`), like section 01 (`search_patch.py` does this).

```python
import sys, re
"""mindmap_patch.py PAGE.html — add (or refresh) the vibe-dashboard Mind Map section. Idempotent.
First run: inserts the section just before Glossary (else References, else the verbatim section, else at the end of
main), numbers it and renumbers the sections after it, adds its row to the section 01 summary table, adds the CSS and
script, keeps page search out of the map and keeps the Glossary from counting terms in it. Later runs replace the CSS,
the section body and the script with this version, leaving the section's number and position alone."""
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
CSS = r'''  /* ---- mind map (NotebookLM style) ---- */
  .mm-bar{display:flex;flex-wrap:wrap;gap:8px;margin:4px 0 2px;padding:8px 0;position:sticky;top:calc(var(--stack-h,0px) + var(--sechead-h,0px));z-index:15;background:var(--panel)}   /* pins under the section header while you scroll the map */
  .mm-wrap{position:relative;overflow:hidden;background:var(--panel);border:1px solid var(--border);border-radius:10px;height:max(300px,calc(100vh - var(--stack-h,0px) - var(--sechead-h,0px) - var(--mmbar-h,48px) - 28px))}
  .mm-wrap svg{display:block;width:100%;height:100%;cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none}
  .mm-wrap.panning svg,.mm-wrap.panning .mm-node{cursor:grabbing}
  .mm-wrap.region svg,.mm-wrap.region .mm-node{cursor:crosshair}
  .mm-rect{position:absolute;border:1.5px dashed var(--cyan);background:rgba(0,229,255,.08);border-radius:3px;pointer-events:none;display:none}
  .mm-ctl-tip .gj-foot.keys{color:var(--cyan)}
  .mm-tipnote{color:rgba(0,255,136,.55)}   /* faint green */
  .mm-zoom[data-tip]{cursor:help}
  .tool-btn.mm-on{color:var(--cyan);border-color:var(--cyan);background:rgba(0,229,255,.10)}
  .mm-bar .mm-sep{width:1px;align-self:stretch;background:var(--border);margin:0 4px}
  .mm-zoom{font-family:var(--mono);font-size:12px;color:var(--text-dim);align-self:center;min-width:44px;text-align:center;font-variant-numeric:tabular-nums}
  .mm-node{cursor:pointer}
  .mm-node rect.box{stroke-width:1.2;transition:filter .15s}
  .mm-node:hover rect.box{filter:brightness(1.35)}
  .mm-node text{font-family:var(--sans);font-size:13px;fill:var(--text);dominant-baseline:central;pointer-events:none}
  .mm-node.root text{font-weight:700;font-size:14px}
  .mm-node .chev circle{fill:var(--panel-2);stroke-width:1.2}
  .mm-node .chev text{font-family:var(--mono);font-size:12px;text-anchor:middle}
  .mm-edge{fill:none;stroke-width:1.6;opacity:.55}
  .mm-hint{font-family:var(--mono);font-size:11px;color:var(--text-mute);margin:6px 0 4px}
  .mm-tip .mm-tip-hint{margin-top:4px;color:var(--gj)}
  .mm-node.linked{cursor:pointer}
  .mm-node.linked:hover rect.box{filter:brightness(1.35)}'''
BODY = r'''      <p>Everything on this page as one map, built from its sections, lists, tables, and callouts. <span class="mm-tipnote">HOVER OVER CONTROL FOR TOOLTIP.</span> Click a bubble's › arrow to open or close its branch, and click a bubble's name to jump to that spot on the page. Hover any bubble for a short summary. The map opens fitted to its frame. Drag to pan; zoom with the − / + buttons, Ctrl/⌘ + scroll, or a pinch. Double-click empty space to fit the whole map again, Shift + click a bubble (or the space near one) to zoom to all the items in that branch, and drag a box with zoom region (or Alt/Option + drag) to zoom to just that area.</p>
      <div class="mm-hint">Drag to pan · Ctrl/⌘ + scroll or pinch to zoom · Double-click empty space to fit · Shift + click to zoom to a branch · Alt/Option + drag (or zoom region) to zoom to a box · Branch colours match each section's category colour.</div>
      <div class="mm-bar">
        <button class="tool-btn" id="mmExpand" data-tip="Expand all" data-tip-body="Opens every branch so every bubble shows. The top bubble stays where it is on screen.">expand all</button>
        <button class="tool-btn" id="mmCollapse" data-tip="Collapse all" data-tip-body="Closes every branch back to the main sections, then fits the map in the frame.">collapse all</button>
        <span class="mm-sep" aria-hidden="true"></span>
        <button class="tool-btn" id="mmZoomOut" data-tip="Zoom out" data-tip-body="Zooms out 20% around the centre of the frame (down to 5%)." data-tip-keys="Also: Ctrl/⌘ + scroll down, or pinch in" aria-label="Zoom out">−</button>
        <span class="mm-zoom" id="mmZoom" data-tip="Zoom level" data-tip-body="The current zoom, from 5% to 300%. 100% is the normal bubble size." aria-live="polite">100%</span>
        <button class="tool-btn" id="mmZoomIn" data-tip="Zoom in" data-tip-body="Zooms in 25% around the centre of the frame (up to 300%)." data-tip-keys="Also: Ctrl/⌘ + scroll up, or pinch out" aria-label="Zoom in">+</button>
        <button class="tool-btn" id="mmFit" data-tip="Fit" data-tip-body="Zooms and centres so the whole map, as currently opened, fits in the frame." data-tip-keys="Also: double-click empty space">fit</button>
        <button class="tool-btn" id="mmRegion" data-tip="Zoom region" data-tip-body="Click to turn on, then drag a box on the map: it zooms to fit that box and the button turns off." data-tip-keys="Shortcut: Alt/Option + drag · Esc cancels" aria-pressed="false">zoom region</button>
        <button class="tool-btn" id="mmReset" data-tip="Reset view" data-tip-body="Back to 100% zoom, with the start of the map at the left edge of the frame.">reset view</button>
      </div>
      <div class="mm-wrap" id="mmWrap"><div class="mm-rect" id="mmRect"></div><svg id="mindmap" role="img" aria-label="Mind map of this page"></svg></div>'''
JS = r'''/* ===== mind map (NotebookLM style): horizontal tree built from this page; click arrows to expand,
   drag to pan, Ctrl/⌘+wheel or pinch to zoom, double-click empty space to fit, Shift+click to zoom to a
   branch, Alt/Option+drag or the zoom region button to zoom to a box. Added by mindmap_patch.py. ===== */
(() => {
  const svg = document.getElementById('mindmap'); if (!svg) return;
  const NS = 'http://www.w3.org/2000/svg';
  /* ---- the tree is built at load from this page itself: every section (number in [ ]), and inside it
     its list items, table rows, callouts, cards and subsections. Branch labels end with {children}.
     Optional hints on the markup: <ul data-mm-label="Features"> names a list's branch;
     <div class="subsec" data-mm-tip="…"> sets a subsection bubble's hover summary;
     <div class="table-wrap" data-mm-group="1" data-mm-group-label="Only in {v}"> groups a table's rows by a column. */
  const TREE = (() => {
    const T = s => (s || '').replace(/\s+/g, ' ').trim();
    const clip = (s, n = 230) => s.length <= n ? s : s.slice(0, n - 1).replace(/\s+\S*$/, '') + '…';
    const txt = el => { if (!el) return ''; const c = el.cloneNode(true);
      c.querySelectorAll('.sort-ind,.col-resizer,.owner-tag,.cat-pill').forEach(x => x.remove());
      return T(c.textContent).replace(/\s*\[\d{2,3}\]/g, ''); };          // drop the [NN] section-number suffixes
    const hidden = el => !!el.closest('[hidden],.owner-only,.own-col');   // never map owner-only content
    const css = getComputedStyle(document.documentElement);
    const catColor = sec => { const v = css.getPropertyValue('--cat-' + sec.dataset.cat).trim(); return /^#[0-9a-f]{6}$/i.test(v) ? v : '#00e5ff'; };
    const secs = [...document.querySelectorAll('main .section')];
    const summary = secs.find(s => s.dataset.title === 'Dashboard Summary');
    const idx = summary && [...summary.querySelectorAll('.table-wrap')].find(w => w.dataset.desc === 'What each section covers');
    const focus = {};
    if (idx) [...idx.querySelectorAll('tbody tr')].forEach(r => { if (r.cells.length >= 5) focus[txt(r.cells[1])] = {f: txt(r.cells[3]), w: txt(r.cells[4])}; });
    const N = (label, tip, el, children, color) => { const n = {label, tip: clip(tip || '')}; if (el) n.go = {el};
      if (children && children.length) { n.children = children; n.label += ' {' + children.length + '}'; } if (color) n.gcolor = color; return n; };
    const rowTip = (heads, r, skip) => [...r.cells].map((c, i) => { if (!i || i === skip) return ''; const v = txt(c); return v ? (heads[i] ? heads[i] + ': ' : '') + v : ''; }).filter(Boolean).join(' · ');
    const LEAF = new Set(['Glossary', 'References', 'Source Document (Verbatim)', 'Search']);
    const top = (body, sel) => [...body.querySelectorAll(sel)].filter(e => !hidden(e) && !(e.parentElement && e.parentElement.closest('.subsec')) && !e.closest('table'));
    const branches = [];
    secs.forEach(sec => {
      const title = sec.dataset.title, body = sec.querySelector('.sec-body');
      if (title === 'Mind Map' || hidden(sec) || !body) return;
      const num = T(sec.querySelector('.sec-num') && sec.querySelector('.sec-num').textContent);
      const tip = focus[title] ? focus[title].f : T(body.querySelector('p') && body.querySelector('p').textContent);
      const kids = [];
      if (sec === summary) {
        if (idx) [...idx.querySelectorAll('tbody tr')].forEach(r => { if (hidden(r) || r.cells.length < 5) return;
          const name = txt(r.cells[1]), f = focus[name]; kids.push(N(name, f ? f.f + (f.w ? ' · Use when: ' + f.w : '') : '', r)); });
        top(body, '.callout').forEach(co => { const l = txt(co.querySelector('.lbl')); kids.push(N(l, txt(co).slice(l.length).trim(), co)); });
      } else if (!LEAF.has(title)) {
        const lists = top(body, 'ul').filter(u => !u.closest('.callout,.resource')), tables = top(body, '.table-wrap'), callouts = top(body, '.callout'), cards = top(body, '.resource'), subs = top(body, '.subsec');
        const others = tables.length + callouts.length + cards.length + subs.length;
        lists.forEach((ul, i) => {
          const items = [...ul.children].filter(li => li.tagName === 'LI' && !hidden(li)).map(li => {
            const tid = li.querySelector('.tid'), all = txt(li);
            const l = tid ? txt(tid) : all.split(' ').slice(0, 6).join(' ') + (all.split(' ').length > 6 ? '…' : '');
            return N(l, tid ? all.slice(l.length).trim() : all, li); });
          if (!items.length) return;
          if (others || lists.length > 1) kids.push(N(ul.dataset.mmLabel || ('Key points' + (lists.length > 1 ? ' ' + (i + 1) : '')), items.length + ' items in this list, one bubble each.', ul, items));
          else kids.push(...items);
        });
        tables.forEach(w => {
          const t = w.querySelector('table'); if (!t || !t.tBodies[0]) return;
          const heads = t.tHead ? [...t.tHead.rows[0].cells].map(txt) : [];
          const rows = [...t.tBodies[0].rows].filter(r => !hidden(r) && r.cells.length);
          if (!rows.length) return;
          const desc = w.dataset.desc || heads[0] || 'Table';
          if (w.dataset.mmGroup !== undefined) {
            const g = +w.dataset.mmGroup, groups = new Map();
            rows.forEach(r => { const v = txt(r.cells[g]); if (!groups.has(v)) groups.set(v, []); groups.get(v).push(N(txt(r.cells[0]), rowTip(heads, r, g), r)); });
            groups.forEach((ch, v) => kids.push(N((w.dataset.mmGroupLabel || '{v}').replace('{v}', v), ch.length + ' row' + (ch.length === 1 ? '' : 's') + ' where ' + (heads[g] || 'the value') + ' is ' + v + '.', ch[0].go.el, ch)));
            return;
          }
          const leaves = rows.map(r => N(txt(r.cells[0]), rowTip(heads, r, -1), r));
          if (tables.length === 1 && !lists.length) kids.push(...leaves);
          else kids.push(N(desc, leaves.length + ' rows in this table.', w, leaves));
        });
        cards.forEach(c => kids.push(N(txt(c.querySelector('.r-name')) || 'Card', txt(c.querySelector('.r-note')), c)));
        subs.forEach(su => { const p = [...su.querySelectorAll('p,.field-hint,.hint')].map(txt).find(Boolean);
          kids.push(N(su.dataset.desc || 'Part', su.dataset.mmTip || p || T(su.textContent), su)); });
        callouts.forEach(co => { const l = txt(co.querySelector('.lbl')); kids.push(N(l || 'Callout', txt(co).slice(l.length).trim(), co)); });
      }
      branches.push(N(title + ' [' + num + ']', tip, sec, kids, catColor(sec)));
    });
    const sub = document.querySelector('header h1 .sub');
    const name = T(document.title.split(' — ')[0]) || T(document.querySelector('header h1') && document.querySelector('header h1').firstChild.textContent);
    return N(name, sub ? T(sub.textContent) : 'This whole page as one map.', summary, branches);
  })();
  const PAL = ['#38dafa','#38fa79','#dafa38','#fa9938','#fa3899','#ea38fa','#7938fa','#3879fa'];
  const ROW = 38, GAP = 64, PADX = 14, BOXH = 28;
  let uid = 0;
  (function prep(n, d, color){ n.id = uid++; n.d = d; n.color = d === 1 ? PAL[(n.id) % PAL.length] : color;
    n.open = d < 1; (n.children || []).forEach((c, i) => { if (d === 0) c.color = PAL[i % PAL.length]; prep(c, d + 1, d === 0 ? PAL[i % PAL.length] : n.color); }); })(TREE, 0, '#00e5ff');
  (function fix(n){ (n.children||[]).forEach((c,i)=>{ if(n.d===0) c.color = c.gcolor || PAL[i % PAL.length]; else c.color = c.gcolor || n.color; fix(c); }); })(TREE);
  TREE.color = '#00e5ff';
  (function par(n){ (n.children || []).forEach(c => { c.parent = n; par(c); }); })(TREE);
  const ctx = document.createElement('canvas').getContext('2d');
  const tw = n => { ctx.font = (n.d === 0 ? '700 14px' : '13px') + ' "DM Sans",sans-serif'; return ctx.measureText(n.label).width; };
  const el = (tag, attrs, parent) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); if (parent) parent.appendChild(e); return e; };
  const rgba = (hex, a) => { const v = parseInt(hex.slice(1), 16); return `rgba(${v>>16},${(v>>8)&255},${v&255},${a})`; };
  /* bubble hover card in the page's own .gj-tip style */
  const tip = document.createElement('div'); tip.className = 'gj-tip mm-tip'; tip.setAttribute('role', 'tooltip'); document.body.appendChild(tip);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[c]);
  let tipFor = null;
  /* where a map bubble points: {sec: title} | {callout: [section title, label]} | {row: [table desc, first-cell text]} | {css: selector} */
  function mmTarget(go){
    if (!go) return null;
    if (go.el) return go.el;
    const secBy = t => [...document.querySelectorAll('.section')].find(s => s.dataset.title === t);
    if (go.sec) return secBy(go.sec) || null;
    if (go.callout) { const s = secBy(go.callout[0]); return s ? [...s.querySelectorAll('.callout')].find(c => (c.querySelector('.lbl')?.textContent || '').trim() === go.callout[1]) || null : null; }
    if (go.row) { const w = [...document.querySelectorAll('.table-wrap')].find(x => x.dataset.desc === go.row[0]);
      return w ? [...w.querySelectorAll('tbody tr')].find(r => (r.cells[0]?.textContent || '').replace(/\s*\[\d+\]\s*$/, '').trim() === go.row[1]) || null : null; }
    if (go.li) { const s = secBy(go.li[0]); return s ? [...s.querySelectorAll('li')].find(l => (l.querySelector('.tid')?.textContent || '').trim() === go.li[1]) || null : null; }
    if (go.css) return document.querySelector(go.css);
    return null;
  }
  function whereOf(el){ if (!el) return '';
    if (el.closest('header')) return 'the audio player under the title';
    const s = el.closest('.section'); const t = s ? s.dataset.title : '';
    if (el === s) return t;
    const it = el.closest('.citem'); const d = it ? (it.querySelector('.citem-desc, .citem-title')?.textContent || '').trim() : '';
    return t + (d ? ' › ' + d : ''); }
  function mmTipShow(n, e){
    {
      const tgt = mmTarget(n.go), kids = (n.children || []).length;
      tip.style.setProperty('--gj', n.color);
      tip.innerHTML = '<div class="gj-head"><span class="gj-title">' + esc(n.label) + '</span></div>' +
        (n.tip ? '<div class="gj-def">' + esc(n.tip) + '</div>' : '') +
        (tgt ? '<div class="gj-foot mm-tip-hint">click to go to ' + esc(whereOf(tgt)) + '</div>' : '') +
        (kids ? '<div class="gj-foot">' + (n.open ? '‹ closes' : '› opens') + ' this branch (' + kids + ')</div>' : '');
      tipFor = n; tip.classList.add('show');
      place((e && e.currentTarget || document.activeElement).getBoundingClientRect());
      return;
    }
  }
  // sit just below the hovered bubble (above it near the bottom of the window), never covering it
  function place(r){
    const w = tip.offsetWidth, h = tip.offsetHeight, vw = innerWidth, vh = innerHeight;
    let x = Math.min(Math.max(8, r.left), vw - w - 8), y = r.bottom + 8;
    if (y + h > vh - 8) y = Math.max(8, r.top - h - 8);
    tip.style.left = x + 'px'; tip.style.top = y + 'px';
  }
  function mmTipMove(){}
  function mmTipHide(){ tipFor = null; tip.classList.remove('show'); }
  addEventListener('scroll', mmTipHide, { passive: true });
  /* ---- zoom / pan state (kept across re-renders) ---- */
  const wrap = document.getElementById('mmWrap'), zoomLbl = document.getElementById('mmZoom');
  let Z = 1, TX = 16, TY = 16, W0 = 0, H0 = 0, gView = null, userMoved = false, lastVis = [];
  const ZMIN = 0.05, ZMAX = 3;
  const vw = () => wrap.clientWidth, vh = () => wrap.clientHeight;
  function clampPan(){ const m = 60, w = W0 * Z, h = H0 * Z;
    TX = Math.min(Math.max(vw() - m, 0), Math.max(Math.min(m - w, 0), TX)); TY = Math.min(Math.max(vh() - m, 0), Math.max(Math.min(m - h, 0), TY)); }
  function apply(){ if (!gView) return; clampPan(); gView.setAttribute('transform', `translate(${TX},${TY}) scale(${Z})`); zoomLbl.textContent = Math.round(Z * 100) + '%'; }
  function zoomAt(f, cx, cy){ const nz = Math.min(ZMAX, Math.max(ZMIN, Z * f)); if (nz === Z) return;
    if (cx === undefined) { const v = visBox(); cx = (v.x0 + v.x1) / 2; cy = (v.y0 + v.y1) / 2; }
    TX = cx - (cx - TX) * nz / Z; TY = cy - (cy - TY) * nz / Z; Z = nz; userMoved = true; mmTipHide(); apply(); }
  function resetView(){ Z = 1; TX = 16; TY = H0 < vh() ? (vh() - H0) / 2 : 16; userMoved = true; apply(); }
  // bring the whole frame into view (just under the pinned toolbar) so nothing it fits is hidden
  function frameIntoView(){ const bar = document.querySelector('.mm-bar'), r = wrap.getBoundingClientRect();
    const top = parseFloat(getComputedStyle(bar).top) + bar.offsetHeight + 8;
    if (r.top < top - 1 || r.bottom > innerHeight + 1) window.scrollTo({top: r.top + scrollY - top, behavior: 'smooth'}); }
  // zoom so a box in map coordinates fills the frame (with a margin), centred
  /* the part of the frame you can actually see (not under the pinned toolbar, not past the window edge), in frame
     coordinates. If too little is showing, scroll the frame into view and use all of it. */
  function visBox(){ const r = wrap.getBoundingClientRect(), bar = document.querySelector('.mm-bar').getBoundingClientRect();
    const t = Math.max(r.top, bar.bottom, 0), b = Math.min(r.bottom, innerHeight), l = Math.max(r.left, 0), rt = Math.min(r.right, innerWidth);
    if (b - t < 160 || rt - l < 160) { frameIntoView(); return {x0: 0, y0: 0, x1: vw(), y1: vh()}; }
    return {x0: l - r.left, y0: t - r.top, x1: rt - r.left, y1: b - r.top}; }
  function zoomToBox(x0, y0, x1, y1, maxZ){ if (!vw()) return;
    const v = visBox(), VW = v.x1 - v.x0, VH = v.y1 - v.y0;
    const pad = 28, w = Math.max(1, x1 - x0), h = Math.max(1, y1 - y0);
    Z = Math.min(maxZ || ZMAX, Math.max(ZMIN, Math.min((VW - 2 * pad) / w, (VH - 2 * pad) / h)));
    TX = v.x0 + VW / 2 - (x0 + w / 2) * Z; TY = v.y0 + VH / 2 - (y0 + h / 2) * Z; userMoved = true; mmTipHide(); apply(); }
  function fitView(auto){ if (!vw()) return; if (!auto) frameIntoView();
    const pad = 24, z = Math.min((vw() - 2 * pad) / W0, (vh() - 2 * pad) / H0);
    Z = Math.min(1.5, Math.max(ZMIN, z));
    TX = (vw() - W0 * Z) / 2; TY = (vh() - H0 * Z) / 2; userMoved = !auto; apply(); }
  // keep a bubble where it is on screen when its branch opens or closes
  function anchored(n, fn){ const sy = n.y * Z + TY; fn(); TY = sy - n.y * Z; userMoved = true; apply(); }
  /* Shift + click: zoom to every visible item in the closest branch.
     A bubble with children = its own branch (opened if closed); a final bubble = its parent's branch. */
  const nodeBox = n => [n.x, n.y - BOXH / 2, n.x + n.w + ((n.children || []).length ? 24 : 0), n.y + BOXH / 2];
  function zoomBranch(n){
    let b = (n.children || []).length ? n : (n.parent || n);
    if (!b.open && (b.children || []).length) anchored(b, () => { b.open = true; render(); });
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    (function walk(m){ const [a, c, d, e] = nodeBox(m); x0 = Math.min(x0, a); y0 = Math.min(y0, c); x1 = Math.max(x1, d); y1 = Math.max(y1, e);
      if (m.open) (m.children || []).forEach(walk); })(b);
    zoomToBox(x0, y0, x1, y1, 1.6);
  }
  function nearestNode(mx, my){ let best = null, bd = Infinity;
    for (const n of lastVis) { const [a, c, d, e] = nodeBox(n); const dx = Math.max(a - mx, 0, mx - d), dy = Math.max(c - my, 0, my - e), dd = dx * dx + dy * dy;
      if (dd < bd) { bd = dd; best = n; } }
    return best; }
  function render(){
    mmTipHide();
    svg.textContent = '';
    const vis = [], colW = []; lastVis = vis;
    (function walk(n){ vis.push(n); n.w = tw(n) + PADX * 2; colW[n.d] = Math.max(colW[n.d] || 0, n.w); if (n.open) (n.children || []).forEach(walk); })(TREE);
    const colX = [0]; for (let d = 1; d < colW.length; d++) colX[d] = colX[d-1] + colW[d-1] + GAP;
    let y = 0;
    (function place(n){ const kids = n.open ? (n.children || []) : [];
      if (!kids.length) { n.y = y + BOXH/2; y += ROW; } else { kids.forEach(place); n.y = (kids[0].y + kids[kids.length-1].y) / 2; }
      n.x = colX[n.d]; })(TREE);
    const W = colX[colW.length-1] + colW[colW.length-1] + 40, H = Math.max(y, ROW);
    W0 = W; H0 = H;
    gView = el('g', {}, svg); apply();
    const gE = el('g', {}, gView), gN = el('g', {}, gView);
    vis.forEach(n => { if (n.open) (n.children || []).forEach(c => {
      const x1 = n.x + n.w + ((n.children||[]).length ? 22 : 0), x2 = c.x, mx = (x1 + x2) / 2;
      el('path', {class:'mm-edge', d:`M${x1},${n.y} C${mx},${n.y} ${mx},${c.y} ${x2},${c.y}`, stroke:c.color}, gE); }); });
    vis.forEach(n => {
      const kids = (n.children || []).length;
      const g = el('g', {class:'mm-node' + (n.d===0?' root':'') + (kids?'':' leaf'), transform:`translate(${n.x},${n.y})`, tabindex:'0', role:'button',
        'aria-label': n.label + (kids ? (n.open ? ', expanded' : ', collapsed') : '')}, gN);
      el('rect', {class:'box', x:0, y:-BOXH/2, width:n.w, height:BOXH, rx:BOXH/2, fill:rgba(n.color, n.d===0?.20:.12), stroke:rgba(n.color,.6)}, g);
      g.__node = n;
      const tx = el('text', {x:PADX, y:0}, g); tx.textContent = n.label;
      g.addEventListener('mouseenter', e => mmTipShow(n, e)); g.addEventListener('mousemove', mmTipMove);   // every bubble, even with no summary
      g.addEventListener('mouseleave', mmTipHide); g.addEventListener('focus', () => mmTipShow(n)); g.addEventListener('blur', mmTipHide);
      if (n.go) g.classList.add('linked');
      if (kids) { const c = el('g', {class:'chev', transform:`translate(${n.w + 12},0)`}, g);
        el('circle', {r:9, stroke:rgba(n.color,.7)}, c); const ct = el('text', {y:1, fill:n.color}, c); ct.textContent = n.open ? '‹' : '›'; }
      // the › arrow opens/closes a branch; the bubble itself jumps to where that topic lives on the page
      const toggle = () => anchored(n, () => { n.open = !n.open; render(); });
      const jump = () => { const tgt = mmTarget(n.go);
        if (!tgt) return false; mmTipHide();
        if (tgt.classList.contains('section') && window.scrollToSection) scrollToSection(sections.indexOf(tgt)); else if (window.jumpToEl) jumpToEl(tgt);
        return true; };
      g.addEventListener('click', e => { if (kids && (e.target.closest('.chev') || !n.go)) toggle(); else if (!jump() && kids) toggle(); });
      g.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); if (!jump() && kids) toggle(); }
        else if (e.key === ' ' || e.key === 'ArrowRight' || e.key === 'ArrowLeft') { if (kids) { e.preventDefault(); if ((e.key === 'ArrowRight') !== n.open || e.key === ' ') toggle(); } } });
    });
  }
  const setAll = (n, v) => { if ((n.children||[]).length) { n.open = v; n.children.forEach(c => setAll(c, v)); } };
  document.getElementById('mmExpand').addEventListener('click', () => anchored(TREE, () => { setAll(TREE, true); render(); }));
  document.getElementById('mmCollapse').addEventListener('click', () => { setAll(TREE, false); TREE.open = true; render(); fitView(true); });
  document.getElementById('mmZoomIn').addEventListener('click', () => zoomAt(1.25));
  document.getElementById('mmZoomOut').addEventListener('click', () => zoomAt(1 / 1.25));
  document.getElementById('mmFit').addEventListener('click', () => fitView());
  const regionBtn = document.getElementById('mmRegion'); let regionMode = false;
  const setRegion = v => { regionMode = v; regionBtn.classList.toggle('mm-on', v); regionBtn.setAttribute('aria-pressed', v); wrap.classList.toggle('region', v); };
  regionBtn.addEventListener('click', () => setRegion(!regionMode));
  addEventListener('keydown', e => { if (e.key === 'Escape' && (regionMode || rect)) { cancelRect(); setRegion(false); } });
  document.getElementById('mmReset').addEventListener('click', resetView);
  /* Ctrl/⌘ + wheel (and trackpad pinch, which arrives as ctrl + wheel) zooms at the cursor; plain wheel still scrolls the page */
  svg.addEventListener('wheel', e => { if (!(e.ctrlKey || e.metaKey)) return; e.preventDefault();
    const r = svg.getBoundingClientRect(); zoomAt(Math.exp(-e.deltaY * (e.deltaMode ? 0.05 : 0.0025)), e.clientX - r.left, e.clientY - r.top); }, { passive: false });
  /* drag to pan (mouse, pen or one finger); two fingers pinch-zoom. A drag never counts as a click on a bubble. */
  const ptrs = new Map(); let dragged = false, startX = 0, startY = 0, pinch = null, rect = null;
  const rectEl = document.getElementById('mmRect');
  function cancelRect(){ rect = null; rectEl.style.display = 'none'; }
  function drawRect(cx, cy){ const r = wrap.getBoundingClientRect();
    const x0 = Math.min(rect.x, cx) - r.left, y0 = Math.min(rect.y, cy) - r.top, w = Math.abs(cx - rect.x), h = Math.abs(cy - rect.y);
    Object.assign(rectEl.style, {display: 'block', left: x0 + 'px', top: y0 + 'px', width: w + 'px', height: h + 'px'}); }
  svg.addEventListener('pointerdown', e => { if (e.button !== 0 && e.pointerType === 'mouse') return;
    if ((regionMode || e.altKey) && ptrs.size === 0) {   // zoom region: drag a box instead of panning
      e.preventDefault(); rect = {x: e.clientX, y: e.clientY, id: e.pointerId}; dragged = false; mmTipHide();
      try { svg.setPointerCapture(e.pointerId); } catch (_) {} return; }
    ptrs.set(e.pointerId, {x: e.clientX, y: e.clientY});
    if (ptrs.size === 1) { dragged = false; startX = e.clientX; startY = e.clientY; }
    if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch = {d: Math.hypot(a.x - b.x, a.y - b.y), mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2}; } });
  svg.addEventListener('pointermove', e => {
    if (rect && e.pointerId === rect.id) { if (Math.hypot(e.clientX - rect.x, e.clientY - rect.y) > 4) dragged = true; if (dragged) drawRect(e.clientX, e.clientY); return; }
    const p = ptrs.get(e.pointerId); if (!p) return;
    const r = svg.getBoundingClientRect();
    if (ptrs.size === 2 && pinch) { p.x = e.clientX; p.y = e.clientY; const [a, b] = [...ptrs.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y), mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
      TX += mx - pinch.mx; TY += my - pinch.my; zoomAt(d / (pinch.d || d), mx - r.left, my - r.top); pinch = {d, mx, my}; dragged = true; return; }
    if (!dragged && Math.hypot(e.clientX - startX, e.clientY - startY) < 5) return;
    if (!dragged) { dragged = true; wrap.classList.add('panning'); mmTipHide(); try { svg.setPointerCapture(e.pointerId); } catch (_) {} }
    TX += e.clientX - p.x; TY += e.clientY - p.y; p.x = e.clientX; p.y = e.clientY; userMoved = true; apply(); });
  const endPtr = e => {
    if (rect && e.pointerId === rect.id) {
      const r = svg.getBoundingClientRect(), w = Math.abs(e.clientX - rect.x), h = Math.abs(e.clientY - rect.y);
      if (e.type === 'pointerup' && w > 8 && h > 8) {
        const sx = Math.min(rect.x, e.clientX) - r.left, sy = Math.min(rect.y, e.clientY) - r.top;
        zoomToBox((sx - TX) / Z, (sy - TY) / Z, (sx + w - TX) / Z, (sy + h - TY) / Z);
        setRegion(false); }
      cancelRect(); if (dragged) setTimeout(() => { dragged = false; }, 0); return; }
    ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch = null;
    if (!ptrs.size) { wrap.classList.remove('panning'); if (dragged) setTimeout(() => { dragged = false; }, 0); } };
  svg.addEventListener('pointerup', endPtr); svg.addEventListener('pointercancel', endPtr);
  svg.addEventListener('click', e => {
    if (dragged || regionMode) { e.stopPropagation(); e.preventDefault(); return; }
    if (e.shiftKey) {   // Shift + click: zoom to the closest branch (never jumps or toggles)
      e.stopPropagation(); e.preventDefault();
      const g = e.target.closest('.mm-node'), r = svg.getBoundingClientRect();
      const n = g ? g.__node : nearestNode((e.clientX - r.left - TX) / Z, (e.clientY - r.top - TY) / Z);
      if (n) zoomBranch(n); } }, true);
  /* double-click empty space: fit */
  svg.addEventListener('dblclick', e => { if (!e.target.closest('.mm-node') && !e.shiftKey) { e.preventDefault(); fitView(); } });
  /* the section starts collapsed (0 px wide): fit the map once it first becomes visible */
  const mmBar = document.querySelector('.mm-bar');
  const setBarH = () => document.documentElement.style.setProperty('--mmbar-h', mmBar.offsetHeight + 'px');
  setBarH();
  if (window.ResizeObserver) { new ResizeObserver(setBarH).observe(mmBar);
    new ResizeObserver(() => { if (vw() && !userMoved) fitView(true); else apply(); }).observe(wrap); }
  render();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { render(); if (!userMoved) fitView(true); });
})();

/* ---- hover cards for the mind map toolbar controls (same card style as the map bubbles) ---- */
(() => {
  const tip = document.createElement('div'); tip.className = 'gj-tip mm-ctl-tip'; tip.setAttribute('role', 'tooltip'); tip.id = 'mmCtlTip';
  tip.style.setProperty('--gj', 'var(--cyan)'); document.body.appendChild(tip);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[c]);
  let cur = null, timer = 0;
  function show(el){ cur = el;
    tip.innerHTML = '<div class="gj-head"><span class="gj-title">' + esc(el.dataset.tip) + '</span></div>' +
      '<div class="gj-def">' + esc(el.dataset.tipBody) + '</div>' + (el.dataset.tipKeys ? '<div class="gj-foot keys">' + esc(el.dataset.tipKeys) + '</div>' : '');
    tip.classList.add('show');
    const r = el.getBoundingClientRect(), w = tip.offsetWidth, h = tip.offsetHeight;
    let x = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), innerWidth - w - 8), y = r.bottom + 8;
    if (y + h > innerHeight - 8) y = Math.max(8, r.top - h - 8);
    tip.style.left = x + 'px'; tip.style.top = y + 'px'; el.setAttribute('aria-describedby', 'mmCtlTip'); }
  function hide(){ clearTimeout(timer); if (cur) cur.removeAttribute('aria-describedby'); cur = null; tip.classList.remove('show'); }
  document.querySelectorAll('.mm-bar [data-tip]').forEach(el => {
    el.addEventListener('mouseenter', () => { clearTimeout(timer); timer = setTimeout(() => show(el), 250); });
    el.addEventListener('mouseleave', hide);
    el.addEventListener('focus', () => show(el)); el.addEventListener('blur', hide);
    el.addEventListener('click', () => { if (cur === el) show(el); });   // refresh position after the click
  });
  addEventListener('scroll', hide, { passive: true });
  addEventListener('keydown', e => { if (e.key === 'Escape') hide(); });
})();'''
def block(text, a, b, new):
    i, j = text.find(a), text.find(b)
    return text[:i] + new + text[j + len(b):] if i >= 0 and j > i else None
cssb = '  /* MIND-MAP-CSS:BEGIN */\n' + CSS + '\n  /* MIND-MAP-CSS:END */\n'
jsb = '<!-- MIND-MAP-JS:BEGIN -->\n<script>\n' + JS + '\n</script>\n<!-- MIND-MAP-JS:END -->\n'
bodyb = '<!-- MIND-MAP-BODY:BEGIN -->\n' + BODY + '\n      <!-- MIND-MAP-BODY:END -->'
if 'MIND-MAP-BODY:BEGIN' in s:
    s = block(s, '  /* MIND-MAP-CSS:BEGIN */', '  /* MIND-MAP-CSS:END */\n', cssb)
    s = block(s, '<!-- MIND-MAP-JS:BEGIN -->', '<!-- MIND-MAP-JS:END -->\n', jsb)
    s = block(s, '<!-- MIND-MAP-BODY:BEGIN -->', '<!-- MIND-MAP-BODY:END -->', bodyb)
    open(p, 'w', encoding='utf-8').write(s); print('mind map: refreshed'); sys.exit()
if 'id="mindmap"' in s: sys.exit('mind map: page already has a hand-made mind map; remove it first')
# --- section: same category as the Dashboard Summary, inserted before Glossary / References / verbatim / end of main
m = re.search(r'<div class="section (cat-[\w-]+)" data-title="Dashboard Summary" data-cat="([\w-]+)">.*?<span class="cat-badge">(.*?)</span>', s, re.S)
if not m: sys.exit('mind map: no Dashboard Summary section found')
cat, dcat, badge = m.groups()
anchor = None
for t in ('Glossary', 'References', 'Source Document (Verbatim)'):
    k = re.search(r'\n[ \t]*(<!--(?:(?!-->).)*-->\s*)*<div class="section [\w-]+" data-title="' + re.escape(t) + '"', s, re.S)
    if k: anchor = k.start() + 1; break
if anchor is None: anchor = s.index('</main>')
nums = [int(x) for x in re.findall(r'<span class="sec-num">(\d+)</span>', s[:anchor])]
n = (max(nums) + 1) if nums else 2
w = len(re.search(r'<span class="sec-num">(\d+)</span>', s).group(1)) if nums else 2
after = s[anchor:]
ctr = iter(range(n + 1, n + 1000))   # sections after the map: numbered consecutively (fixes the template's 97/98/99 placeholders too)
after = re.sub(r'<span class="sec-num">(\d+)</span>', lambda x: '<span class="sec-num">%0*d</span>' % (w, next(ctr)), after)
section = ('  <div class="section %s" data-title="Mind Map" data-cat="%s">\n'
           '    <div class="sec-head"><span class="sec-num">%0*d</span><span class="sec-title">Mind Map</span><span class="cat-badge">%s</span><span class="chevron">▶</span></div>\n'
           '    <div class="sec-body">\n      %s\n    </div>\n  </div>\n\n') % (cat, dcat, w, n, badge, bodyb)
s = s[:anchor] + section + after
# --- summary row (number filled at runtime from the section itself)
row = ('<tr><td><span class="secnum" data-target-title="Mind Map"></span></td><td><strong>Mind Map</strong></td><td class="sec-cat"></td>'
       '<td>Clickable map of every section, table row, list item, and callout</td><td>Seeing the whole page at a glance, or jumping straight to a detail</td></tr>')
g = s.find('<tr><td><span class="secnum" data-target-title="Glossary">')
if g < 0:
    t = s.find('data-desc="What each section covers"'); g = s.find('</tbody>', t) if t >= 0 else -1
if g < 0: sys.exit('mind map: no "What each section covers" table found')
s = s[:g] + row + '\n            ' + s[g:]
# --- CSS, script, search + glossary exclusions
i = s.index('</style>'); s = s[:i] + cssb + s[i:]
i = s.rfind('</body>'); i = i if i >= 0 else len(s); s = s[:i] + jsb + s[i:]
old = "node.tagName!=='SCRIPT' && node.tagName!=='STYLE'"
if old in s and "toLowerCase()!=='svg'" not in s: s = s.replace(old, old + " && node.tagName.toLowerCase()!=='svg'", 1)
# add 'Mind Map' to the Glossary's EXCLUDE set whatever it already holds (search_patch.py adds 'Search' first)
s = re.sub(r"const EXCLUDE = new Set\(\[((?:(?!\]\)).)*?)\]\);",
           lambda x: x.group(0) if "'Mind Map'" in x.group(1) else "const EXCLUDE = new Set([" + x.group(1) + ",'Mind Map']);", s, count=1)
open(p, 'w', encoding='utf-8').write(s)
print('mind map: added as section %0*d' % (w, n))
```

After the patch, check in a browser: the map opens fitted, every section appears as a branch with the right `[NN]`, a few bubbles jump to the right place, and the console shows no errors or warnings.

## Search scroll logic (reference)

If a dashboard's script is ever rebuilt or merged, the `hitTarget` / `focusMatch` reference code is in `references/search-scroll.md`.