# Audio refresh scheduled task

One run-on-demand scheduled task serves every dashboard's owner-only ↻ button.
Create it only if `list_triggers` shows no task with this name.

- **Name:** `Vibe dashboard — refresh audio overview`
- **Schedule:** none (omit `cron_expression` and `run_once_at`)
- **initiation:** `human_request` · **notifications:** `{push: true}`
- **Prompt:** (verbatim)

```
Refresh the audio overview on one of Swami's vibe dashboards.

The firing's extra message gives the dashboard's claude.ai artifact URL (a line "ARTIFACT_URL: https://claude.ai/artifact/..."). If there is no such URL, or it is not a claude.ai artifact link, stop and do nothing.

Steps:
1. Load the vibe-dashboard skill (Skill tool) and follow its "Audio overview" section, sub-sections "Writing the narration", "Pronunciation" (including "Noun/verb stress"), and "Refreshing an existing dashboard". SKILL_DIR below means that skill's folder (the one holding scripts/, normally /mnt/skills/plugins/vibe-dashboard). The skill's Pronunciation table is the authority for how words are spelled in the narration.
2. Save the stress_audio.py helper exactly as printed in the skill's "Noun/verb stress" bullet (the python block that starts with "#!/usr/bin/env python3" and the docstring "stress_audio.py — run the vibe-dashboard audio_overview.py …") to /home/claude/stress_audio.py, verbatim. Do not save it inside the skill folder.
3. Read the artifact with the Artifact tool (action "read" with the URL, then action "read" with path "index.html" to get the full page as a local file). Only proceed if the read says Swami can edit it ("writer").
4. Run `python3 SKILL_DIR/scripts/audio_overview.py extract <page.html>` to get the page's current text outline, and write a fresh narration (single speaker, ~2–3 minutes, plain spoken English) to /home/claude/narration.txt describing the dashboard as it now stands. Introduce every section by its number, then its header ("Section five, The Timeline Debate. …").
   ACRONYM RULE (required): write letter-by-letter acronyms solid in capitals with NO spaces and NO dots — AI, CNC, US, PLC, STL. The voice spells these correctly ("AI" = "ay eye", long A as in "ate", meaning artificial intelligence). NEVER separate letters with spaces ("A I", "C N C"): a lone "A" is read as "uh". NEVER use dots ("P.L.A.", "P.E.T.G.", "C.A.M."): dots make the voice pause between letters.
   REQUIRED SPELLINGS (from the skill's Pronunciation table): PLA → "pee-ell-eh" (pee el ay, long A, no pauses); PETG → "pee-ee-tee-gee" (long E, G said "gee", no pauses); fillet → "fillette" (plural "fillettes"); CAD → "cad" (rhymes with "fad"); 3D CAD → "three D cad"; CAM → "cam" (rhymes with "ram"); live (adjective) → "lyve"; callout → "call-out" (plural "call-outs"). For any other acronym the voice would otherwise say as a word, write a hyphenated respelling of its letter names (like "pee-ell-eh"), never dots or spaces. To check a spelling, phonemize it inside a short phrase from the narration with the Kokoro tokenizer (kokoro_onnx Kokoro(...).tokenizer.phonemize(text, 'en-us'), model files in ~/.cache/vibe-audio) and make sure every syllable comes out as intended, with no pause between letters.
5. NOUN/VERB STRESS AUDIT (required): run `python3 /home/claude/stress_audio.py SKILL_DIR audit /home/claude/narration.txt`. For every word it lists, decide from its sentence whether it is a verb (stress on the 2nd syllable, e.g. "Fathom re-CORDS sessions") or a noun/adjective (stress on the 1st syllable, e.g. "the REC-ords", "REE-search"). Wherever the voice stresses the wrong syllable, mark that word in narration.txt with exact phonemes, `[word](/phonemes/)` — e.g. `[records](/ɹᵻkˈɔːɹdz/)` (verb), `[research](/ɹˈiːsɜːtʃ/)` (noun) — taking the phonemes the audit printed and moving only the stress mark ˈ and the vowels it changes. Re-run the audit until every listed word is right.
6. Run `python3 /home/claude/stress_audio.py SKILL_DIR build <page.html> /home/claude/narration.txt <out.html>` — it runs the skill's audio_overview.py build with the markup applied, regenerates the MP3 with the female Kokoro voice and replaces the existing player audio, keeping the owner-only refresh button settings already embedded in the page. If the build fails, follow the skill's "When the recording can't be made" steps only as far as reporting the one-line cause in the final line; do not publish a page without audio.
7. Publish <out.html> back to the SAME artifact with the Artifact tool, passing `url` = the artifact URL and NO `capabilities` field (so the page keeps its declared capabilities). Label the publish "Audio overview refresh".
8. Finish with one line: the new audio length, how many words the stress audit marked, and the time of the refresh. Do not change anything else on the page.
```

The page fires it with `fire_trigger({trigger_id, text: "ARTIFACT_URL: <url>"})`, so the URL
always comes from the page's own `data-artifact` attribute.
