"""search_patch.py PAGE.html — add (or refresh) the vibe-dashboard Search section. Idempotent.

First run: inserts a "Search" section as section 02 (right after the Dashboard Summary) in its own category
colour, renumbers every section after it, adds its row to the section 01 summary table, adds the CSS and
script, the generic-subsection patch ([SEARCH] / [FILTERS] parts), keeps the toolbar quick search out of the
results, and keeps the Glossary from linking or counting terms inside it.
Later runs replace the CSS, the section body and the script with this version, leaving numbering alone.

What it searches (built in the browser at load, from the page itself, so it always matches what is shown):
every content section's list items, paragraphs, callouts, cards and table rows, every glossary term and
reference, and the Source Document (Verbatim) text split into passages. Section 01, the Search section and
the Mind Map are skipped; owner-only and hidden items are left out for other viewers.
Index dashboards that also search the text of linked dashboards (search-index.json) extend this with the
reference implementation in swami-claude-skills/vibe-dashboards ai-in-fusion-chats/search.js.
"""
import sys, re, colorsys

p = sys.argv[1]
s = open(p, encoding='utf-8').read()

CSS = r'''  .xs{display:flex;flex-direction:column;gap:12px;margin:6px 0 4px}
  .xs > .citem{margin:0}
  .xs .citem-body > .subsec{padding-top:12px;display:flex;flex-direction:column;gap:12px}
  .xs-bar{display:flex;gap:8px}
  #xsq{flex:1;min-width:0;background:var(--panel-2);border:1px solid var(--border);color:var(--text);font-family:var(--mono);font-size:14px;padding:11px 14px;border-radius:8px;outline:none}
  #xsq:focus{border-color:var(--cat-search);box-shadow:0 0 0 2px color-mix(in srgb,var(--cat-search) 18%,transparent)}
  .xs-filters{display:flex;flex-direction:column;gap:8px}
  .xs-row{display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px}
  .xs-lab{font-family:var(--mono);font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--text-mute);min-width:64px}
  .xs-chips{display:flex;flex-wrap:wrap;gap:6px;min-width:0}
  .xs-chip{font-family:var(--mono);font-size:11px;background:var(--panel-2);border:1px solid var(--border);color:var(--text-dim);padding:4px 9px;border-radius:20px;cursor:pointer}
  .xs-chip:hover{border-color:var(--cyan);color:var(--cyan)}
  .xs-chip.on{border-color:var(--cyan);color:var(--bg);background:var(--cyan)}
  .xs-chip .xs-n{opacity:.75}
  .xs-kind{--tc:#38dafa;color:var(--tc);border-color:color-mix(in srgb,var(--tc) 40%,transparent)}
  .xs-kind:hover{color:var(--tc);border-color:var(--tc)}
  .xs-kind.on{background:var(--tc);color:#0d0d0f;border-color:var(--tc)}
  #xssec{background:var(--panel-2);border:1px solid var(--border);color:var(--text);font-family:var(--mono);font-size:12px;padding:5px 8px;border-radius:6px;color-scheme:dark;max-width:100%}
  .xs-status{font-family:var(--mono);font-size:11.5px;color:var(--text-mute)}
  .xs-status b{color:var(--text)}
  .xs-res{display:flex;flex-direction:column;gap:14px}
  .xs-gh{font-family:var(--mono);font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--cat-search);margin:0 0 6px}
  .xs-gh span{color:var(--text-mute);letter-spacing:.04em}
  .xs-group{display:flex;flex-direction:column;gap:8px}
  .xs-item{background:var(--panel-2);border:1px solid var(--border);border-radius:8px;padding:10px 12px;min-width:0}
  .xs-top{display:flex;flex-wrap:wrap;align-items:baseline;gap:4px 10px}
  .xs-go{background:none;border:0;padding:0;font:inherit;font-size:14.5px;font-weight:700;color:var(--text);cursor:pointer;text-align:left}
  .xs-go:hover{color:var(--cyan);text-decoration:underline}
  .xs .xs-tag{display:inline-block;font-family:var(--mono);font-size:10px;letter-spacing:.08em;text-transform:uppercase;border:1px solid;border-radius:20px;padding:0 7px;color:var(--tc);border-color:color-mix(in srgb,var(--tc) 45%,transparent);background:color-mix(in srgb,var(--tc) 9%,transparent)}
  .xs-type{font-family:var(--mono);font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--text-mute)}
  .xs-snip{font-size:13.5px;color:var(--text-dim);margin-top:5px;line-height:1.5;overflow-wrap:anywhere}
  .xs-hit{color:#0d0d0f;background:var(--cat-search);border-radius:2px;padding:0 1px;font-weight:600}
  .xs-meta{display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin-top:7px;font-family:var(--mono);font-size:11.5px}
  .xs-sec{background:none;border:0;padding:0;font:inherit;color:var(--cyan);cursor:pointer}
  .xs-sec:hover{text-decoration:underline}
  .xs-more{align-self:flex-start;background:none;border:1px dashed var(--border);color:var(--text-dim);font-family:var(--mono);font-size:11.5px;padding:5px 10px;border-radius:6px;cursor:pointer}
  .xs-more:hover{border-color:var(--cyan);color:var(--cyan)}
  .xs-tips{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
  .xs-tips .xs-gh{width:100%}
  .xs-try{font-family:var(--mono);font-size:12px;background:var(--panel-2);border:1px solid var(--border);color:var(--text);padding:4px 10px;border-radius:6px;cursor:pointer}
  .xs-try:hover{border-color:var(--cat-search);color:var(--cat-search)}
  .xs-tipline{width:100%;font-size:13px;color:var(--text-dim);margin-top:6px}
  .xs-empty{font-size:13.5px;color:var(--text-dim)}
  .xs code{font-family:var(--mono);font-size:12.5px;color:var(--text);background:var(--panel-2);border:1px solid var(--border);border-radius:4px;padding:0 5px}
  .xs-chunk.xs-flash{animation:gflash 1.8s ease-out}
  #xsq{color:var(--green);caret-color:var(--green)}
  #xsq::placeholder{color:var(--green);opacity:.75}
  .xs-bar{position:sticky;top:calc(var(--stack-h,0px) + var(--sechead-h,0px) + var(--xs-ihead,42px));z-index:14;background:var(--panel);padding:8px 0;margin:-8px 0}
  .xs-gtog{display:flex;align-items:center;gap:8px;width:100%;background:var(--panel-2);border:1px solid var(--border);border-radius:8px;padding:8px 12px;cursor:pointer;text-align:left;font:inherit;font-family:var(--mono);font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--cat-search);margin:0}
  .xs-gtog:hover{border-color:var(--cat-search)}
  .xs-gtog:focus-visible{outline:2px solid var(--cyan);outline-offset:2px}
  .xs-gchev{font-size:9px;color:var(--text-mute);transition:transform .15s}
  .xs-group.open .xs-gchev{transform:rotate(90deg);color:var(--cat-search)}
  .xs-gbody{display:none;flex-direction:column;gap:8px}
  .xs-group.open .xs-gbody{display:flex}
  @media (max-width:600px){.xs-lab{min-width:0;width:100%}}'''

BODY = r'''      <p>Find anything on this page: every note, table row, glossary term, and reference, plus the full source document when the page has one. Type a few words and click a result to jump straight to it.</p>
      <div id="xs" class="xs">
        <div class="subsec" data-tag="search" data-desc="Search box and results">
          <div class="xs-bar"><input id="xsq" type="search" placeholder="type words to find on this page…" autocomplete="off" aria-label="Find on this page"><button type="button" id="xsclear" class="tool-btn">clear</button><button type="button" id="xsexp" class="tool-btn" title="Open every result group">expand all</button><button type="button" id="xscol" class="tool-btn" title="Close every result group">collapse all</button></div>
          <div id="xsstatus" class="xs-status"></div>
          <div id="xsres" class="xs-res" aria-live="polite"></div>
        </div>
        <div class="subsec" data-tag="filters" data-desc="Narrow by type, category, and section">
          <div class="xs-filters">
            <div class="xs-row"><span class="xs-lab">Show</span><div id="xstypes" class="xs-chips"></div></div>
            <div class="xs-row"><span class="xs-lab">Category</span><div id="xscats" class="xs-chips"></div></div>
            <div class="xs-row"><span class="xs-lab">Section</span><select id="xssec" aria-label="Section"></select></div>
          </div>
          <div class="xs-tipline">Filters work with or without words in the box. With an empty box, they list everything that matches.</div>
        </div>
        <div class="table-wrap no-sort" data-desc="How to write a query">
          <table>
            <thead><tr><th>To do this</th><th>Type</th><th>Example</th></tr></thead>
            <tbody>
              <tr><td><strong>Match several words</strong></td><td>Words in any order</td><td><code data-xs-ex="words">two words</code> finds items with both</td></tr>
              <tr><td><strong>Match the start of a word</strong></td><td>The first few letters</td><td><code data-xs-ex="prefix">param</code> finds <span data-xs-ex="prefixfull">parameter</span></td></tr>
              <tr><td><strong>Forgive a typo</strong></td><td>Nothing extra; used only when nothing matches as typed</td><td><code data-xs-ex="typo">filet</code> finds <span data-xs-ex="typofull">fillet</span></td></tr>
              <tr><td><strong>Match an exact phrase</strong></td><td>Words in "quotes"</td><td><code data-xs-ex="phrase">"exact phrase"</code></td></tr>
              <tr><td><strong>Leave a word out</strong></td><td>A minus sign before it</td><td><code data-xs-ex="neg">word -other</code></td></tr>
              <tr><td><strong>Open the best match</strong></td><td>Enter</td><td>Jumps to the top result</td></tr>
            </tbody>
          </table>
        </div>
        <div class="callout"><span class="lbl">What it covers</span>Every content section's list items, paragraphs, callouts, cards and table rows, every term in the glossary and every reference, and the full source document split into passages. The summary index and the mind map are left out. It is read from the page when it opens, so it always matches what you see.</div>
      </div>'''

JS = r'''/* ===== Search section (vibe-dashboard search_patch.py): finds anything on this page.
   Built at load from the page itself. Words in any order, start-of-word matches, small typos forgiven
   only when nothing matches as typed, "phrases", -exclusions; filters by type, category and section. ===== */
(() => {
const XS = document.getElementById('xs'); if(!XS || typeof sections === 'undefined') return;
const $ = id => document.getElementById(id);
const input = $('xsq'), res = $('xsres'), status = $('xsstatus');
const esc = t => String(t).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const norm = s => String(s).toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g,'').replace(/[‘’]/g,"'");
const toks = s => norm(s).match(/[a-z0-9]+/g) || [];
const tx = n => (n ? n.textContent : '').replace(/\s+/g, ' ').trim();
const clean = n => { if(!n) return ''; const c = n.cloneNode(true);
  c.querySelectorAll('.sort-ind,.col-resizer,.owner-tag,.cat-pill,.gj-tip').forEach(x => x.remove());
  return tx(c).replace(/\s*\[\d{2,3}\]/g, ''); };
const hiddenEl = el => !!(el && el.closest('[hidden],.owner-only,.own-col'));
const css = getComputedStyle(document.documentElement);
const SKIP = new Set(['Dashboard Summary', 'Search', 'Mind Map']);
const TYPES = [['note','Notes'], ['row','Table rows'], ['term','Glossary terms'], ['ref','References'], ['source','Source document']];

/* ---------------- documents ---------------- */
const docs = [], CATS = new Map();
sections.forEach((sec, si) => {
  const title = sec.dataset.title;
  if(SKIP.has(title) || sec.contains(XS)) return;
  const body = sec.querySelector('.sec-body'); if(!body) return;
  const cat = {name: sec.dataset.cat || '', label: tx(sec.querySelector('.cat-badge')),
               color: css.getPropertyValue('--cat-' + sec.dataset.cat).trim() || '#38dafa'};
  if(cat.name && !CATS.has(cat.name)) CATS.set(cat.name, cat);
  const base = {sec: title, si, secNum: tx(sec.querySelector('.sec-num')), cat};
  const pre = body.classList.contains('verbatim-body') ? body.querySelector('pre') : null;
  if(pre){                                     // split the source into passages you can jump to
    const text = pre.textContent; if(!text.trim()) return;
    const parts = text.split(/(\n\s*\n)/); const chunks = []; let cur = '';
    parts.forEach(pt => { cur += pt; if(cur.length > 700 && /\n\s*\n$/.test(pt)) { chunks.push(cur); cur = ''; } });
    if(cur) chunks.push(cur);
    pre.textContent = '';
    chunks.forEach((c, i) => { const sp = document.createElement('span'); sp.className = 'xs-chunk'; sp.textContent = c; pre.appendChild(sp);
      const first = c.trim().split('\n')[0].trim();
      docs.push(Object.assign({type:'source', title: first.length > 70 ? first.slice(0, 69) + '…' : (first || 'Passage ' + (i + 1)), body: c.replace(/\s+/g, ' ').trim(), el: sp}, base)); });
    return;
  }
  const t = title === 'Glossary' ? 'term' : title === 'References' ? 'ref' : 'row';
  body.querySelectorAll('tbody tr').forEach(tr => {
    if(hiddenEl(tr)) return;
    const wrap = tr.closest('.table-wrap');
    const vals = [...tr.cells].filter(c => !c.classList.contains('own-col') && !c.matches('.gloss-uses,.gloss-count')).map(clean).filter(Boolean);
    if(!vals.length) return;
    docs.push(Object.assign({type:t, title:vals[0], body:vals.slice(1).join(' · '), el:tr, desc: wrap ? (wrap.dataset.desc || '') : ''}, base));
  });
  if(t !== 'row') return;
  body.querySelectorAll('.callout, .resource, li, p').forEach(el => {
    if(hiddenEl(el) || el.closest('table')) return;
    if(el.tagName === 'LI' && el.closest('.callout,.resource')) return;
    if(el.tagName === 'P' && el.closest('.callout,.resource,li')) return;
    let ttl = '', bod = '', kind = 'Note';
    if(el.classList.contains('callout')){ ttl = clean(el.querySelector('.lbl')); bod = clean(el); if(bod.startsWith(ttl)) bod = bod.slice(ttl.length).trim(); kind = 'Callout'; }
    else if(el.classList.contains('resource')){ ttl = clean(el.querySelector('.r-name')); bod = clean(el.querySelector('.r-note')); kind = 'Card'; }
    else if(el.tagName === 'LI'){ const tid = el.querySelector('.tid'); ttl = tid ? clean(tid) : ''; bod = clean(el); if(ttl && bod.startsWith(ttl)) bod = bod.slice(ttl.length).trim(); kind = 'List item'; }
    else { bod = clean(el); kind = 'Paragraph'; }
    if(!bod && !ttl) return;
    docs.push(Object.assign({type:'note', title: ttl || title, body: bod, el, kind}, base));
  });
});

/* ---------------- index ---------------- */
const POST = new Map();
docs.forEach((d, i) => {
  d.tt = new Set(toks(d.title)); d.bt = new Set(toks(d.body)); d.nt = norm(d.title + ' ' + d.body);
  for(const t of d.tt) (POST.get(t) || POST.set(t, new Set()).get(t)).add(i);
  for(const t of d.bt) (POST.get(t) || POST.set(t, new Set()).get(t)).add(i);
});
const VOCAB = [...POST.keys()];
function within(a, b, max){
  if(Math.abs(a.length - b.length) > max) return false;
  let pp = null, prev = Array.from({length:b.length + 1}, (_, j) => j);      // edits incl. swapped neighbours (gyriod -> gyroid)
  for(let i = 1; i <= a.length; i++){
    const cur = [i]; let best = i;
    for(let j = 1; j <= b.length; j++){
      cur[j] = Math.min(prev[j] + 1, cur[j-1] + 1, prev[j-1] + (a[i-1] === b[j-1] ? 0 : 1));
      if(pp && i > 1 && j > 1 && a[i-1] === b[j-2] && a[i-2] === b[j-1]) cur[j] = Math.min(cur[j], pp[j-2] + 1);
      if(cur[j] < best) best = cur[j];
    }
    if(best > max) return false;
    pp = prev; prev = cur;
  }
  return prev[b.length] <= max;
}
const ALIAS = {f360:'fusion', fusion360:'fusion'};
function expand(w){
  w = ALIAS[w] || w;
  const out = new Map();
  const fz = w.length >= 8 ? 2 : (w.length >= 4 ? 1 : 0);
  const st = w.length > 4 ? w.replace(/ies$/, 'y').replace(/(es|s|ing|ed)$/, '') : w;
  for(const t of VOCAB){
    if(t === w) out.set(t, 3);
    else if(w.length >= 2 && t.startsWith(w)) out.set(t, 2);
    else if(st !== w && st.length >= 3 && t.startsWith(st)) out.set(t, 2);
  }
  if(out.size || !fz || !/^[a-z]+$/.test(w)) return out;
  const near = VOCAB.filter(t => t.length >= 4 && t[0] === w[0] && within(w, t, fz));
  const isSub = t => { let j = 0; for(const ch of t) if(ch === w[j]) j++; return j === w.length; };
  const best = near.filter(isSub);
  (best.length ? best : near).forEach(t => out.set(t, 1));
  out.fuzzy = true;
  return out;
}
function parse(qs){
  const phrases = [], neg = [], pos = [];
  qs = qs.replace(/"([^"]+)"/g, (m, ph) => { const n = norm(ph).trim(); if(n) phrases.push(n); return ' '; });
  qs.split(/\s+/).forEach(w => { if(!w) return;
    if(w[0] === '-' && w.length > 1) toks(w.slice(1)).forEach(t => neg.push(t)); else toks(w).forEach(t => pos.push(t)); });
  return {phrases, neg, pos:[...new Set(pos)]};
}

/* ---------------- filters ---------------- */
const F = {types:new Set(), cats:new Set(), sec:''};
const typeBox = $('xstypes'), catBox = $('xscats'), secSel = $('xssec');
const present = TYPES.filter(([k]) => docs.some(d => d.type === k));
typeBox.innerHTML = present.map(([k, n]) => '<button type="button" class="xs-chip" data-t="' + k + '">' + n + ' <span class="xs-n"></span></button>').join('');
catBox.innerHTML = [...CATS.values()].map(c => '<button type="button" class="xs-chip xs-kind" data-c="' + esc(c.name) + '" style="--tc:' + esc(c.color) + '">' + esc(c.label || c.name) + '</button>').join('');
const secs = [...new Map(docs.map(d => [d.sec, d.secNum])).entries()];
secSel.innerHTML = '<option value="">All sections</option>' + secs.map(([t, n]) => '<option value="' + esc(t) + '">' + esc(n + ' ' + t) + '</option>').join('');
const toggle = (set, v) => set.has(v) ? set.delete(v) : set.add(v);
typeBox.addEventListener('click', e => { const b = e.target.closest('[data-t]'); if(!b) return; toggle(F.types, b.dataset.t); b.classList.toggle('on'); run(); });
catBox.addEventListener('click', e => { const b = e.target.closest('[data-c]'); if(!b) return; toggle(F.cats, b.dataset.c); b.classList.toggle('on'); run(); });
secSel.addEventListener('change', () => { F.sec = secSel.value; run(); });
$('xsclear').addEventListener('click', () => { input.value = ''; F.types.clear(); F.cats.clear(); F.sec = ''; secSel.value = '';
  XS.querySelectorAll('.xs-chip.on').forEach(b => b.classList.remove('on')); run(); input.focus(); });
const passFilters = d => (!F.types.size || F.types.has(d.type)) && (!F.cats.size || F.cats.has(d.cat.name)) && (!F.sec || d.sec === F.sec);
const visible = d => !(d.el && d.el.closest('[hidden]'));
const filtersOn = () => F.types.size || F.cats.size || F.sec;

/* ---------------- search ---------------- */
const reEsc = w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function search(qs){
  const {phrases, neg, pos} = parse(qs);
  const exp = pos.map(expand);
  let ids = null;
  exp.forEach(m => { const st = new Set(); for(const t of m.keys()) (POST.get(t) || []).forEach(i => st.add(i));
    ids = ids ? new Set([...ids].filter(i => st.has(i))) : st; });
  if(!ids) ids = new Set(docs.map((_, i) => i));
  const negSet = new Set(); neg.forEach(w => VOCAB.forEach(t => { if(t.startsWith(w)) (POST.get(t) || []).forEach(i => negSet.add(i)); }));
  const hits = [];
  ids.forEach(i => {
    if(negSet.has(i)) return;
    const d = docs[i];
    if(phrases.some(ph => !d.nt.includes(ph))) return;
    if(!visible(d) || !passFilters(d)) return;
    let sc = 0;
    exp.forEach(m => { let b = 0; m.forEach((w, t) => { if(d.tt.has(t)) b = Math.max(b, w * 2.2); else if(d.bt.has(t)) b = Math.max(b, w); }); sc += b; });
    sc += phrases.length * 4 + (d.type === 'term' ? 1 : 0) - (d.type === 'source' ? 0.5 : 0);
    hits.push({d, sc, i});
  });
  hits.sort((a, b) => b.sc - a.sc || a.i - b.i);
  const words = [...new Set([].concat(...exp.map(m => [...m.keys()])))].sort((a, b) => b.length - a.length).slice(0, 60);
  const alts = words.map(reEsc).concat(phrases.map(ph => reEsc(ph).replace(/\s+/g, '\\s+')));
  const fuzzy = [].concat(...exp.filter(m => m.fuzzy).map(m => [...m.keys()])).slice(0, 8);
  return {fuzzy, hits, re: alts.length ? new RegExp('(' + alts.join('|') + ')', 'gi') : null};
}
function hl(t, re){
  if(!re) return esc(t);
  let out = '', i = 0;
  for(const m of t.matchAll(re)){ out += esc(t.slice(i, m.index)) + '<b class="xs-hit">' + esc(m[0]) + '</b>'; i = m.index + m[0].length; }
  return out + esc(t.slice(i));
}
function snip(t, re, len){
  len = len || 240; t = t || '';
  if(t.length <= len) return hl(t, re);
  let at = 0;
  if(re){ re.lastIndex = 0; const m = re.exec(t); if(m) at = Math.max(0, m.index - 90); re.lastIndex = 0; }
  if(at){ const sp = t.indexOf(' ', at); at = sp > 0 && sp < at + 20 ? sp + 1 : at; }
  return (at ? '… ' : '') + hl(t.slice(at, at + len), re) + (at + len < t.length ? ' …' : '');
}

/* ---------------- render ---------------- */
const LIMIT = 6, open = {};
let shown = [], last = {hits:[], re:null};
const label = d => d.type === 'row' ? (d.desc || 'Table row') : d.type === 'term' ? 'Term' : d.type === 'ref' ? 'Reference' : d.type === 'source' ? 'Passage' : d.kind;
function itemHTML(h, k, re){
  const d = h.d;
  return '<div class="xs-item"><div class="xs-top"><span class="xs-type">' + esc(label(d)) + '</span>'
    + '<button type="button" class="xs-go" data-k="' + k + '">' + hl(d.title, re) + '</button></div>'
    + (d.body ? '<div class="xs-snip">' + snip(d.body, re) + '</div>' : '')
    + '<div class="xs-meta"><button type="button" class="xs-sec" data-si="' + d.si + '">' + esc(d.sec) + ' [' + esc(d.secNum) + ']</button>'
    + '<span class="xs-tag" style="--tc:' + esc(d.cat.color) + '">' + esc(d.cat.label || d.cat.name) + '</span></div></div>';
}
const expanded = {};   // result groups the viewer opened (all start collapsed)
function render(hits, re, counts){
  shown = hits;
  const groups = {}; TYPES.forEach(([k]) => groups[k] = []);
  hits.forEach((h, i) => groups[h.d.type].push([h, i]));
  typeBox.querySelectorAll('[data-t]').forEach(b => { b.querySelector('.xs-n').textContent = counts ? (groups[b.dataset.t].length || '') : ''; });
  let html = '';
  TYPES.forEach(([k, name]) => {
    const g = groups[k]; if(!g.length) return;
    const lim = open[k] ? g.length : LIMIT;
    const ex = !!expanded[k];
    html += '<div class="xs-group' + (ex ? ' open' : '') + '"><button type="button" class="xs-gh xs-gtog" data-g="' + k + '" aria-expanded="' + ex + '"><span class="xs-gchev">▶</span>' + name + ' <span>' + g.length + '</span></button>'
      + '<div class="xs-gbody">' + g.slice(0, lim).map(([h, i]) => itemHTML(h, i, re)).join('')
      + (g.length > lim ? '<button type="button" class="xs-more" data-open="' + k + '">Show all ' + g.length + '</button>' : '') + '</div></div>';
  });
  res.innerHTML = html || '<div class="xs-empty">No matches. Try fewer words, a shorter word, or clear the filters.</div>';
}

/* example queries taken from this page: the glossary's most-used terms, else its most common words */
const EX = (() => {
  const terms = [...document.querySelectorAll('tr[data-gterm]')].filter(r => !hiddenEl(r))
    .map(r => ({w: clean(r.cells[0]).replace(/\s*\(.*?\)\s*/g, ' ').trim().toLowerCase(), n: parseInt(clean(r.querySelector('.gloss-count')), 10) || 0}))
    .filter(x => x.w && x.n).sort((a, b) => b.n - a.n).map(x => x.w);
  if(terms.length < 4){
    const STOP = new Set('the and for with that this from are was were you your have has not but can will into its they them then than when what where which who how all any each more most other some such only also just over very about after before there their these those been being would could should here every page section'.split(' '));
    const freq = new Map(); docs.forEach(d => d.bt.forEach(t => { if(t.length > 4 && !STOP.has(t) && !/^\d+$/.test(t)) freq.set(t, (freq.get(t) || 0) + 1); }));
    [...freq.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).forEach(([t]) => { if(!terms.includes(t)) terms.push(t); });
  }
  const single = terms.map(t => t.split(/\s+/)).flat().filter(w => /^[a-z]{6,}$/.test(w) && POST.has(w));
  const long = single[0] || 'parameter', typoOf = single.find(w => w.length >= 6) || long;
  const typo = typoOf.slice(0, 2) + typoOf.slice(3);            // drop the third letter
  const multi = terms.find(t => / /.test(t)) || terms[0] || 'exact phrase';
  return {terms: terms.slice(0, 5), prefix: long.slice(0, Math.max(4, Math.ceil(long.length / 2))), prefixfull: long, typo, typofull: typoOf,
    words: terms.length > 1 ? terms[0].split(' ')[0] + ' ' + terms[1].split(' ')[0] : long, phrase: '"' + multi + '"',
    neg: (terms[0] || long).split(' ')[0] + ' -' + ((terms[1] || 'other').split(' ')[0])};
})();
XS.querySelectorAll('[data-xs-ex]').forEach(el => { const v = EX[el.dataset.xsEx]; if(v) el.textContent = v; });
function tips(){
  res.innerHTML = '<div class="xs-tips"><div class="xs-gh">Try</div>'
    + EX.terms.concat([EX.phrase]).filter((v, i, a) => v && a.indexOf(v) === i)
      .map(t => '<button type="button" class="xs-try">' + esc(t) + '</button>').join('')
    + '<div class="xs-tipline">Words match in any order and by the start of a word. Small typos are forgiven. Use "quotes" for an exact phrase and -word to leave a word out. Or pick a filter with an empty box to browse.</div></div>';
  typeBox.querySelectorAll('.xs-n').forEach(n => n.textContent = '');
}
function run(){
  const qs = input.value.trim();
  Object.keys(open).forEach(k => delete open[k]);
  Object.keys(expanded).forEach(k => delete expanded[k]);
  if(!qs){
    if(!filtersOn()) return tips();
    const hits = docs.map((d, i) => ({d, sc:0, i})).filter(h => visible(h.d) && passFilters(h.d));
    last = {hits, re:null}; return render(hits, null, true);
  }
  last = search(qs); render(last.hits, last.re, true);
  if(last.fuzzy && last.fuzzy.length) res.insertAdjacentHTML('afterbegin', '<div class="xs-tipline">No exact match for some words, so similar spellings are included: <b>' + last.fuzzy.map(esc).join(', ') + '</b></div>');
}
let tmr = 0;
input.addEventListener('input', () => { clearTimeout(tmr); tmr = setTimeout(run, 140); });
input.addEventListener('keydown', e => {
  if(e.key === 'Enter'){ e.preventDefault(); const b = res.querySelector('.xs-go'); if(b) b.click(); }
  if(e.key === 'Escape'){ input.value = ''; run(); }
});
res.addEventListener('click', e => {
  const go = e.target.closest('.xs-go');
  if(go){ const h = shown[+go.dataset.k]; if(h && h.d.el){ jumpToEl(h.d.el);
    if(h.d.type === 'source'){ h.d.el.classList.remove('xs-flash'); void h.d.el.offsetWidth; h.d.el.classList.add('xs-flash'); } } return; }
  const sb = e.target.closest('.xs-sec'); if(sb){ scrollToSection(+sb.dataset.si); return; }
  const gt = e.target.closest('.xs-gtog'); if(gt){ const k = gt.dataset.g; expanded[k] = !expanded[k];
    const grp = gt.parentElement; grp.classList.toggle('open', !!expanded[k]); gt.setAttribute('aria-expanded', !!expanded[k]); return; }
  const m = e.target.closest('.xs-more'); if(m){ open[m.dataset.open] = 1; render(last.hits, last.re, true); return; }
  const t = e.target.closest('.xs-try'); if(t){ input.value = t.textContent; run(); input.focus(); }
});
const setAllGroups = v => res.querySelectorAll('.xs-gtog').forEach(gt => { const k = gt.dataset.g;
  if(v) expanded[k] = true; else delete expanded[k];
  gt.parentElement.classList.toggle('open', v); gt.setAttribute('aria-expanded', v); });
document.getElementById('xsexp').addEventListener('click', () => setAllGroups(true));
document.getElementById('xscol').addEventListener('click', () => {
  setAllGroups(false);
  /* bring the search box back into view: its [SEARCH] item lands just under the pinned headers */
  const item = input.closest('.citem'); if(!item) return;
  const cs = getComputedStyle(document.documentElement);
  const off = (parseFloat(cs.getPropertyValue('--stack-h')) || 0) + (parseFloat(cs.getPropertyValue('--sechead-h')) || 0);
  const y = item.getBoundingClientRect().top + scrollY - off;
  if(scrollY > y + 1) window.scrollTo({top: Math.max(0, y), behavior: 'smooth'});
  input.focus({preventScroll: true});
});
/* the sticky search row pins just below its [SEARCH] item header: track that header's height */
(() => {
  const bar = document.querySelector('.xs-bar'), head = bar && bar.closest('.citem') && bar.closest('.citem').querySelector('.citem-head');
  if(!head) return;
  const set = () => { const h = head.getBoundingClientRect().height; if(h) bar.style.setProperty('--xs-ihead', h + 'px'); };
  set(); if(window.ResizeObserver) new ResizeObserver(set).observe(head);
})();
const nSrc = docs.filter(d => d.type === 'source').length;
status.innerHTML = 'Searching <b>' + (docs.length - nSrc).toLocaleString() + '</b> items on this page'
  + (nSrc ? ' · plus <b>' + nSrc + '</b> passage' + (nSrc === 1 ? '' : 's') + ' of the source document' : '');
tips();
})();'''

def block(text, a, b, new):
    i, j = text.find(a), text.find(b)
    return text[:i] + new + text[j + len(b):] if i >= 0 and j > i else None
cssb = '  /* SEARCH-CSS:BEGIN */\n' + CSS + '\n  /* SEARCH-CSS:END */\n'
jsb = '<!-- SEARCH-JS:BEGIN -->\n<script>\n' + JS + '\n</script>\n<!-- SEARCH-JS:END -->\n'
bodyb = '<!-- SEARCH-BODY:BEGIN -->\n' + BODY + '\n      <!-- SEARCH-BODY:END -->'

if 'SEARCH-BODY:BEGIN' in s:
    for a, b, new in (('  /* SEARCH-CSS:BEGIN */', '  /* SEARCH-CSS:END */\n', cssb),
                      ('<!-- SEARCH-JS:BEGIN -->', '<!-- SEARCH-JS:END -->\n', jsb),
                      ('<!-- SEARCH-BODY:BEGIN -->', '<!-- SEARCH-BODY:END -->', bodyb)):
        r = block(s, a, b, new)
        if r is None: sys.exit('search: marker missing — ' + a)
        s = r
    open(p, 'w', encoding='utf-8').write(s); print('search: refreshed'); sys.exit()
if 'id="xs"' in s: sys.exit('search: page already has a hand-made Search section (an index dashboard?); leave it, or remove it first')

# --- its own category colour: next unused palette colour, else the hue farthest from every colour in use
PAL = ['#38dafa', '#38fa79', '#dafa38', '#fa9938', '#fa3899', '#ea38fa', '#7938fa', '#3879fa']
root = s[s.index(':root'):s.index('}', s.index(':root'))]
used = [v.lower() for v in re.findall(r'--cat-[\w-]+:\s*(#[0-9a-fA-F]{6})', root)]
hue = lambda h: colorsys.rgb_to_hls(*(int(h[i:i+2], 16) / 255 for i in (1, 3, 5)))[0] * 360
free = [c for c in PAL if c not in used]
def _rgb(h): return [int(h[i:i+2], 16) for i in (1, 3, 5)]
def _ok(c, need_h=30, need_rgb=90):      # the page's checkCategoryColours wants >=25 deg hue and >=90 RGB apart
    hc, rc = hue(c), _rgb(c)
    return min(min(abs(hc - hue(u)), 360 - abs(hc - hue(u))) for u in used) >= need_h and \
           min(sum((a - b) ** 2 for a, b in zip(rc, _rgb(u))) ** .5 for u in used) >= need_rgb
if free: col = free[0]
else:   # all 8 palette colours taken: the brightest-reading colour farthest (in RGB) from every colour in use
    best, bestd = None, -1
    for h in range(0, 360, 2):
        for l in (0.55, 0.6, 0.65, 0.7, 0.75):
            for sat in (0.95, 0.8, 0.65):
                r_, g_, b_ = colorsys.hls_to_rgb(h / 360, l, sat)
                c = '#%02x%02x%02x' % (round(r_ * 255), round(g_ * 255), round(b_ * 255))
                if not _ok(c): continue
                dmin = min(sum((a - b) ** 2 for a, b in zip(_rgb(c), _rgb(u))) ** .5 for u in used)
                if dmin > bestd: best, bestd = c, dmin
    col = best or '#79fa38'
    if not best: print('search: warning — no colour is clearly distinct from the', len(used), 'in use; pick one by hand')
rgb = ','.join(str(int(col[i:i+2], 16)) for i in (1, 3, 5))
last_var = list(re.finditer(r'\n(\s*)--cat-[\w-]+:\s*#[0-9a-fA-F]{6};[^\n]*', s[:s.index('}', s.index(':root'))]))[-1]
s = s[:last_var.end()] + f'\n{last_var.group(1)}--cat-search:{col};' + s[last_var.end():]
catcss = f'''  .cat-search .cat-badge{{color:var(--cat-search);background:rgba({rgb},.10)}}
  .cat-search{{border-left:3px solid var(--cat-search)}}
  .toc-chip.tc-search{{border-left-color:var(--cat-search)}}
  .toc-chip.tc-search:hover{{color:var(--cat-search)}}
  .toc-tip.tc-search .tip-badge{{color:var(--cat-search);background:rgba({rgb},.10)}}
'''

# --- section 02, right after the Dashboard Summary section
m = re.search(r'<div class="section [\w-]+" data-title="Dashboard Summary"', s)
if not m: sys.exit('search: no Dashboard Summary section found')
nxt = re.search(r'\n[ \t]*(?:<!--(?:(?!-->).)*-->\s*)*<div class="section ', s[m.end():], re.S)
anchor = m.end() + nxt.start() + 1 if nxt else s.index('</main>')
w = len(re.search(r'<span class="sec-num">(\d+)</span>', s).group(1))
section = ('  <div class="section cat-search" data-title="Search" data-cat="search">\n'
           '    <div class="sec-head"><span class="sec-num">%0*d</span><span class="sec-title">Search</span><span class="cat-badge">Search</span><span class="chevron">▶</span></div>\n'
           '    <div class="sec-body">\n      %s\n    </div>\n  </div>\n\n') % (w, 2, bodyb)
s = s[:anchor] + section + s[anchor:]
# renumber every section in page order
ctr = iter(range(1, 1000))
s = re.sub(r'<span class="sec-num">(\d+)</span>', lambda x: '<span class="sec-num">%0*d</span>' % (w, next(ctr)), s)
# summary table: shift the hand-numbered rows from 02 on, then add the Search row after row 01
t0 = s.find('data-desc="What each section covers"')
if t0 < 0: sys.exit('search: no "What each section covers" table found')
t1 = s.index('</tbody>', t0)
tbl = re.sub(r'<span class="secnum">(\d+)</span>', lambda x: x.group(0) if int(x.group(1)) < 2 else '<span class="secnum">%0*d</span>' % (w, int(x.group(1)) + 1), s[t0:t1])
row = ('<tr><td><span class="secnum" data-target-title="Search"></span></td><td><strong>Search</strong></td><td class="sec-cat"></td>'
       '<td>Find anything on the page by words, with filters</td><td>Looking for a topic, a term, a number, or something said in the source</td></tr>')
r1 = re.search(r'<tr><td><span class="secnum">0*1</span>.*?</tr>', tbl, re.S)
if r1: tbl = tbl[:r1.end()] + '\n            ' + row + tbl[r1.end():]
else:
    k = tbl.index('<tbody>') + len('<tbody>'); tbl = tbl[:k] + '\n            ' + row + tbl[k:]
s = s[:t0] + tbl + s[t1:]

# --- generic subsections ([SEARCH] / [FILTERS] parts), unless already patched
o1 = "body.querySelectorAll('.callout, .resource, .table-wrap').forEach(el => {\n    let kind, text;\n    if(el.classList.contains('callout')){"
n1 = "body.querySelectorAll('.subsec, .callout, .resource, .table-wrap').forEach(el => {\n    let kind, text;\n    if(el.parentElement.closest('.subsec')) return;\n    if(el.classList.contains('subsec')){\n      kind = el.dataset.tag || 'part';\n      text = (el.dataset.desc || 'Part').trim();\n    } else if(el.classList.contains('callout')){"
if 'subsec, .callout, .resource, .table-wrap' not in s:
    if o1 not in s: sys.exit('search: deriveSubs anchor not found (template changed?)')
    s = s.replace(o1, n1, 1)
tc = re.search(r"const TAG_CH = \{([^}]*)\};", s)
if not tc: sys.exit('search: TAG_CH not found')
inner = tc.group(1)
for k, v in (('search', 'SEARCH'), ('filters', 'FILTERS')):
    if re.search(r'\b' + k + r'\s*:', inner) is None: inner += ", %s:'%s'" % (k, v)
s = s[:tc.start()] + 'const TAG_CH = {' + inner + '};' + s[tc.end():]

# --- toolbar quick search skips the results; glossary skips the section
old = "node.tagName!=='SCRIPT' && node.tagName!=='STYLE'"
if old in s and "node.id!=='xs'" not in s: s = s.replace(old, old + " && node.id!=='xs'", 1)
ex = re.search(r"const EXCLUDE = new Set\(\[([^\]]*)\]\);", s)
if ex and "'Search'" not in ex.group(1):
    s = s[:ex.start()] + "const EXCLUDE = new Set([" + ex.group(1) + ",'Search']);" + s[ex.end():]

# --- CSS + script
i = s.index('</style>'); s = s[:i] + catcss + cssb + s[i:]
i = s.rfind('</body>'); i = i if i >= 0 else len(s); s = s[:i] + jsb + s[i:]
open(p, 'w', encoding='utf-8').write(s)
print('search: added as section 02, colour %s' % col)
