import json, sys, re
page_path, narr_path, snip_path = sys.argv[1:4]
paras = [' '.join(p.split()) for p in re.split(r'\n\s*\n|\n', open(narr_path, encoding='utf8').read()) if p.strip()]
block = open(snip_path, encoding='utf8').read().strip().replace('__PARAGRAPHS_JSON__', json.dumps(paras, ensure_ascii=False).replace('</', '<\\/'))
page = open(page_path, encoding='utf8').read()
B, E = '<!-- AUDIO-OVERVIEW:BEGIN', '<!-- AUDIO-OVERVIEW:END -->'
i = page.find(B)
if i >= 0: j = page.find(E, i) + len(E); page = page[:i] + block + page[j:]
else: k = page.find('</header>'); page = page[:k] + block + '\n' + page[k:]
open(page_path, 'w', encoding='utf8').write(page); print('browser-voice player added,', len(paras), 'paragraphs')
