#!/usr/bin/env python3
"""comments_sections.py PAGE.html COMMENTS.json — add (or refresh) the four comment-dashboard sections of a vibe dashboard:
<post> (the post / model / video), <glance> (counts + participants), <themes> (Claude's synthesis) and <threads> (every
message in ONE table: Topic / From / QTY / QTY-TOT / [extra columns] / Comment / Link, opening sorted by Topic).
Idempotent: a second run replaces everything it added. Run it after filling the template and before the table-fit,
Search and Mind Map patches (re-running it later is fine too: it renumbers every section in page order).
Input: the standard comment JSON (see "Comment & review dashboards" in the vibe-dashboard skill)."""
import sys, re, json, html, collections
page_path, data_path = sys.argv[1], sys.argv[2]
S = open(page_path, encoding='utf-8').read()
D = json.load(open(data_path, encoding='utf-8'))
E = lambda s: html.escape(str(s if s is not None else ''), quote=True)
src, items = D['source'], D['items']
L = {'post': 'The Post', 'glance': 'Discussion at a Glance', 'themes': 'Themes & Takeaways', 'threads': 'Comment Threads',
     'item': 'comment', 'items': 'comments', 'owner_tag': 'OP', 'owner_role': 'post author', 'platform': 'Facebook', **D.get('labels', {})}
TOPICS = D['topics']                                   # [{"name","desc"}], in the order to list them
EXTRA = D.get('extra_columns', [])                      # e.g. ["Stars"], ["Likes"]
OWNER = src.get('author', '')
PAL = ['#38dafa', '#38fa79', '#dafa38', '#fa9938', '#fa3899', '#ea38fa', '#7938fa', '#3879fa']
GREY = '#9aa0aa'
MB, ME = '<!-- COMMENTS-SECTIONS:BEGIN -->', '<div hidden data-cs-end></div>'   # end marker is an element, not a comment, so other patches never insert inside the block

# ---------------------------------------------------------------- checks on the data
ids = {x['id'] for x in items}
assert len(ids) == len(items), 'duplicate ids'
for x in items:
    assert x.get('parent_id') in ids or x['type'] == 'comment', ('reply without parent', x['id'])
    assert x.get('topic') in {t['name'] for t in TOPICS}, ('item has no listed topic', x['id'], x.get('topic'))
by_id = {x['id']: x for x in items}
roots = [x for x in items if x['type'] == 'comment']
tnum = {r['id']: i for i, r in enumerate(roots, 1)}
thread_of = collections.defaultdict(list)
for x in items: thread_of[x['thread_root_id']].append(x)

# ---------------------------------------------------------------- remove a previous run
S = re.sub(r'\n?[ \t]*' + re.escape(MB) + r'.*?' + re.escape(ME) + r'[ \t]*\n?', '\n', S, flags=re.S)
S = re.sub(r'  /\* COMMENTS-CSS:BEGIN \*/.*?/\* COMMENTS-CSS:END \*/\n', '', S, flags=re.S)
S = re.sub(r'/\* COMMENTS-JS:BEGIN \*/.*?/\* COMMENTS-JS:END \*/\n', '', S, flags=re.S)
S = re.sub(r'<tr data-cs-row>.*?</tr>\s*', '', S, flags=re.S)

# ---------------------------------------------------------------- categories (next unused palette colours)
used = {v.lower() for k, v in re.findall(r'--cat-([\w-]+):\s*(#[0-9a-fA-F]{6})', S) if k not in ('post', 'stats', 'takeaways', 'thread')}
free = [c for c in PAL if c not in used]
CATS = [('post', L['post'].upper().replace('THE ', '')[:14] or 'POST'), ('stats', 'STATS'), ('takeaways', 'TAKEAWAYS'), ('thread', 'THREADS')]
if len(free) < 4: sys.exit('comments_sections: not enough unused palette colours for 4 categories')
rgb = lambda h: ','.join(str(int(h[i:i + 2], 16)) for i in (1, 3, 5))
css = '  /* COMMENTS-CSS:BEGIN */\n  :root{' + ''.join(f'--cat-{c}:{free[i]};' for i, (c, _) in enumerate(CATS)) + '}\n'
for i, (c, _) in enumerate(CATS):
    h = free[i]
    css += (f"  .cat-{c} .cat-badge{{color:var(--cat-{c});background:rgba({rgb(h)},.10)}}\n  .cat-{c}{{border-left:3px solid var(--cat-{c})}}\n"
            f"  .toc-chip.tc-{c}{{border-left-color:var(--cat-{c})}}\n  .toc-chip.tc-{c}:hover{{color:var(--cat-{c})}}\n"
            f"  .toc-tip.tc-{c} .tip-badge{{color:var(--cat-{c});background:rgba({rgb(h)},.10)}}\n")
css += ("  .dt{color:#fff;font-weight:700}\n  .nw{white-space:nowrap}\n  .muted-mono{font-family:var(--mono);font-size:11px;color:var(--text-mute)}\n"
        "  .owner-badge{font-family:var(--mono);font-size:10px;color:var(--cat-post);border:1px solid color-mix(in srgb,var(--cat-post) 45%,transparent);border-radius:4px;padding:0 4px;margin-left:6px}\n"
        "  .img-note{font-family:var(--mono);font-size:11px;color:var(--text-mute)}\n  .orig-text{display:block;margin-top:4px;font-size:12.5px;color:var(--text-mute)}\n"
        "  .cs-link{font-family:var(--mono);color:var(--cyan);text-decoration:none;font-size:15px}\n"
        "  .th-start td{border-top:2px solid color-mix(in srgb,var(--cat-thread) 45%,transparent)}\n  /* COMMENTS-CSS:END */\n")
i = S.index('</style>'); S = S[:i] + css + S[i:]

# ---------------------------------------------------------------- helpers
titles = set(re.findall(r'data-title="([^"]+)"', S)) | {'Search', 'Mind Map', L['post'], L['glance'], L['themes'], L['threads']}
titles = sorted({html.unescape(t) for t in titles}, key=len, reverse=True)
def ctext(t):
    """message text -> HTML: escaped, links clickable, newlines -> <br>, section titles defused (no accidental section links)"""
    t = E(t)
    t = re.sub(r'(https?://[^\s<]+)', lambda m: f'<a href="{m.group(1)}" target="_blank" rel="noopener">{m.group(1)}</a>', t)
    for ti in titles:
        if len(ti) > 3: t = t.replace(E(ti), E(ti[0]) + '<wbr>' + E(ti[1:]))
    return t.replace('\n', '<br>')
li = lambda tid, content: f'        <li><span class="tid">{E(tid)}</span>{content}</li>\n'
owner = lambda name: f'<span class="owner-badge">{E(L["owner_tag"])}</span>' if name == OWNER and OWNER else ''
dt = lambda s: f'<strong class="dt">{E(s)}</strong>'
def section(title, cat, badge, body):
    return (f'  <div class="section cat-{cat}" data-title="{E(title)}" data-cat="{cat}">\n'
            f'    <div class="sec-head"><span class="sec-num">00</span><span class="sec-title">{E(title)}</span>'
            f'<span class="cat-badge">{E(badge)}</span><span class="chevron">▶</span></div>\n    <div class="sec-body">\n{body}\n    </div>\n  </div>\n')
n_top, n_all = len(roots), len(items)
people = collections.OrderedDict()
for x in items:
    p = people.setdefault(x['author']['name'], {'c': 0, 'r': 0, 'url': x['author'].get('profile_url'), 'first': x})
    p['c' if x['type'] == 'comment' else 'r'] += 1
    if (x.get('sort_time') or '') < (p['first'].get('sort_time') or ''): p['first'] = x
own_c = sum(1 for x in items if x['author']['name'] == OWNER and x['type'] == 'comment')
own_r = sum(1 for x in items if x['author']['name'] == OWNER and x['type'] == 'reply')
media = sum(1 for x in items if x.get('has_media'))
timed = [x for x in items if x.get('sort_time')]
first = min(timed, key=lambda x: x['sort_time']) if timed else None
last = max(timed, key=lambda x: x['sort_time']) if timed else None

# ---------------------------------------------------------------- 1. the post
res = ''.join(f'      <div class="resource"><span class="r-name">{E(r["name"])}</span><span class="r-note">{r.get("note_html", E(r.get("note", "")))}</span>'
              f'<a href="{E(r["url"])}" target="_blank" rel="noopener">{E(r.get("link_text", "open ↗"))}</a></div>\n' for r in D.get('resources', []))
post_body = (f'      <p>{D["post_intro_html"]}</p>\n' if D.get('post_intro_html') else '') + \
    (f'      <div class="callout"><span class="lbl">{E(D.get("post_label", "Original post"))}</span>{ctext(src.get("text", ""))}</div>\n' if src.get('text') else '') + res

# ---------------------------------------------------------------- 2. at a glance
busiest = sorted(roots, key=lambda r: -len(thread_of[r['id']]))[:5]
busy = ', '.join(f'{E(r["author"]["name"])} ({len(thread_of[r["id"]]) - 1} repl{"y" if len(thread_of[r["id"]]) == 2 else "ies"})' for r in busiest)
rows = [('Top-level ' + L['items'], n_top), ('Replies', n_all - n_top), ('Total', n_all)]
if src.get('shown_count') is not None:
    rows.append((f"{L['platform']}'s shown count", f'{src["shown_count"]}' + (' (all captured)' if src['shown_count'] == n_all else f' ({n_all} captured)')))
rows += [('Participants', len(people)), (f'Messages by the {L["owner_role"]}', f'{own_c} top-level, {own_r} replies')]
if media: rows.append(('With a photo, GIF or video', media))
if first: rows.append(('Date range (approx)' if D.get('approx_times') else 'Date range', f'{dt(first["date_display"])} → {dt(last["date_display"])}'))
rows += [(k, v) for k, v in D.get('stats_rows', [])]
stats_tbl = ''.join(f'<tr><td><strong>{E(k)}</strong></td><td>{v if isinstance(v, str) and "<" in v else E(v)}</td></tr>' for k, v in rows)
prow = sorted(people.items(), key=lambda kv: (-(kv[1]['c'] + kv[1]['r']), kv[0]))
part_tbl = ''.join(
    f'<tr><td><strong>' + (f'<a href="{E(p["url"])}" target="_blank" rel="noopener">{E(n)}</a>' if p['url'] else E(n)) + f'</strong>{owner(n)}</td>'
    f'<td>{p["c"]}</td><td>{p["r"]}</td><td>{p["c"] + p["r"]}</td><td>{dt(p["first"].get("date_short") or p["first"].get("date_display", ""))}</td></tr>' for n, p in prow)
glance_body = (f'      <p>{D["glance_intro_html"]}</p>\n' if D.get('glance_intro_html') else '') + \
    f'      <ul data-desc="Busiest threads and who answered">\n' + \
    li('Busiest', f'The longest threads were started by {busy}.') + \
    li(L['owner_role'].title(), f'{E(OWNER)} wrote {own_c} top-level {L["item"] if own_c == 1 else L["items"]} and {own_r} repl{"y" if own_r == 1 else "ies"}.') + \
    ''.join(li(b['tid'], b['html']) for b in D.get('glance_bullets', [])) + '      </ul>\n' + \
    f'      <div class="table-wrap" data-desc="Discussion stats"><table><thead><tr><th>Measure</th><th>Value</th></tr></thead><tbody>{stats_tbl}</tbody></table></div>\n' + \
    f'      <div class="table-wrap" data-desc="Participants"><table><thead><tr><th>Name</th><th>Top-level</th><th>Replies</th><th>Total</th><th>First seen</th></tr></thead><tbody>{part_tbl}</tbody></table></div>'

# ---------------------------------------------------------------- 3. themes (Claude's synthesis, written per dashboard)
themes_body = (f'      <p>This section is Claude\'s own synthesis of the {n_all} {L["items"]}, not something posted on {E(L["platform"])}. '
               'Each callout names a recurring position and who raised it; follow the names into the threads table for the full exchanges.</p>\n'
               + ''.join(f'      <div class="callout"><span class="lbl">{E(t["label"])}</span>{t["html"]}</div>\n' for t in D['themes']))

# ---------------------------------------------------------------- 4. the threads table
tcol, k = {}, 0
for t in TOPICS:
    if t['name'] == 'Chatter': tcol[t['name']] = GREY
    else: tcol[t['name']] = PAL[k % len(PAL)]; k += 1
tag = lambda name: f'<span class="tid" style="--tc:{tcol[name]}">{E(name)}</span>'
trs = []
for x in items:
    par = by_id.get(x.get('parent_id'))
    th = thread_of[x['thread_root_id']]
    qty = sum(1 for y in th if y['topic'] == x['topic'])
    frm = (f'<strong>{E(x["author"]["name"])}</strong>{owner(x["author"]["name"])}'
           f'<br><span class="muted-mono nw">→ {E(par["author"]["name"]) if par else "top-level"}</span>'
           f'<br><span class="muted-mono nw">T{tnum[x["thread_root_id"]]} · #{x["order"]}' + (f' · {E(x["relative_time"])}' if x.get('relative_time') else '') + '</span>'
           + (f'<br><strong class="dt nw">{E(x["date_short"] or x["date_display"])}</strong>' if (x.get('date_short') or x.get('date_display')) else ''))
    body = ('↳ ' * x['depth']) + (ctext(x['text']) if x.get('text') else '')
    if x.get('text_original'):
        body += f'<span class="orig-text">[{E(x.get("language", "original"))}] {ctext(x["text_original"])}</span>'
    if x.get('has_media'): body += ('<br>' if x.get('text') else '') + f'<span class="img-note">[photo, GIF or video attached: open on {E(L["platform"])} to see it]</span>'
    if not x.get('text') and not x.get('has_media'): body += '<span class="img-note">[no text]</span>'
    ex = ''.join(f'<td>{E((x.get("extra") or {}).get(c, ""))}</td>' for c in EXTRA)
    cls = ' class="th-start"' if x['type'] == 'comment' and x is not items[0] else ''
    link = f'<a class="cs-link" href="{E(x["permalink"])}" target="_blank" rel="noopener" title="Open on {E(L["platform"])}">↗</a>' if x.get('permalink') else '—'
    trs.append(f'<tr{cls}><td>{tag(x["topic"])}</td><td>{frm}</td><td>{qty}</td><td>{len(th)}</td>{ex}<td>{body}</td><td>{link}</td></tr>')
tc = collections.Counter(x['topic'] for x in items)
heads = '<th>Topic</th><th>From</th><th>QTY</th><th>QTY-TOT</th>' + ''.join(f'<th>{E(c)}</th>' for c in EXTRA) + '<th>Comment</th><th>Link</th>'
threads_body = (
    f'      <p>All {len(roots)} threads in one table: {n_all} {L["items"]} in the order {E(L["platform"])} lists them. '
    'The <strong>Topic</strong> tag on each row names what that message is about, one color per topic. The table opens sorted by Topic; '
    'click the Topic header twice to get back to thread order (a thin line then marks where each new thread starts). '
    '<strong>QTY</strong> is how many messages in that row\'s thread have the same topic, so it matches the rows you see together under each topic; '
    '<strong>QTY-TOT</strong> is how many messages the whole thread has, across all topics. Sort by QTY-TOT to bring the biggest threads together. '
    f'The From column shows who wrote the message, who it answers (or top-level for a new thread), its thread number (T8 = thread 8), position'
    + (' and age' if any(x.get('relative_time') for x in items) else '') + ', and its ' + ('approximate ' if D.get('approx_times') else '') + 'time; '
    f'↳ marks reply depth, and ↗ opens the exact {L["item"]} on {E(L["platform"])}.</p>\n'
    '      <ul data-desc="Topics and how many messages each has">\n'
    + ''.join(f'        <li><span class="tid" style="--tc:{tcol[t["name"]]}">{E(t["name"])}</span>{tc[t["name"]]} message{"" if tc[t["name"]] == 1 else "s"}. {E(t["desc"])}</li>\n' for t in TOPICS)
    + '      </ul>\n'
    f'      <div class="table-wrap" data-desc="All {n_all} {L["items"]} and replies" data-mm-group="0" data-mm-group-label="{{v}}"><table><thead><tr>{heads}</tr></thead><tbody>{"".join(trs)}</tbody></table></div>')

# ---------------------------------------------------------------- insert sections after the Dashboard Summary
secs = [(L['post'], 'post', CATS[0][1], post_body), (L['glance'], 'stats', 'STATS', glance_body),
        (L['themes'], 'takeaways', 'TAKEAWAYS', themes_body), (L['threads'], 'thread', 'THREADS', threads_body)]
block = MB + '\n' + ''.join(section(*s) for s in secs) + '  ' + ME + '\n'
m = re.search(r'<div class="section [\w-]+" data-title="Search"', S) or re.search(r'<div class="section [\w-]+" data-title="Dashboard Summary"', S)
if not m: sys.exit('comments_sections: no Dashboard Summary section')   # after Search when it is there (re-runs), else after the summary
# end of the summary section = start of the next section (or a comment just before it)
nxt = re.search(r'\n[ \t]*(?:<!--(?:(?!-->).)*-->\s*)*<div class="section ', S[m.end():], re.S)
at = m.end() + (nxt.start() + 1 if nxt else 0)
S = S[:at] + block + '\n' + S[at:]

# ---------------------------------------------------------------- summary rows (numbers filled at runtime), before the first pre-wired row
FOCUS = D.get('summary_focus', {})
srows = ''.join(
    f'<tr data-cs-row><td><span class="secnum" data-target-title="{E(t)}"></span></td><td><strong>{E(t)}</strong></td><td class="sec-cat"></td>'
    f'<td>{E(FOCUS.get(key, [f])[0])}</td><td>{E(FOCUS.get(key, [f, w])[1])}</td></tr>\n            '
    for key, t, f, w in [
        ('post', L['post'], f'The original {L.get("post_noun", "post")}, its author, and its links', 'You want to see exactly what was posted'),
        ('glance', L['glance'], 'Counts, busiest threads, and every participant', 'Sizing up the discussion or finding a person'),
        ('themes', L['themes'], "Claude's synthesis of the main positions and open questions", 'You want the gist without reading every message'),
        ('threads', L['threads'], f'All {n_all} messages in one table, tagged by topic, with links', 'Reading the exchanges in full, or one topic at a time')])
anchor = None
j = S.find('<tr><td><span class="secnum" data-target-title="Search">')
if j >= 0: anchor = S.index('</tr>', j) + len('</tr>')     # right after the Search row on re-runs
for t in ([] if anchor else ['Mind Map', 'Glossary', 'References', 'Source Document (Verbatim)']):
    j = S.find(f'<tr><td><span class="secnum" data-target-title="{t}">')
    if j >= 0 and (anchor is None or j < anchor): anchor = j
if anchor is None:
    t = S.find('data-desc="What each section covers"'); anchor = S.find('</tbody>', t)
S = S[:anchor] + ('\n            ' if S[anchor-5:anchor] == '</tr>' else '') + srows.rstrip() + ('' if S[anchor-5:anchor] == '</tr>' else '\n            ') + S[anchor:]

# ---------------------------------------------------------------- JS: open the threads table sorted by Topic
js = ('/* COMMENTS-JS:BEGIN */\n(function(){\n  const sec = document.querySelector(\'.section[data-cat="thread"]\');\n'
      '  const table = sec && sec.querySelector(\'.table-wrap table\'); if(!table || !table.tHead) return;\n'
      '  const th = [...table.tHead.rows[0].cells].find(c => { const t = c.childNodes[0]; return t && t.nodeType === 3 && t.nodeValue.trim().toUpperCase() === \'TOPIC\'; });\n'
      '  if(th) th.click();\n})();\n/* COMMENTS-JS:END */\n')
a = 'buildFloatingHeaders();\n'
if a not in S: sys.exit('comments_sections: buildFloatingHeaders(); not found')
i = S.index(a) + len(a); S = S[:i] + js + S[i:]

# ---------------------------------------------------------------- Source Document text, when the template placeholder is still there
if '{{VERBATIM_TEXT}}' in S:
    v = [f'{OWNER} · {src.get("date_display", "")}', src.get('text', ''), '']
    for r in roots:
        v.append(f'— Thread {tnum[r["id"]]} —')
        for x in thread_of[r['id']]:
            ind = '    ' * x['depth'] + '→ ' * x['depth']
            txt = (x.get('text') or '').replace('\n', '\n' + ' ' * len(ind)) or '[media only]'
            v.append(f'{ind}{x["author"]["name"]} · {x.get("date_display", "")}: {txt}')
        v.append('')
    vt = '\n'.join(v).replace('\\', '\\\\').replace('`', '\\`').replace('${', '\\${').replace('</', '<\\/')
    S = S.replace('{{VERBATIM_TEXT}}', vt, 1)
    S = S.replace("document.getElementById('verbatim').textContent = VERBATIM.replace(/\\n/g, '\\n\\n');", "document.getElementById('verbatim').textContent = VERBATIM;")

# ---------------------------------------------------------------- renumber every section in page order
c = iter(range(1, 1000))
S = re.sub(r'<span class="sec-num">\d+</span>', lambda _: '<span class="sec-num">%02d</span>' % next(c), S)
open(page_path, 'w', encoding='utf-8').write(S)
print(f'comments sections: {n_all} {L["items"]} in {len(roots)} threads, {len(TOPICS)} topics, colours {free[:4]}')
